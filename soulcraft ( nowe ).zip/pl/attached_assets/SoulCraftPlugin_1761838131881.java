// SoulCraftPlugin.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public class SoulCraftPlugin extends JavaPlugin {
    private ScoreboardManager scoreboardManager;
    private EconomyManager economyManager;
    private ClanManager clanManager;
    private SoulManager soulManager;
    private ZombieManager zombieManager;
    private UpgradeGUI upgradeGUI;
    private RankManager rankManager;
    private KitManager kitManager;
    private SpawnManager spawnManager;
    private AntiLogoutManager antiLogoutManager;
    private CommandHandler commandHandler;
    private MarketManager marketManager;
    private ShopManager shopManager;
    private HomeManager homeManager;
    private BossManager bossManager;
    private NPCManager npcManager;
    private WarpManager warpManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Managers (nie rejestrujemy eventów w konstruktorach)
        scoreboardManager = new ScoreboardManager(this);
        economyManager = new EconomyManager(this);
        clanManager = new ClanManager(this);
        soulManager = new SoulManager(this);
        zombieManager = new ZombieManager(this);
        upgradeGUI = new UpgradeGUI(this);
        rankManager = new RankManager(this);
        kitManager = new KitManager(this, rankManager);
        spawnManager = new SpawnManager(this, rankManager);
        antiLogoutManager = new AntiLogoutManager(this);
        marketManager = new MarketManager(this);
        shopManager = new ShopManager(this);
        homeManager = new HomeManager(this, rankManager);
        bossManager = new BossManager(this);
        npcManager = new NPCManager(this);
        warpManager = new WarpManager(this, rankManager);

        commandHandler = new CommandHandler(this, rankManager, marketManager, shopManager, homeManager, bossManager,
                npcManager, warpManager);

        // Rejestracja listenerów centralnie, tylko raz
        Bukkit.getPluginManager().registerEvents(soulManager, this);
        Bukkit.getPluginManager().registerEvents(zombieManager, this);
        Bukkit.getPluginManager().registerEvents(upgradeGUI, this);
        Bukkit.getPluginManager().registerEvents(kitManager, this);
        Bukkit.getPluginManager().registerEvents(antiLogoutManager, this);
        Bukkit.getPluginManager().registerEvents(marketManager, this);
        Bukkit.getPluginManager().registerEvents(shopManager, this);
        Bukkit.getPluginManager().registerEvents(bossManager, this);
        Bukkit.getPluginManager().registerEvents(npcManager, this);
        Bukkit.getPluginManager().registerEvents(warpManager, this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(this, rankManager), this);

        // Komendy
        Objects.requireNonNull(getCommand("dodajhajs")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("usunhajs")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("klan")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("zombie")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("ulepsz")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("jakgrac")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("help")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("event")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dajrange")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("spawn")).setExecutor(spawnManager);
        Objects.requireNonNull(getCommand("ustawspawn")).setExecutor(spawnManager);
        Objects.requireNonNull(getCommand("kit")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dajkrysztal")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("rynek")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("wystaw")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("sklep")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("sethome")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("usunhome")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("home")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("ustawboos")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("startboos")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("spawnnpc")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("rebirth")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dodajczarnamateria")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("warp")).setExecutor(commandHandler);

        clanManager.loadClans();

        // Inicjalizacja max health dla online graczy
        Bukkit.getOnlinePlayers().forEach(player -> {
            int level = getConfig().getInt("players." + player.getUniqueId() + ".healthLevel", 0);
            player.setMaxHealth(20 + level * 2);
            rankManager.updatePermissions(player);
        });
    }

    @Override
    public void onDisable() {
        saveConfig();
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public SoulManager getSoulManager() {
        return soulManager;
    }

    public ZombieManager getZombieManager() {
        return zombieManager;
    }

    public UpgradeGUI getUpgradeGUI() {
        return upgradeGUI;
    }

    public RankManager getRankManager() {
        return rankManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public SpawnManager getSpawnManager() {
        return spawnManager;
    }

    public AntiLogoutManager getAntiLogoutManager() {
        return antiLogoutManager;
    }

    public CommandHandler getCommandHandler() {
        return commandHandler;
    }

    public MarketManager getMarketManager() {
        return marketManager;
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public BossManager getBossManager() {
        return bossManager;
    }

    public NPCManager getNPCManager() {
        return npcManager;
    }

    public WarpManager getWarpManager() {
        return warpManager;
    }
}
