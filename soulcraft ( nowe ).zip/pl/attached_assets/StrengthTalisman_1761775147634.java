package com.soulcraft.items.consumables;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class StrengthTalisman extends CustomItem {
    public StrengthTalisman(SoulCraftPlugin plugin) {
        super(
            "strength_talisman",
            "§c§lTalizman Mocy",
            Material.FIRE_CHARGE,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §cMagiczny        §7│",
                "§7│ §cTalizman        §7│",
                "§7│ §fEfekty (180s):  §7│",
                "§7│ §cSiła III       §7│",
                "§7│ §4+50% Damage    §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §cOgromna moc",
                "§d⚔ Model: 4004"
            ),
            4004
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 3600, 2));
            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 3600, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 3600, 0));
            
            player.getWorld().spawnParticle(Particle.FLAME, player.getLocation(), 50, 1, 1, 1);
            player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 0.8f);
            player.sendMessage("§c§l✦ Moc talizman przepełnia cię!");
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
