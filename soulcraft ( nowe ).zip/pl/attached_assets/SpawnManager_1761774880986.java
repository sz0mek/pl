// SpawnManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SpawnManager implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private Location spawnLocation;
    private final Map<UUID, TeleportData> teleportingPlayers = new HashMap<>();

    public SpawnManager(SoulCraftPlugin plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
        loadSpawnLocation();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTa komenda jest tylko dla graczy!");
            return true;
        }

        if (command.getName().equalsIgnoreCase("ustawspawn")) {
            if (!player.hasPermission("soulcraft.op")) {
                player.sendMessage("§cNie masz permisji!");
                return true;
            }
            spawnLocation = player.getLocation();
            plugin.getConfig().set("spawn.world", spawnLocation.getWorld().getName());
            plugin.getConfig().set("spawn.x", spawnLocation.getX());
            plugin.getConfig().set("spawn.y", spawnLocation.getY());
            plugin.getConfig().set("spawn.z", spawnLocation.getZ());
            plugin.getConfig().set("spawn.yaw", spawnLocation.getYaw());
            plugin.getConfig().set("spawn.pitch", spawnLocation.getPitch());
            plugin.saveConfig();
            player.sendMessage("§aSpawn ustawiony na: " + spawnLocation.getBlockX() + ", " + spawnLocation.getBlockY()
                    + ", " + spawnLocation.getBlockZ());
            return true;
        } else if (command.getName().equalsIgnoreCase("spawn")) {
            if (spawnLocation == null) {
                player.sendMessage("§cSpawn nie został jeszcze ustawiony!");
                return true;
            }
            startTeleport(player);
            return true;
        }
        return false;
    }

    private void loadSpawnLocation() {
        if (plugin.getConfig().contains("spawn.world")) {
            World world = Bukkit.getWorld(plugin.getConfig().getString("spawn.world"));
            double x = plugin.getConfig().getDouble("spawn.x");
            double y = plugin.getConfig().getDouble("spawn.y");
            double z = plugin.getConfig().getDouble("spawn.z");
            float yaw = (float) plugin.getConfig().getDouble("spawn.yaw");
            float pitch = (float) plugin.getConfig().getDouble("spawn.pitch");
            spawnLocation = new Location(world, x, y, z, yaw, pitch);
        }
    }

    private void startTeleport(Player player) {
        if (teleportingPlayers.containsKey(player.getUniqueId()))
            return;

        int delayTicks;
        String rank = rankManager.getRank(player);
        switch (rank) {
            case "soulgod":
                delayTicks = 5 * 20;
                break;
            case "svip":
                delayTicks = 10 * 20;
                break;
            case "vip":
                delayTicks = 15 * 20;
                break;
            default:
                delayTicks = 20 * 20;
                break; // gracz
        }

        TeleportData data = new TeleportData(delayTicks, player.getLocation());
        teleportingPlayers.put(player.getUniqueId(), data);

        new BukkitRunnable() {
            int timeLeft = delayTicks / 20;

            @Override
            public void run() {
                if (!teleportingPlayers.containsKey(player.getUniqueId())) {
                    this.cancel();
                    return;
                }

                if (!player.getLocation().equals(data.initialLocation)) {
                    player.sendMessage("§cRuszanie się anuluje teleportację!");
                    teleportingPlayers.remove(player.getUniqueId());
                    this.cancel();
                    return;
                }

                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                        TextComponent.fromLegacyText(ChatColor.RED + "Teleportacja za " + timeLeft + " sekund..."));
                timeLeft--;

                if (timeLeft < 0) {
                    player.teleport(spawnLocation);
                    player.sendMessage("§aZostałeś teleportowany do spawnu!");
                    teleportingPlayers.remove(player.getUniqueId());
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void cancelTeleport(Player player) {
        teleportingPlayers.remove(player.getUniqueId());
    }

    private static class TeleportData {
        int delayTicks;
        Location initialLocation;

        TeleportData(int delayTicks, Location initialLocation) {
            this.delayTicks = delayTicks;
            this.initialLocation = initialLocation;
        }
    }
}
