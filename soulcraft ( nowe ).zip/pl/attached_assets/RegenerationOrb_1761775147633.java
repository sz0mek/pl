package com.soulcraft.items.consumables;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class RegenerationOrb extends CustomItem {
    public RegenerationOrb(SoulCraftPlugin plugin) {
        super(
            "regeneration_orb",
            "§a§lKula Regeneracji",
            Material.SLIME_BALL,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §aLecznicza Kula  §7│",
                "§7│ §fEfekt:           §7│",
                "§7│ §aPełne HP        §7│",
                "§7│ §2Absorpcja +10   §7│",
                "§7│ §eNatychmiastowe  §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §aPełne uzdrowienie",
                "§d⚔ Model: 4002"
            ),
            4002
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setSaturation(20);
            
            player.getWorld().spawnParticle(Particle.HEART, player.getLocation(), 20, 1, 1, 1);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
            player.sendMessage("§a§l✦ Pełne uzdrowienie!");
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
