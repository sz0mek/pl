package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class CriticalStrike extends Ability {
    private final SoulCraftPlugin plugin;
    
    public CriticalStrike(SoulCraftPlugin plugin) {
        super("critical_strike", "§c§lCios Krytyczny", "§7Szansa 25% na 2x obrażeń", 0, "svip", 12000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        // Passive ability - increases damage in combat listener
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
