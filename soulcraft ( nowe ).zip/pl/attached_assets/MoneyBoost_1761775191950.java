package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class MoneyBoost extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;
    private final int bonusSouls = 50;

    public MoneyBoost(SoulCraftPlugin plugin) {
        super(
            "moneyboost",
            "§6§lBoost Dusz",
            "§7Dodatkowe dusze za zabijanie mobów"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        EntityDeathEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onMobKill(EntityDeathEvent event) {
        if (event.getEntity().getKiller() instanceof Player) {
            Player killer = (Player) event.getEntity().getKiller();
            if (canUse(killer)) {
                plugin.getSoulManager().addSouls(killer.getUniqueId().toString(), bonusSouls);
                killer.sendMessage(String.format("§6§l+ %d dusz §7(Money Boost)", bonusSouls));
            }
        }
    }
}
