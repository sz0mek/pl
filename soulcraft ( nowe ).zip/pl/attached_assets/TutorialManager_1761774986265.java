package com.soulcraft.tutorial;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;

public class TutorialManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Integer> tutorialProgress = new HashMap<>();
    private final List<TutorialStep> steps = new ArrayList<>();
    
    public TutorialManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        initializeTutorial();
    }
    
    private void initializeTutorial() {
        steps.add(new TutorialStep("Witaj w SoulCraft!", "§7Naciśnij SHIFT aby kontynuować", 500));
        steps.add(new TutorialStep("§6Dusze", "§7Zbieraj dusze zabijając moby! Wpisz /help", 1000));
        steps.add(new TutorialStep("§eMisje", "§7Ukończ misje aby zdobyć nagrody! /missions", 1500));
        steps.add(new TutorialStep("§bCustom Itemy", "§7Znajdź epické itemy z bossów!", 2000));
        steps.add(new TutorialStep("§5Zdolności", "§7Odblokuj abilities za dusze! /abilities", 2500));
        steps.add(new TutorialStep("§2Klany", "§7Dołącz do klanu: /klan", 1000));
        steps.add(new TutorialStep("§4Dungeons", "§7Eksploruj dungeons: /dungeon", 1500));
        steps.add(new TutorialStep("§dPowodzenia!", "§7Tutorial ukończony! Otrzymujesz 1000 dusz!", 3000));
    }
    
    public void startTutorial(Player player) {
        tutorialProgress.put(player.getUniqueId(), 0);
        showStep(player, 0);
    }
    
    public void nextStep(Player player) {
        int current = tutorialProgress.getOrDefault(player.getUniqueId(), 0);
        if (current >= steps.size() - 1) {
            completeTutorial(player);
            return;
        }
        
        tutorialProgress.put(player.getUniqueId(), current + 1);
        showStep(player, current + 1);
    }
    
    private void showStep(Player player, int stepIndex) {
        if (stepIndex >= steps.size()) return;
        TutorialStep step = steps.get(stepIndex);
        player.sendTitle(step.title, step.subtitle, 20, step.duration / 50, 20);
    }
    
    private void completeTutorial(Player player) {
        tutorialProgress.remove(player.getUniqueId());
        player.sendMessage("§a§l✔ Tutorial ukończony!");
        plugin.getSoulManager().addSouls(player.getUniqueId().toString(), 1000);
    }
    
    record TutorialStep(String title, String subtitle, int duration) {}
}
