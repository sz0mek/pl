package com.soulcraft.items.weapons;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class PhantomBow extends CustomItem {
    private final SoulCraftPlugin plugin;

    public PhantomBow(SoulCraftPlugin plugin) {
        super(
            "phantom_bow",
            "§b§lŁuk Widma",
            Material.BOW,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §bDuchowy Łuk     §7│",
                "§7│ §fStrzały:         §7│",
                "§7│ §bPrzenikają przez§7│",
                "§7│ §bwiele celów      §7│",
                "§7│ §a+30% obrażeń    §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §bWidmowe Strzały",
                "§d⚔ Model: 1004"
            ),
            1004
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Phantom arrows are handled by arrow hit events
    }
}
