package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class HealOnHit extends Ability {
    private final SoulCraftPlugin plugin;
    
    public HealOnHit(SoulCraftPlugin plugin) {
        super("heal_on_hit", "§a§lŻycie przy Trafieniu", "§7Odzyskuj 2 HP przy każdym trafieniu", 0, "vip", 5000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        double currentHealth = player.getHealth();
        double maxHealth = player.getMaxHealth();
        player.setHealth(Math.min(currentHealth + 2.0, maxHealth));
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
