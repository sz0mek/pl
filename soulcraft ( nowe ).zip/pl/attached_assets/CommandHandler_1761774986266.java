package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CommandHandler implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private final MarketManager marketManager;
    private final ShopManager shopManager;
    private final HomeManager homeManager;
    private final BossManager bossManager;
    private final NPCManager npcManager;
    private final WarpManager warpManager;

    public CommandHandler(SoulCraftPlugin plugin, RankManager rankManager, MarketManager marketManager,
            ShopManager shopManager, HomeManager homeManager, BossManager bossManager,
            NPCManager npcManager, WarpManager warpManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
        this.marketManager = marketManager;
        this.shopManager = shopManager;
        this.homeManager = homeManager;
        this.bossManager = bossManager;
        this.npcManager = npcManager;
        this.warpManager = warpManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmdName = command.getName().toLowerCase();

        // NOWA KOMENDA WARP
        if (cmdName.equals("warp")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            warpManager.openMainWarpGUI(player);
            return true;
        }

        // OP-only commands
        if (cmdName.equals("dodajhajs") || cmdName.equals("usunhajs") || cmdName.equals("zombie")
                || cmdName.equals("event") || cmdName.equals("dajrange") || cmdName.equals("dajkrysztal")
                || cmdName.equals("ustawboos") || cmdName.equals("startboos") || cmdName.equals("spawnnpc")
                || cmdName.equals("dodajczarnamateria")) {

            if (!sender.hasPermission("soulcraft.op"))
                return false;
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy z permisją OP!");
                return true;
            }
            Player player = (Player) sender;

            if (cmdName.equals("dodajhajs") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                if (target != null) {
                    try {
                        double amount = Double.parseDouble(args[1]);
                        plugin.getEconomyManager().addBalance(target.getUniqueId().toString(), amount);
                        sender.sendMessage("§aDodano " + amount + " hajsu dla " + args[0]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cKwota musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cGracz nie jest online!");
                }
                return true;
            }

            if (cmdName.equals("usunhajs") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                if (target != null) {
                    try {
                        double amount = Double.parseDouble(args[1]);
                        plugin.getEconomyManager().removeBalance(target.getUniqueId().toString(), amount);
                        sender.sendMessage("§aUsunięto " + amount + " hajsu dla " + args[0]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cKwota musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cGracz nie jest online!");
                }
                return true;
            }

            if (cmdName.equals("zombie")) {
                plugin.getZombieManager().spawnSpecialZombie(player.getLocation());
                player.sendMessage("§aPrzywołano specjalnego zombie!");
                return true;
            }

            if (cmdName.equals("event")) {
                World world = player.getWorld();
                int x = (int) (Math.random() * 2000 - 1000);
                int z = (int) (Math.random() * 2000 - 1000);
                Location loc = world.getHighestBlockAt(x, z).getLocation().add(0, 1, 0);
                world.getBlockAt(loc).setType(Material.BEDROCK);
                plugin.getZombieManager().spawnZombiesAround(loc);
                player.sendMessage("§5Wymuszono event: Kryształ dusz i zombie na " + loc.getBlockX() + ", "
                        + loc.getBlockZ() + "!");
                return true;
            }

            if (cmdName.equals("dajrange") && args.length >= 2) {
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§cGracz nie jest online!");
                    return true;
                }
                String rank = args[1].toLowerCase();
                long duration = 0;
                if (args.length == 3) {
                    String time = args[2].toLowerCase();
                    try {
                        if (time.endsWith("m"))
                            duration = Long.parseLong(time.replace("m", "")) * 60;
                        else if (time.endsWith("h"))
                            duration = Long.parseLong(time.replace("h", "")) * 60 * 60;
                        else if (time.endsWith("d"))
                            duration = Long.parseLong(time.replace("d", "")) * 60 * 60 * 24;
                        else if (time.equals("na zawsze"))
                            duration = -1;
                    } catch (NumberFormatException e) {
                        player.sendMessage("§cNieprawidłowy czas!");
                        return true;
                    }
                }
                if (rankManager.isValidRank(rank)) {
                    rankManager.setRank(target, rank, duration);
                    player.sendMessage("§aNadano rangę " + rank + " graczowi " + target.getName()
                            + (duration > 0 ? " na " + (duration / 60) + " minut" : ""));
                } else {
                    player.sendMessage("§cNieprawidłowa ranga!");
                }
                return true;
            }

            if (cmdName.equals("dajkrysztal") && args.length == 3) {
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§cGracz nie jest online!");
                    return true;
                }
                int level;
                int amount;
                try {
                    level = Integer.parseInt(args[1]);
                    amount = Integer.parseInt(args[2]);
                    if (level < 1 || level > 5 || amount < 1) {
                        player.sendMessage("§cPoziom musi być od 1 do 5, a ilość większa od 0!");
                        return true;
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("§cPoziom i ilość muszą być liczbami!");
                    return true;
                }
                ItemStack crystal = createSoulCrystal(level);
                crystal.setAmount(amount);
                target.getInventory().addItem(crystal);
                player.sendMessage(
                        "§aDano " + amount + " kryształów dusz (lvl " + level + ") graczowi " + target.getName());
                return true;
            }

            if (cmdName.equals("ustawboos")) {
                bossManager.setBossSpawn(player);
                player.sendMessage("§aUstawiono spawn bossa!");
                return true;
            }

            if (cmdName.equals("startboos")) {
                bossManager.spawnBoss(player);
                player.sendMessage("§aRozpoczęto bossa!");
                return true;
            }

            if (cmdName.equals("spawnnpc")) {
                int type = 1; // default
                if (args.length > 0) {
                    try {
                        type = Integer.parseInt(args[0]);
                    } catch (NumberFormatException e) {
                        player.sendMessage("§cTyp musi być liczbą (1 lub 2)!");
                        return true;
                    }
                }
                npcManager.spawnNPC(player, type);
                return true;
            }

            if (cmdName.equals("dodajczarnamateria") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                String targetUUID = null;
                if (target != null) {
                    targetUUID = target.getUniqueId().toString();
                } else {
                    // Try to find offline player UUID by name
                    for (String uuid : plugin.getConfig().getConfigurationSection("players") != null
                            ? plugin.getConfig().getConfigurationSection("players").getKeys(false)
                            : new java.util.HashSet<String>()) {
                        if (args[0].equals(plugin.getConfig().getString("players." + uuid + ".name"))) {
                            targetUUID = uuid;
                            break;
                        }
                    }
                }

                if (targetUUID != null) {
                    try {
                        int amount = Integer.parseInt(args[1]);
                        plugin.getEconomyManager().addBlackMatter(targetUUID, amount);
                        sender.sendMessage("§aDodano " + amount + " czarnej materii dla " + args[0]);
                        if (target != null) {
                            target.sendMessage("§aOtrzymałeś " + amount + " czarnej materii!");
                        }
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cIlość musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cNie znaleziono gracza!");
                }
                return true;
            }

            return true;
        }

        // Rebirth command
        if (cmdName.equals("rebirth")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            String uuid = player.getUniqueId().toString();
            int healthLevel = plugin.getConfig().getInt("players." + uuid + ".healthLevel", 0);

            if (healthLevel == 5) {
                plugin.getConfig().set("players." + uuid + ".healthLevel", 0);
                plugin.getEconomyManager().addBlackMatter(uuid, 20);
                plugin.saveConfig();

                player.setMaxHealth(20);
                player.setHealth(20);
                player.sendMessage(
                        "§aPrzeszedłeś rebirth! Straciłeś ulepszone serca, ale zdobyłeś 20 czarnej materii.");
            } else {
                player.sendMessage("§cMusisz mieć maksymalne ulepszenie serc (poziom 5)!");
            }
            return true;
        }

        // Clan commands
        if (cmdName.equals("klan")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length == 0)
                return false;
            switch (args[0].toLowerCase()) {
                case "stworz":
                    if (args.length == 2) {
                        if (plugin.getClanManager().isInClan(player.getName())) {
                            player.sendMessage("§cJuż jesteś w klanie! Użyj /klan opusc aby go opuścić.");
                            return true;
                        }
                        plugin.getClanManager().createClan(player.getName(), args[1]);
                        player.sendMessage("§aStworzono klan " + args[1]);
                    }
                    break;
                case "dodaj":
                    if (args.length == 2) {
                        if (!plugin.getClanManager().isInClan(player.getName())) {
                            player.sendMessage("§cNie jesteś w żadnym klanie!");
                            return true;
                        }
                        plugin.getClanManager().invitePlayer(player.getName(), args[1]);
                    }
                    break;
                case "przyjmij":
                    plugin.getClanManager().acceptInvite(player.getName());
                    break;
                case "opusc":
                    plugin.getClanManager().leaveClan(player.getName());
                    break;
                default:
                    player.sendMessage("§cUżycie: /klan [stworz|dodaj|przyjmij|opusc] [argumenty]");
                    break;
            }
            return true;
        }

        // Market
        if (cmdName.equals("rynek")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            marketManager.openMarketGUI(player);
            return true;
        }

        if (cmdName.equals("wystaw")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /wystaw <cena>");
                return true;
            }
            try {
                double price = Double.parseDouble(args[0]);
                if (price <= 0) {
                    player.sendMessage("§cCena musi być większa od 0!");
                    return true;
                }
                ItemStack item = player.getInventory().getItemInMainHand();
                if (item == null || item.getType() == Material.AIR) {
                    player.sendMessage("§cMusisz trzymać przedmiot w ręce!");
                    return true;
                }
                ItemStack itemToSell = item.clone();
                itemToSell.setAmount(1);
                marketManager.addItemToMarket(player, itemToSell, price);
                if (item.getAmount() > 1) {
                    item.setAmount(item.getAmount() - 1);
                } else {
                    player.getInventory().setItemInMainHand(null);
                }
                player.sendMessage("§aWystawiono przedmiot na rynek za " + price + " hajsu!");
            } catch (NumberFormatException e) {
                player.sendMessage("§cCena musi być liczbą!");
            }
            return true;
        }

        // Shop
        if (cmdName.equals("sklep")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            shopManager.openShopGUI(player);
            return true;
        }

        // Home
        if (cmdName.equals("sethome")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /sethome <nazwa>");
                return true;
            }
            homeManager.setHome(player, args[0]);
            return true;
        }

        if (cmdName.equals("usunhome")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /usunhome <nazwa>");
                return true;
            }
            homeManager.removeHome(player, args[0]);
            return true;
        }

        if (cmdName.equals("home")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                String homes = homeManager.getHomesString(player.getUniqueId().toString());
                player.sendMessage("§eTwoje domy: " + homes);
                player.sendMessage("§eUżycie: /home <nazwa>");
                return true;
            }
            homeManager.teleportToHome(player, args[0]);
            return true;
        }

        // Upgrade GUI
        if (cmdName.equals("ulepsz")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            plugin.getUpgradeGUI().openGUI(player);
            return true;
        }

        // How to play
        if (cmdName.equals("jakgrac")) {
            sender.sendMessage("§6Jak grać w SoulCraft:\n" +
                    "§e1. Zdobywaj dusze zabijając graczy lub specjalne zombie.\n" +
                    "§e2. Ulepszaj miecz komendą /ulepsz (trzymaj miecz w rękę).\n" +
                    "§e3. Twórz klany komendą /klan stworz <nazwa>.\n" +
                    "§e4. Zapraszaj do klanu: /klan dodaj <nick>.\n" +
                    "§e5. Akceptuj zaproszenia: /klan przyjmij.\n" +
                    "§e6. Używaj rynku: /rynek (przeglądaj) i /wystaw <cena> (sprzedawaj).\n" +
                    "§e7. Odwiedzaj sklep: /sklep (kupuj/sprzedawaj przedmioty).\n" +
                    "§e8. Ustawiaj domy: /sethome <nazwa>, teleportuj się: /home <nazwa>.\n" +
                    "§e9. Zwracaj uwagę na kryształy dusz na mapie - pojawiają się losowo!\n" +
                    "§e10. Używaj warpów: /warp (teleportacja do stałych punktów).\n" +
                    "§e11. Po osiągnięciu 5 poziomu serc użyj /rebirth aby zdobyć czarną materię!");
            return true;
        }

        // Kits
        if (cmdName.equals("kit")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            plugin.getKitManager().openKitGUI(player);
            return true;
        }

        // Help
        if (cmdName.equals("help")) {
            sender.sendMessage("§6Komendy SoulCraft:\n" +
                    "§e/dodajhajs <gracz> <kwota> §7- Dodaje hajs (tylko OP)\n" +
                    "§e/usunhajs <gracz> <kwota> §7- Usuwa hajs (tylko OP)\n" +
                    "§e/klan stworz <nazwa> §7- Tworzy klan\n" +
                    "§e/klan dodaj <nick> §7- Zaprasza gracza do klanu\n" +
                    "§e/klan przyjmij §7- Akceptuje zaproszenie do klanu\n" +
                    "§e/klan opusc §7- Opuszcza klan\n" +
                    "§e/zombie §7- Przywołuje specjalnego zombie (tylko OP)\n" +
                    "§e/ulepsz §7- Otwiera GUI ulepszania miecza\n" +
                    "§e/jakgrac §7- Pokazuje jak grać\n" +
                    "§e/help §7- Pokazuje wszystkie komendy\n" +
                    "§e/event §7- Wymusza event kryształu i zombie (tylko OP)\n" +
                    "§e/dajrange <gracz> <ranga> [czas] §7- Nadaje rangę (tylko OP)\n" +
                    "§e/spawn §7- Teleportuje do spawnu\n" +
                    "§e/ustawspawn §7- Ustawia spawn (tylko OP)\n" +
                    "§e/kit §7- Otwiera GUI kitów\n" +
                    "§e/dajkrysztal <gracz> <lvl> <ile> §7- Daje kryształy dusz (tylko OP)\n" +
                    "§e/rynek §7- Otwiera rynek graczy\n" +
                    "§e/wystaw <cena> §7- Wystawia przedmiot na rynek\n" +
                    "§e/sklep §7- Otwiera sklep\n" +
                    "§e/sethome <nazwa> §7- Ustawia dom\n" +
                    "§e/usunhome <nazwa> §7- Usuwa dom\n" +
                    "§e/home <nazwa> §7- Teleportuje do domu\n" +
                    "§e/ustawboos §7- Ustawia spawn bossa (tylko OP)\n" +
                    "§e/startboos §7- Przywołuje bossa (tylko OP)\n" +
                    "§e/spawnnpc [type] §7- Przywołuje NPC (tylko OP)\n" +
                    "§e/rebirth §7- Przechodzi rebirth (max serca)\n" +
                    "§e/warp §7- System warpów (teleportacja do stałych punktów)\n" +
                    "§e/dodajczarnamateria <gracz> <ile> §7- Dodaje czarną materię (tylko OP)");
            return true;
        }

        return false;
    }

    public ItemStack createSoulCrystal(int level) {
        ItemStack crystal = new ItemStack(Material.EMERALD);
        ItemMeta meta = crystal.getItemMeta();
        if (meta != null) {
            String name = "Kryształ Dusz (Lvl " + level + ")";
            meta.setDisplayName("§b" + name);
            meta.setLore(java.util.Arrays.asList("Dodaje " + (level * 10) + " dusz",
                    "Kliknij prawym przyciskiem myszy trzymając przedmiot"));
            crystal.setItemMeta(meta);
        }
        return crystal;
    }
}
