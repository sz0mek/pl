package com.soulcraft.dungeons;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;

public class DungeonManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Dungeon> dungeons = new HashMap<>();
    private final Map<UUID, DungeonSession> activeSessions = new HashMap<>();
    
    public DungeonManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        registerDungeons();
    }
    
    private void registerDungeons() {
        dungeons.put("soul_catacombs", new Dungeon("soul_catacombs", "§5§lKatakumby Dusz", 1, 10, 5000));
        dungeons.put("void_abyss", new Dungeon("void_abyss", "§0§lOtchłań Pustki", 10, 20, 15000));
        dungeons.put("chaos_fortress", new Dungeon("chaos_fortress", "§c§lTwierdza Chaosu", 20, 30, 30000));
        dungeons.put("phantom_realm", new Dungeon("phantom_realm", "§3§lKrólestwo Widm", 30, 40, 50000));
        dungeons.put("eternal_sanctum", new Dungeon("eternal_sanctum", "§6§lWieczne Sanktuarium", 40, 50, 100000));
    }
    
    public void startDungeon(Player player, String dungeonId) {
        Dungeon dungeon = dungeons.get(dungeonId);
        if (dungeon == null) return;
        
        DungeonSession session = new DungeonSession(player, dungeon, plugin);
        activeSessions.put(player.getUniqueId(), session);
        session.start();
    }
    
    public void completeDungeon(Player player) {
        DungeonSession session = activeSessions.remove(player.getUniqueId());
        if (session != null) {
            session.complete();
        }
    }
    
    public static class Dungeon {
        final String id, name;
        final int minLevel, maxLevel, soulReward;
        
        public Dungeon(String id, String name, int minLevel, int maxLevel, int soulReward) {
            this.id = id;
            this.name = name;
            this.minLevel = minLevel;
            this.maxLevel = maxLevel;
            this.soulReward = soulReward;
        }
    }
    
    public static class DungeonSession {
        final Player player;
        final Dungeon dungeon;
        final SoulCraftPlugin plugin;
        int roomsCleared = 0;
        long startTime;
        
        public DungeonSession(Player player, Dungeon dungeon, SoulCraftPlugin plugin) {
            this.player = player;
            this.dungeon = dungeon;
            this.plugin = plugin;
        }
        
        public void start() {
            startTime = System.currentTimeMillis();
            player.sendMessage("§5§l✦ Rozpoczęto dungeon: " + dungeon.name);
        }
        
        public void complete() {
            long duration = (System.currentTimeMillis() - startTime) / 1000;
            player.sendMessage("§a§l✔ Ukończono dungeon w " + duration + " sekund!");
            plugin.getSoulManager().addSouls(player.getUniqueId().toString(), dungeon.soulReward);
        }
    }
}
