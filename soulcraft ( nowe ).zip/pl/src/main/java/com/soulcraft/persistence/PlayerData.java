package com.soulcraft.persistence;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.*;

/**
 * Complete player data model
 */
public class PlayerData {
    private final UUID playerId;
    
    // Core stats
    private int level;
    private long souls;
    private long experience;
    private int rebirths;
    private int blackMatter;
    
    // Abilities
    private Set<String> unlockedAbilities;
    private Map<String, Long> abilityCooldowns;
    
    // Pet
    private String activePet;
    private Map<String, PetData> pets;
    
    // Missions
    private Map<String, MissionProgress> activeMissions;
    private Set<String> completedMissions;
    private long dailyResetTime;
    private long weeklyResetTime;
    
    // Clan
    private String clanId;
    private long clanContribution;
    
    // Items
    private Map<String, Integer> customItemCounts;
    
    // Features
    private Map<String, Boolean> features;
    
    // Statistics
    private int mobsKilled;
    private int playersKilled;
    private int bossesKilled;
    private int dungeonsCompleted;
    private long playtime;
    
    public PlayerData(UUID playerId) {
        this.playerId = playerId;
        this.level = 1;
        this.souls = 1000; // Starting souls
        this.experience = 0;
        this.rebirths = 0;
        this.blackMatter = 0;
        this.unlockedAbilities = new HashSet<>();
        this.abilityCooldowns = new HashMap<>();
        this.pets = new HashMap<>();
        this.activeMissions = new HashMap<>();
        this.completedMissions = new HashSet<>();
        this.customItemCounts = new HashMap<>();
        this.features = new HashMap<>();
        this.dailyResetTime = System.currentTimeMillis();
        this.weeklyResetTime = System.currentTimeMillis();
    }
    
    // Serialization
    public void toYaml(YamlConfiguration config) {
        config.set("playerId", playerId.toString());
        config.set("level", level);
        config.set("souls", souls);
        config.set("experience", experience);
        config.set("rebirths", rebirths);
        config.set("blackMatter", blackMatter);
        
        config.set("abilities.unlocked", new ArrayList<>(unlockedAbilities));
        config.set("abilities.cooldowns", abilityCooldowns);
        
        config.set("pet.active", activePet);
        ConfigurationSection petsSection = config.createSection("pet.data");
        for (Map.Entry<String, PetData> entry : pets.entrySet()) {
            ConfigurationSection petSection = petsSection.createSection(entry.getKey());
            entry.getValue().toYaml(petSection);
        }
        
        ConfigurationSection missionsSection = config.createSection("missions.active");
        for (Map.Entry<String, MissionProgress> entry : activeMissions.entrySet()) {
            ConfigurationSection missionSection = missionsSection.createSection(entry.getKey());
            entry.getValue().toYaml(missionSection);
        }
        config.set("missions.completed", new ArrayList<>(completedMissions));
        config.set("missions.dailyReset", dailyResetTime);
        config.set("missions.weeklyReset", weeklyResetTime);
        
        config.set("clan.id", clanId);
        config.set("clan.contribution", clanContribution);
        
        config.set("items", customItemCounts);
        config.set("features", features);
        
        config.set("stats.mobsKilled", mobsKilled);
        config.set("stats.playersKilled", playersKilled);
        config.set("stats.bossesKilled", bossesKilled);
        config.set("stats.dungeonsCompleted", dungeonsCompleted);
        config.set("stats.playtime", playtime);
    }
    
    public static PlayerData fromYaml(UUID playerId, YamlConfiguration config) {
        PlayerData data = new PlayerData(playerId);
        
        data.level = config.getInt("level", 1);
        data.souls = config.getLong("souls", 1000);
        data.experience = config.getLong("experience", 0);
        data.rebirths = config.getInt("rebirths", 0);
        data.blackMatter = config.getInt("blackMatter", 0);
        
        data.unlockedAbilities = new HashSet<>(config.getStringList("abilities.unlocked"));
        ConfigurationSection cooldownsSection = config.getConfigurationSection("abilities.cooldowns");
        if (cooldownsSection != null) {
            for (String key : cooldownsSection.getKeys(false)) {
                data.abilityCooldowns.put(key, cooldownsSection.getLong(key));
            }
        }
        
        data.activePet = config.getString("pet.active");
        ConfigurationSection petsSection = config.getConfigurationSection("pet.data");
        if (petsSection != null) {
            for (String petType : petsSection.getKeys(false)) {
                ConfigurationSection petSection = petsSection.getConfigurationSection(petType);
                data.pets.put(petType, PetData.fromYaml(petSection));
            }
        }
        
        ConfigurationSection missionsSection = config.getConfigurationSection("missions.active");
        if (missionsSection != null) {
            for (String missionId : missionsSection.getKeys(false)) {
                ConfigurationSection missionSection = missionsSection.getConfigurationSection(missionId);
                data.activeMissions.put(missionId, MissionProgress.fromYaml(missionSection));
            }
        }
        data.completedMissions = new HashSet<>(config.getStringList("missions.completed"));
        data.dailyResetTime = config.getLong("missions.dailyReset", System.currentTimeMillis());
        data.weeklyResetTime = config.getLong("missions.weeklyReset", System.currentTimeMillis());
        
        data.clanId = config.getString("clan.id");
        data.clanContribution = config.getLong("clan.contribution", 0);
        
        ConfigurationSection itemsSection = config.getConfigurationSection("items");
        if (itemsSection != null) {
            for (String item : itemsSection.getKeys(false)) {
                data.customItemCounts.put(item, itemsSection.getInt(item));
            }
        }
        
        ConfigurationSection featuresSection = config.getConfigurationSection("features");
        if (featuresSection != null) {
            for (String feature : featuresSection.getKeys(false)) {
                data.features.put(feature, featuresSection.getBoolean(feature));
            }
        }
        
        data.mobsKilled = config.getInt("stats.mobsKilled", 0);
        data.playersKilled = config.getInt("stats.playersKilled", 0);
        data.bossesKilled = config.getInt("stats.bossesKilled", 0);
        data.dungeonsCompleted = config.getInt("stats.dungeonsCompleted", 0);
        data.playtime = config.getLong("stats.playtime", 0);
        
        return data;
    }
    
    // Getters and Setters
    public UUID getPlayerId() { return playerId; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
    public long getSouls() { return souls; }
    public void setSouls(long souls) { this.souls = souls; }
    public void addSouls(long amount) { this.souls += amount; }
    public boolean removeSouls(long amount) {
        if (souls >= amount) {
            souls -= amount;
            return true;
        }
        return false;
    }
    public long getExperience() { return experience; }
    public void setExperience(long experience) { this.experience = experience; }
    public void addExperience(long amount) { this.experience += amount; }
    public int getRebirths() { return rebirths; }
    public void setRebirths(int rebirths) { this.rebirths = rebirths; }
    public void incrementRebirths() { this.rebirths++; }
    
    public int getBlackMatter() { return blackMatter; }
    public void setBlackMatter(int blackMatter) { this.blackMatter = blackMatter; }
    public void addBlackMatter(int amount) { this.blackMatter += amount; }
    public boolean removeBlackMatter(int amount) {
        if (blackMatter >= amount) {
            blackMatter -= amount;
            return true;
        }
        return false;
    }
    
    public Set<String> getUnlockedAbilities() { return unlockedAbilities; }
    public void unlockAbility(String ability) { unlockedAbilities.add(ability); }
    public boolean hasAbility(String ability) { return unlockedAbilities.contains(ability); }
    
    public Map<String, Long> getAbilityCooldowns() { return abilityCooldowns; }
    public void setAbilityCooldown(String ability, long cooldownEnd) {
        abilityCooldowns.put(ability, cooldownEnd);
    }
    public boolean isAbilityOnCooldown(String ability) {
        Long cooldownEnd = abilityCooldowns.get(ability);
        return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
    }
    
    public String getActivePet() { return activePet; }
    public void setActivePet(String activePet) { this.activePet = activePet; }
    public Map<String, PetData> getPets() { return pets; }
    public PetData getPet(String type) { return pets.get(type); }
    public void setPet(String type, PetData petData) { pets.put(type, petData); }
    
    public Map<String, MissionProgress> getActiveMissions() { return activeMissions; }
    public void addActiveMission(String missionId, MissionProgress progress) {
        activeMissions.put(missionId, progress);
    }
    public MissionProgress getMissionProgress(String missionId) {
        return activeMissions.get(missionId);
    }
    public void removeMission(String missionId) { activeMissions.remove(missionId); }
    
    public Set<String> getCompletedMissions() { return completedMissions; }
    public void completeMission(String missionId) { completedMissions.add(missionId); }
    public boolean hasCompletedMission(String missionId) {
        return completedMissions.contains(missionId);
    }
    
    public long getDailyResetTime() { return dailyResetTime; }
    public void setDailyResetTime(long time) { this.dailyResetTime = time; }
    public long getWeeklyResetTime() { return weeklyResetTime; }
    public void setWeeklyResetTime(long time) { this.weeklyResetTime = time; }
    
    public String getClanId() { return clanId; }
    public void setClanId(String clanId) { this.clanId = clanId; }
    public long getClanContribution() { return clanContribution; }
    public void addClanContribution(long amount) { this.clanContribution += amount; }
    
    public Map<String, Integer> getCustomItemCounts() { return customItemCounts; }
    public int getItemCount(String item) { return customItemCounts.getOrDefault(item, 0); }
    public void setItemCount(String item, int count) { customItemCounts.put(item, count); }
    public void addItem(String item, int count) {
        customItemCounts.put(item, getItemCount(item) + count);
    }
    
    public Map<String, Boolean> getFeatures() { return features; }
    public boolean hasFeature(String feature) { return features.getOrDefault(feature, false); }
    public void setFeature(String feature, boolean enabled) { features.put(feature, enabled); }
    
    public int getMobsKilled() { return mobsKilled; }
    public void incrementMobsKilled() { this.mobsKilled++; }
    public int getPlayersKilled() { return playersKilled; }
    public void incrementPlayersKilled() { this.playersKilled++; }
    public int getBossesKilled() { return bossesKilled; }
    public void incrementBossesKilled() { this.bossesKilled++; }
    public int getDungeonsCompleted() { return dungeonsCompleted; }
    public void incrementDungeonsCompleted() { this.dungeonsCompleted++; }
    public long getPlaytime() { return playtime; }
    public void addPlaytime(long milliseconds) { this.playtime += milliseconds; }
    
    // Helper classes
    public static class PetData {
        private int level;
        private long experience;
        private String evolutionStage;
        private int happiness;
        private long lastFed;
        private String customName;
        private Set<String> unlockedSkills;
        private int deaths;
        private boolean hasDeathProtection;
        
        public PetData() {
            this.level = 1;
            this.experience = 0;
            this.evolutionStage = "Baby";
            this.happiness = 100;
            this.lastFed = System.currentTimeMillis();
            this.customName = null;
            this.unlockedSkills = new HashSet<>();
            this.deaths = 0;
            this.hasDeathProtection = false;
        }
        
        public void toYaml(ConfigurationSection section) {
            section.set("level", level);
            section.set("experience", experience);
            section.set("evolution", evolutionStage);
            section.set("happiness", happiness);
            section.set("lastFed", lastFed);
            section.set("customName", customName);
            section.set("unlockedSkills", new ArrayList<>(unlockedSkills));
            section.set("deaths", deaths);
            section.set("deathProtection", hasDeathProtection);
        }
        
        public static PetData fromYaml(ConfigurationSection section) {
            PetData data = new PetData();
            data.level = section.getInt("level", 1);
            data.experience = section.getLong("experience", 0);
            data.evolutionStage = section.getString("evolution", "Baby");
            data.happiness = section.getInt("happiness", 100);
            data.lastFed = section.getLong("lastFed", System.currentTimeMillis());
            data.customName = section.getString("customName");
            data.unlockedSkills = new HashSet<>(section.getStringList("unlockedSkills"));
            data.deaths = section.getInt("deaths", 0);
            data.hasDeathProtection = section.getBoolean("deathProtection", false);
            return data;
        }
        
        public int getLevel() { return level; }
        public void setLevel(int level) { this.level = level; }
        public long getExperience() { return experience; }
        public void setExperience(long experience) { this.experience = experience; }
        public void addExperience(long amount) { this.experience += amount; }
        public String getEvolutionStage() { return evolutionStage; }
        public void setEvolutionStage(String stage) { this.evolutionStage = stage; }
        public int getHappiness() { return happiness; }
        public void setHappiness(int happiness) { this.happiness = Math.max(0, Math.min(100, happiness)); }
        public void addHappiness(int amount) { setHappiness(happiness + amount); }
        public long getLastFed() { return lastFed; }
        public void setLastFed(long time) { this.lastFed = time; }
        public String getCustomName() { return customName; }
        public void setCustomName(String name) { this.customName = name; }
        public Set<String> getUnlockedSkills() { return unlockedSkills; }
        public void unlockSkill(String skill) { unlockedSkills.add(skill); }
        public boolean hasSkill(String skill) { return unlockedSkills.contains(skill); }
        public int getDeaths() { return deaths; }
        public void incrementDeaths() { this.deaths++; }
        public boolean hasDeathProtection() { return hasDeathProtection; }
        public void setDeathProtection(boolean protection) { this.hasDeathProtection = protection; }
    }
    
    public static class MissionProgress {
        private String missionId;
        private int progress;
        private int required;
        private long startTime;
        private long expiryTime;
        
        public MissionProgress(String missionId, int required, long expiryTime) {
            this.missionId = missionId;
            this.progress = 0;
            this.required = required;
            this.startTime = System.currentTimeMillis();
            this.expiryTime = expiryTime;
        }
        
        public void toYaml(ConfigurationSection section) {
            section.set("id", missionId);
            section.set("progress", progress);
            section.set("required", required);
            section.set("startTime", startTime);
            section.set("expiryTime", expiryTime);
        }
        
        public static MissionProgress fromYaml(ConfigurationSection section) {
            String id = section.getString("id");
            int required = section.getInt("required");
            long expiryTime = section.getLong("expiryTime");
            MissionProgress mp = new MissionProgress(id, required, expiryTime);
            mp.progress = section.getInt("progress");
            mp.startTime = section.getLong("startTime");
            return mp;
        }
        
        public String getMissionId() { return missionId; }
        public int getProgress() { return progress; }
        public void setProgress(int progress) { this.progress = progress; }
        public void incrementProgress() { this.progress++; }
        public void addProgress(int amount) { this.progress += amount; }
        public int getRequired() { return required; }
        public boolean isComplete() { return progress >= required; }
        public long getStartTime() { return startTime; }
        public long getExpiryTime() { return expiryTime; }
        public boolean isExpired() { return System.currentTimeMillis() > expiryTime; }
        public int getPercentComplete() { return (int)((progress / (double)required) * 100); }
    }
}
