package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public class AutoReplant extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public AutoReplant(SoulCraftPlugin plugin) {
        super(
            "autoreplant",
            "§2§lAuto Replant",
            "§7Automatyczne ponowne sadzenie roślin"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        BlockBreakEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onCropBreak(BlockBreakEvent event) {
        if (!canUse(event.getPlayer())) {
            return;
        }
        
        Block block = event.getBlock();
        Material type = block.getType();
        
        if (!(block.getBlockData() instanceof Ageable ageable)) {
            return;
        }
        
        if (ageable.getAge() != ageable.getMaximumAge()) {
            return;
        }
        
        Material seedType = getSeedType(type);
        if (seedType == null) {
            return;
        }
        
        // Replant the crop
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            block.setType(type);
            Ageable newCrop = (Ageable) block.getBlockData();
            newCrop.setAge(0);
            block.setBlockData(newCrop);
        }, 1L);
    }

    private Material getSeedType(Material cropType) {
        return switch (cropType) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> null;
        };
    }
}
