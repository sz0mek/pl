// AntiLogoutManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

public class AntiLogoutManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Integer> logoutTimers = new HashMap<>();
    private final Map<UUID, BukkitTask> activeTasks = new HashMap<>();

    public AntiLogoutManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player player && event.getDamager() instanceof Player) {
            UUID uuid = player.getUniqueId();
            
            // Cancel previous task if exists (FIX: prevents memory leak)
            if (activeTasks.containsKey(uuid)) {
                activeTasks.get(uuid).cancel();
                activeTasks.remove(uuid);
            }
            
            logoutTimers.put(uuid, 30); // Resetuj timer do 30 sekund

            BukkitTask task = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!logoutTimers.containsKey(uuid)) {
                        activeTasks.remove(uuid);
                        this.cancel();
                        return;
                    }

                    int timeLeft = logoutTimers.get(uuid);
                    if (timeLeft <= 0) {
                        logoutTimers.remove(uuid);
                        activeTasks.remove(uuid);
                        this.cancel();
                        return;
                    }

                    player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent
                            .fromLegacyText(ChatColor.RED + "" + ChatColor.BOLD + "Logout: " + timeLeft + " sekund"));
                    logoutTimers.put(uuid, timeLeft - 1);
                }
            }.runTaskTimer(plugin, 0L, 20L);
            
            activeTasks.put(uuid, task);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        
        // Cancel active task on quit
        if (activeTasks.containsKey(uuid)) {
            activeTasks.get(uuid).cancel();
            activeTasks.remove(uuid);
        }
        
        if (logoutTimers.containsKey(uuid)) {
            int timeLeft = logoutTimers.get(uuid);
            if (timeLeft > 0) {
                player.setHealth(0); // Zabij gracza
                for (ItemStack item : player.getInventory().getContents()) {
                    if (item != null) {
                        player.getWorld().dropItemNaturally(player.getLocation(), item);
                    }
                }
                player.getInventory().clear();
            }
            logoutTimers.remove(uuid);
        }
    }
}
