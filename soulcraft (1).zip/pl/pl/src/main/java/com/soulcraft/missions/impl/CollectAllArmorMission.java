package com.soulcraft.missions.impl;

import com.soulcraft.missions.Mission;
import org.bukkit.entity.Player;
import java.util.*;

public class CollectAllArmorMission extends Mission {
    private final Map<UUID, Set<String>> collectedArmor = new HashMap<>();
    private final Map<UUID, Boolean> completed = new HashMap<>();
    private static final Set<String> ALL_ARMOR = Set.of("eternal_chestplate", "shadow_helmet", "void_leggings", "soul_boots");
    
    public CollectAllArmorMission(String id, String displayName, String description, MissionType type,
                                 int requiredProgress, List<MissionReward> rewards, String requiredRank) {
        super(id, displayName, description, type, requiredProgress, rewards, requiredRank);
    }
    
    @Override
    public boolean checkProgress(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof String) {
            String armorId = (String) args[0];
            if (ALL_ARMOR.contains(armorId)) {
                collectedArmor.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(armorId);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int getProgress(UUID playerId) {
        return collectedArmor.getOrDefault(playerId, new HashSet<>()).size();
    }
    @Override
    public void setProgress(UUID playerId, int value) { }
    @Override
    public void incrementProgress(UUID playerId, int amount) { }
    @Override
    public boolean isCompleted(UUID playerId) { return completed.getOrDefault(playerId, false); }
    @Override
    public void complete(Player player) {
        completed.put(player.getUniqueId(), true);
        giveRewards(player);
        player.sendMessage("§a§l✔ Ukończono misję: " + displayName);
    }
    @Override
    public void giveRewards(Player player) { }
    @Override
    public void reset(UUID playerId) {
        collectedArmor.remove(playerId);
        completed.remove(playerId);
    }
}
