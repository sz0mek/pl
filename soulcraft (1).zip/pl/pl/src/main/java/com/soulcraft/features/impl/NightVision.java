package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class NightVision extends GameFeature {
    private final SoulCraftPlugin plugin;

    public NightVision(SoulCraftPlugin plugin) {
        super(
            "nightvision",
            "§e§lNight Vision",
            "§7Permanentna noktowizja"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (canUse(player)) {
                    player.addPotionEffect(new PotionEffect(
                        PotionEffectType.NIGHT_VISION,
                        400,
                        0,
                        false,
                        false,
                        false
                    ));
                }
            }
        }, 0L, 200L);
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
    }
}
