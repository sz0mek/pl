package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class KeepInventory extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public KeepInventory(SoulCraftPlugin plugin) {
        super(
            "keepinventory",
            "§6§lZachowanie Ekwipunku",
            "§7Nie tracisz przedmiotów po śmierci"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        PlayerDeathEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        if (!canUse(event.getEntity())) {
            return;
        }
        
        event.setKeepInventory(true);
        event.setKeepLevel(true);
        event.getDrops().clear();
        event.setDroppedExp(0);
        
        event.getEntity().sendMessage("§6§l✦ Twój ekwipunek został zachowany!");
    }
}
