package com.soulcraft.events;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.core.NotificationService;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class EventOrchestrator {
    
    private final SoulCraftPlugin plugin;
    private final NotificationService notificationService;
    private final Map<String, BukkitTask> activeEvents = new HashMap<>();
    private final List<RandomEvent> availableEvents = new ArrayList<>();
    private BukkitTask randomEventTask;
    
    public EventOrchestrator(SoulCraftPlugin plugin, NotificationService notificationService) {
        this.plugin = plugin;
        this.notificationService = notificationService;
        registerEvents();
        startRandomEventScheduler();
    }
    
    private void registerEvents() {
        availableEvents.add(new ItemRainEvent());
        availableEvents.add(new WorldBossEvent());
        availableEvents.add(new DoubleExpEvent());
        availableEvents.add(new TreasureChestEvent());
        availableEvents.add(new ParkourChallengeEvent());
        availableEvents.add(new QuizEvent());
        availableEvents.add(new DoubleMoneyEvent());
        availableEvents.add(new DoubleSoulsEvent());
        availableEvents.add(new MeteorShowerEvent());
        availableEvents.add(new LuckyHourEvent());
    }
    
    private void startRandomEventScheduler() {
        randomEventTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (Bukkit.getOnlinePlayers().size() < 1) return;
                
                RandomEvent event = availableEvents.get(ThreadLocalRandom.current().nextInt(availableEvents.size()));
                triggerEvent(event);
            }
        }.runTaskTimer(plugin, 20 * 60 * 15, 20 * 60 * ThreadLocalRandom.current().nextInt(15, 31));
    }
    
    public void startEvent(String eventName) {
        RandomEvent event = availableEvents.stream()
            .filter(e -> e.getName().equalsIgnoreCase(eventName))
            .findFirst()
            .orElse(null);
        
        if (event != null) {
            triggerEvent(event);
        }
    }
    
    public void stopAllEvents() {
        activeEvents.values().forEach(BukkitTask::cancel);
        activeEvents.clear();
    }
    
    public List<String> listEvents() {
        List<String> events = new ArrayList<>();
        availableEvents.forEach(event -> events.add(event.getName()));
        return events;
    }
    
    private void triggerEvent(RandomEvent event) {
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        Bukkit.broadcastMessage("§e§l         ⚡ EVENT ROZPOCZĘTY! ⚡");
        Bukkit.broadcastMessage("§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        Bukkit.broadcastMessage("§7Event: §e§l" + event.getName());
        Bukkit.broadcastMessage("§7Opis: §f" + event.getDescription());
        Bukkit.broadcastMessage("§7Czas trwania: §a" + event.getDuration() + " sekund");
        Bukkit.broadcastMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        Bukkit.broadcastMessage("");
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            notificationService.sendTitle(player, "§6§l⚡ EVENT! ⚡", "§e" + event.getName(), 10, 60, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.0f);
        }
        
        BukkitTask task = event.start(plugin, notificationService);
        activeEvents.put(event.getName(), task);
        
        new BukkitRunnable() {
            @Override
            public void run() {
                event.stop();
                activeEvents.remove(event.getName());
                Bukkit.broadcastMessage("§6§l[EVENT] §fEvent §e" + event.getName() + " §fzakończony!");
            }
        }.runTaskLater(plugin, 20L * event.getDuration());
    }
    
    public void shutdown() {
        if (randomEventTask != null) {
            randomEventTask.cancel();
        }
        stopAllEvents();
    }
    
    private abstract class RandomEvent {
        protected String name;
        protected String description;
        protected int duration;
        
        public abstract BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService);
        public abstract void stop();
        
        public String getName() { return name; }
        public String getDescription() { return description; }
        public int getDuration() { return duration; }
    }
    
    private class ItemRainEvent extends RandomEvent {
        public ItemRainEvent() {
            this.name = "Deszcz Przedmiotów";
            this.description = "Losowe przedmioty spadają z nieba!";
            this.duration = 60;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        Location loc = player.getLocation().add(
                            ThreadLocalRandom.current().nextInt(-5, 6),
                            10,
                            ThreadLocalRandom.current().nextInt(-5, 6)
                        );
                        ItemStack item = getRandomItem();
                        player.getWorld().dropItem(loc, item);
                    }
                }
            }.runTaskTimer(plugin, 0, 40);
        }
        
        @Override
        public void stop() {}
        
        private ItemStack getRandomItem() {
            Material[] items = {Material.DIAMOND, Material.GOLD_INGOT, Material.IRON_INGOT, 
                              Material.EMERALD, Material.COOKED_BEEF, Material.GOLDEN_APPLE};
            return new ItemStack(items[ThreadLocalRandom.current().nextInt(items.length)], 
                               ThreadLocalRandom.current().nextInt(1, 5));
        }
    }
    
    private class WorldBossEvent extends RandomEvent {
        public WorldBossEvent() {
            this.name = "Boss Światowy";
            this.description = "Potężny boss pojawił się na mapie!";
            this.duration = 300;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            World world = Bukkit.getWorlds().get(0);
            Location spawnLoc = world.getSpawnLocation().add(
                ThreadLocalRandom.current().nextInt(-100, 101),
                0,
                ThreadLocalRandom.current().nextInt(-100, 101)
            );
            spawnLoc.setY(world.getHighestBlockYAt(spawnLoc));
            
            Bukkit.broadcastMessage("§c§l[BOSS] §fBoss pojawił się na: §eX:" + spawnLoc.getBlockX() + 
                                  " Z:" + spawnLoc.getBlockZ());
            
            return new BukkitRunnable() {
                @Override
                public void run() {}
            }.runTaskTimer(plugin, 0, 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class DoubleExpEvent extends RandomEvent {
        public DoubleExpEvent() {
            this.name = "Podwójne EXP";
            this.description = "Zyskujesz 2x więcej doświadczenia!";
            this.duration = 180;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {}
            }.runTaskTimer(plugin, 0, 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class TreasureChestEvent extends RandomEvent {
        public TreasureChestEvent() {
            this.name = "Skrzynia Skarbów";
            this.description = "Losowa skrzynia pojawiła się na mapie!";
            this.duration = 120;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            World world = Bukkit.getWorlds().get(0);
            Location loc = world.getSpawnLocation().add(
                ThreadLocalRandom.current().nextInt(-150, 151),
                0,
                ThreadLocalRandom.current().nextInt(-150, 151)
            );
            loc.setY(world.getHighestBlockYAt(loc) + 1);
            
            loc.getBlock().setType(Material.CHEST);
            Bukkit.broadcastMessage("§e§l[SKARB] §fSkrzynia pojawiła się na: §6X:" + loc.getBlockX() + 
                                  " Z:" + loc.getBlockZ());
            
            return new BukkitRunnable() {
                @Override
                public void run() {
                    loc.getBlock().setType(Material.AIR);
                }
            }.runTaskLater(plugin, 20L * duration);
        }
        
        @Override
        public void stop() {}
    }
    
    private class ParkourChallengeEvent extends RandomEvent {
        public ParkourChallengeEvent() {
            this.name = "Wyzwanie Parkour";
            this.description = "Ukończ parkour i wygraj nagrody!";
            this.duration = 240;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {}
            }.runTaskTimer(plugin, 0, 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class QuizEvent extends RandomEvent {
        public QuizEvent() {
            this.name = "Quiz";
            this.description = "Odpowiedz na pytania i wygraj!";
            this.duration = 120;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                private int questionNum = 0;
                
                @Override
                public void run() {
                    if (questionNum < 5) {
                        Bukkit.broadcastMessage("§e§l[QUIZ] §fPytanie " + (questionNum + 1) + "/5");
                        questionNum++;
                    }
                }
            }.runTaskTimer(plugin, 0, 20 * 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class DoubleMoneyEvent extends RandomEvent {
        public DoubleMoneyEvent() {
            this.name = "Podwójne Monety";
            this.description = "Zyskujesz 2x więcej hajsu!";
            this.duration = 180;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {}
            }.runTaskTimer(plugin, 0, 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class DoubleSoulsEvent extends RandomEvent {
        public DoubleSoulsEvent() {
            this.name = "Podwójne Dusze";
            this.description = "Zyskujesz 2x więcej dusz!";
            this.duration = 180;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {}
            }.runTaskTimer(plugin, 0, 20);
        }
        
        @Override
        public void stop() {}
    }
    
    private class MeteorShowerEvent extends RandomEvent {
        public MeteorShowerEvent() {
            this.name = "Deszcz Meteorytów";
            this.description = "Meteoryty spadają z nieba!";
            this.duration = 90;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        Location loc = player.getLocation().add(
                            ThreadLocalRandom.current().nextInt(-10, 11),
                            50,
                            ThreadLocalRandom.current().nextInt(-10, 11)
                        );
                        player.getWorld().createExplosion(loc, 2.0f, false, false);
                    }
                }
            }.runTaskTimer(plugin, 0, 60);
        }
        
        @Override
        public void stop() {}
    }
    
    private class LuckyHourEvent extends RandomEvent {
        public LuckyHourEvent() {
            this.name = "Szczęśliwa Godzina";
            this.description = "Wszystkie bonusy aktywne!";
            this.duration = 300;
        }
        
        @Override
        public BukkitTask start(SoulCraftPlugin plugin, NotificationService notificationService) {
            return new BukkitRunnable() {
                @Override
                public void run() {
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        notificationService.sendActionBar(player, "§6§l⭐ SZCZĘŚLIWA GODZINA! §e2x EXP, HAJS, DUSZE!");
                    }
                }
            }.runTaskTimer(plugin, 0, 40);
        }
        
        @Override
        public void stop() {}
    }
}
