package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class CustomCommand implements CommandExecutor, Listener {
    private final SoulCraftPlugin plugin;
    private static final String MAIN_GUI_TITLE = "§5§lPanel Admina SoulCraft";
    private static final String ITEMS_GUI_TITLE = "§6§lCustom Items";
    private static final String BOSSES_GUI_TITLE = "§c§lSpawn Bossów";
    private static final String FEATURES_GUI_TITLE = "§b§lFunkcje Gameplay";

    public CustomCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTylko gracze mogą używać tej komendy!");
            return true;
        }

        if (!player.hasPermission("soulcraft.admin")) {
            player.sendMessage("§cBrak uprawnień!");
            return true;
        }

        openMainGUI(player);
        return true;
    }

    private void openMainGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, MAIN_GUI_TITLE);
        
        gui.setItem(10, createItem(Material.DIAMOND_SWORD, "§6§lCustom Items", "§7Zarządzaj custom itemami", "§aKliknij aby otworzyć"));
        gui.setItem(12, createItem(Material.WITHER_SKELETON_SKULL, "§c§lBossy", "§7Zarządzaj bossami", "§aKliknij aby spawnować"));
        gui.setItem(14, createItem(Material.NETHER_STAR, "§b§lFunkcje", "§7Włącz/wyłącz funkcje", "§aKliknij aby zarządzać"));
        gui.setItem(16, createItem(Material.EMERALD, "§a§lEkonomia", "§7Zarządzaj duszami", "§7Używaj /dodajhajs i /usunhajs"));
        gui.setItem(22, createItem(Material.BARRIER, "§cZamknij", "§7Zamyka panel"));
        
        player.openInventory(gui);
    }

    private void openItemsGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, ITEMS_GUI_TITLE);
        
        gui.setItem(0, createItem(Material.NETHERITE_SWORD, "§5Kosa Dusz"));
        gui.setItem(1, createItem(Material.NETHERITE_SWORD, "§0Ostrze Pustki"));
        gui.setItem(2, createItem(Material.NETHERITE_AXE, "§cMłot Chaosu"));
        gui.setItem(3, createItem(Material.BOW, "§bŁuk Widma"));
        gui.setItem(4, createItem(Material.BLAZE_ROD, "§5Laska Ciemności"));
        gui.setItem(9, createItem(Material.NETHERITE_HELMET, "§8Hełm Cienia"));
        gui.setItem(10, createItem(Material.NETHERITE_CHESTPLATE, "§6Wieczna Zbroja"));
        gui.setItem(11, createItem(Material.NETHERITE_LEGGINGS, "§5Spodnie Pustki"));
        gui.setItem(12, createItem(Material.NETHERITE_BOOTS, "§bButy Dusz"));
        gui.setItem(53, createItem(Material.ARROW, "§ePowrót"));
        
        player.openInventory(gui);
    }

    private void openBossesGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, BOSSES_GUI_TITLE);
        
        gui.setItem(10, createItem(Material.WITHER_SKELETON_SKULL, "§5Pożeracz Dusz"));
        gui.setItem(11, createItem(Material.IRON_BLOCK, "§0Tytan Pustki"));
        gui.setItem(12, createItem(Material.NETHERITE_BLOCK, "§cRycerz Chaosu"));
        gui.setItem(13, createItem(Material.PHANTOM_MEMBRANE, "§bPan Widm"));
        gui.setItem(14, createItem(Material.NETHER_STAR, "§4Mroczny Imperator"));
        gui.setItem(22, createItem(Material.ARROW, "§ePowrót"));
        
        player.openInventory(gui);
    }

    private void openFeaturesGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, FEATURES_GUI_TITLE);
        
        gui.setItem(0, createItem(Material.HOPPER, "§aAuto Pickup"));
        gui.setItem(1, createItem(Material.FEATHER, "§bDouble Jump"));
        gui.setItem(2, createItem(Material.WHEAT_SEEDS, "§2Auto Replant"));
        gui.setItem(3, createItem(Material.CHEST, "§6Keep Inventory"));
        gui.setItem(4, createItem(Material.FURNACE, "§cAuto Smelt"));
        gui.setItem(5, createItem(Material.GLOWSTONE, "§eNight Vision"));
        gui.setItem(6, createItem(Material.SLIME_BALL, "§dNo Fall Damage"));
        gui.setItem(7, createItem(Material.COOKED_BEEF, "§aFast Eat"));
        gui.setItem(8, createItem(Material.APPLE, "§cAuto Feed"));
        gui.setItem(9, createItem(Material.EXPERIENCE_BOTTLE, "§bXP Boost"));
        gui.setItem(10, createItem(Material.GOLD_INGOT, "§6Money Boost"));
        gui.setItem(11, createItem(Material.DIAMOND, "§5Loot Boost"));
        gui.setItem(22, createItem(Material.ARROW, "§ePowrót"));
        
        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        String title = event.getView().getTitle();
        
        if (title.equals(MAIN_GUI_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot == 10) openItemsGUI(player);
            else if (slot == 12) openBossesGUI(player);
            else if (slot == 14) openFeaturesGUI(player);
            else if (slot == 22) player.closeInventory();
        }
        else if (title.equals(ITEMS_GUI_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot == 53) openMainGUI(player);
            else {
                String itemId = getItemIdFromSlot(slot);
                if (itemId != null) {
                    player.getInventory().addItem(plugin.getCustomItemRegistry().createItem(itemId, 1));
                    player.sendMessage("§a§lOtrzymałeś custom item!");
                }
            }
        }
        else if (title.equals(BOSSES_GUI_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot == 22) openMainGUI(player);
            else {
                String bossId = getBossIdFromSlot(slot);
                if (bossId != null) {
                    plugin.getBossRegistry().spawnBoss(bossId, player.getLocation());
                    player.sendMessage("§a§lBoss zespawnowany!");
                    player.closeInventory();
                }
            }
        }
        else if (title.equals(FEATURES_GUI_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot == 22) openMainGUI(player);
            else if (slot <= 11) {
                String featureId = getFeatureIdFromSlot(slot);
                if (featureId != null) {
                    boolean enabled = plugin.getFeatureManager().isFeatureEnabled(featureId);
                    plugin.getFeatureManager().toggleFeature(featureId, !enabled);
                    player.sendMessage("§a§lFunkcja " + featureId + ": " + (!enabled ? "§aWŁĄCZONA" : "§cWYŁĄCZONA"));
                }
            }
        }
    }

    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) {
                meta.setLore(Arrays.asList(lore));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private String getItemIdFromSlot(int slot) {
        return switch (slot) {
            case 0 -> "soul_reaper";
            case 1 -> "void_blade";
            case 2 -> "chaos_hammer";
            case 3 -> "phantom_bow";
            case 4 -> "dark_staff";
            case 9 -> "shadow_helmet";
            case 10 -> "eternal_chestplate";
            case 11 -> "void_leggings";
            case 12 -> "soul_boots";
            default -> null;
        };
    }

    private String getBossIdFromSlot(int slot) {
        return switch (slot) {
            case 10 -> "soul_eater";
            case 11 -> "void_titan";
            case 12 -> "chaos_knight";
            case 13 -> "phantom_lord";
            case 14 -> "dark_emperor";
            default -> null;
        };
    }

    private String getFeatureIdFromSlot(int slot) {
        return switch (slot) {
            case 0 -> "autopickup";
            case 1 -> "doublejump";
            case 2 -> "autoreplant";
            case 3 -> "keepinventory";
            case 4 -> "autosmelt";
            case 5 -> "nightvision";
            case 6 -> "nofalldamage";
            case 7 -> "fasteat";
            case 8 -> "autofeed";
            case 9 -> "xpboost";
            case 10 -> "moneyboost";
            case 11 -> "lootboost";
            default -> null;
        };
    }
}
