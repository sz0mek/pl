# SoulCraft RPG Plugin - Replit Environment

## Overview
SoulCraft RPG is a comprehensive Minecraft Spigot plugin providing 600+ hours of engaging RPG content. This project has been successfully configured to build in the Replit environment.

## Project Type
Java Minecraft Plugin (Spigot/Bukkit API 1.21)

## Recent Changes
**Date: November 2, 2025 - Dungeon System Overhaul**
- ✅ **DungeonGUI Rewritten** - Complete GUI-based dungeon management
  - Party creation, invites with auto-expiry (60s), member management
  - Active dungeon progress GUI (time, progress, exit option)
  - All operations accessible through intuitive menus
- ✅ **Dungeon Generation Fixed** - Improved procedural generation
  - Proper room spacing (baseRoomSize + 25) prevents overlaps
  - 2-block wide corridors with walls and ceiling
  - Working portal frames (3x3 obsidian with beacon/diamond for entry, end stone/emerald for exit)
  - 5-8 rooms per dungeon with structured directional placement
- ✅ **Rewards Balanced** - Reduced from OP levels to reasonable progression
  - Easy (Lv1): 300 souls, 50 XP
  - Normal (Lv10): 1,500 souls, 200 XP  
  - Hard (Lv25): 4,500 souls, 500 XP
  - Extreme (Lv40): 8,000 souls, 900 XP
  - Chaos (Lv60): 12,000 souls, 1,200 XP
- ✅ **Code Cleanup** - Removed legacy DungeonManager duplicate
- ✅ **Build Verified** - Successfully compiles 152 source files into 572KB JAR

**Date: November 2, 2025 - Fresh GitHub Import Setup**
- ✅ **Project Structure Flattened** - Removed nested pl/pl directory structure
- ✅ **Java & Maven Installed** - Java 19 (GraalVM CE 22.3.1) and Maven 3.8.6 configured
- ✅ **Build Workflow Configured** - Automated build on Run button click

**Previous Development (from original setup):**
- Full implementation of 12 unique abilities, 5 custom bosses, 69 custom items
- Pet system with leveling, evolution, and skills
- Mission system with 26 mission types
- Clan system with economy integration

## How to Build

### Using the Run Button (Recommended)
Simply click the **Run** button in Replit. The workflow will:
1. Navigate to the `pl` directory
2. Execute the `build.sh` script
3. Compile all Java sources using Maven
4. Generate the plugin JAR at `pl/target/SoulCraftPlugin-1.0.jar`

Build time: ~14 seconds (first build may take ~25 seconds for dependency downloads)

### Manual Build
```bash
cd pl
./build.sh
```

Or directly with Maven:
```bash
cd pl
mvn clean package -DskipTests
```

## Installation Instructions

After building the plugin:

1. **Download the JAR**: Get `pl/target/SoulCraftPlugin-1.0.jar` from the target folder
2. **Install on Server**: Place the JAR in your Minecraft server's `plugins` folder
3. **Restart Server**: Restart your Minecraft server (Spigot/Paper 1.21 or compatible)
4. **Verify**: Check server console for "SoulCraftPlugin enabled" message

## Technical Stack

### Build Environment
- **Java Runtime**: OpenJDK 19.0.2 (GraalVM CE 22.3.1)
- **Build Tool**: Apache Maven 3.8.6
- **Compiler**: Java 17 source/target compatibility
- **Target API**: Spigot 1.21-R0.1-SNAPSHOT

### Server Requirements
- **Minecraft Server**: Spigot or Paper 1.21+
- **Java**: 17 or higher
- **Recommended RAM**: 2GB+ for optimal performance

## Project Structure
```
pl/                          # Plugin root directory
├── src/main/
│   ├── java/com/soulcraft/  # Java source files
│   │   ├── SoulCraftPlugin.java       # Main plugin class
│   │   ├── abilities/                 # 12 unique abilities
│   │   ├── bosses/                    # 5 custom bosses with AI
│   │   ├── items/                     # 69 custom items
│   │   ├── missions/                  # 26 mission types
│   │   ├── pets/                      # Pet system (levels 1-100)
│   │   ├── clans/                     # Clan management
│   │   ├── dungeons/                  # Procedural dungeons
│   │   └── ...                        # Other systems
│   └── resources/                     # Configuration files
│       ├── plugin.yml                 # Plugin manifest
│       ├── config.yml                 # Main configuration
│       ├── missions.yml               # Mission definitions
│       └── balance.yml                # Game balance settings
├── build.sh                 # Build script
├── pom.xml                  # Maven configuration
└── target/                  # Build output (generated)
    └── SoulCraftPlugin-1.0.jar        # Final plugin JAR (568KB)
```

## Features Overview

### Core Systems (All Fully Implemented)
- **12 Unique Abilities**: Berserk, Critical Strike, Dodge, Heal on Hit, Life Steal, Lucky, Regeneration, Shield, Soul Shield, Speed Burst, Thorns, Vampirism
- **5 Custom Bosses**: Soul Eater, Void Titan, Chaos Knight, Phantom Lord, Dark Emperor (with AI and phases)
- **69 Custom Items**: 16 weapons, 11 armor pieces, 8 tools, 10 consumables, 24 special items
- **Pet System**: Complete with AI (follow/attack/defend), leveling 1-100, evolution stages, skills, happiness
- **Clan System**: Comprehensive management with economy integration
- **Mission System**: 26 types of missions with tracking and rewards
- **Dungeon System**: Procedurally generated with party invite mechanics
- **Rebirth System**: Progress through rebirths for stat bonuses (+5% HP, +3% DMG, +2% SPD)
- **12 Gameplay Features**: Auto Pickup, Double Jump, Auto Replant, Keep Inventory, Auto Smelt, Night Vision, No Fall Damage, Fast Eat, Auto Feed, XP Boost, Money Boost, Loot Boost
- **Economy System**: Secure transactions with anti-exploit measures and Black Matter premium currency

### Commands (40+)
Key commands include:
- `/custom` or `/admin` - Admin panel for managing all systems
- `/spawnboss <boss_id>` - Spawn custom bosses
- `/giveitem <player> <item_id>` - Give custom items
- `/feature <toggle|enable|disable>` - Manage gameplay features
- `/abilities` - Open abilities shop
- `/missions` - View mission menu
- `/dungeon [name]` - Dungeon system
- `/pet [spawn|level|shop]` - Pet management
- `/profil [player]` - View player profile
- And many more...

See `pl/src/main/resources/plugin.yml` for complete command list.

## User Preferences
- Prefer simple language and clear explanations
- Iterative development with small commits
- Ask before major architectural changes
- Confirm before security/economy changes

## Architecture Notes
- Service-oriented architecture with `ClanService`, `EconomyService`, `SoulService`
- Unified `CommandHandler` manages all plugin commands
- Comprehensive null-safety checks and graceful fallbacks
- Custom GUIs with robust inventory protection
- Maven Shade Plugin bundles all dependencies into single JAR

## Build Output Details
- **Build Time**: ~14 seconds (cached), ~25 seconds (first build)
- **JAR Size**: 572 KB (shaded with dependencies)
- **Source Files**: 152 Java files
- **Output Location**: `pl/target/SoulCraftPlugin-1.0.jar`

## Development Status
This plugin contains fully implemented systems for all core features. The codebase is production-ready with complete implementations of game mechanics, event handlers, and persistence layers. Polish admin documentation is available at `pl/ADMIN_DOKUMENTACJA_PL.md`.

## Notes
- This is a **Minecraft server plugin**, not a web application
- The Run button builds the plugin but does not start a Minecraft server
- To use the plugin, you must install it on a Spigot/Paper Minecraft server
- The build process creates a standalone JAR file ready for deployment
