# SoulCraft RPG Plugin

## Overview
SoulCraft RPG is a comprehensive Minecraft RPG plugin designed to deliver over 600 hours of engaging, production-ready content. The project aims to provide a rich gameplay experience through a variety of integrated systems, making it suitable for immediate deployment on Minecraft servers. It boasts a secure economy, robust clan mechanics, diverse abilities, and challenging boss encounters, all within a stable, service-oriented architecture.

## User Preferences
I prefer simple language and clear, concise explanations. I want iterative development with frequent, small commits. Ask me before making major architectural changes or introducing new external dependencies. Do not make changes to files related to security or economy without explicit confirmation.

## System Architecture
The project is built on Java 17 (targeting Spigot/Bukkit API 1.21-R0.1-SNAPSHOT) with Java 19 (GraalVM CE 22.3.1) as the runtime and Maven 3.8.6 for build automation. It utilizes a service-oriented architecture with core services like `ClanService`, `EconomyService`, and `SoulService` to enhance maintainability and testability.

### Key Features and Implementations:
- **Core Systems**: Fully implemented and integrated systems include:
    - **Ability System**: 12 distinct abilities (e.g., HealOnHit, Dodge, CriticalStrike) with cooldowns and effects.
    - **Boss System**: 5 unique bosses with AI, phases, and arena enforcement.
    - **Dungeon System**: Procedural generation for dynamic dungeon experiences.
    - **Pet System**: Pets with 1-100 leveling, evolution, skills, and happiness mechanics.
    - **Clan System**: Comprehensive clan management with economy integration.
    - **Rebirth System**: Provides stat bonuses (+5% HP, +3% DMG, +2% SPD) upon rebirth.
    - **Mission System**: 26 types of missions with tracking and rewards.
    - **Custom Items**: Over 50 custom items with unique effects.
    - **Economy System**: Secure transaction handling, anti-exploit measures, and Black Matter premium currency support.
    - **Shop System**: 17 comprehensive shop categories with 200+ items (weapons, food, building materials, rare items, armor, pets, boosters, cosmetics, special tools, keys, redstone, farming, alchemy, transport, decorations, rare blocks, and music). Fully functional buy/sell mechanics with economy integration.
- **UI/UX**: Custom GUIs for enchanting, shops, and upgrades are implemented with robust protection against inventory manipulation events.
- **Command Handling**: A unified `CommandHandler` manages over 40 plugin commands.
- **Error Handling**: Comprehensive null-safety checks and graceful fallbacks are implemented across the codebase.
- **Build Process**: Automated build workflow generates a shaded JAR (`SoulCraftPlugin-1.0.jar`) ready for deployment.

## External Dependencies
- **Spigot API**: `1.21-R0.1-SNAPSHOT` for Minecraft server interaction.
- **Maven Shade Plugin**: Used for dependency shading during the build process.

## Replit Environment Setup
**Last Verified**: November 2, 2025

### Environment Configuration
- **Java Runtime**: Java 19 (GraalVM CE 22.3.1) installed via `java-graalvm22.3` module
- **Build Tool**: Apache Maven 3.8.6 (included with Java module)
- **System Packages**: unzip (for extracting project files)

### Workflow Configuration
- **Build Workflow**: Configured to run `./build.sh` which compiles the plugin using Maven
- The workflow executes `mvn clean package -DskipTests` to build the shaded JAR
- Build output: `target/SoulCraftPlugin-1.0.jar` (622 KB shaded JAR ready for Minecraft server deployment)
- Build time: ~40 seconds (first build with dependency download), ~10-15 seconds (subsequent builds)

### Project Structure
- All source files located in `src/main/java/com/soulcraft/`
- Configuration files in `src/main/resources/`
- Build artifacts generated in `target/` directory
- `.gitignore` configured for Maven/Java projects

### Usage
1. Click the **Run** button to build the plugin
2. Download `target/SoulCraftPlugin-1.0.jar` after build completes
3. Install JAR file in your Minecraft server's `plugins/` folder

### Notes
- This is a Minecraft plugin project (no web frontend)
- The plugin requires a Spigot/Paper 1.21 server to run
- Build process verified and working in Replit environment