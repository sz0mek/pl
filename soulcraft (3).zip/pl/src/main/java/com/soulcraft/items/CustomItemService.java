package com.soulcraft.items;

import com.soulcraft.persistence.DataStore;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.*;

/**
 * Complete custom items system with 50+ items
 */
public class CustomItemService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final Map<String, CustomItemConfig> itemConfigs;
    private final NamespacedKey customItemKey;
    
    public CustomItemService(Plugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.itemConfigs = new HashMap<>();
        this.customItemKey = new NamespacedKey(plugin, "custom_item");
        
        loadAllItems();
    }
    
    private void loadAllItems() {
        // Weapons
        registerWeapon("void_blade", Material.NETHERITE_SWORD, "§5§lVoid Blade", 15.0, 1.6, "§7Cuts through reality itself", "LEGENDARY");
        registerWeapon("soul_reaper", Material.NETHERITE_SWORD, "§c§lSoul Reaper", 14.0, 1.6, "§7Steals souls from enemies", "EPIC");
        registerWeapon("chaos_hammer", Material.NETHERITE_AXE, "§6§lChaos Hammer", 16.0, 1.2, "§7Smashes with chaos energy", "LEGENDARY");
        registerWeapon("dark_staff", Material.BLAZE_ROD, "§5§lDark Staff", 10.0, 1.8, "§7Channels dark magic", "EPIC");
        registerWeapon("phantom_bow", Material.BOW, "§9§lPhantom Bow", 12.0, 1.0, "§7Shoots spectral arrows", "RARE");
        
        // Armor
        registerArmor("eternal_chestplate", Material.NETHERITE_CHESTPLATE, "§6§lEternal Chestplate", 10.0, 0.3, "§7Never breaks", "LEGENDARY");
        registerArmor("shadow_helmet", Material.NETHERITE_HELMET, "§8§lShadow Helmet", 4.0, 0.2, "§7Grants night vision", "EPIC");
        registerArmor("soul_boots", Material.NETHERITE_BOOTS, "§5§lSoul Boots", 4.0, 0.2, "§7Increased speed", "EPIC");
        registerArmor("void_leggings", Material.NETHERITE_LEGGINGS, "§5§lVoid Leggings", 7.0, 0.25, "§7Void protection", "EPIC");
        
        // Tools
        registerTool("soul_pickaxe", Material.NETHERITE_PICKAXE, "§d§lSoul Pickaxe", 8.0, "§7Mines faster with souls", "RARE");
        registerTool("void_shovel", Material.NETHERITE_SHOVEL, "§5§lVoid Shovel", 7.0, "§7Digs through anything", "RARE");
        registerTool("ender_axe", Material.NETHERITE_AXE, "§9§lEnder Axe", 10.0, "§7Teleports trees", "EPIC");
        
        // Consumables
        registerConsumable("soul_potion", Material.POTION, "§d§lSoul Potion", "§7Restores 10 hearts", "UNCOMMON");
        registerConsumable("experience_book", Material.BOOK, "§e§lExperience Book", "§7+1000 XP", "COMMON");
        registerConsumable("regeneration_orb", Material.ENDER_EYE, "§a§lRegeneration Orb", "§7+Regeneration II (5min)", "RARE");
        
        // Special Items
        registerSpecial("lucky_coin", Material.GOLD_NUGGET, "§6§lLucky Coin", "§7+25% loot chance", "RARE");
        registerSpecial("soul_compass", Material.COMPASS, "§5§lSoul Compass", "§7Points to nearest boss", "EPIC");
        registerSpecial("speed_crystal", Material.DIAMOND, "§b§lSpeed Crystal", "§7+Speed II permanent", "LEGENDARY");
        registerSpecial("strength_talisman", Material.NETHER_STAR, "§c§lStrength Talisman", "§7+Strength II permanent", "LEGENDARY");
        registerSpecial("teleportation_stone", Material.ENDER_PEARL, "§9§lTeleportation Stone", "§7Right-click to teleport", "EPIC");
        
        // Add more items to reach 50+
        addMoreWeapons();
        addMoreArmor();
        addMoreTools();
        addMoreConsumables();
        addMoreSpecialItems();
        addExtraItems();
    }
    
    private void addMoreWeapons() {
        registerWeapon("fire_sword", Material.DIAMOND_SWORD, "§c§lFire Sword", 10.0, 1.6, "§7Sets enemies ablaze", "RARE");
        registerWeapon("ice_blade", Material.DIAMOND_SWORD, "§b§lIce Blade", 10.0, 1.6, "§7Freezes enemies", "RARE");
        registerWeapon("thunder_axe", Material.DIAMOND_AXE, "§e§lThunder Axe", 12.0, 1.2, "§7Strikes with lightning", "EPIC");
        registerWeapon("poison_dagger", Material.IRON_SWORD, "§2§lPoison Dagger", 7.0, 2.0, "§7Poisons on hit", "UNCOMMON");
        registerWeapon("holy_mace", Material.IRON_AXE, "§f§lHoly Mace", 11.0, 1.3, "§7Smites undead", "RARE");
        registerWeapon("cursed_scythe", Material.IRON_HOE, "§8§lCursed Scythe", 9.0, 1.5, "§7Drains life", "EPIC");
        registerWeapon("dragon_fang", Material.DIAMOND_SWORD, "§6§lDragon Fang", 13.0, 1.6, "§7Dragon's fury", "LEGENDARY");
        registerWeapon("crystal_spear", Material.TRIDENT, "§b§lCrystal Spear", 11.0, 1.4, "§7Pierces armor", "RARE");
    }
    
    private void addMoreArmor() {
        registerArmor("dragon_scales", Material.DIAMOND_CHESTPLATE, "§6§lDragon Scales", 8.0, 0.25, "§7Fire resistance", "LEGENDARY");
        registerArmor("frost_helmet", Material.DIAMOND_HELMET, "§b§lFrost Helmet", 3.0, 0.15, "§7Ice immunity", "RARE");
        registerArmor("demon_boots", Material.DIAMOND_BOOTS, "§c§lDemon Boots", 3.0, 0.15, "§7Lava walking", "EPIC");
        registerArmor("angel_wings", Material.ELYTRA, "§f§lAngel Wings", 0.0, 0.0, "§7Infinite flight", "LEGENDARY");
        registerArmor("warrior_plate", Material.IRON_CHESTPLATE, "§7§lWarrior Plate", 6.0, 0.2, "§7Basic protection", "COMMON");
    }
    
    private void addMoreTools() {
        registerTool("fortune_pickaxe", Material.DIAMOND_PICKAXE, "§6§lFortune Pickaxe", 6.0, "§7Fortune V", "EPIC");
        registerTool("silk_shovel", Material.DIAMOND_SHOVEL, "§f§lSilk Shovel", 5.0, "§7Silk Touch V", "RARE");
        registerTool("lumberjack_axe", Material.DIAMOND_AXE, "§2§lLumberjack Axe", 8.0, "§7Cuts entire trees", "RARE");
        registerTool("multi_tool", Material.NETHERITE_PICKAXE, "§5§lMulti Tool", 7.0, "§7All-in-one tool", "LEGENDARY");
    }
    
    private void addMoreConsumables() {
        registerConsumable("health_potion_large", Material.POTION, "§c§lLarge Health Potion", "§7+20 hearts instant", "RARE");
        registerConsumable("mana_crystal", Material.LAPIS_LAZULI, "§9§lMana Crystal", "§7Restore all cooldowns", "EPIC");
        registerConsumable("xp_bottle", Material.EXPERIENCE_BOTTLE, "§e§lXP Bottle", "§7+500 XP", "UNCOMMON");
        registerConsumable("soul_fragment", Material.GHAST_TEAR, "§5§lSoul Fragment", "§7+1000 souls", "RARE");
        registerConsumable("resurrection_totem", Material.TOTEM_OF_UNDYING, "§6§lResurrection Totem", "§7One free respawn", "LEGENDARY");
    }
    
    private void addMoreSpecialItems() {
        registerSpecial("pet_egg_wolf", Material.EGG, "§6§lWolf Egg", "§7Summon a wolf pet", "UNCOMMON");
        registerSpecial("pet_egg_cat", Material.EGG, "§d§lCat Egg", "§7Summon a cat pet", "UNCOMMON");
        registerSpecial("pet_egg_dragon", Material.DRAGON_EGG, "§5§lDragon Egg", "§7Summon a dragon pet", "LEGENDARY");
        registerSpecial("dungeon_key_easy", Material.TRIPWIRE_HOOK, "§a§lEasy Dungeon Key", "§7Access easy dungeons", "COMMON");
        registerSpecial("dungeon_key_hard", Material.TRIPWIRE_HOOK, "§c§lHard Dungeon Key", "§7Access hard dungeons", "RARE");
        registerSpecial("dungeon_key_nightmare", Material.TRIPWIRE_HOOK, "§5§lNightmare Key", "§7Access nightmare dungeons", "LEGENDARY");
        registerSpecial("clan_banner", Material.WHITE_BANNER, "§b§lClan Banner", "§7Create a clan", "EPIC");
        registerSpecial("warp_scroll", Material.PAPER, "§9§lWarp Scroll", "§7Set custom warp", "UNCOMMON");
        registerSpecial("boss_summon_token", Material.NETHER_STAR, "§c§lBoss Summon Token", "§7Summon a boss", "LEGENDARY");
        registerSpecial("enchant_crystal", Material.PRISMARINE_CRYSTALS, "§b§lEnchant Crystal", "§7Add random enchant", "RARE");
        registerSpecial("protection_amulet", Material.SHIELD, "§e§lProtection Amulet", "§7Absorb one fatal hit", "EPIC");
        registerSpecial("soul_anchor", Material.LODESTONE, "§5§lSoul Anchor", "§7Prevent death once", "LEGENDARY");
        registerSpecial("treasure_map", Material.MAP, "§6§lTreasure Map", "§7Find hidden treasure", "RARE");
        registerSpecial("magnet_charm", Material.IRON_INGOT, "§7§lMagnet Charm", "§7Auto-collect items", "UNCOMMON");
        registerSpecial("flight_feather", Material.FEATHER, "§f§lFlight Feather", "§7+5 min flight", "EPIC");
        registerSpecial("void_crystal", Material.END_CRYSTAL, "§5§lVoid Crystal", "§7Teleport to void", "LEGENDARY");
        registerSpecial("phoenix_down", Material.FIRE_CHARGE, "§c§lPhoenix Down", "§7Auto-revive on death", "MYTHIC");
    }
    
    private void addExtraItems() {
        registerWeapon("shadow_dagger", Material.IRON_SWORD, "§8§lShadow Dagger", 8.0, 2.4, "§7Strike from shadows", "RARE");
        registerWeapon("storm_blade", Material.DIAMOND_SWORD, "§b§lStorm Blade", 11.0, 1.6, "§7Call down lightning", "EPIC");
        registerWeapon("blood_axe", Material.IRON_AXE, "§c§lBlood Axe", 10.0, 1.3, "§7Lifesteal on hit", "RARE");
        
        registerArmor("mage_robes", Material.LEATHER_CHESTPLATE, "§9§lMage Robes", 4.0, 0.1, "§7Boost magic power", "RARE");
        registerArmor("tank_armor", Material.IRON_CHESTPLATE, "§7§lTank Armor", 7.0, 0.25, "§7Maximum defense", "UNCOMMON");
        
        registerTool("auto_fisher", Material.FISHING_ROD, "§9§lAuto Fisher", 5.0, "§7Automatic fishing", "RARE");
        
        registerConsumable("energy_drink", Material.HONEY_BOTTLE, "§e§lEnergy Drink", "§7+Speed IV (2min)", "UNCOMMON");
        registerConsumable("soul_shard", Material.AMETHYST_SHARD, "§5§lSoul Shard", "§7+500 souls", "UNCOMMON");
        
        registerSpecial("double_xp_token", Material.SUNFLOWER, "§e§lDouble XP Token", "§72x XP for 1 hour", "EPIC");
        registerSpecial("rare_loot_token", Material.EMERALD, "§a§lRare Loot Token", "§7Better drops (30min)", "EPIC");
    }
    
    private void registerWeapon(String id, Material material, String name, double damage, double attackSpeed, String lore, String rarity) {
        CustomItemConfig config = new CustomItemConfig();
        config.id = id;
        config.material = material;
        config.name = name;
        config.lore = Arrays.asList(lore, "", "§7Damage: §c+" + damage, "§7Attack Speed: §e" + attackSpeed, "", getRarityColor(rarity) + "§l" + rarity);
        config.type = ItemType.WEAPON;
        config.rarity = rarity;
        config.damage = damage;
        config.attackSpeed = attackSpeed;
        itemConfigs.put(id, config);
    }
    
    private void registerArmor(String id, Material material, String name, double armor, double toughness, String lore, String rarity) {
        CustomItemConfig config = new CustomItemConfig();
        config.id = id;
        config.material = material;
        config.name = name;
        config.lore = Arrays.asList(lore, "", "§7Armor: §9+" + armor, "§7Toughness: §9+" + toughness, "", getRarityColor(rarity) + "§l" + rarity);
        config.type = ItemType.ARMOR;
        config.rarity = rarity;
        config.armor = armor;
        config.toughness = toughness;
        itemConfigs.put(id, config);
    }
    
    private void registerTool(String id, Material material, String name, double efficiency, String lore, String rarity) {
        CustomItemConfig config = new CustomItemConfig();
        config.id = id;
        config.material = material;
        config.name = name;
        config.lore = Arrays.asList(lore, "", "§7Efficiency: §a+" + efficiency, "", getRarityColor(rarity) + "§l" + rarity);
        config.type = ItemType.TOOL;
        config.rarity = rarity;
        config.efficiency = efficiency;
        itemConfigs.put(id, config);
    }
    
    private void registerConsumable(String id, Material material, String name, String lore, String rarity) {
        CustomItemConfig config = new CustomItemConfig();
        config.id = id;
        config.material = material;
        config.name = name;
        config.lore = Arrays.asList(lore, "", "§e§lRIGHT-CLICK TO USE", "", getRarityColor(rarity) + "§l" + rarity);
        config.type = ItemType.CONSUMABLE;
        config.rarity = rarity;
        itemConfigs.put(id, config);
    }
    
    private void registerSpecial(String id, Material material, String name, String lore, String rarity) {
        CustomItemConfig config = new CustomItemConfig();
        config.id = id;
        config.material = material;
        config.name = name;
        config.lore = Arrays.asList(lore, "", getRarityColor(rarity) + "§l" + rarity);
        config.type = ItemType.SPECIAL;
        config.rarity = rarity;
        itemConfigs.put(id, config);
    }
    
    private String getRarityColor(String rarity) {
        switch (rarity.toUpperCase()) {
            case "COMMON": return "§f";
            case "UNCOMMON": return "§a";
            case "RARE": return "§9";
            case "EPIC": return "§5";
            case "LEGENDARY": return "§6";
            case "MYTHIC": return "§c";
            default: return "§7";
        }
    }
    
    /**
     * Create custom item
     */
    public ItemStack createItem(String itemId) {
        return createItem(itemId, 1);
    }
    
    public ItemStack createItem(String itemId, int amount) {
        CustomItemConfig config = itemConfigs.get(itemId);
        if (config == null) return null;
        
        ItemStack item = new ItemStack(config.material, amount);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(config.name);
        meta.setLore(config.lore);
        meta.setUnbreakable(config.type == ItemType.SPECIAL || config.rarity.equals("LEGENDARY"));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ENCHANTS);
        
        // Add custom item identifier
        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(customItemKey, PersistentDataType.STRING, itemId);
        
        // Apply stats based on type
        if (config.type == ItemType.WEAPON && config.damage > 0) {
            AttributeModifier damageModifier = new AttributeModifier(UUID.randomUUID(), "generic.attack_damage",
                config.damage - 1, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlot.HAND);
            meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, damageModifier);
            
            AttributeModifier speedModifier = new AttributeModifier(UUID.randomUUID(), "generic.attack_speed",
                config.attackSpeed - 4, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlot.HAND);
            meta.addAttributeModifier(Attribute.GENERIC_ATTACK_SPEED, speedModifier);
        }
        
        if (config.type == ItemType.ARMOR && config.armor > 0) {
            EquipmentSlot slot = getArmorSlot(config.material);
            AttributeModifier armorModifier = new AttributeModifier(UUID.randomUUID(), "generic.armor",
                config.armor, AttributeModifier.Operation.ADD_NUMBER, slot);
            meta.addAttributeModifier(Attribute.GENERIC_ARMOR, armorModifier);
            
            if (config.toughness > 0) {
                AttributeModifier toughnessModifier = new AttributeModifier(UUID.randomUUID(), "generic.armor_toughness",
                    config.toughness, AttributeModifier.Operation.ADD_NUMBER, slot);
                meta.addAttributeModifier(Attribute.GENERIC_ARMOR_TOUGHNESS, toughnessModifier);
            }
        }
        
        // Add enchantment glow for rare+ items
        if (!config.rarity.equals("COMMON") && !config.rarity.equals("UNCOMMON")) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        }
        
        item.setItemMeta(meta);
        return item;
    }
    
    /**
     * Check if item is custom item
     */
    public boolean isCustomItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer();
        return container.has(customItemKey, PersistentDataType.STRING);
    }
    
    /**
     * Get custom item ID
     */
    public String getCustomItemId(ItemStack item) {
        if (!isCustomItem(item)) return null;
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer();
        return container.get(customItemKey, PersistentDataType.STRING);
    }
    
    /**
     * Get armor slot from material
     */
    private EquipmentSlot getArmorSlot(Material material) {
        String name = material.name();
        if (name.contains("HELMET")) return EquipmentSlot.HEAD;
        if (name.contains("CHESTPLATE")) return EquipmentSlot.CHEST;
        if (name.contains("LEGGINGS")) return EquipmentSlot.LEGS;
        if (name.contains("BOOTS")) return EquipmentSlot.FEET;
        return EquipmentSlot.HAND;
    }
    
    /**
     * Get all items
     */
    public Map<String, CustomItemConfig> getAllItems() {
        return itemConfigs;
    }
    
    /**
     * Get items by type
     */
    public List<CustomItemConfig> getItemsByType(ItemType type) {
        List<CustomItemConfig> items = new ArrayList<>();
        for (CustomItemConfig config : itemConfigs.values()) {
            if (config.type == type) {
                items.add(config);
            }
        }
        return items;
    }
    
    /**
     * Get item price in souls based on rarity
     */
    public long getItemPrice(String itemId) {
        CustomItemConfig config = itemConfigs.get(itemId);
        if (config == null) return 0;
        
        int basePrice = switch (config.rarity.toUpperCase()) {
            case "COMMON" -> 100;
            case "UNCOMMON" -> 500;
            case "RARE" -> 2000;
            case "EPIC" -> 10000;
            case "LEGENDARY" -> 50000;
            case "MYTHIC" -> 250000;
            default -> 100;
        };
        
        double multiplier = switch (config.type) {
            case WEAPON -> 1.5;
            case ARMOR -> 1.3;
            case TOOL -> 1.2;
            case CONSUMABLE -> 0.8;
            case SPECIAL -> 2.0;
        };
        
        return (long) (basePrice * multiplier);
    }
    
    /**
     * Get item sell price (50% of purchase price)
     */
    public long getItemSellPrice(String itemId) {
        return getItemPrice(itemId) / 2;
    }
    
    /**
     * Get item value based on ItemStack
     */
    public long getItemValue(ItemStack item) {
        String itemId = getCustomItemId(item);
        if (itemId == null) return 0;
        return getItemSellPrice(itemId) * item.getAmount();
    }
    
    /**
     * Custom item configuration
     */
    public static class CustomItemConfig {
        public String id;
        public Material material;
        public String name;
        public List<String> lore;
        public ItemType type;
        public String rarity;
        public double damage;
        public double attackSpeed;
        public double armor;
        public double toughness;
        public double efficiency;
    }
    
    /**
     * Item types
     */
    public enum ItemType {
        WEAPON,
        ARMOR,
        TOOL,
        CONSUMABLE,
        SPECIAL
    }
}
