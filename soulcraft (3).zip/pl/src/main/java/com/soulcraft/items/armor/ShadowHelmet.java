package com.soulcraft.items.armor;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class ShadowHelmet extends CustomItem {
    public ShadowHelmet(SoulCraftPlugin plugin) {
        super(
            "shadow_helmet",
            "§8§lHełm Cienia",
            Material.NETHERITE_HELMET,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §8Pancerz Mroku   §7│",
                "§7│ §fBonusy:          §7│",
                "§7│ §7Noktowizja      §7│",
                "§7│ §8Niewidzialność  §7│",
                "§7│ §5+15 Ochrony     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §8Ukrycie w cieniu",
                "§d⚔ Model: 2001"
            ),
            2001
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0));
            player.sendMessage("§8§l✦ Stajesz się cieniem!");
            event.setCancelled(true);
        }
    }
}
