package com.soulcraft.items.tools;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class SoulPickaxe extends CustomItem {
    public SoulPickaxe(SoulCraftPlugin plugin) {
        super(
            "soul_pickaxe",
            "§d§lKilof Dusz",
            Material.NETHERITE_PICKAXE,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §dMagiczny Kilof  §7│",
                "§7│ §fZdolności:       §7│",
                "§7│ §eSpawny 3x3      §7│",
                "§7│ §aAutosmelt       §7│",
                "§7│ §5+50% doświadcz. §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Specjalne: §dDusze kopiących",
                "§d⚔ Model: 3001"
            ),
            3001
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // 3x3 mining handled by block break events
    }
}
