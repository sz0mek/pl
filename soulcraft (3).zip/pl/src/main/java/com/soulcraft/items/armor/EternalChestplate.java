package com.soulcraft.items.armor;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class EternalChestplate extends CustomItem {
    public EternalChestplate(SoulCraftPlugin plugin) {
        super(
            "eternal_chestplate",
            "§6§lWieczna Zbroja",
            Material.NETHERITE_CHESTPLATE,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §6Niezniszczalna  §7│",
                "§7│ §fBonusy:          §7│",
                "§7│ §eRegeneracja HP  §7│",
                "§7│ §aAbsorpcja       §7│",
                "§7│ §6+20 Ochrony     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §6Wieczna regeneracja",
                "§d⚔ Model: 2002"
            ),
            2002
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Passive regeneration handled elsewhere
    }
}
