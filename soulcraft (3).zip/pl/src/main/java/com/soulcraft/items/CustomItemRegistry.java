package com.soulcraft.items;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CustomItemRegistry implements Listener {
    private static CustomItemRegistry instance;
    private final Map<String, CustomItem> items = new HashMap<>();
    private final SoulCraftPlugin plugin;

    private CustomItemRegistry(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        registerAllItems();
    }

    public static CustomItemRegistry getInstance(SoulCraftPlugin plugin) {
        if (instance == null) {
            instance = new CustomItemRegistry(plugin);
        }
        return instance;
    }

    private void registerAllItems() {
        // Zarejestruj wszystkie 20 custom itemów tutaj
        register(new com.soulcraft.items.weapons.SoulReaper(plugin));
        register(new com.soulcraft.items.weapons.VoidBlade(plugin));
        register(new com.soulcraft.items.weapons.ChaosHammer(plugin));
        register(new com.soulcraft.items.weapons.PhantomBow(plugin));
        register(new com.soulcraft.items.weapons.DarkStaff(plugin));
        
        register(new com.soulcraft.items.armor.ShadowHelmet(plugin));
        register(new com.soulcraft.items.armor.EternalChestplate(plugin));
        register(new com.soulcraft.items.armor.VoidLeggings(plugin));
        register(new com.soulcraft.items.armor.SoulBoots(plugin));
        
        register(new com.soulcraft.items.tools.SoulPickaxe(plugin));
        register(new com.soulcraft.items.tools.EnderAxe(plugin));
        register(new com.soulcraft.items.tools.VoidShovel(plugin));
        
        register(new com.soulcraft.items.consumables.SoulPotion(plugin));
        register(new com.soulcraft.items.consumables.RegenerationOrb(plugin));
        register(new com.soulcraft.items.consumables.ExperienceBook(plugin));
        
        register(new com.soulcraft.items.special.TeleportationStone(plugin));
        register(new com.soulcraft.items.special.LuckyCoin(plugin));
        register(new com.soulcraft.items.special.SoulCompass(plugin));
    }

    public void register(CustomItem item) {
        items.put(item.getId(), item);
    }

    public CustomItem getItem(String id) {
        return items.get(id);
    }

    public ItemStack createItem(String id, int amount) {
        CustomItem item = items.get(id);
        if (item == null) {
            return null;
        }
        return item.create(amount);
    }

    public CustomItem getItemFromStack(ItemStack stack) {
        for (CustomItem item : items.values()) {
            if (item.isThisItem(stack)) {
                return item;
            }
        }
        return null;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (item == null) {
            return;
        }

        CustomItem customItem = getItemFromStack(item);
        if (customItem != null) {
            customItem.onUse(event.getPlayer(), event);
        }
    }

    @EventHandler
    public void onKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null) {
            ItemStack weapon = killer.getInventory().getItemInMainHand();
            CustomItem customItem = getItemFromStack(weapon);
            if (customItem != null) {
                customItem.onKill(killer, event.getEntity());
            }
        }
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            ItemStack weapon = attacker.getInventory().getItemInMainHand();
            CustomItem customItem = getItemFromStack(weapon);
            if (customItem != null) {
                customItem.onHit(attacker, event.getEntity());
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        ItemStack item = event.getItemDrop().getItemStack();
        CustomItem customItem = getItemFromStack(item);
        
        if (customItem != null) {
            if (!event.getPlayer().isSneaking()) {
                event.setCancelled(true);
                event.getPlayer().sendMessage("§c§l✖ Nie możesz wyrzucić tego przedmiotu! (Shift+Q aby wyrzucić)");
            } else {
                event.getPlayer().sendMessage("§e§l⚠ Uwaga! Wyrzucasz rzadki przedmiot!");
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Iterator<ItemStack> iterator = event.getDrops().iterator();
        
        int customItemsKept = 0;
        while (iterator.hasNext()) {
            ItemStack item = iterator.next();
            CustomItem customItem = getItemFromStack(item);
            
            if (customItem != null && customItem.getId().contains("legendary") || 
                (customItem != null && customItem.getId().contains("mythic"))) {
                iterator.remove();
                
                if (player.getInventory().firstEmpty() != -1) {
                    player.getInventory().addItem(item);
                } else {
                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                }
                customItemsKept++;
            }
        }
        
        if (customItemsKept > 0) {
            player.sendMessage("§6§l✦ Zachowano " + customItemsKept + " rzadkich przedmiotów!");
        }
    }

    public Map<String, CustomItem> getAllItems() {
        return new HashMap<>(items);
    }
}
