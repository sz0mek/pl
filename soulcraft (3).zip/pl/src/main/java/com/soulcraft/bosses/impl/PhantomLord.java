package com.soulcraft.bosses.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.bosses.CustomBoss;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PhantomLord extends CustomBoss {
    private final SoulCraftPlugin plugin;

    public PhantomLord(SoulCraftPlugin plugin) {
        super(
            "phantom_lord",
            "§b§l✦ Pan Widm ✦",
            EntityType.PHANTOM,
            450.0,
            16.0,
            5500
        );
        this.plugin = plugin;
    }

    @Override
    public void onSpawn(LivingEntity boss) {
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
        boss.getWorld().spawnParticle(Particle.CLOUD, boss.getLocation(), 150, 3, 3, 3);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_PHANTOM_AMBIENT, 2.0f, 0.7f);
    }

    @Override
    public void onTick(LivingEntity boss) {
        // Phantom trail
        if (boss.getTicksLived() % 3 == 0) {
            boss.getWorld().spawnParticle(Particle.CLOUD, boss.getLocation(), 5, 0.3, 0.3, 0.3);
        }
        
        // Summon phantom minions
        if (boss.getTicksLived() % 200 == 0 && Math.random() < 0.3) {
            boss.getWorld().spawnEntity(boss.getLocation(), EntityType.PHANTOM);
            boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_PHANTOM_SWOOP, 1.0f, 1.2f);
        }
        
        // Teleport randomly
        if (boss.getTicksLived() % 100 == 0 && Math.random() < 0.2) {
            boss.getNearbyEntities(10, 10, 10).stream()
                .filter(e -> e instanceof Player)
                .findFirst()
                .ifPresent(player -> {
                    boss.teleport(player.getLocation().add(
                        Math.random() * 6 - 3,
                        2,
                        Math.random() * 6 - 3
                    ));
                    boss.getWorld().spawnParticle(Particle.PORTAL, boss.getLocation(), 30);
                });
        }
    }

    @Override
    public void onDeath(LivingEntity boss, Player killer) {
        boss.getWorld().spawnParticle(Particle.EXPLOSION, boss.getLocation(), 100, 2, 2, 2);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_PHANTOM_DEATH, 2.0f, 0.5f);
        
        // Drop phantom items
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("phantom_bow", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("teleportation_stone", 2)
        );
    }

    @Override
    public void onAttack(LivingEntity boss, Entity target) {
        if (target instanceof Player player) {
            // Phantom curse
            player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 60, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2));
            boss.getWorld().playSound(target.getLocation(), Sound.ENTITY_PHANTOM_BITE, 1.0f, 0.8f);
        }
    }
}
