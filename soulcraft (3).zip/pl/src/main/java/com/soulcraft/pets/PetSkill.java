package com.soulcraft.pets;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.List;

public class PetSkill {
    private final String name;
    private final int levelRequired;
    private final long cooldown;
    private final SkillType type;
    
    public PetSkill(String name, int levelRequired, long cooldown, SkillType type) {
        this.name = name;
        this.levelRequired = levelRequired;
        this.cooldown = cooldown;
        this.type = type;
    }
    
    public String getName() { return name; }
    public int getLevelRequired() { return levelRequired; }
    public long getCooldown() { return cooldown; }
    public SkillType getType() { return type; }
    
    public void execute(LivingEntity pet, Player owner, LivingEntity target) {
        switch (type) {
            case DAMAGE:
                executeDamage(pet, owner, target);
                break;
            case HEAL:
                executeHeal(pet, owner);
                break;
            case BUFF:
                executeBuff(pet, owner);
                break;
            case AOE:
                executeAOE(pet, owner);
                break;
            case UTILITY:
                executeUtility(pet, owner, target);
                break;
        }
        
        playSkillEffects(pet.getLocation());
    }
    
    private void executeDamage(LivingEntity pet, Player owner, LivingEntity target) {
        if (target == null) return;
        
        double damage = getDamageForSkill(name, pet);
        target.damage(damage, pet);
        
        Location loc = target.getLocation();
        loc.getWorld().spawnParticle(Particle.CRIT, loc, 20, 0.5, 0.5, 0.5, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
    }
    
    private void executeHeal(LivingEntity pet, Player owner) {
        double healAmount = getHealForSkill(name);
        
        owner.setHealth(Math.min(owner.getMaxHealth(), owner.getHealth() + healAmount));
        
        Location loc = owner.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART, loc.add(0, 1, 0), 10, 0.5, 0.5, 0.5, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
    }
    
    private void executeBuff(LivingEntity pet, Player owner) {
        switch (name) {
            case "Howl (Buff allies)":
                owner.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 1));
                owner.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
                break;
            case "Frenzy (Attack speed)":
                owner.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 200, 2));
                pet.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 2));
                break;
            case "Turtle Stance (+Defense)":
                owner.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 300, 2));
                pet.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 300, 1));
                break;
            case "Lucky Charm (+Loot)":
                owner.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 600, 2));
                break;
        }
        
        Location loc = pet.getLocation();
        loc.getWorld().spawnParticle(Particle.ENCHANT, loc, 30, 1, 1, 1, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1.0f, 1.2f);
    }
    
    private void executeAOE(LivingEntity pet, Player owner) {
        Location center = pet.getLocation();
        double radius = 5.0;
        double damage = getDamageForSkill(name, pet);
        
        List<Entity> nearby = pet.getNearbyEntities(radius, radius, radius);
        for (Entity entity : nearby) {
            if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                LivingEntity target = (LivingEntity) entity;
                target.damage(damage, pet);
            }
        }
        
        center.getWorld().spawnParticle(Particle.EXPLOSION, center, 5, 2, 0.5, 2, 0.1);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
    }
    
    private void executeUtility(LivingEntity pet, Player owner, LivingEntity target) {
        switch (name) {
            case "Shadow Step (Teleport)":
                if (target != null) {
                    Location behindTarget = target.getLocation().subtract(target.getLocation().getDirection().multiply(2));
                    pet.teleport(behindTarget);
                    pet.getWorld().spawnParticle(Particle.CLOUD, pet.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
                }
                break;
            case "Wing Gust (Knockback)":
                List<Entity> nearby = pet.getNearbyEntities(4, 4, 4);
                for (Entity entity : nearby) {
                    if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                        Vector direction = entity.getLocation().subtract(pet.getLocation()).toVector().normalize();
                        entity.setVelocity(direction.multiply(2));
                    }
                }
                break;
            case "Dragon Roar (Fear)":
                List<Entity> feared = pet.getNearbyEntities(8, 8, 8);
                for (Entity entity : feared) {
                    if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                        LivingEntity le = (LivingEntity) entity;
                        le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 3));
                        le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1));
                    }
                }
                pet.getWorld().playSound(pet.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 2.0f, 0.8f);
                break;
        }
    }
    
    private double getDamageForSkill(String skillName, LivingEntity pet) {
        double baseDamage = pet.getAttribute(org.bukkit.attribute.Attribute.GENERIC_ATTACK_DAMAGE) != null 
            ? pet.getAttribute(org.bukkit.attribute.Attribute.GENERIC_ATTACK_DAMAGE).getValue() 
            : 5.0;
        
        double multiplier = 1.0;
        if (skillName.contains("Alpha Strike") || skillName.contains("Ultimate")) {
            multiplier = 3.0;
        } else if (skillName.contains("Inferno") || skillName.contains("Explosive")) {
            multiplier = 2.5;
        } else if (skillName.contains("Piercing") || skillName.contains("Heavy")) {
            multiplier = 1.5;
        }
        
        return baseDamage * multiplier;
    }
    
    private double getHealForSkill(String skillName) {
        if (skillName.contains("Divine Blessing")) {
            return 10.0;
        } else if (skillName.contains("Healing Aura")) {
            return 4.0;
        } else if (skillName.contains("Pollination")) {
            return 2.0;
        }
        return 3.0;
    }
    
    private void playSkillEffects(Location location) {
        location.getWorld().spawnParticle(Particle.ENCHANT, location.add(0, 1, 0), 15, 0.3, 0.3, 0.3, 0.1);
    }
    
    public enum SkillType {
        DAMAGE,
        HEAL,
        BUFF,
        AOE,
        UTILITY
    }
}
