package com.soulcraft.pets;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.persistence.PlayerData.PetData;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Complete pet system with 1-100 leveling, 10+ pet types, skills, feeding, and full AI
 */
public class PetService implements Listener {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final Map<String, PetTypeConfig> petTypes;
    private final Map<UUID, ActivePet> activePets;
    private final Map<UUID, Map<String, Long>> skillCooldowns;
    private final PetGUI petGUI;
    
    private final int MAX_LEVEL = 100;
    private final int BASE_XP = 100;
    private final double XP_SCALING = 1.15;
    
    public PetService(Plugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.petTypes = new HashMap<>();
        this.activePets = new HashMap<>();
        this.skillCooldowns = new HashMap<>();
        this.petGUI = new PetGUI(this, dataStore);
        
        loadPetTypes();
        startPetAITask();
        startHappinessDecayTask();
        
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        plugin.getServer().getPluginManager().registerEvents(petGUI, plugin);
    }
    
    public Plugin getPlugin() { return plugin; }
    public PetGUI getGUI() { return petGUI; }
    
    private void loadPetTypes() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        String[] types = {"wolf", "cat", "dragon", "phoenix", "skeleton", "zombie", "turtle", "rabbit", "bee", "fox"};
        
        for (String type : types) {
            String path = "pets.types." + type;
            PetTypeConfig config = new PetTypeConfig();
            
            config.id = type;
            config.name = balance.getString(path + ".name", type);
            config.baseDamage = balance.getDouble(path + ".base_damage");
            config.baseHealth = balance.getDouble(path + ".base_health");
            config.baseSpeed = balance.getDouble(path + ".base_speed");
            config.baseDefense = balance.getDouble(path + ".base_defense", 0);
            config.growthDamage = balance.getDouble(path + ".growth_damage");
            config.growthHealth = balance.getDouble(path + ".growth_health");
            config.growthDefense = balance.getDouble(path + ".growth_defense", 0);
            config.special = balance.getString(path + ".special", "");
            config.unlocksAtLevel = balance.getInt(path + ".unlocks_at_level", 1);
            
            petTypes.put(type, config);
        }
    }
    
    public int getUnlockLevel(String petType) {
        PetTypeConfig config = petTypes.get(petType);
        return config != null ? config.unlocksAtLevel : 1;
    }
    
    public long getRequiredXP(int level) {
        if (level >= MAX_LEVEL) return 0;
        return (long)(BASE_XP * Math.pow(XP_SCALING, level - 1));
    }
    
    public PetData getPetData(UUID playerId, String petType) {
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        PetData petData = playerData.getPet(petType);
        
        if (petData == null) {
            petData = new PetData();
            playerData.setPet(petType, petData);
        }
        
        return petData;
    }
    
    public void addPetXP(UUID playerId, String petType, long amount) {
        PetData petData = getPetData(playerId, petType);
        
        double happinessBonus = 1.0 + (petData.getHappiness() * 0.01);
        long bonusAmount = (long)(amount * happinessBonus);
        
        int oldLevel = petData.getLevel();
        petData.addExperience(bonusAmount);
        
        while (petData.getLevel() < MAX_LEVEL) {
            long required = getRequiredXP(petData.getLevel());
            if (petData.getExperience() >= required) {
                petData.setExperience(petData.getExperience() - required);
                petData.setLevel(petData.getLevel() + 1);
                
                checkEvolution(playerId, petType, petData);
                unlockSkills(petData);
            } else {
                break;
            }
        }
        
        int newLevel = petData.getLevel();
        if (newLevel > oldLevel) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§6§lPET LEVEL UP! §e" + petType + " §7is now level §e" + newLevel);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
                player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
                
                ActivePet activePet = activePets.get(playerId);
                if (activePet != null && activePet.type.equals(petType)) {
                    updatePetStats(activePet.entity, petType, petData);
                }
            }
        }
    }
    
    private void checkEvolution(UUID playerId, String petType, PetData petData) {
        int level = petData.getLevel();
        String newStage = null;
        
        if (level >= 100) {
            newStage = "Legendary";
        } else if (level >= 71) {
            newStage = "Ancient";
        } else if (level >= 41) {
            newStage = "Adult";
        } else if (level >= 21) {
            newStage = "Young";
        } else {
            newStage = "Baby";
        }
        
        if (newStage != null && !newStage.equals(petData.getEvolutionStage())) {
            petData.setEvolutionStage(newStage);
            
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§5§l✦ PET EVOLVED! §d" + petType + " §7→ " + getEvolutionColor(newStage) + newStage);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.0f);
                player.getWorld().strikeLightningEffect(player.getLocation());
                player.getWorld().spawnParticle(Particle.DRAGON_BREATH, player.getLocation(), 100, 2, 2, 2, 0.1);
                
                if (newStage.equals("Legendary")) {
                    Bukkit.broadcastMessage("§6§l✦✦✦ " + player.getName() + "'s " + petType + " REACHED LEGENDARY EVOLUTION! ✦✦✦");
                }
            }
        }
    }
    
    private void unlockSkills(PetData petData) {
        int level = petData.getLevel();
        
        if (level >= 1 && !petData.hasSkill("skill_1")) {
            petData.unlockSkill("skill_1");
        }
        if (level >= 25 && !petData.hasSkill("skill_2")) {
            petData.unlockSkill("skill_2");
        }
        if (level >= 50 && !petData.hasSkill("skill_3")) {
            petData.unlockSkill("skill_3");
        }
        if (level >= 75 && !petData.hasSkill("skill_4")) {
            petData.unlockSkill("skill_4");
        }
    }
    
    public boolean spawnPet(Player player, String petType) {
        UUID playerId = player.getUniqueId();
        
        if (activePets.containsKey(playerId)) {
            despawnPet(player);
        }
        
        PetTypeConfig config = petTypes.get(petType);
        if (config == null) {
            player.sendMessage("§c§lUnknown pet type!");
            return false;
        }
        
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        if (playerData.getLevel() < config.unlocksAtLevel) {
            player.sendMessage("§c§lRequires level " + config.unlocksAtLevel + " to unlock this pet!");
            return false;
        }
        
        PetData petData = getPetData(playerId, petType);
        
        LivingEntity entity = spawnPetEntity(player.getLocation(), petType);
        if (entity == null) {
            player.sendMessage("§c§lFailed to spawn pet!");
            return false;
        }
        
        updatePetStats(entity, petType, petData);
        updatePetName(entity, player, petType, petData);
        
        if (entity instanceof Tameable) {
            ((Tameable) entity).setTamed(true);
            ((Tameable) entity).setOwner(player);
        }
        
        entity.setRemoveWhenFarAway(false);
        entity.setPersistent(true);
        
        activePets.put(playerId, new ActivePet(entity, petType, petData));
        playerData.setActivePet(petType);
        
        player.sendMessage("§a§l✓ Spawned: " + getEvolutionColor(petData.getEvolutionStage()) + 
            (petData.getCustomName() != null ? petData.getCustomName() : config.name) + 
            " §7[Level " + petData.getLevel() + "]");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 0.5f, 1.5f);
        player.getWorld().spawnParticle(Particle.HEART, entity.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
        
        return true;
    }
    
    private LivingEntity spawnPetEntity(Location location, String petType) {
        World world = location.getWorld();
        
        switch (petType.toLowerCase()) {
            case "wolf":
                return world.spawn(location, Wolf.class);
            case "cat":
                return world.spawn(location, Cat.class);
            case "dragon":
                return world.spawn(location, EnderDragon.class);
            case "phoenix":
                return world.spawn(location, Blaze.class);
            case "skeleton":
                Skeleton skeleton = world.spawn(location, Skeleton.class);
                skeleton.getEquipment().setItemInMainHand(new ItemStack(Material.BOW));
                return skeleton;
            case "zombie":
                return world.spawn(location, Zombie.class);
            case "turtle":
                return world.spawn(location, Turtle.class);
            case "rabbit":
                return world.spawn(location, Rabbit.class);
            case "bee":
                return world.spawn(location, Bee.class);
            case "fox":
                return world.spawn(location, Fox.class);
            default:
                return null;
        }
    }
    
    private void updatePetStats(LivingEntity entity, String petType, PetData petData) {
        PetTypeConfig config = petTypes.get(petType);
        if (config == null) return;
        
        int level = petData.getLevel();
        
        double health = config.baseHealth + (config.growthHealth * level);
        double damage = config.baseDamage + (config.growthDamage * level);
        double speed = config.baseSpeed;
        double defense = config.baseDefense + (config.growthDefense * level);
        
        String evolution = petData.getEvolutionStage();
        double evolutionBonus = getEvolutionBonus(evolution);
        
        health *= (1 + evolutionBonus);
        damage *= (1 + evolutionBonus);
        
        if (entity.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(Math.min(health, 2048));
            entity.setHealth(Math.min(health, 2048));
        }
        
        if (entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(speed * 0.1);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_ARMOR) != null) {
            entity.getAttribute(Attribute.GENERIC_ARMOR).setBaseValue(defense * 20);
        }
        
        applyPetSpecial(entity, config.special, petData);
        applyEvolutionEffects(entity, evolution);
    }
    
    private double getEvolutionBonus(String evolution) {
        switch (evolution) {
            case "Young": return 0.15;
            case "Adult": return 0.35;
            case "Ancient": return 0.65;
            case "Legendary": return 1.0;
            default: return 0.0;
        }
    }
    
    private void applyPetSpecial(LivingEntity entity, String special, PetData petData) {
        if (special == null || special.isEmpty()) return;
        
        switch (special.toLowerCase()) {
            case "stealth_bonus":
                if (petData.getLevel() >= 50) {
                    entity.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
                }
                break;
            case "flight":
                if (petData.getLevel() >= 75) {
                    entity.setGravity(false);
                }
                break;
            case "undead_resilience":
                entity.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 1, false, false));
                break;
        }
    }
    
    private void applyEvolutionEffects(LivingEntity entity, String evolution) {
        if (evolution.equals("Legendary")) {
            entity.setGlowing(true);
            Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                if (!entity.isDead()) {
                    entity.getWorld().spawnParticle(Particle.END_ROD, entity.getLocation(), 2, 0.3, 0.3, 0.3, 0.01);
                }
            }, 0L, 10L);
        }
    }
    
    private void updatePetName(LivingEntity entity, Player owner, String petType, PetData petData) {
        String displayName = petData.getCustomName() != null ? petData.getCustomName() : capitalize(petType);
        String evolutionColor = getEvolutionColor(petData.getEvolutionStage());
        
        entity.setCustomName(evolutionColor + displayName + " §7[Lv." + petData.getLevel() + "] §f♥");
        entity.setCustomNameVisible(true);
    }
    
    private String getEvolutionColor(String stage) {
        switch (stage) {
            case "Baby": return "§f";
            case "Young": return "§a";
            case "Adult": return "§9";
            case "Ancient": return "§5";
            case "Legendary": return "§6§l";
            default: return "§7";
        }
    }
    
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    
    public void despawnPet(Player player) {
        UUID playerId = player.getUniqueId();
        ActivePet activePet = activePets.remove(playerId);
        
        if (activePet != null) {
            activePet.entity.getWorld().spawnParticle(Particle.CLOUD, activePet.entity.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
            activePet.entity.remove();
            player.sendMessage("§7Pet despawned.");
        }
        
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        playerData.setActivePet(null);
    }
    
    public void feedPet(Player player, ItemStack food) {
        UUID playerId = player.getUniqueId();
        ActivePet activePet = activePets.get(playerId);
        
        if (activePet == null) {
            player.sendMessage("§c§lYou don't have an active pet!");
            return;
        }
        
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        List<String> favoriteFoods = balance.getStringList("pets.feeding.favorite_foods." + activePet.type);
        
        int happinessGain = 0;
        if (favoriteFoods.contains(food.getType().name())) {
            happinessGain = balance.getInt("pets.feeding.happiness_gain.favorite", 20);
            player.sendMessage("§a§lYour pet loves this! §e+§e" + happinessGain + " happiness");
        } else {
            happinessGain = balance.getInt("pets.feeding.happiness_gain.normal", 10);
            player.sendMessage("§a§lPet fed! §e+" + happinessGain + " happiness");
        }
        
        activePet.petData.addHappiness(happinessGain);
        activePet.petData.setLastFed(System.currentTimeMillis());
        
        food.setAmount(food.getAmount() - 1);
        
        activePet.entity.getWorld().spawnParticle(Particle.HEART, activePet.entity.getLocation().add(0, 1, 0), 10, 0.5, 0.5, 0.5, 0.1);
        player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0f, 1.0f);
    }
    
    @EventHandler
    public void onPetInteract(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        Entity entity = event.getRightClicked();
        
        ActivePet activePet = activePets.get(player.getUniqueId());
        if (activePet != null && activePet.entity.equals(entity)) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            
            if (hand.getType().isEdible() || isFavoriteFood(hand.getType(), activePet.type)) {
                feedPet(player, hand);
                event.setCancelled(true);
            }
        }
    }
    
    private boolean isFavoriteFood(Material material, String petType) {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        List<String> favoriteFoods = balance.getStringList("pets.feeding.favorite_foods." + petType);
        return favoriteFoods.contains(material.name());
    }
    
    @EventHandler
    public void onPetDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        
        for (Map.Entry<UUID, ActivePet> entry : activePets.entrySet()) {
            if (entry.getValue().entity.equals(entity)) {
                UUID playerId = entry.getKey();
                Player player = Bukkit.getPlayer(playerId);
                ActivePet activePet = entry.getValue();
                
                if (activePet.petData.hasDeathProtection()) {
                    event.getDrops().clear();
                    event.setDroppedExp(0);
                    
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        entity.setHealth(entity.getMaxHealth() * 0.5);
                        entity.teleport(entity.getLocation().add(0, 1, 0));
                    });
                    
                    activePet.petData.setDeathProtection(false);
                    
                    if (player != null) {
                        player.sendMessage("§6§l✦ Death Protection activated! Your pet survived!");
                        player.playSound(player.getLocation(), Sound.BLOCK_BELL_USE, 1.0f, 1.0f);
                    }
                    
                    entity.getWorld().spawnParticle(Particle.FIREWORK, entity.getLocation(), 100, 1, 1, 1, 0.1);
                } else {
                    activePet.petData.incrementDeaths();
                    
                    if (player != null) {
                        player.sendMessage("§c§l✖ Your " + activePet.type + " died!");
                        player.playSound(player.getLocation(), Sound.ENTITY_WOLF_DEATH, 1.0f, 0.8f);
                    }
                    
                    activePets.remove(playerId);
                    
                    if (activePet.petData.getLevel() >= 50 && activePet.petData.hasSkill("skill_3")) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (player != null && player.isOnline()) {
                                spawnPet(player, activePet.type);
                                player.sendMessage("§5§l✦ Your pet revived itself!");
                            }
                        }, 100L);
                    }
                }
                break;
            }
        }
    }
    
    @EventHandler
    public void onPetDamaged(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof LivingEntity)) return;
        
        LivingEntity entity = (LivingEntity) event.getEntity();
        
        for (ActivePet activePet : activePets.values()) {
            if (activePet.entity.equals(entity)) {
                double reduction = 0;
                
                if (activePet.petData.getEvolutionStage().equals("Legendary")) {
                    reduction = 0.3;
                } else if (activePet.petData.getEvolutionStage().equals("Ancient")) {
                    reduction = 0.2;
                } else if (activePet.petData.getEvolutionStage().equals("Adult")) {
                    reduction = 0.1;
                }
                
                if (reduction > 0) {
                    event.setDamage(event.getDamage() * (1 - reduction));
                }
                break;
            }
        }
    }
    
    private void startPetAITask() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, ActivePet> entry : new HashMap<>(activePets).entrySet()) {
                UUID playerId = entry.getKey();
                ActivePet activePet = entry.getValue();
                
                Player owner = Bukkit.getPlayer(playerId);
                if (owner == null || !owner.isOnline()) {
                    activePet.entity.remove();
                    activePets.remove(playerId);
                    continue;
                }
                
                if (activePet.entity.isDead()) {
                    activePets.remove(playerId);
                    continue;
                }
                
                double distance = activePet.entity.getLocation().distance(owner.getLocation());
                if (distance > 20) {
                    activePet.entity.teleport(owner.getLocation());
                    activePet.entity.getWorld().spawnParticle(Particle.PORTAL, activePet.entity.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
                }
                
                if (activePet.entity instanceof Creature) {
                    Creature creature = (Creature) activePet.entity;
                    
                    LivingEntity currentTarget = creature.getTarget();
                    
                    if (currentTarget == null || currentTarget.isDead() || !currentTarget.isValid()) {
                        LivingEntity nearestEnemy = findNearestEnemy(activePet.entity, owner);
                        if (nearestEnemy != null) {
                            creature.setTarget(nearestEnemy);
                            useSkillIfReady(activePet, owner, nearestEnemy);
                        }
                    } else {
                        useSkillIfReady(activePet, owner, currentTarget);
                    }
                }
                
                if (activePet.petData.getEvolutionStage().equals("Legendary")) {
                    activePet.entity.getWorld().spawnParticle(Particle.ENCHANT, 
                        activePet.entity.getLocation(), 2, 0.3, 0.3, 0.3, 0.01);
                }
            }
        }, 20L, 20L);
    }
    
    private LivingEntity findNearestEnemy(LivingEntity pet, Player owner) {
        LivingEntity nearestEnemy = null;
        double nearestDistance = 15.0;
        
        for (Entity entity : pet.getNearbyEntities(15, 15, 15)) {
            if (entity instanceof LivingEntity && !(entity instanceof Player) && !(entity instanceof ArmorStand)) {
                LivingEntity livingEntity = (LivingEntity) entity;
                
                if (livingEntity instanceof Tameable) {
                    Tameable tameable = (Tameable) livingEntity;
                    if (tameable.isTamed() && tameable.getOwner() != null) {
                        continue;
                    }
                }
                
                double dist = pet.getLocation().distance(livingEntity.getLocation());
                if (dist < nearestDistance) {
                    nearestDistance = dist;
                    nearestEnemy = livingEntity;
                }
            }
        }
        
        return nearestEnemy;
    }
    
    private void useSkillIfReady(ActivePet activePet, Player owner, LivingEntity target) {
        if (!activePet.petData.getUnlockedSkills().isEmpty()) {
            Map<String, Long> cooldowns = skillCooldowns.computeIfAbsent(owner.getUniqueId(), k -> new HashMap<>());
            
            for (String skillId : activePet.petData.getUnlockedSkills()) {
                Long lastUsed = cooldowns.get(skillId);
                long cooldown = 10000;
                
                if (lastUsed == null || System.currentTimeMillis() - lastUsed > cooldown) {
                    PetSkill skill = createSkillFromId(skillId, activePet.petData.getLevel());
                    if (skill != null) {
                        skill.execute(activePet.entity, owner, target);
                        cooldowns.put(skillId, System.currentTimeMillis());
                        break;
                    }
                }
            }
        }
    }
    
    private PetSkill createSkillFromId(String skillId, int level) {
        PetSkill.SkillType type = PetSkill.SkillType.DAMAGE;
        
        if (skillId.contains("heal") || skillId.contains("aura")) {
            type = PetSkill.SkillType.HEAL;
        } else if (skillId.contains("buff") || skillId.contains("stance")) {
            type = PetSkill.SkillType.BUFF;
        } else if (skillId.contains("aoe") || skillId.contains("rain") || skillId.contains("explosion")) {
            type = PetSkill.SkillType.AOE;
        }
        
        return new PetSkill(skillId, level, 10000, type);
    }
    
    private void startHappinessDecayTask() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, ActivePet> entry : activePets.entrySet()) {
                ActivePet activePet = entry.getValue();
                
                long timeSinceLastFed = System.currentTimeMillis() - activePet.petData.getLastFed();
                long hoursSinceLastFed = timeSinceLastFed / (1000 * 60 * 60);
                
                if (hoursSinceLastFed > 0) {
                    int decay = (int)(hoursSinceLastFed * 5);
                    if (decay > 0) {
                        activePet.petData.addHappiness(-decay);
                        activePet.petData.setLastFed(System.currentTimeMillis());
                        
                        Player player = Bukkit.getPlayer(entry.getKey());
                        if (player != null && activePet.petData.getHappiness() < 20) {
                            player.sendMessage("§e§l⚠ Your pet is unhappy! Feed it to restore happiness.");
                        }
                    }
                }
            }
        }, 6000L, 6000L);
    }
    
    public void cleanup(UUID playerId) {
        ActivePet activePet = activePets.remove(playerId);
        if (activePet != null) {
            activePet.entity.remove();
        }
        skillCooldowns.remove(playerId);
    }
    
    public LivingEntity getActivePet(UUID playerId) {
        ActivePet activePet = activePets.get(playerId);
        return activePet != null ? activePet.entity : null;
    }
    
    public static class PetTypeConfig {
        public String id;
        public String name;
        public double baseDamage;
        public double baseHealth;
        public double baseSpeed;
        public double baseDefense;
        public double growthDamage;
        public double growthHealth;
        public double growthDefense;
        public String special;
        public int unlocksAtLevel;
    }
    
    private static class ActivePet {
        public LivingEntity entity;
        public String type;
        public PetData petData;
        
        public ActivePet(LivingEntity entity, String type, PetData petData) {
            this.entity = entity;
            this.type = type;
            this.petData = petData;
        }
    }
}
