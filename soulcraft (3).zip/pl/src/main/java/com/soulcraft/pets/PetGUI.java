package com.soulcraft.pets;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.persistence.PlayerData.PetData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class PetGUI implements Listener {
    private final PetService petService;
    private final DataStore dataStore;
    
    public PetGUI(PetService petService, DataStore dataStore) {
        this.petService = petService;
        this.dataStore = dataStore;
    }
    
    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§6§lPet Management");
        
        PlayerData playerData = dataStore.loadPlayerData(player.getUniqueId());
        Map<String, PetData> pets = playerData.getPets();
        
        String[] petTypes = {"wolf", "cat", "dragon", "phoenix", "skeleton", "zombie", "turtle", "rabbit", "bee", "fox"};
        
        int slot = 10;
        for (String petType : petTypes) {
            ItemStack item = createPetIcon(petType, pets.get(petType), playerData);
            inv.setItem(slot, item);
            slot++;
            if (slot == 17) slot = 19;
            if (slot == 26) slot = 28;
        }
        
        ItemStack feedItem = new ItemStack(Material.COOKED_BEEF);
        ItemMeta feedMeta = feedItem.getItemMeta();
        feedMeta.setDisplayName("§a§lFeed Active Pet");
        feedMeta.setLore(Arrays.asList(
            "§7Click with food in hand",
            "§7to feed your pet",
            "§e+Happiness, +XP Bonus"
        ));
        feedItem.setItemMeta(feedMeta);
        inv.setItem(48, feedItem);
        
        ItemStack renameItem = new ItemStack(Material.NAME_TAG);
        ItemMeta renameMeta = renameItem.getItemMeta();
        renameMeta.setDisplayName("§e§lRename Pet");
        renameMeta.setLore(Arrays.asList(
            "§7Type in chat to rename",
            "§7your active pet"
        ));
        renameItem.setItemMeta(renameMeta);
        inv.setItem(50, renameItem);
        
        ItemStack infoItem = new ItemStack(Material.BOOK);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName("§b§lPet Info");
        infoMeta.setLore(Arrays.asList(
            "§7Pets gain XP from:",
            "§e• Mob kills (10 XP)",
            "§e• Boss kills (100 XP)",
            "§e• Dungeons (150 XP)",
            "§e• Missions (50 XP)",
            "",
            "§7Evolution stages:",
            "§71-20: §fBaby",
            "§721-40: §aYoung",
            "§741-70: §9Adult",
            "§771-99: §5Ancient",
            "§7100: §6§lLegendary"
        ));
        infoItem.setItemMeta(infoMeta);
        inv.setItem(49, infoItem);
        
        player.openInventory(inv);
    }
    
    private ItemStack createPetIcon(String petType, PetData petData, PlayerData playerData) {
        Material material = getPetMaterial(petType);
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (petData == null) {
            meta.setDisplayName("§7" + capitalize(petType) + " §c[LOCKED]");
            int unlockLevel = petService.getUnlockLevel(petType);
            meta.setLore(Arrays.asList(
                "§cRequires level " + unlockLevel,
                "§7Your level: §e" + playerData.getLevel()
            ));
        } else {
            String displayName = petData.getCustomName() != null 
                ? petData.getCustomName() 
                : capitalize(petType);
            
            meta.setDisplayName(getEvolutionColor(petData.getEvolutionStage()) + displayName + 
                " §7[Lv." + petData.getLevel() + "]");
            
            List<String> lore = new ArrayList<>();
            lore.add("§7Evolution: " + getEvolutionColor(petData.getEvolutionStage()) + petData.getEvolutionStage());
            lore.add("§7Level: §e" + petData.getLevel() + " §7/ 100");
            
            long required = petService.getRequiredXP(petData.getLevel());
            int xpPercent = required > 0 ? (int)((petData.getExperience() / (double)required) * 100) : 100;
            lore.add("§7XP: §e" + petData.getExperience() + " §7/ §e" + required + " §7(" + xpPercent + "%)");
            
            lore.add("§7Happiness: " + getHappinessBar(petData.getHappiness()));
            lore.add("§7XP Bonus: §e+" + petData.getHappiness() + "%");
            lore.add("");
            lore.add("§7Skills: §e" + petData.getUnlockedSkills().size());
            lore.add("§7Deaths: §c" + petData.getDeaths());
            lore.add("");
            
            if (playerData.getActivePet() != null && playerData.getActivePet().equals(petType)) {
                lore.add("§a§l✓ ACTIVE");
                lore.add("§7Click to despawn");
            } else {
                lore.add("§eClick to spawn");
            }
            
            meta.setLore(lore);
        }
        
        item.setItemMeta(meta);
        return item;
    }
    
    private Material getPetMaterial(String petType) {
        switch (petType.toLowerCase()) {
            case "wolf": return Material.BONE;
            case "cat": return Material.COD;
            case "dragon": return Material.DRAGON_EGG;
            case "phoenix": return Material.BLAZE_ROD;
            case "skeleton": return Material.BOW;
            case "zombie": return Material.ROTTEN_FLESH;
            case "turtle": return Material.TURTLE_EGG;
            case "rabbit": return Material.RABBIT_FOOT;
            case "bee": return Material.HONEYCOMB;
            case "fox": return Material.SWEET_BERRIES;
            default: return Material.EGG;
        }
    }
    
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    
    private String getEvolutionColor(String stage) {
        switch (stage) {
            case "Baby": return "§f";
            case "Young": return "§a";
            case "Adult": return "§9";
            case "Ancient": return "§5";
            case "Legendary": return "§6§l";
            default: return "§7";
        }
    }
    
    private String getHappinessBar(int happiness) {
        int bars = happiness / 10;
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < 10; i++) {
            if (i < bars) {
                sb.append("§a█");
            } else {
                sb.append("§7█");
            }
        }
        
        sb.append(" §e").append(happiness).append("%");
        return sb.toString();
    }
    
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals("§6§lPet Management")) return;
        
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        
        String displayName = clicked.getItemMeta().getDisplayName();
        
        if (displayName.contains("[LOCKED]")) {
            player.sendMessage("§c§lThis pet is locked! Level up to unlock it.");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return;
        }
        
        if (displayName.contains("Feed") || displayName.contains("Rename") || displayName.contains("Info")) {
            return;
        }
        
        String petType = extractPetType(clicked.getType());
        if (petType != null) {
            PlayerData playerData = dataStore.loadPlayerData(player.getUniqueId());
            
            if (playerData.getActivePet() != null && playerData.getActivePet().equals(petType)) {
                petService.despawnPet(player);
                player.playSound(player.getLocation(), Sound.ENTITY_CHICKEN_EGG, 1.0f, 0.8f);
            } else {
                petService.spawnPet(player, petType);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
            }
            
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(petService.getPlugin(), () -> openMainMenu(player), 1L);
        }
    }
    
    private String extractPetType(Material material) {
        switch (material) {
            case BONE: return "wolf";
            case COD: return "cat";
            case DRAGON_EGG: return "dragon";
            case BLAZE_ROD: return "phoenix";
            case BOW: return "skeleton";
            case ROTTEN_FLESH: return "zombie";
            case TURTLE_EGG: return "turtle";
            case RABBIT_FOOT: return "rabbit";
            case HONEYCOMB: return "bee";
            case SWEET_BERRIES: return "fox";
            default: return null;
        }
    }
}
