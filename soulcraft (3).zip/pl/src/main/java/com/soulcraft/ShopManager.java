package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class ShopManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Set<UUID> activeMainPlayers = new HashSet<>();
    private final Set<UUID> activeCategoryPlayers = new HashSet<>();
    private final Map<String, Map<Material, ShopItem>> categories = new LinkedHashMap<>();

    public ShopManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        initializeShop();
    }

    private void initializeShop() {
        // KATEGORIA 1: BROŃ I NARZĘDZIA
        Map<Material, ShopItem> weaponsTools = new LinkedHashMap<>();
        weaponsTools.put(Material.WOODEN_SWORD, new ShopItem(10, 8, "Podstawowy miecz"));
        weaponsTools.put(Material.STONE_SWORD, new ShopItem(25, 20, "Kamienny miecz"));
        weaponsTools.put(Material.IRON_SWORD, new ShopItem(100, 80, "Żelazny miecz"));
        weaponsTools.put(Material.GOLDEN_SWORD, new ShopItem(350, 280, "Złoty miecz"));
        weaponsTools.put(Material.DIAMOND_SWORD, new ShopItem(500, 400, "Potężny miecz diamentowy"));
        weaponsTools.put(Material.NETHERITE_SWORD, new ShopItem(1500, 1200, "Najlepszy miecz w grze"));
        weaponsTools.put(Material.WOODEN_PICKAXE, new ShopItem(15, 12, "Drewniany kilof"));
        weaponsTools.put(Material.STONE_PICKAXE, new ShopItem(30, 24, "Kamienny kilof"));
        weaponsTools.put(Material.IRON_PICKAXE, new ShopItem(120, 96, "Żelazny kilof"));
        weaponsTools.put(Material.GOLDEN_PICKAXE, new ShopItem(380, 304, "Złoty kilof"));
        weaponsTools.put(Material.DIAMOND_PICKAXE, new ShopItem(300, 240, "Szybkie kopanie diamentów"));
        weaponsTools.put(Material.NETHERITE_PICKAXE, new ShopItem(800, 640, "Niezniszczalny kilof"));
        weaponsTools.put(Material.DIAMOND_AXE, new ShopItem(300, 240, "Szybkie ścinanie drzew"));
        weaponsTools.put(Material.NETHERITE_AXE, new ShopItem(800, 640, "Najlepszy topór"));
        weaponsTools.put(Material.DIAMOND_HOE, new ShopItem(400, 320, "Diamentowa motyka"));
        weaponsTools.put(Material.BOW, new ShopItem(50, 40, "Klasyczny łuk"));
        weaponsTools.put(Material.CROSSBOW, new ShopItem(80, 64, "Potężna kusza"));
        weaponsTools.put(Material.TRIDENT, new ShopItem(600, 480, "Trójząb morski"));
        categories.put("Broń & Narzędzia", weaponsTools);

        // KATEGORIA 2: JEDZENIE
        Map<Material, ShopItem> food = new LinkedHashMap<>();
        food.put(Material.APPLE, new ShopItem(3, 2, "Zdrowe jabłko"));
        food.put(Material.BREAD, new ShopItem(4, 3, "Podstawowe pożywienie"));
        food.put(Material.COOKED_BEEF, new ShopItem(8, 6, "Najlepsze jedzenie"));
        food.put(Material.COOKED_PORKCHOP, new ShopItem(8, 6, "Soczysty schab"));
        food.put(Material.COOKED_CHICKEN, new ShopItem(6, 4, "Szybka regeneracja"));
        food.put(Material.COOKED_MUTTON, new ShopItem(7, 5, "Pieczona baranina"));
        food.put(Material.BAKED_POTATO, new ShopItem(5, 3, "Pieczone ziemniaki"));
        food.put(Material.GOLDEN_APPLE, new ShopItem(50, 40, "Magiczne właściwości"));
        food.put(Material.ENCHANTED_GOLDEN_APPLE, new ShopItem(500, 400, "Legendarny przedmiot"));
        food.put(Material.COOKIE, new ShopItem(2, 1, "Słodkie ciastko"));
        food.put(Material.CAKE, new ShopItem(20, 16, "Tort urodzinowy"));
        food.put(Material.PUMPKIN_PIE, new ShopItem(12, 9, "Dyniowe ciasto"));
        food.put(Material.MELON_SLICE, new ShopItem(3, 2, "Arbuz orzeźwiający"));
        categories.put("Jedzenie", food);

        // KATEGORIA 3: MATERIAŁY BUDOWLANE
        Map<Material, ShopItem> building = new LinkedHashMap<>();
        building.put(Material.COBBLESTONE, new ShopItem(1, 1, "Bruk kamienny"));
        building.put(Material.STONE, new ShopItem(2, 1, "Podstawowy kamień"));
        building.put(Material.STONE_BRICKS, new ShopItem(3, 2, "Kamienne cegły"));
        building.put(Material.OAK_WOOD, new ShopItem(3, 2, "Drewno dębowe"));
        building.put(Material.SPRUCE_WOOD, new ShopItem(3, 2, "Drewno świerkowe"));
        building.put(Material.BIRCH_WOOD, new ShopItem(3, 2, "Drewno brzozowe"));
        building.put(Material.GLASS, new ShopItem(5, 3, "Przezroczyste szkło"));
        building.put(Material.WHITE_CONCRETE, new ShopItem(4, 3, "Biały beton"));
        building.put(Material.BLACK_CONCRETE, new ShopItem(4, 3, "Czarny beton"));
        building.put(Material.RED_CONCRETE, new ShopItem(4, 3, "Czerwony beton"));
        building.put(Material.QUARTZ_BLOCK, new ShopItem(10, 8, "Blok kwarcu"));
        building.put(Material.IRON_BLOCK, new ShopItem(90, 70, "Blok żelaza"));
        building.put(Material.GOLD_BLOCK, new ShopItem(180, 140, "Blok złota"));
        building.put(Material.DIAMOND_BLOCK, new ShopItem(900, 700, "Cenny blok diamentów"));
        building.put(Material.NETHERITE_BLOCK, new ShopItem(9000, 7200, "Najrzadszy blok"));
        categories.put("Materiały Budowlane", building);

        // KATEGORIA 4: RZADKIE PRZEDMIOTY
        Map<Material, ShopItem> rare = new LinkedHashMap<>();
        rare.put(Material.DIAMOND, new ShopItem(100, 80, "Cenny diament"));
        rare.put(Material.EMERALD, new ShopItem(150, 120, "Szmaragd handlarski"));
        rare.put(Material.NETHERITE_INGOT, new ShopItem(1000, 800, "Najrzadszy materiał"));
        rare.put(Material.NETHER_STAR, new ShopItem(2000, 1600, "Gwiazda Netheru"));
        rare.put(Material.DRAGON_EGG, new ShopItem(5000, 4000, "Jajo smoka - unikalne"));
        rare.put(Material.ELYTRA, new ShopItem(3000, 2400, "Skrzydła Elytry"));
        rare.put(Material.TOTEM_OF_UNDYING, new ShopItem(1500, 1200, "Totem nieśmiertelności"));
        rare.put(Material.HEART_OF_THE_SEA, new ShopItem(800, 640, "Serce oceanu"));
        rare.put(Material.BEACON, new ShopItem(2500, 2000, "Magiczny beacon"));
        rare.put(Material.END_CRYSTAL, new ShopItem(600, 480, "Kryształ Endu"));
        rare.put(Material.SHULKER_BOX, new ShopItem(700, 560, "Skrzynia Shulkera"));
        rare.put(Material.ENCHANTED_BOOK, new ShopItem(400, 320, "Zaklęta księga"));
        categories.put("Rzadkie Przedmioty", rare);

        // KATEGORIA 5: PANCERZE I OBRONA  
        Map<Material, ShopItem> combat = new LinkedHashMap<>();
        combat.put(Material.LEATHER_HELMET, new ShopItem(20, 16, "Skórzany hełm"));
        combat.put(Material.LEATHER_CHESTPLATE, new ShopItem(32, 25, "Skórzany napierśnik"));
        combat.put(Material.LEATHER_LEGGINGS, new ShopItem(28, 22, "Skórzane nogawice"));
        combat.put(Material.LEATHER_BOOTS, new ShopItem(16, 13, "Skórzane buty"));
        combat.put(Material.IRON_HELMET, new ShopItem(80, 64, "Żelazny hełm"));
        combat.put(Material.IRON_CHESTPLATE, new ShopItem(128, 102, "Żelazny napierśnik"));
        combat.put(Material.IRON_LEGGINGS, new ShopItem(112, 90, "Żelazne nogawice"));
        combat.put(Material.IRON_BOOTS, new ShopItem(64, 51, "Żelazne buty"));
        combat.put(Material.DIAMOND_HELMET, new ShopItem(200, 160, "Ochrona głowy"));
        combat.put(Material.DIAMOND_CHESTPLATE, new ShopItem(320, 256, "Ochrona torsu"));
        combat.put(Material.DIAMOND_LEGGINGS, new ShopItem(280, 224, "Ochrona nóg"));
        combat.put(Material.DIAMOND_BOOTS, new ShopItem(160, 128, "Ochrona stóp"));
        combat.put(Material.SHIELD, new ShopItem(100, 80, "Tarcza ochronna"));
        combat.put(Material.ARROW, new ShopItem(1, 1, "Podstawowa strzała"));
        combat.put(Material.SPECTRAL_ARROW, new ShopItem(5, 4, "Widmowa strzała"));
        categories.put("Pancerze & Obrona", combat);
        
        // KATEGORIA 6: PETY (tokens nie do odsprzedaży aby uniknąć exploitu)
        Map<Material, ShopItem> pets = new LinkedHashMap<>();
        pets.put(Material.BONE, new ShopItem(500, 0, "Token: Wilk Dusz (nie do odsprzedaży)"));
        pets.put(Material.ROTTEN_FLESH, new ShopItem(450, 0, "Token: Zombie Guardian (nie do odsprzedaży)"));
        pets.put(Material.SPIDER_EYE, new ShopItem(550, 0, "Token: Pajęcza Królowa (nie do odsprzedaży)"));
        pets.put(Material.STRING, new ShopItem(600, 0, "Token: Kot Chaosu (nie do odsprzedaży)"));
        pets.put(Material.FEATHER, new ShopItem(480, 0, "Token: Sokół Strażnik (nie do odsprzedaży)"));
        pets.put(Material.RABBIT_FOOT, new ShopItem(520, 0, "Token: Szczęśliwy Królik (nie do odsprzedaży)"));
        pets.put(Material.TROPICAL_FISH, new ShopItem(580, 0, "Token: Egzotyczna Rybka (nie do odsprzedaży)"));
        pets.put(Material.BLAZE_POWDER, new ShopItem(800, 0, "Token: Feniks Ognia (nie do odsprzedaży)"));
        pets.put(Material.ENDER_PEARL, new ShopItem(950, 0, "Token: Enderman Pomocnik (nie do odsprzedaży)"));
        pets.put(Material.PHANTOM_MEMBRANE, new ShopItem(1200, 0, "Token: Fantom Pustki (nie do odsprzedaży)"));
        pets.put(Material.DRAGON_BREATH, new ShopItem(1500, 0, "Token: Duch Smoka (nie do odsprzedaży)"));
        pets.put(Material.GHAST_TEAR, new ShopItem(1100, 0, "Token: Mini Ghast (nie do odsprzedaży)"));
        categories.put("Pety", pets);
        
        // KATEGORIA 7: BOOSTERY (nie do odsprzedaży aby uniknąć exploitu)
        Map<Material, ShopItem> boosters = new LinkedHashMap<>();
        boosters.put(Material.EXPERIENCE_BOTTLE, new ShopItem(250, 0, "Booster EXP x2 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.GOLD_NUGGET, new ShopItem(250, 0, "Booster Hajsu x2 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.BLAZE_ROD, new ShopItem(350, 0, "Booster PvP x1.5 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.MAGMA_CREAM, new ShopItem(300, 0, "Booster Farm x2 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.SLIME_BALL, new ShopItem(280, 0, "Booster Drop x1.75 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.ENDER_EYE, new ShopItem(450, 0, "Booster Luck x2 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.PRISMARINE_SHARD, new ShopItem(320, 0, "Booster Rybak x3 (1h) (nie do odsprzedaży)"));
        boosters.put(Material.CHORUS_FRUIT, new ShopItem(380, 0, "Booster Teleport x2 (1h) (nie do odsprzedaży)"));
        categories.put("Boostery", boosters);
        
        // KATEGORIA 8: KOSMETYKI
        Map<Material, ShopItem> cosmetics = new LinkedHashMap<>();
        cosmetics.put(Material.PUMPKIN, new ShopItem(150, 120, "Dynia na głowę"));
        cosmetics.put(Material.PLAYER_HEAD, new ShopItem(300, 240, "Losowa głowa gracza"));
        cosmetics.put(Material.FIREWORK_ROCKET, new ShopItem(50, 40, "Fajerwerki"));
        cosmetics.put(Material.GLOW_INK_SAC, new ShopItem(80, 64, "Świecący atrament"));
        cosmetics.put(Material.ARMOR_STAND, new ShopItem(120, 96, "Stojak na zbroje"));
        cosmetics.put(Material.PAINTING, new ShopItem(60, 48, "Obraz dekoracyjny"));
        cosmetics.put(Material.ITEM_FRAME, new ShopItem(30, 24, "Ramka na przedmioty"));
        cosmetics.put(Material.FLOWER_POT, new ShopItem(25, 20, "Doniczka na kwiaty"));
        cosmetics.put(Material.WHITE_BANNER, new ShopItem(90, 72, "Ozdobny sztandar"));
        cosmetics.put(Material.GLOW_ITEM_FRAME, new ShopItem(45, 36, "Świecąca ramka"));
        categories.put("Kosmetyki", cosmetics);
        
        // KATEGORIA 9: NARZĘDZIA
        Map<Material, ShopItem> tools = new LinkedHashMap<>();
        tools.put(Material.IRON_SHOVEL, new ShopItem(180, 144, "Łopata Szybkości"));
        tools.put(Material.DIAMOND_SHOVEL, new ShopItem(320, 256, "Łopata Efektywności"));
        tools.put(Material.SHEARS, new ShopItem(100, 80, "Nożyce"));
        tools.put(Material.FISHING_ROD, new ShopItem(250, 200, "Wędka"));
        tools.put(Material.FLINT_AND_STEEL, new ShopItem(150, 120, "Krzesiwo"));
        tools.put(Material.COMPASS, new ShopItem(200, 160, "Kompas"));
        tools.put(Material.CLOCK, new ShopItem(180, 144, "Zegar"));
        tools.put(Material.LEAD, new ShopItem(45, 36, "Smycz"));
        tools.put(Material.NAME_TAG, new ShopItem(100, 80, "Znacznik imienia"));
        tools.put(Material.SADDLE, new ShopItem(150, 120, "Siodło"));
        categories.put("Narzędzia", tools);
        
        // KATEGORIA 10: KLUCZE DO SKRZYŃ
        Map<Material, ShopItem> keys = new LinkedHashMap<>();
        keys.put(Material.TRIPWIRE_HOOK, new ShopItem(500, 0, "Klucz Brązowy (nie do odsprzedaży)"));
        keys.put(Material.IRON_NUGGET, new ShopItem(1000, 0, "Klucz Srebrny (nie do odsprzedaży)"));
        keys.put(Material.GOLD_INGOT, new ShopItem(2000, 0, "Klucz Złoty (nie do odsprzedaży)"));
        keys.put(Material.RECOVERY_COMPASS, new ShopItem(5000, 0, "Klucz Diamentowy (nie do odsprzedaży)"));
        keys.put(Material.ECHO_SHARD, new ShopItem(10000, 0, "Klucz Legendarny (nie do odsprzedaży)"));
        categories.put("Klucze do Skrzyń", keys);
        
        // KATEGORIA 11: REDSTONE I MECHANIZMY
        Map<Material, ShopItem> redstone = new LinkedHashMap<>();
        redstone.put(Material.REDSTONE, new ShopItem(10, 8, "Proszek redstone"));
        redstone.put(Material.REDSTONE_TORCH, new ShopItem(15, 12, "Pochodnia redstone"));
        redstone.put(Material.REPEATER, new ShopItem(25, 20, "Przekaźnik"));
        redstone.put(Material.COMPARATOR, new ShopItem(30, 24, "Komparator"));
        redstone.put(Material.PISTON, new ShopItem(40, 32, "Tłok"));
        redstone.put(Material.STICKY_PISTON, new ShopItem(50, 40, "Lepki tłok"));
        redstone.put(Material.DISPENSER, new ShopItem(60, 48, "Dozownik"));
        redstone.put(Material.DROPPER, new ShopItem(55, 44, "Podajnik"));
        redstone.put(Material.HOPPER, new ShopItem(80, 64, "Lejek"));
        redstone.put(Material.OBSERVER, new ShopItem(70, 56, "Obserwator"));
        redstone.put(Material.LEVER, new ShopItem(12, 10, "Dźwignia"));
        redstone.put(Material.STONE_BUTTON, new ShopItem(8, 6, "Przycisk"));
        redstone.put(Material.TNT, new ShopItem(100, 80, "Dynamit"));
        categories.put("Redstone & Mechanizmy", redstone);
        
        // KATEGORIA 12: FARMA
        Map<Material, ShopItem> farming = new LinkedHashMap<>();
        farming.put(Material.WHEAT_SEEDS, new ShopItem(2, 1, "Nasiona pszenicy"));
        farming.put(Material.CARROT, new ShopItem(3, 2, "Marchewka"));
        farming.put(Material.POTATO, new ShopItem(3, 2, "Ziemniak"));
        farming.put(Material.BEETROOT_SEEDS, new ShopItem(2, 1, "Nasiona buraka"));
        farming.put(Material.MELON_SEEDS, new ShopItem(5, 4, "Nasiona melona"));
        farming.put(Material.PUMPKIN_SEEDS, new ShopItem(5, 4, "Nasiona dyni"));
        farming.put(Material.BONE_MEAL, new ShopItem(4, 3, "Mączka kostna"));
        farming.put(Material.WATER_BUCKET, new ShopItem(50, 40, "Wiadro wody"));
        farming.put(Material.LAVA_BUCKET, new ShopItem(80, 64, "Wiadro lawy"));
        farming.put(Material.BUCKET, new ShopItem(30, 24, "Puste wiadro"));
        farming.put(Material.WHEAT, new ShopItem(4, 3, "Pszenica"));
        farming.put(Material.SUGAR_CANE, new ShopItem(6, 5, "Trzcina cukrowa"));
        farming.put(Material.CACTUS, new ShopItem(8, 6, "Kaktus"));
        categories.put("Farma & Hodowla", farming);
        
        // KATEGORIA 13: ALCHEMIA
        Map<Material, ShopItem> alchemy = new LinkedHashMap<>();
        alchemy.put(Material.BREWING_STAND, new ShopItem(100, 80, "Stolik alchemiczny"));
        alchemy.put(Material.NETHER_WART, new ShopItem(20, 16, "Brodawka Netherowa"));
        alchemy.put(Material.GLOWSTONE_DUST, new ShopItem(30, 24, "Proszek świecący"));
        alchemy.put(Material.FERMENTED_SPIDER_EYE, new ShopItem(40, 32, "Fermentowane oko"));
        alchemy.put(Material.SUGAR, new ShopItem(10, 8, "Cukier"));
        alchemy.put(Material.GLISTERING_MELON_SLICE, new ShopItem(35, 28, "Błyszczący melon"));
        alchemy.put(Material.GOLDEN_CARROT, new ShopItem(35, 28, "Złota marchewka"));
        alchemy.put(Material.PUFFERFISH, new ShopItem(55, 44, "Ryba rozdymka"));
        alchemy.put(Material.TURTLE_HELMET, new ShopItem(120, 96, "Hełm żółwia"));
        alchemy.put(Material.POTION, new ShopItem(80, 64, "Podstawowa mikstura"));
        categories.put("Alchemia", alchemy);
        
        // KATEGORIA 14: TRANSPORT
        Map<Material, ShopItem> transport = new LinkedHashMap<>();
        transport.put(Material.MINECART, new ShopItem(100, 80, "Wagonik"));
        transport.put(Material.CHEST_MINECART, new ShopItem(150, 120, "Wagonik ze skrzynią"));
        transport.put(Material.FURNACE_MINECART, new ShopItem(140, 112, "Wagonik z piecem"));
        transport.put(Material.TNT_MINECART, new ShopItem(180, 144, "Wagonik z TNT"));
        transport.put(Material.HOPPER_MINECART, new ShopItem(200, 160, "Wagonik z lejkiem"));
        transport.put(Material.RAIL, new ShopItem(15, 12, "Tory"));
        transport.put(Material.POWERED_RAIL, new ShopItem(30, 24, "Tory zasilane"));
        transport.put(Material.DETECTOR_RAIL, new ShopItem(25, 20, "Tory wykrywające"));
        transport.put(Material.ACTIVATOR_RAIL, new ShopItem(28, 22, "Tory aktywacyjne"));
        transport.put(Material.OAK_BOAT, new ShopItem(80, 64, "Łódka dębowa"));
        transport.put(Material.BIRCH_BOAT, new ShopItem(80, 64, "Łódka brzozowa"));
        categories.put("Transport", transport);
        
        // KATEGORIA 15: DEKORACJE
        Map<Material, ShopItem> decoration = new LinkedHashMap<>();
        decoration.put(Material.TORCH, new ShopItem(5, 4, "Pochodnia"));
        decoration.put(Material.LANTERN, new ShopItem(15, 12, "Latarnia"));
        decoration.put(Material.SOUL_LANTERN, new ShopItem(20, 16, "Latarnia duszy"));
        decoration.put(Material.GLOWSTONE, new ShopItem(25, 20, "Świecący kamień"));
        decoration.put(Material.SEA_LANTERN, new ShopItem(30, 24, "Morska latarnia"));
        decoration.put(Material.RED_MUSHROOM, new ShopItem(8, 6, "Czerwony grzyb"));
        decoration.put(Material.BROWN_MUSHROOM, new ShopItem(8, 6, "Brązowy grzyb"));
        decoration.put(Material.DANDELION, new ShopItem(5, 4, "Mlecz"));
        decoration.put(Material.POPPY, new ShopItem(5, 4, "Mak"));
        decoration.put(Material.ROSE_BUSH, new ShopItem(12, 10, "Krzak róż"));
        decoration.put(Material.LILY_PAD, new ShopItem(10, 8, "Lilia wodna"));
        decoration.put(Material.FERN, new ShopItem(6, 5, "Paproć"));
        decoration.put(Material.SHORT_GRASS, new ShopItem(4, 3, "Trawa"));
        decoration.put(Material.VINE, new ShopItem(7, 5, "Pnącza"));
        decoration.put(Material.BAMBOO, new ShopItem(9, 7, "Bambus"));
        categories.put("Dekoracje", decoration);
        
        // KATEGORIA 16: BLOKI RZADKIE
        Map<Material, ShopItem> rareBlocks = new LinkedHashMap<>();
        rareBlocks.put(Material.OBSIDIAN, new ShopItem(50, 40, "Obsydian"));
        rareBlocks.put(Material.CRYING_OBSIDIAN, new ShopItem(80, 64, "Płaczący obsydian"));
        rareBlocks.put(Material.ANCIENT_DEBRIS, new ShopItem(800, 640, "Pradawne szczątki"));
        rareBlocks.put(Material.NETHERITE_SCRAP, new ShopItem(500, 400, "Odłamek Netheritu"));
        rareBlocks.put(Material.GILDED_BLACKSTONE, new ShopItem(100, 80, "Pozłacany czernit"));
        rareBlocks.put(Material.NETHER_GOLD_ORE, new ShopItem(60, 48, "Złoto Netheru"));
        rareBlocks.put(Material.END_STONE, new ShopItem(40, 32, "Kamień Endu"));
        rareBlocks.put(Material.PURPUR_BLOCK, new ShopItem(45, 36, "Blok Purpury"));
        rareBlocks.put(Material.PRISMARINE, new ShopItem(55, 44, "Pryzmaryn"));
        rareBlocks.put(Material.SPONGE, new ShopItem(150, 120, "Gąbka"));
        rareBlocks.put(Material.HONEYCOMB_BLOCK, new ShopItem(90, 72, "Blok plastra miodu"));
        rareBlocks.put(Material.SCULK, new ShopItem(120, 96, "Sculk"));
        categories.put("Bloki Rzadkie", rareBlocks);
        
        // KATEGORIA 17: MUZYKA I DŹWIĘKI
        Map<Material, ShopItem> music = new LinkedHashMap<>();
        music.put(Material.NOTE_BLOCK, new ShopItem(50, 40, "Blok dźwiękowy"));
        music.put(Material.JUKEBOX, new ShopItem(120, 96, "Szafa grająca"));
        music.put(Material.MUSIC_DISC_13, new ShopItem(200, 160, "Płyta muzyczna 13"));
        music.put(Material.MUSIC_DISC_CAT, new ShopItem(200, 160, "Płyta muzyczna Cat"));
        music.put(Material.MUSIC_DISC_BLOCKS, new ShopItem(220, 176, "Płyta Blocks"));
        music.put(Material.MUSIC_DISC_CHIRP, new ShopItem(220, 176, "Płyta Chirp"));
        music.put(Material.MUSIC_DISC_FAR, new ShopItem(220, 176, "Płyta Far"));
        music.put(Material.MUSIC_DISC_MALL, new ShopItem(220, 176, "Płyta Mall"));
        music.put(Material.MUSIC_DISC_MELLOHI, new ShopItem(220, 176, "Płyta Mellohi"));
        music.put(Material.MUSIC_DISC_STAL, new ShopItem(220, 176, "Płyta Stal"));
        music.put(Material.MUSIC_DISC_STRAD, new ShopItem(220, 176, "Płyta Strad"));
        music.put(Material.MUSIC_DISC_WARD, new ShopItem(220, 176, "Płyta Ward"));
        music.put(Material.MUSIC_DISC_11, new ShopItem(250, 200, "Płyta 11 (rzadka)"));
        music.put(Material.MUSIC_DISC_WAIT, new ShopItem(220, 176, "Płyta Wait"));
        categories.put("Muzyka & Dźwięki", music);
    }

    public void openShopGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new ShopMainHolder(), 54, "§6§l🏪 SKLEP SOULCRAFT 🏪");
        activeMainPlayers.add(player.getUniqueId());

        ItemStack goldFiller = createCustomItem(Material.YELLOW_STAINED_GLASS_PANE, "§e§l◆", Arrays.asList("§6✨ Złoty blask sklepu..."));
        ItemStack orangeFiller = createCustomItem(Material.ORANGE_STAINED_GLASS_PANE, "§6§l◇", Arrays.asList("§e💰 Energia handlu..."));
        
        for (int i = 0; i < 54; i++) {
            if (i < 9 || i >= 45) {
                gui.setItem(i, goldFiller);
            } else if (i % 9 == 0 || i % 9 == 8) {
                gui.setItem(i, orangeFiller);
            } else {
                gui.setItem(i, goldFiller);
            }
        }

        long balance = plugin.getEconomyService().getBalance(player.getUniqueId());
        ItemStack balanceItem = createCustomItem(Material.GOLD_INGOT,
            "§6§l💰 TWÓJ BALANS 💰",
            Arrays.asList(
                "§7╭─────────────────╮",
                "§7│ §fAktualne saldo: §7│",
                "§7│ §6§l    " + String.format("%.0f", (double)balance) + " hajsu    §7│",
                "§7╰─────────────────╯",
                "",
                "§e💡 Kup i sprzedawaj przedmioty",
                "§e💡 aby zwiększyć swój majątek!"));
        gui.setItem(4, balanceItem);

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30};
        Material[] icons = {
            Material.DIAMOND_SWORD,
            Material.GOLDEN_APPLE,
            Material.STONE,
            Material.EMERALD,
            Material.DIAMOND_HELMET,
            Material.BONE,
            Material.EXPERIENCE_BOTTLE,
            Material.FIREWORK_ROCKET,
            Material.IRON_SHOVEL,
            Material.TRIPWIRE_HOOK,
            Material.REDSTONE,
            Material.WHEAT_SEEDS,
            Material.BREWING_STAND,
            Material.MINECART,
            Material.ROSE_BUSH,
            Material.OBSIDIAN,
            Material.NOTE_BLOCK
        };
        
        String[] descriptions = {
            "Potężne bronie i narzędzia",
            "Pożywienie i jedzenie", 
            "Wszystko do budowy",
            "Najcenniejsze skarby",
            "Pancerze bojowe",
            "Wierni towarzysze",
            "Zwiększ zyski!",
            "Dodatki kosmetyczne",
            "Łopaty, wędki, nożyce",
            "Tajemnicze klucze",
            "Układy i mechanizmy",
            "Rolnictwo",
            "Mikstury i eliksiry",
            "Pojazdy i podróże",
            "Piękne rośliny",
            "Niezwykłe bloki",
            "Płyty i melodie"
        };

        int categoryIndex = 0;
        for (String categoryName : categories.keySet()) {
            if (categoryIndex >= slots.length) break;
            
            ItemStack categoryItem = createCustomItem(icons[categoryIndex],
                "§e§l📦 " + categoryName.toUpperCase() + " 📦",
                Arrays.asList(
                    "§7╭─────────────────────────╮",
                    "§7│ §f" + descriptions[categoryIndex] + " §7│",
                    "§7│                         §7│",
                    "§7│ §aPrzedmioty: §f" + categories.get(categoryName).size() + "          §7│",
                    "§7╰─────────────────────────╯",
                    "",
                    "§a§l➤ KLIKNIJ ABY PRZEGLĄDAĆ!"));
            gui.setItem(slots[categoryIndex], categoryItem);

            ItemStack sparkle = createCustomItem(Material.GLOWSTONE_DUST, "§e§l✦", Arrays.asList("§6Magiczny blask..."));
            if (categoryIndex < 7 && slots[categoryIndex] - 9 >= 0) {
                gui.setItem(slots[categoryIndex] - 9, sparkle);
            }
            
            categoryIndex++;
        }

        ItemStack instructions = createCustomItem(Material.BOOK,
            "§b§l📚 JAK KORZYSTAĆ ZE SKLEPU 📚",
            Arrays.asList(
                "§7╭─────────────────────────╮",
                "§7│ §fInstrukcje obsługi:     §7│",
                "§7│                         §7│", 
                "§7│ §a• LPM §7= Kup przedmiot   §7│",
                "§7│ §c• PPM §7= Sprzedaj        §7│",
                "§7│ §e• Wybierz kategorię      §7│",
                "§7│ §e• Sprawdź swój balans    §7│",
                "§7╰─────────────────────────╯"));
        gui.setItem(49, instructions);

        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ SKLEP",
            Arrays.asList("§7Zamknij interfejs sklepu"));
        gui.setItem(53, close);

        player.openInventory(gui);
    }

    public void openCategoryGUI(Player player, String categoryName) {
        Map<Material, ShopItem> items = categories.get(categoryName);
        if (items == null) return;

        int size = Math.max(54, ((items.size() / 9) + 1) * 9);
        if (size > 54) size = 54;
        
        Inventory gui = Bukkit.createInventory(new ShopCategoryHolder(categoryName), size, 
            "§e§l📦 " + categoryName.toUpperCase() + " 📦");
        activeCategoryPlayers.add(player.getUniqueId());

        ItemStack filler = createCustomItem(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "§b§l◆", 
            Arrays.asList("§3✨ " + categoryName + "..."));
        for (int i = 0; i < size; i++) {
            gui.setItem(i, filler);
        }

        long balance = plugin.getEconomyService().getBalance(player.getUniqueId());
        ItemStack balanceItem = createCustomItem(Material.GOLD_NUGGET,
            "§6💰 Balans: §f" + String.format("%.0f", (double)balance) + " hajsu",
            Arrays.asList("§7Twoje aktualne środki"));
        gui.setItem(4, balanceItem);

        int slot = 9;
        for (Map.Entry<Material, ShopItem> entry : items.entrySet()) {
            if (slot >= size - 9) break;
            
            Material material = entry.getKey();
            ShopItem shopItem = entry.getValue();
            
            String sellInfo;
            if (shopItem.sellPrice <= 0) {
                sellInfo = "§c§l✗ Nie można odsprzedać";
            } else {
                sellInfo = "§e§l$ PPM: SPRZEDAJ za " + String.format("%.0f", shopItem.sellPrice) + " hajsu";
            }
            
            ItemStack item = createCustomItem(material,
                "§f§l" + formatMaterialName(material),
                Arrays.asList(
                    "§7╭─────────────────────╮",
                    "§7│ §f" + shopItem.description + " §7│",
                    "§7│                     §7│",
                    "§7│ §aCena kupna: §f" + String.format("%.0f", shopItem.buyPrice) + " hajsu §7│",
                    shopItem.sellPrice > 0 ? 
                        "§7│ §cCena sprzedaży: §f" + String.format("%.0f", shopItem.sellPrice) + " hajsu §7│" : 
                        "§7│ §cNie do odsprzedaży §7│",
                    "§7╰─────────────────────╯",
                    "",
                    balance >= shopItem.buyPrice ? 
                        "§a§l✓ LPM: KUP za " + String.format("%.0f", shopItem.buyPrice) + " hajsu" :
                        "§c§l✗ Za mało hajsu do kupna",
                    sellInfo));
            gui.setItem(slot++, item);
        }

        ItemStack back = createCustomItem(Material.ARROW,
            "§e§l⬅ POWRÓT DO KATEGORII",
            Arrays.asList("§7Wróć do głównego menu sklepu"));
        gui.setItem(size - 5, back);

        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ",
            Arrays.asList("§7Zamknij sklep"));
        gui.setItem(size - 1, close);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        
        if (holder instanceof ShopMainHolder) {
            handleMainShopClick(event, player);
        } else if (holder instanceof ShopCategoryHolder) {
            handleCategoryClick(event, player);
        }
    }

    private void handleMainShopClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeMainPlayers.remove(player.getUniqueId());
            return;
        }

        String categoryName = getCategoryFromSlot(raw);
        if (categoryName != null) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
        }
    }

    private void handleCategoryClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (clicked.getType() == Material.ARROW) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openShopGUI(player), 1L);
            return;
        }

        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeCategoryPlayers.remove(player.getUniqueId());
            return;
        }

        if (raw < 9 || clicked.getType() == Material.LIGHT_BLUE_STAINED_GLASS_PANE || 
            clicked.getType() == Material.GOLD_NUGGET) return;

        ShopCategoryHolder categoryHolder = (ShopCategoryHolder) event.getView().getTopInventory().getHolder();
        String categoryName = categoryHolder.getCategoryName();
        Map<Material, ShopItem> items = categories.get(categoryName);
        if (items == null) return;

        Material material = clicked.getType();
        ShopItem shopItem = items.get(material);
        if (shopItem == null) return;

        UUID uuid = player.getUniqueId();
        long balance = plugin.getEconomyService().getBalance(uuid);

        if (event.isLeftClick()) {
            if (balance >= shopItem.buyPrice) {
                boolean success = plugin.getEconomyService().withdraw(uuid, shopItem.buyPrice, "Shop purchase");
                if (success) {
                    player.getInventory().addItem(new ItemStack(material, 1));
                    
                    player.sendMessage("§a§l💰 ═══════════════════════════════ 💰");
                    player.sendMessage("§a§l    ✓ ZAKUP POMYŚLNY! ✓");
                    player.sendMessage("§f    Przedmiot: §e" + formatMaterialName(material));
                    player.sendMessage("§f    Zapłacono: §c" + String.format("%.0f", shopItem.buyPrice) + " hajsu");
                    player.sendMessage("§f    Pozostało: §a" + String.format("%.0f", (double)(balance - Math.round(shopItem.buyPrice))) + " hajsu");
                    player.sendMessage("§a§l💰 ═══════════════════════════════ 💰");
                    
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
                } else {
                    player.sendMessage("§cWystąpił błąd podczas transakcji!");
                }
            } else {
                double needed = shopItem.buyPrice - balance;
                player.sendMessage("§c§l💸 ═══════════════════════════════ 💸");
                player.sendMessage("§c§l    ✗ ZA MAŁO HAJSU! ✗");
                player.sendMessage("§f    Potrzebujesz: §e" + String.format("%.0f", shopItem.buyPrice) + " hajsu");
                player.sendMessage("§f    Masz: §c" + String.format("%.0f", (double)balance) + " hajsu");
                player.sendMessage("§f    Brakuje Ci: §4" + String.format("%.0f", needed) + " hajsu");
                player.sendMessage("§c§l💸 ═══════════════════════════════ 💸");
            }
            
        } else if (event.isRightClick()) {
            if (shopItem.sellPrice <= 0) {
                player.sendMessage("§c§l✗ ═══════════════════════════════ ✗");
                player.sendMessage("§c§l    TEGO PRZEDMIOTU NIE MOŻNA ODSPRZEDAĆ! ");
                player.sendMessage("§c§l✗ ═══════════════════════════════ ✗");
                return;
            }
            
            if (player.getInventory().contains(material)) {
                player.getInventory().removeItem(new ItemStack(material, 1));
                boolean success = plugin.getEconomyService().deposit(uuid, shopItem.sellPrice, "Shop sale");
                if (success) {
                    player.sendMessage("§e§l💰 ═══════════════════════════════ 💰");
                    player.sendMessage("§e§l    ✓ SPRZEDAŻ POMYŚLNA! ✓");
                    player.sendMessage("§f    Przedmiot: §e" + formatMaterialName(material));
                    player.sendMessage("§f    Otrzymano: §a" + String.format("%.0f", shopItem.sellPrice) + " hajsu");
                    player.sendMessage("§f    Masz teraz: §a" + String.format("%.0f", (double)(balance + Math.round(shopItem.sellPrice))) + " hajsu");
                    player.sendMessage("§e§l💰 ═══════════════════════════════ 💰");
                    
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
                } else {
                    player.getInventory().addItem(new ItemStack(material, 1));
                    player.sendMessage("§cWystąpił błąd podczas transakcji!");
                }
            } else {
                player.sendMessage("§c§l📦 ═══════════════════════════════ 📦");
                player.sendMessage("§c§l    ✗ BRAK PRZEDMIOTU! ✗");
                player.sendMessage("§f    Nie masz §e" + formatMaterialName(material));
                player.sendMessage("§f    w swoim ekwipunku!");
                player.sendMessage("§c§l📦 ═══════════════════════════════ 📦");
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ShopMainHolder || holder instanceof ShopCategoryHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getView().getTopInventory().getSize()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ShopMainHolder) {
            activeMainPlayers.remove(player.getUniqueId());
        } else if (holder instanceof ShopCategoryHolder) {
            activeCategoryPlayers.remove(player.getUniqueId());
        }
    }

    private String getCategoryFromSlot(int slot) {
        switch (slot) {
            case 10: return "Broń & Narzędzia";
            case 11: return "Jedzenie";
            case 12: return "Materiały Budowlane";
            case 13: return "Rzadkie Przedmioty";
            case 14: return "Pancerze & Obrona";
            case 15: return "Pety";
            case 16: return "Boostery";
            case 19: return "Kosmetyki";
            case 20: return "Narzędzia";
            case 21: return "Klucze do Skrzyń";
            case 22: return "Redstone & Mechanizmy";
            case 23: return "Farma & Hodowla";
            case 24: return "Alchemia";
            case 25: return "Transport";
            case 28: return "Dekoracje";
            case 29: return "Bloki Rzadkie";
            case 30: return "Muzyka & Dźwięki";
            default: return null;
        }
    }

    private ItemStack createCustomItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private String formatMaterialName(Material material) {
        String name = material.name().toLowerCase().replace("_", " ");
        String[] words = name.split(" ");
        StringBuilder formatted = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                formatted.append(Character.toUpperCase(word.charAt(0)))
                         .append(word.substring(1))
                         .append(" ");
            }
        }
        return formatted.toString().trim();
    }

    static class ShopItem {
        final double buyPrice;
        final double sellPrice;
        final String description;

        ShopItem(double buyPrice, double sellPrice, String description) {
            this.buyPrice = buyPrice;
            this.sellPrice = sellPrice;
            this.description = description;
        }
    }

    private static class ShopMainHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static class ShopCategoryHolder implements InventoryHolder {
        private final String categoryName;

        public ShopCategoryHolder(String categoryName) {
            this.categoryName = categoryName;
        }

        public String getCategoryName() {
            return categoryName;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
