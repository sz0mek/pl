package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class Dodge extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Dodge(SoulCraftPlugin plugin) {
        super("dodge", "§b§lUnik", "§7Szansa 20% na uniknięcie obrażeń", 0, "vip", 8000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        // Passive ability - handled in event listeners
        if (Math.random() < 0.20) {
            if (args.length > 0 && args[0] instanceof org.bukkit.event.entity.EntityDamageEvent) {
                ((org.bukkit.event.entity.EntityDamageEvent) args[0]).setCancelled(true);
                player.sendMessage("§b§l✦ Uniknięto obrażeń!");
            }
        }
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
