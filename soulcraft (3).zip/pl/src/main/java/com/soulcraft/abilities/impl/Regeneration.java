package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Regeneration extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Regeneration(SoulCraftPlugin plugin) {
        super("regeneration", "§2§lRegeneracja", "§7Regeneracja III permanentnie", 0, "vip", 10000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 2, false, false));
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
