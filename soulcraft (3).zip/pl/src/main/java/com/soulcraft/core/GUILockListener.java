package com.soulcraft.core;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashSet;
import java.util.Set;

public class GUILockListener implements Listener {
    
    private final Set<Class<? extends InventoryHolder>> protectedHolders = new HashSet<>();
    private final NamespacedKey guiItemKey;
    
    public GUILockListener(org.bukkit.plugin.Plugin plugin) {
        this.guiItemKey = new NamespacedKey(plugin, "gui-locked");
    }
    
    public void registerProtectedHolder(Class<? extends InventoryHolder> holderClass) {
        protectedHolders.add(holderClass);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Inventory clickedInv = event.getClickedInventory();
        if (clickedInv == null) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder == null) return;
        
        boolean isProtected = protectedHolders.stream()
            .anyMatch(clazz -> clazz.isInstance(holder));
        
        if (isProtected) {
            int rawSlot = event.getRawSlot();
            if (rawSlot < event.getView().getTopInventory().getSize()) {
                event.setCancelled(true);
            }
            return;
        }
        
        ItemStack item = event.getCurrentItem();
        if (item != null && item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            if (meta.getPersistentDataContainer().has(guiItemKey, PersistentDataType.BYTE)) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder == null) return;
        
        boolean isProtected = protectedHolders.stream()
            .anyMatch(clazz -> clazz.isInstance(holder));
        
        if (isProtected) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getView().getTopInventory().getSize()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryMoveItem(InventoryMoveItemEvent event) {
        InventoryHolder holder = event.getDestination().getHolder();
        if (holder == null) return;
        
        boolean isProtected = protectedHolders.stream()
            .anyMatch(clazz -> clazz.isInstance(holder));
        
        if (isProtected) {
            event.setCancelled(true);
        }
    }
    
    public NamespacedKey getGuiItemKey() {
        return guiItemKey;
    }
}
