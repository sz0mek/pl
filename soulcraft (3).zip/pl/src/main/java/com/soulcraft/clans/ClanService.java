package com.soulcraft.clans;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Complete clan system with economy, wars, territory, and seasons
 */
public class ClanService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    
    private final Map<String, Clan> clans;  // clan ID -> clan
    private final Map<UUID, String> playerClans;  // player ID -> clan ID
    private final Map<String, ClanWar> activeWars;  // war ID -> war
    
    private final long CREATION_COST = 50000;
    private final int DAILY_COST_PER_MEMBER = 100;
    private final long WAR_COST = 25000;
    private final int WAR_DURATION = 3600000;
    
    private final Map<UUID, Long> lastChatTime;
    
    public ClanService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.clans = new ConcurrentHashMap<>();
        this.playerClans = new ConcurrentHashMap<>();
        this.activeWars = new ConcurrentHashMap<>();
        this.lastChatTime = new ConcurrentHashMap<>();
        
        loadClans();
        startUpkeepTask();
        startWarCheckTask();
    }
    
    private void loadClans() {
        java.io.File clansFolder = new java.io.File(plugin.getDataFolder(), "clans");
        if (!clansFolder.exists()) {
            clansFolder.mkdirs();
            return;
        }
        
        java.io.File[] clanFiles = clansFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (clanFiles == null) return;
        
        for (java.io.File file : clanFiles) {
            try {
                YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
                Clan clan = Clan.fromYaml(config);
                if (clan != null) {
                    clans.put(clan.id, clan);
                    for (UUID member : clan.members) {
                        playerClans.put(member, clan.id);
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to load clan from " + file.getName());
            }
        }
        
        plugin.getLogger().info("Loaded " + clans.size() + " clans");
    }
    
    private void saveClan(Clan clan) {
        java.io.File clansFolder = new java.io.File(plugin.getDataFolder(), "clans");
        if (!clansFolder.exists()) {
            clansFolder.mkdirs();
        }
        
        java.io.File clanFile = new java.io.File(clansFolder, clan.id + ".yml");
        try {
            YamlConfiguration config = new YamlConfiguration();
            clan.toYaml(config);
            config.save(clanFile);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to save clan " + clan.name);
        }
    }
    
    public void saveAll() {
        for (Clan clan : clans.values()) {
            saveClan(clan);
        }
    }
    
    /**
     * Create new clan
     */
    public boolean createClan(UUID ownerId, String clanName, String tag) {
        // Check if player already in clan
        if (playerClans.containsKey(ownerId)) {
            return false;
        }
        
        // Check cost
        if (!economyService.hasEnough(ownerId, CREATION_COST)) {
            return false;
        }
        
        // Check if name/tag already exists
        for (Clan clan : clans.values()) {
            if (clan.name.equalsIgnoreCase(clanName) || clan.tag.equalsIgnoreCase(tag)) {
                return false;
            }
        }
        
        // Charge cost
        if (!economyService.withdraw(ownerId, CREATION_COST, "Clan creation")) {
            return false;
        }
        
        // Create clan
        String clanId = UUID.randomUUID().toString();
        Clan clan = new Clan();
        clan.id = clanId;
        clan.name = clanName;
        clan.tag = tag;
        clan.owner = ownerId;
        clan.members.add(ownerId);
        clan.level = 1;
        clan.bankBalance = 0;
        clan.creationTime = System.currentTimeMillis();
        
        clans.put(clanId, clan);
        playerClans.put(ownerId, clanId);
        
        // Update player data
        PlayerData data = dataStore.loadPlayerData(ownerId);
        data.setClanId(clanId);
        
        Player player = Bukkit.getPlayer(ownerId);
        if (player != null) {
            player.sendMessage("§b§l✦ Clan Created! §e" + clanName + " §7[" + tag + "]");
        }
        
        return true;
    }
    
    /**
     * Invite player to clan
     */
    public boolean invitePlayer(UUID inviterId, UUID targetId) {
        String clanId = playerClans.get(inviterId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check permissions
        if (!clan.owner.equals(inviterId) && !clan.officers.contains(inviterId)) {
            return false;
        }
        
        // Check if target already in clan
        if (playerClans.containsKey(targetId)) {
            return false;
        }
        
        // Check member limit
        if (clan.members.size() >= clan.getMaxMembers()) {
            return false;
        }
        
        // Add to pending invites
        clan.pendingInvites.add(targetId);
        
        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            target.sendMessage("§b§l✦ Clan Invite! §e" + clan.name + " §7[" + clan.tag + "]");
            target.sendMessage("§7Use /klan accept to join!");
        }
        
        return true;
    }
    
    /**
     * Accept clan invite
     */
    public boolean acceptInvite(UUID playerId, String clanId) {
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.pendingInvites.contains(playerId)) {
            return false;
        }
        
        clan.pendingInvites.remove(playerId);
        clan.members.add(playerId);
        playerClans.put(playerId, clanId);
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.setClanId(clanId);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a§l✓ Joined clan: §e" + clan.name);
        }
        
        // Announce to clan
        broadcastToClan(clanId, "§b" + player.getName() + " joined the clan!");
        
        return true;
    }
    
    /**
     * Leave clan
     */
    public boolean leaveClan(UUID playerId) {
        String clanId = playerClans.remove(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check if owner
        if (clan.owner.equals(playerId)) {
            if (clan.members.size() > 1) {
                // Transfer ownership or disband
                return false; // Require explicit transfer
            } else {
                // Disband clan
                clans.remove(clanId);
            }
        } else {
            clan.members.remove(playerId);
            clan.officers.remove(playerId);
        }
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.setClanId(null);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§7Left clan: " + clan.name);
        }
        
        return true;
    }
    
    /**
     * Contribute to clan bank
     */
    public boolean contribute(UUID playerId, long amount) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!economyService.hasEnough(playerId, amount)) {
            return false;
        }
        
        if (!economyService.withdraw(playerId, amount, "Clan contribution")) {
            return false;
        }
        
        clan.bankBalance += amount;
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.addClanContribution(amount);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a§l✓ Contributed §6" + amount + " souls §ato clan bank");
        }
        
        return true;
    }
    
    /**
     * Upgrade clan level
     */
    public boolean upgradeClan(UUID playerId) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check permissions
        if (!clan.owner.equals(playerId)) {
            return false;
        }
        
        if (clan.level >= 100) {
            return false;
        }
        
        long xpNeeded = clan.getXPForNextLevel();
        if (clan.experience < xpNeeded) {
            return false;
        }
        
        clan.experience -= xpNeeded;
        clan.level++;
        
        broadcastToClan(clanId, "§b§l✦ Clan upgraded to level " + clan.level + "!");
        saveClan(clan);
        
        return true;
    }
    
    /**
     * Add XP to clan from member activity
     */
    public void addClanXP(UUID playerId, long xp, String source) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return;
        
        clan.experience += xp;
        clan.totalXP += xp;
        
        while (clan.level < 100 && clan.experience >= clan.getXPForNextLevel()) {
            long required = clan.getXPForNextLevel();
            clan.experience -= required;
            clan.level++;
            broadcastToClan(clanId, "§b§l✦ Clan leveled up to " + clan.level + "!");
            broadcastToClan(clanId, "§7XP gained from: " + source);
        }
        
        if (clan.level >= 100) {
            clan.experience = 0;
        }
    }
    
    /**
     * Promote member to officer
     */
    public boolean promoteToOfficer(UUID promoterId, UUID targetId) {
        String clanId = playerClans.get(promoterId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(promoterId)) return false;
        if (!clan.members.contains(targetId)) return false;
        if (clan.officers.contains(targetId)) return false;
        
        clan.officers.add(targetId);
        saveClan(clan);
        
        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            target.sendMessage("§b§l✦ You have been promoted to Officer!");
        }
        
        broadcastToClan(clanId, "§b" + (target != null ? target.getName() : "Member") + " was promoted to Officer!");
        return true;
    }
    
    /**
     * Demote officer to member
     */
    public boolean demoteOfficer(UUID demoterId, UUID targetId) {
        String clanId = playerClans.get(demoterId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(demoterId)) return false;
        
        clan.officers.remove(targetId);
        saveClan(clan);
        
        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            target.sendMessage("§7You have been demoted to Member");
        }
        
        return true;
    }
    
    /**
     * Kick member from clan
     */
    public boolean kickMember(UUID kickerId, UUID targetId) {
        String clanId = playerClans.get(kickerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(kickerId) && !clan.officers.contains(kickerId)) {
            return false;
        }
        
        if (clan.owner.equals(targetId)) return false;
        
        clan.members.remove(targetId);
        clan.officers.remove(targetId);
        playerClans.remove(targetId);
        
        PlayerData data = dataStore.loadPlayerData(targetId);
        data.setClanId(null);
        
        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            target.sendMessage("§c§lYou have been kicked from the clan!");
        }
        
        broadcastToClan(clanId, "§c" + (target != null ? target.getName() : "Member") + " was kicked from the clan!");
        saveClan(clan);
        
        return true;
    }
    
    /**
     * Transfer clan ownership
     */
    public boolean transferOwnership(UUID currentOwner, UUID newOwner) {
        String clanId = playerClans.get(currentOwner);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(currentOwner)) return false;
        if (!clan.members.contains(newOwner)) return false;
        
        clan.owner = newOwner;
        saveClan(clan);
        
        broadcastToClan(clanId, "§b§l✦ Ownership transferred to " + Bukkit.getOfflinePlayer(newOwner).getName());
        
        return true;
    }
    
    /**
     * Clan chat message
     */
    public void sendClanChat(UUID playerId, String message) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return;
        
        long now = System.currentTimeMillis();
        Long lastChat = lastChatTime.get(playerId);
        if (lastChat != null && now - lastChat < 1000) {
            return;
        }
        lastChatTime.put(playerId, now);
        
        Player sender = Bukkit.getPlayer(playerId);
        String senderName = sender != null ? sender.getName() : "Unknown";
        String role = clan.owner.equals(playerId) ? "§6Leader" : (clan.officers.contains(playerId) ? "§bOfficer" : "§7Member");
        
        broadcastToClan(clanId, "§8[§eClan§8] " + role + " §f" + senderName + " §8» §f" + message);
    }
    
    /**
     * Claim territory chunk
     */
    public boolean claimTerritory(UUID playerId, org.bukkit.Chunk chunk) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(playerId) && !clan.officers.contains(playerId)) {
            return false;
        }
        
        int chunkKey = getChunkKey(chunk);
        
        if (isTerritoryClaimedByAnother(chunkKey, clanId)) {
            return false;
        }
        
        if (clan.territory.size() >= clan.getMaxTerritory()) {
            return false;
        }
        
        long claimCost = 10000;
        if (clan.bankBalance < claimCost) {
            return false;
        }
        
        clan.bankBalance -= claimCost;
        clan.territory.put(chunkKey, (int)(System.currentTimeMillis() / 1000));
        saveClan(clan);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§b§l✓ Territory claimed! §7(" + clan.territory.size() + "/" + clan.getMaxTerritory() + ")");
        }
        
        return true;
    }
    
    /**
     * Unclaim territory chunk
     */
    public boolean unclaimTerritory(UUID playerId, org.bukkit.Chunk chunk) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(playerId) && !clan.officers.contains(playerId)) {
            return false;
        }
        
        int chunkKey = getChunkKey(chunk);
        if (!clan.territory.containsKey(chunkKey)) {
            return false;
        }
        
        clan.territory.remove(chunkKey);
        saveClan(clan);
        
        return true;
    }
    
    /**
     * Check if chunk is claimed by a clan
     */
    public String getChunkOwner(org.bukkit.Chunk chunk) {
        int chunkKey = getChunkKey(chunk);
        for (Clan clan : clans.values()) {
            if (clan.territory.containsKey(chunkKey)) {
                return clan.id;
            }
        }
        return null;
    }
    
    /**
     * Check if chunk is claimed by another clan
     */
    private boolean isTerritoryClaimedByAnother(int chunkKey, String clanId) {
        for (Clan clan : clans.values()) {
            if (!clan.id.equals(clanId) && clan.territory.containsKey(chunkKey)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Get chunk key for hashmap
     */
    private int getChunkKey(org.bukkit.Chunk chunk) {
        return (chunk.getX() << 16) | (chunk.getZ() & 0xFFFF);
    }
    
    /**
     * Withdraw from clan bank
     */
    public boolean withdraw(UUID playerId, long amount) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(playerId)) {
            return false;
        }
        
        if (clan.bankBalance < amount) {
            return false;
        }
        
        clan.bankBalance -= amount;
        economyService.deposit(playerId, amount, "Clan bank withdrawal");
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a§l✓ Withdrawn §6" + amount + " souls §afrom clan bank");
        }
        
        saveClan(clan);
        return true;
    }
    
    /**
     * Purchase clan upgrade
     */
    public boolean purchaseUpgrade(UUID playerId, String upgradeName) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.owner.equals(playerId)) {
            return false;
        }
        
        if (clan.upgrades.contains(upgradeName)) {
            return false;
        }
        
        long cost = getUpgradeCost(upgradeName, clan.level);
        if (clan.bankBalance < cost) {
            return false;
        }
        
        clan.bankBalance -= cost;
        clan.upgrades.add(upgradeName);
        saveClan(clan);
        
        broadcastToClan(clanId, "§b§l✦ Purchased upgrade: §e" + upgradeName);
        
        return true;
    }
    
    /**
     * Get upgrade cost based on clan level
     */
    private long getUpgradeCost(String upgrade, int level) {
        switch (upgrade) {
            case "extra_territory": return 50000 + (level * 1000);
            case "protection_boost": return 75000 + (level * 1500);
            case "resource_generation": return 100000 + (level * 2000);
            case "damage_boost": return 150000 + (level * 3000);
            case "xp_boost": return 200000 + (level * 4000);
            default: return 100000;
        }
    }
    
    /**
     * Declare war on another clan
     */
    public boolean declareWar(UUID declarerId, String targetClanId) {
        String attackerClanId = playerClans.get(declarerId);
        if (attackerClanId == null) return false;
        
        Clan attackerClan = clans.get(attackerClanId);
        Clan defenderClan = clans.get(targetClanId);
        
        if (attackerClan == null || defenderClan == null) return false;
        
        // Check permissions
        if (!attackerClan.owner.equals(declarerId)) {
            return false;
        }
        
        // Check cost
        if (attackerClan.bankBalance < WAR_COST) {
            return false;
        }
        
        attackerClan.bankBalance -= WAR_COST;
        saveClan(attackerClan);
        
        // Create war
        String warId = UUID.randomUUID().toString();
        ClanWar war = new ClanWar();
        war.id = warId;
        war.attackerClanId = attackerClanId;
        war.defenderClanId = targetClanId;
        war.startTime = System.currentTimeMillis();
        war.endTime = war.startTime + WAR_DURATION;
        war.attackerPoints = 0;
        war.defenderPoints = 0;
        
        activeWars.put(warId, war);
        
        // Announce
        broadcastToClan(attackerClanId, "§c§l⚔ War declared against " + defenderClan.name + "!");
        broadcastToClan(targetClanId, "§c§l⚔ War declared by " + attackerClan.name + "!");
        
        Bukkit.broadcastMessage("§c§l⚔ CLAN WAR! §e" + attackerClan.name + " §7vs §e" + defenderClan.name);
        
        return true;
    }
    
    /**
     * Record kill in clan war
     */
    public void recordWarKill(UUID killerId, UUID victimId) {
        String killerClanId = playerClans.get(killerId);
        String victimClanId = playerClans.get(victimId);
        
        if (killerClanId == null || victimClanId == null) return;
        
        // Find active war between these clans
        for (ClanWar war : activeWars.values()) {
            if ((war.attackerClanId.equals(killerClanId) && war.defenderClanId.equals(victimClanId)) ||
                (war.attackerClanId.equals(victimClanId) && war.defenderClanId.equals(killerClanId))) {
                
                // Add points
                if (war.attackerClanId.equals(killerClanId)) {
                    war.attackerPoints += 10;
                } else {
                    war.defenderPoints += 10;
                }
                
                break;
            }
        }
    }
    
    /**
     * End clan war
     */
    public void endWar(String warId) {
        ClanWar war = activeWars.remove(warId);
        if (war == null) return;
        
        Clan attackerClan = clans.get(war.attackerClanId);
        Clan defenderClan = clans.get(war.defenderClanId);
        
        if (attackerClan == null || defenderClan == null) return;
        
        // Determine winner
        Clan winner;
        Clan loser;
        long winnerReward = 100000;
        long loserReward = 25000;
        
        if (war.attackerPoints > war.defenderPoints) {
            winner = attackerClan;
            loser = defenderClan;
        } else {
            winner = defenderClan;
            loser = attackerClan;
        }
        
        winner.bankBalance += winnerReward;
        loser.bankBalance += loserReward;
        
        // Announce
        Bukkit.broadcastMessage("§c§l⚔ Clan War Ended!");
        Bukkit.broadcastMessage("§e" + winner.name + " §7defeated §e" + loser.name);
        
        broadcastToClan(winner.id, "§a§l✓ Victory! +§6" + winnerReward + " souls");
        broadcastToClan(loser.id, "§c§lDefeat! +§6" + loserReward + " souls");
    }
    
    /**
     * Get clan
     */
    public Clan getClan(String clanId) {
        return clans.get(clanId);
    }
    
    /**
     * Get player's clan
     */
    public Clan getPlayerClan(UUID playerId) {
        String clanId = playerClans.get(playerId);
        return clanId != null ? clans.get(clanId) : null;
    }
    
    /**
     * Broadcast message to clan
     */
    private void broadcastToClan(String clanId, String message) {
        Clan clan = clans.get(clanId);
        if (clan == null) return;
        
        for (UUID memberId : clan.members) {
            Player player = Bukkit.getPlayer(memberId);
            if (player != null) {
                player.sendMessage(message);
            }
        }
    }
    
    /**
     * Start upkeep task
     */
    private void startUpkeepTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Clan clan : clans.values()) {
                long upkeep = clan.members.size() * DAILY_COST_PER_MEMBER;
                
                if (clan.bankBalance >= upkeep) {
                    clan.bankBalance -= upkeep;
                } else {
                    // Warn clan about insufficient funds
                    broadcastToClan(clan.id, "§c§l⚠ Insufficient funds for upkeep!");
                }
            }
        }, 24000L, 24000L); // Run every 20 minutes (simulated day)
    }
    
    /**
     * Start war check task
     */
    private void startWarCheckTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            // Check and end wars
            List<String> endedWars = new ArrayList<>();
            for (Map.Entry<String, ClanWar> entry : activeWars.entrySet()) {
                if (System.currentTimeMillis() > entry.getValue().endTime) {
                    endWar(entry.getKey());
                    endedWars.add(entry.getKey());
                }
            }
            endedWars.forEach(activeWars::remove);
        }, 6000L, 6000L); // Run every 5 minutes
    }
    
    /**
     * Clan class
     */
    public static class Clan {
        public String id;
        public String name;
        public String tag;
        public UUID owner;
        public Set<UUID> members = new HashSet<>();
        public Set<UUID> officers = new HashSet<>();
        public Set<UUID> pendingInvites = new HashSet<>();
        public int level = 1;
        public long bankBalance = 0;
        public long creationTime;
        public Map<Integer, Integer> territory = new HashMap<>();  // chunk -> claim time
        public long experience = 0L;
        public long totalXP = 0L;
        public Set<String> upgrades = new HashSet<>();
        
        public int getMaxMembers() {
            return level * 10;
        }
        
        public long getMaxBankSize() {
            return level * 250000L;
        }
        
        public long getUpgradeCost() {
            return level * 100000L;
        }
        
        public long getXPForNextLevel() {
            return 5000L + (level - 1) * 2500L;
        }
        
        public int getMaxTerritory() {
            int base = 5 + (level * 2);
            return upgrades.contains("extra_territory") ? base + 10 : base;
        }
        
        public void toYaml(YamlConfiguration config) {
            config.set("id", id);
            config.set("name", name);
            config.set("tag", tag);
            config.set("owner", owner.toString());
            config.set("level", level);
            config.set("bankBalance", bankBalance);
            config.set("creationTime", creationTime);
            config.set("experience", experience);
            config.set("totalXP", totalXP);
            
            List<String> memberStrings = new ArrayList<>();
            for (UUID member : members) {
                memberStrings.add(member.toString());
            }
            config.set("members", memberStrings);
            
            List<String> officerStrings = new ArrayList<>();
            for (UUID officer : officers) {
                officerStrings.add(officer.toString());
            }
            config.set("officers", officerStrings);
            
            List<String> inviteStrings = new ArrayList<>();
            for (UUID invite : pendingInvites) {
                inviteStrings.add(invite.toString());
            }
            config.set("pendingInvites", inviteStrings);
            
            config.set("territory", territory);
            config.set("upgrades", new ArrayList<>(upgrades));
        }
        
        public static Clan fromYaml(YamlConfiguration config) {
            try {
                Clan clan = new Clan();
                clan.id = config.getString("id");
                clan.name = config.getString("name");
                clan.tag = config.getString("tag");
                clan.owner = UUID.fromString(config.getString("owner"));
                clan.level = config.getInt("level", 1);
                clan.bankBalance = config.getLong("bankBalance", 0);
                clan.creationTime = config.getLong("creationTime", System.currentTimeMillis());
                clan.experience = config.getLong("experience", 0);
                clan.totalXP = config.getLong("totalXP", 0);
                
                List<String> memberStrings = config.getStringList("members");
                for (String memberString : memberStrings) {
                    clan.members.add(UUID.fromString(memberString));
                }
                
                List<String> officerStrings = config.getStringList("officers");
                for (String officerString : officerStrings) {
                    clan.officers.add(UUID.fromString(officerString));
                }
                
                List<String> inviteStrings = config.getStringList("pendingInvites");
                for (String inviteString : inviteStrings) {
                    clan.pendingInvites.add(UUID.fromString(inviteString));
                }
                
                @SuppressWarnings("unchecked")
                Map<String, Object> territoryObj = (Map<String, Object>) config.get("territory");
                if (territoryObj != null) {
                    for (Map.Entry<String, Object> entry : territoryObj.entrySet()) {
                        clan.territory.put(Integer.parseInt(entry.getKey()), (Integer) entry.getValue());
                    }
                }
                
                List<String> upgradeList = config.getStringList("upgrades");
                clan.upgrades.addAll(upgradeList);
                
                return clan;
            } catch (Exception e) {
                return null;
            }
        }
    }
    
    /**
     * Clan war class
     */
    public static class ClanWar {
        public String id;
        public String attackerClanId;
        public String defenderClanId;
        public long startTime;
        public long endTime;
        public int attackerPoints;
        public int defenderPoints;
    }
}
