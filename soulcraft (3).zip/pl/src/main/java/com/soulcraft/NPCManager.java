package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.ChatColor;
import org.bukkit.Sound;

import java.util.*;

public class NPCManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Villager> npcs = new HashMap<>();
    private final Set<UUID> activeCraftingPlayers = new HashSet<>();
    private final Set<UUID> activeShopPlayers = new HashSet<>();

    public NPCManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        loadNPCs();
    }

    public void spawnNPC(Player player, int type) {
        Location loc = player.getLocation();
        World world = loc.getWorld();
        if (world == null) {
            player.sendMessage("§cNie można przywołać NPC tutaj.");
            return;
        }

        Villager npc = world.spawn(loc, Villager.class);
        npc.setProfession(Villager.Profession.CLERIC);
        npc.setAI(false);
        npc.setPersistent(true);

        UUID npcId = UUID.randomUUID();
        npcs.put(npcId, npc);

        String npcName;
        if (type == 2) {
            npcName = "§0§l⚫ Kupiec Czarnej Materii ⚫";
        } else {
            npcName = "§d§l✨ Czarodziejka ✨";
            type = 1;
        }

        npc.setCustomName(npcName);
        npc.setCustomNameVisible(true);

        plugin.getConfig().set("npcs." + npcId + ".type", type);
        plugin.getConfig().set("npcs." + npcId + ".world", loc.getWorld().getName());
        plugin.getConfig().set("npcs." + npcId + ".x", loc.getX());
        plugin.getConfig().set("npcs." + npcId + ".y", loc.getY());
        plugin.getConfig().set("npcs." + npcId + ".z", loc.getZ());
        plugin.getConfig().set("npcs." + npcId + ".yaw", loc.getYaw());
        plugin.getConfig().set("npcs." + npcId + ".pitch", loc.getPitch());
        plugin.saveConfig();

        player.sendMessage("§aPrzywołano " + npcName + "!");
    }

    private void loadNPCs() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("npcs");
        if (section == null)
            return;
        for (String key : section.getKeys(false)) {
            try {
                UUID npcId = UUID.fromString(key);
                String worldName = plugin.getConfig().getString("npcs." + key + ".world");
                World world = Bukkit.getWorld(worldName);
                if (world == null)
                    continue;

                double x = plugin.getConfig().getDouble("npcs." + key + ".x");
                double y = plugin.getConfig().getDouble("npcs." + key + ".y");
                double z = plugin.getConfig().getDouble("npcs." + key + ".z");
                float yaw = (float) plugin.getConfig().getDouble("npcs." + key + ".yaw");
                float pitch = (float) plugin.getConfig().getDouble("npcs." + key + ".pitch");
                int type = plugin.getConfig().getInt("npcs." + key + ".type", 1);

                Location loc = new Location(world, x, y, z, yaw, pitch);
                Villager npc = world.spawn(loc, Villager.class);
                npc.setProfession(Villager.Profession.CLERIC);
                npc.setAI(false);
                npc.setPersistent(true);

                String npcName = type == 2 ? "§0§l⚫ Kupiec Czarnej Materii ⚫" : "§d§l✨ Czarodziejka ✨";
                npc.setCustomName(npcName);
                npc.setCustomNameVisible(true);

                npcs.put(npcId, npc);
            } catch (Exception ignored) {
            }
        }
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager villager))
            return;
        if (villager.getCustomName() == null)
            return;

        event.setCancelled(true);

        if (villager.getCustomName().contains("Czarodziejka")) {
            // Efekt dźwiękowy i wizualny
            event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.2f);
            openCraftingGUI(event.getPlayer());
        } else if (villager.getCustomName().contains("Kupiec Czarnej Materii")) {
            // Efekt dźwiękowy mroczny
            event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD, 1.0f,
                    0.8f);
            openBlackMatterShopGUI(event.getPlayer());
        }
    }

    private void openCraftingGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new CraftingHolder(), 54, "§d§l✨ CZARODZIEJKA ✨");
        activeCraftingPlayers.add(player.getUniqueId());

        // Piękne wypełnienie - magiczne szkło
        ItemStack magicFiller = createCustomItem(Material.PURPLE_STAINED_GLASS_PANE, "§d§l✦",
                Arrays.asList("§5Magiczna energia..."));
        ItemStack darkFiller = createCustomItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◆",
                Arrays.asList("§8Mroczna moc..."));

        // Wzór wypełnienia - piękny gradient
        for (int i = 0; i < 54; i++) {
            if (i < 9 || i >= 45) {
                gui.setItem(i, magicFiller); // Górny i dolny rząd - fioletowe
            } else if (i % 9 == 0 || i % 9 == 8) {
                gui.setItem(i, darkFiller); // Boki - czarne
            } else {
                gui.setItem(i, magicFiller); // Środek - fioletowe
            }
        }

        // SEKCJA GÓRNA - Opisy przedmiotów
        ItemStack swordDesc = createCustomItem(Material.DIAMOND_SWORD,
                "§b§l⚔ DIAMENTOWY MIECZ ⚔",
                Arrays.asList(
                        "§7╭─────────────────────╮",
                        "§7│ §fWymagane enchantmenty: §7│",
                        "§7│ §c• Sharpness V        §7│",
                        "§7│ §a• Unbreaking III     §7│",
                        "§7╰─────────────────────╯",
                        "",
                        "§d§l➤ §7Włóż poniżej w slot!"));
        gui.setItem(11, swordDesc);

        ItemStack headDesc = createCustomItem(Material.PLAYER_HEAD,
                "§5§l👑 GŁOWA KRÓLA DUSZ 👑",
                Arrays.asList(
                        "§7╭─────────────────────╮",
                        "§7│ §fRzadki drop z bossa  §7│",
                        "§7│ §5Król Dusz           §7│",
                        "§7│ §cNiezwykle potężny!  §7│",
                        "§7╰─────────────────────╯",
                        "",
                        "§d§l➤ §7Włóż poniżej w slot!"));
        gui.setItem(15, headDesc);

        // SEKCJA ŚRODKOWA - Sloty na przedmioty
        gui.setItem(29, null); // Slot na miecz
        gui.setItem(33, null); // Slot na głowę

        // Wskaźniki slotów
        ItemStack swordSlot = createCustomItem(Material.LIME_STAINED_GLASS_PANE,
                "§a§l⬇ SLOT NA MIECZ ⬇",
                Arrays.asList("§7Przeciągnij tutaj diamentowy miecz"));
        gui.setItem(20, swordSlot);
        gui.setItem(38, swordSlot);

        ItemStack headSlot = createCustomItem(Material.LIME_STAINED_GLASS_PANE,
                "§a§l⬇ SLOT NA GŁOWĘ ⬇",
                Arrays.asList("§7Przeciągnij tutaj głowę króla"));
        gui.setItem(24, headSlot);
        gui.setItem(42, headSlot);

        // PRZYCISK TWORZENIA - centralny, piękny
        ItemStack craftButton = createCustomItem(Material.ANVIL,
                "§6§l⚡ UTWÓRZ MIECZ KRÓLA DUSZ ⚡",
                Arrays.asList(
                        "§7╭─────────────────────────╮",
                        "§7│ §fPołącz moc obu przedmiotów §7│",
                        "§7│ §ew legendarną broń!        §7│",
                        "§7╰─────────────────────────╯",
                        "",
                        "§c§l⚠ §7Potrzebujesz oba przedmioty!",
                        "",
                        "§a§l➤ KLIKNIJ ABY STWORZYĆ!"));
        gui.setItem(31, craftButton);

        // Efekty wizualne wokół przycisku
        ItemStack sparkle = createCustomItem(Material.YELLOW_STAINED_GLASS_PANE, "§e§l✦ §6Magiczna iskra §e§l✦",
                Arrays.asList("§7Energia magii..."));
        gui.setItem(22, sparkle);
        gui.setItem(30, sparkle);
        gui.setItem(32, sparkle);
        gui.setItem(40, sparkle);

        player.openInventory(gui);

        // Efekt dźwiękowy otwarcia
        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.5f, 1.5f);
    }

    private void openBlackMatterShopGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new BlackMatterShopHolder(), 54,
                "§0§l⚫ KUPIEC CZARNEJ MATERII ⚫");
        activeShopPlayers.add(player.getUniqueId());

        // Mroczne wypełnienie
        ItemStack darkFiller = createCustomItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◆",
                Arrays.asList("§8Mroczna energia..."));
        ItemStack grayFiller = createCustomItem(Material.GRAY_STAINED_GLASS_PANE, "§8§l◇",
                Arrays.asList("§7Cienie przeszłości..."));

        // Wzór wypełnienia - mroczny gradient
        for (int i = 0; i < 54; i++) {
            if (i < 9 || i >= 45) {
                gui.setItem(i, darkFiller); // Górny i dolny rząd
            } else if (i % 9 == 0 || i % 9 == 8) {
                gui.setItem(i, grayFiller); // Boki
            } else {
                gui.setItem(i, darkFiller); // Środek
            }
        }

        // SALDO GRACZA - na górze, centralnie
        int blackMatter = plugin.getEconomyService().getBlackMatter(player.getUniqueId());
        ItemStack balance = createCustomItem(Material.COAL,
                "§0§l💰 TWOJA CZARNA MATERIA 💰",
                Arrays.asList(
                        "§7╭─────────────────╮",
                        "§7│ §fAktualne saldo: §7│",
                        "§7│ §0§l    " + blackMatter + "         §7│",
                        "§7╰─────────────────╯",
                        "",
                        "§8Zbieraj więcej robiąc",
                        "§8rebirthy!"));
        gui.setItem(4, balance);

        // PRZEDMIOT 1 - Kryształ Dusz (lewa strona)
        ItemStack crystal = plugin.getCommandHandler().createSoulCrystal(5);
        ItemMeta crystalMeta = crystal.getItemMeta();
        if (crystalMeta != null) {
            crystalMeta.setDisplayName("§b§l💎 KRYSZTAŁ DUSZ (LVL 5) 💎");
            List<String> lore = new ArrayList<>();
            lore.add("§7╭─────────────────────────╮");
            lore.add("§7│ §fPotężny kryształ zawierający §7│");
            lore.add("§7│ §benergię pokonanych dusz    §7│");
            lore.add("§7│ §aPoziom: §25               §7│");
            lore.add("§7╰─────────────────────────╯");
            lore.add("");
            lore.add("§6§l💰 CENA: §0§l1 czarna materia");
            lore.add("");
            if (blackMatter >= 1) {
                lore.add("§a§l✓ KLIKNIJ LPM ABY KUPIĆ!");
            } else {
                lore.add("§c§l✗ Nie masz wystarczająco środków!");
            }
            crystalMeta.setLore(lore);
            crystal.setItemMeta(crystalMeta);
        }
        gui.setItem(21, crystal);

        // Dekoracja wokół kryształu
        ItemStack crystalFrame = createCustomItem(Material.LIGHT_BLUE_STAINED_GLASS_PANE,
                "§b§l◆ §3Aura kryształu §b§l◆", Arrays.asList("§7Energia wibruje..."));
        gui.setItem(12, crystalFrame);
        gui.setItem(20, crystalFrame);
        gui.setItem(22, crystalFrame);
        gui.setItem(30, crystalFrame);

        // PRZEDMIOT 2 - Zaklinacz Dusz (prawa strona)
        ItemStack enchanter = createCustomItem(Material.NETHER_STAR,
                "§0§l⭐ ZAKLINACZ DUSZ ⭐",
                Arrays.asList(
                        "§7╭─────────────────────────╮",
                        "§7│ §fMistyczne narzędzie do   §7│",
                        "§7│ §dulepszania przedmiotów   §7│",
                        "§7│ §5Kliknij PPM aby użyć     §7│",
                        "§7╰─────────────────────────╯",
                        "",
                        "§6§l💰 CENA: §0§l20 czarnej materii",
                        "",
                        blackMatter >= 20 ? "§a§l✓ KLIKNIJ LPM ABY KUPIĆ!" : "§c§l✗ Nie masz wystarczająco środków!"));
        gui.setItem(23, enchanter);

        // Dekoracja wokół zaklniacza
        ItemStack enchanterFrame = createCustomItem(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆ §dMagiczna aura §5§l◆",
                Arrays.asList("§7Moc pulsuje..."));
        gui.setItem(14, enchanterFrame);
        gui.setItem(24, enchanterFrame);
        gui.setItem(32, enchanterFrame);

        // DODATKOWE EFEKTY WIZUALNE
        ItemStack soulFlame = createCustomItem(Material.SOUL_TORCH, "§9§l🔥 Płomień Dusz 🔥",
                Arrays.asList("§7Wieczny ogień mroku..."));
        gui.setItem(10, soulFlame);
        gui.setItem(16, soulFlame);

        player.openInventory(gui);

        // Efekt dźwiękowy otwarcia - mroczny
        player.playSound(player.getLocation(), Sound.AMBIENT_SOUL_SAND_VALLEY_ADDITIONS, 0.7f, 0.8f);
    }

    // Pomocnicza metoda do tworzenia pięknych itemów
    private ItemStack createCustomItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;

        if (event.getView().getTopInventory().getHolder() instanceof CraftingHolder) {
            handleCraftingClick(event, player);
        } else if (event.getView().getTopInventory().getHolder() instanceof BlackMatterShopHolder) {
            handleBlackMatterShopClick(event, player);
        }
    }

    private void handleCraftingClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return; // player inventory

        InventoryAction action = event.getAction();

        // Sloty 29 i 33: ALLOW placing and taking items (nowe pozycje)
        if (raw == 29 || raw == 33) {
            event.setCancelled(false);
            return;
        }

        // Inne sloty: cancel
        event.setCancelled(true);

        if (raw == 31) { // craft button (nowa pozycja)
            ItemStack sword = event.getView().getTopInventory().getItem(29);
            ItemStack head = event.getView().getTopInventory().getItem(33);

            if (isValidSword(sword) && isValidHead(head)) {
                // Consume items
                event.getView().getTopInventory().setItem(29, null);
                event.getView().getTopInventory().setItem(33, null);

                ItemStack legendary = createLegendarySword();
                player.getInventory().addItem(legendary);

                // Piękne wiadomości i efekty
                player.sendMessage("§d§l✨ ═══════════════════════════════════ ✨");
                player.sendMessage("§5§l    🗡️ STWORZONO MIECZ KRÓLA DUSZ! 🗡️");
                player.sendMessage("§d§l✨ ═══════════════════════════════════ ✨");
                player.sendMessage("§7Czarodziejka szepce: §d'Niech moc królów będzie z tobą...'");

                // Efekty dźwiękowe
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);

                player.closeInventory();
                activeCraftingPlayers.remove(player.getUniqueId());
            } else {
                player.sendMessage("§c§l⚠ Nie masz wymaganych przedmiotów w odpowiednich slotach!");
                player.sendMessage(
                        "§7Potrzebujesz: §bDiamentowy Miecz §7(Sharpness V, Unbreaking III) i §5Głowę Króla Dusz");
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            }
        }
    }

    private void handleBlackMatterShopClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return;

        event.setCancelled(true);

        if (!event.getClick().isLeftClick())
            return;

        UUID uuid = player.getUniqueId();
        int blackMatter = plugin.getEconomyService().getBlackMatter(uuid);

        if (raw == 21) { // Crystal (nowa pozycja)
            if (blackMatter >= 1) {
                plugin.getEconomyService().removeBlackMatter(uuid, 1);
                player.getInventory().addItem(plugin.getCommandHandler().createSoulCrystal(5));

                // Piękne wiadomości
                player.sendMessage("§b§l💎 ═══════════════════════════════ 💎");
                player.sendMessage("§a§l  ✓ ZAKUP POMYŚLNY! ✓");
                player.sendMessage("§f  Kupiłeś: §bKryształ Dusz (Lvl 5)");
                player.sendMessage("§f  Zapłaciłeś: §01 czarną materię");
                player.sendMessage("§b§l💎 ═══════════════════════════════ 💎");

                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
                player.closeInventory();
                activeShopPlayers.remove(player.getUniqueId());
            } else {
                player.sendMessage("§c§l💰 Nie masz wystarczająco czarnej materii!");
                player.sendMessage("§7Potrzebujesz: §01 §7| Masz: §0" + blackMatter);
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 0.8f);
            }
        } else if (raw == 23) { // Enchanter
            if (blackMatter >= 20) {
                plugin.getEconomyService().removeBlackMatter(uuid, 20);
                ItemStack enchanter = new ItemStack(Material.NETHER_STAR);
                ItemMeta meta = enchanter.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName("§0Zaklinacz Dusz");
                    meta.setLore(Arrays.asList("§7Kliknij PPM aby otworzyć GUI ulepszania"));
                    enchanter.setItemMeta(meta);
                }
                player.getInventory().addItem(enchanter);
                player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
                player.sendMessage("§a§l  ✓ ZAKUP POMYŚLNY! ✓");
                player.sendMessage("§f  Kupiłeś: §0Zaklinacz Dusz");
                player.sendMessage("§f  Zapłaciłeś: §020 czarnej materii");
                player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.8f);
                player.closeInventory();
                activeShopPlayers.remove(player.getUniqueId());
            } else {
                player.sendMessage("§c§l💰 Nie masz wystarczająco czarnej materii!");
                player.sendMessage("§7Potrzebujesz: §020 §7| Masz: §0" + blackMatter);
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 0.8f);
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player))
            return;

        if (event.getView().getTopInventory().getHolder() instanceof CraftingHolder) {
            // Allow dragging only into slots 29 and 33 (nowe pozycje)
            for (int slot : event.getRawSlots()) {
                if (slot >= event.getView().getTopInventory().getSize())
                    continue;
                if (slot != 29 && slot != 33) {
                    event.setCancelled(true);
                    return;
                }
            }
        } else if (event.getView().getTopInventory().getHolder() instanceof BlackMatterShopHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player))
            return;

        if (event.getView().getTopInventory().getHolder() instanceof CraftingHolder) {
            // Return items (nowe pozycje slotów)
            ItemStack s = event.getView().getTopInventory().getItem(29);
            ItemStack h = event.getView().getTopInventory().getItem(33);
            if (s != null)
                player.getInventory().addItem(s);
            if (h != null)
                player.getInventory().addItem(h);
            activeCraftingPlayers.remove(player.getUniqueId());
        } else if (event.getView().getTopInventory().getHolder() instanceof BlackMatterShopHolder) {
            activeShopPlayers.remove(player.getUniqueId());
        }
    }

    private boolean isValidSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD)
            return false;
        if (!item.hasItemMeta())
            return false;
        Map<Enchantment, Integer> ench = item.getEnchantments();
        return ench.getOrDefault(Enchantment.SHARPNESS, 0) >= 5 &&
                ench.getOrDefault(Enchantment.UNBREAKING, 0) >= 3;
    }

    private boolean isValidHead(ItemStack item) {
        if (item == null || item.getType() != Material.PLAYER_HEAD)
            return false;
        if (!item.hasItemMeta())
            return false;
        String name = item.getItemMeta().getDisplayName();
        return name != null && name.contains("Głowa Króla Dusz");
    }

    private ItemStack createLegendarySword() {
        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = sword.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§5§l👑 MIECZ KRÓLA DUSZ 👑");
            meta.setLore(Arrays.asList(
                    "§7╭─────────────────────────────╮",
                    "§7│ §fLegendarny miecz wykuty     §7│",
                    "§7│ §fz mocy pokonanego władcy.  §7│",
                    "§7│                             §7│",
                    "§7│ §5§lMoc Królewska:            §7│",
                    "§7│ §c• Sharpness VII            §7│",
                    "§7│ §a• Unbreaking X             §7│",
                    "§7╰─────────────────────────────╯",
                    "",
                    "§d§lStworzony przez Czarodziejkę",
                    "§8§o'Niech moc królów będzie z tobą...'"));
            meta.addEnchant(Enchantment.SHARPNESS, 7, true);
            meta.addEnchant(Enchantment.UNBREAKING, 10, true);
            sword.setItemMeta(meta);
        }
        return sword;
    }

    private static class CraftingHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static class BlackMatterShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}