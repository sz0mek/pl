package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Arrays;

public class AbilityCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final AbilityManager abilityManager;
    
    public AbilityCommand(SoulCraftPlugin plugin, AbilityManager manager) {
        this.plugin = plugin;
        this.abilityManager = manager;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTa komenda dostępna tylko dla graczy!");
            return true;
        }
        
        openAbilityShop(player);
        return true;
    }
    
    private void openAbilityShop(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, "§5§lZDOLNOŚCI RPG");
        
        gui.setItem(10, createAbilityItem(Material.GOLDEN_APPLE, "§aHeal on Hit", 1000, "Leczysz się zadając obrażenia"));
        gui.setItem(11, createAbilityItem(Material.FEATHER, "§bDodge", 1500, "Szansa na unik ataku"));
        gui.setItem(12, createAbilityItem(Material.SUGAR, "§fSpeed Burst", 1200, "Przyśpieszenie po zabiciu"));
        gui.setItem(13, createAbilityItem(Material.DIAMOND_SWORD, "§cCritical Strike", 2000, "Szansa na krytyczne uderzenie"));
        gui.setItem(14, createAbilityItem(Material.REDSTONE, "§4Life Steal", 2500, "Kradnij życie przeciwnikom"));
        gui.setItem(15, createAbilityItem(Material.CACTUS, "§2Thorns", 1800, "Odbijaj obrażenia"));
        gui.setItem(19, createAbilityItem(Material.GLISTERING_MELON_SLICE, "§dRegeneration", 3000, "Regeneracja HP co 3s"));
        gui.setItem(20, createAbilityItem(Material.SHIELD, "§9Shield", 3500, "Tymczasowa tarcza"));
        gui.setItem(21, createAbilityItem(Material.BLAZE_POWDER, "§6Berserk", 4000, "Więcej dmg przy niskim HP"));
        gui.setItem(22, createAbilityItem(Material.EMERALD, "§aLucky", 2800, "Lepszy loot z mobów"));
        gui.setItem(23, createAbilityItem(Material.FERMENTED_SPIDER_EYE, "§5Vampirism", 5000, "Leczenie + Life Steal"));
        gui.setItem(24, createAbilityItem(Material.NETHER_STAR, "§dSoul Shield", 10000, "Absorbcja obrażeń"));
        
        player.openInventory(gui);
    }
    
    private ItemStack createAbilityItem(Material material, String name, int cost, String description) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Arrays.asList(
            "§7" + description,
            "",
            "§6Koszt: §e" + cost + " dusz",
            "§e§lKLIKNIJ ABY ODBLOKOWAĆ!"
        ));
        item.setItemMeta(meta);
        return item;
    }
}
