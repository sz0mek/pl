package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.dungeons.DungeonGUI;
import com.soulcraft.dungeons.EnhancedDungeonService;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class DungeonCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final DungeonGUI dungeonGUI;
    
    public DungeonCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        this.dungeonGUI = new DungeonGUI(plugin.getDungeonService(), plugin.getDataStore());
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cThis command is only available for players!");
            return true;
        }
        
        if (args.length == 0) {
            dungeonGUI.openDungeonSelection(player);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "easy":
            case "medium":
            case "hard":
            case "nightmare":
            case "chaos":
                plugin.getDungeonService().startDungeon(player, subCommand);
                break;
                
            case "leave":
                if (plugin.getDungeonService().isInDungeon(player.getUniqueId())) {
                    plugin.getDungeonService().leaveDungeon(player);
                } else {
                    player.sendMessage("§c§lYou are not in a dungeon!");
                }
                break;
                
            case "party":
                handlePartyCommand(player, args);
                break;
                
            case "gui":
                dungeonGUI.openDungeonSelection(player);
                break;
                
            default:
                player.sendMessage("§5§l✦ Dungeon Commands ✦");
                player.sendMessage("§e/dungeon §7- Open dungeon GUI");
                player.sendMessage("§e/dungeon <easy|medium|hard|nightmare|chaos> §7- Enter dungeon");
                player.sendMessage("§e/dungeon leave §7- Leave current dungeon");
                player.sendMessage("§e/dungeon party create §7- Create a party");
                player.sendMessage("§e/dungeon party invite <player> §7- Invite player to party");
                player.sendMessage("§e/dungeon party start <difficulty> §7- Start party dungeon");
                break;
        }
        
        return true;
    }
    
    private void handlePartyCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§c§lUsage: /dungeon party <create|invite|start>");
            return;
        }
        
        String partyAction = args[1].toLowerCase();
        EnhancedDungeonService service = plugin.getDungeonService();
        
        switch (partyAction) {
            case "create":
                EnhancedDungeonService.DungeonParty party = service.createParty(player);
                if (party == null) {
                    player.sendMessage("§c§lYou are already in a party! Use /dungeon party leave first.");
                    return;
                }
                player.sendMessage("§a§lParty created! Party ID: §e" + party.id.substring(0, 8));
                player.sendMessage("§7Use §e/dungeon party invite <player>§7 to add members");
                break;
                
            case "invite":
                if (args.length < 3) {
                    player.sendMessage("§c§lUsage: /dungeon party invite <player>");
                    return;
                }
                Player targetPlayer = plugin.getServer().getPlayer(args[2]);
                if (targetPlayer == null) {
                    player.sendMessage("§c§lPlayer not found!");
                    return;
                }
                service.inviteToParty(player, targetPlayer);
                break;
                
            case "accept":
                service.acceptPartyInvite(player);
                break;
                
            case "decline":
                service.declinePartyInvite(player);
                break;
                
            case "leave":
                service.leaveParty(player);
                break;
                
            case "list":
                EnhancedDungeonService.DungeonParty currentParty = service.getPlayerParty(player);
                if (currentParty == null) {
                    player.sendMessage("§c§lYou are not in a party!");
                    return;
                }
                player.sendMessage("§5§l✦ Party Members ✦ §7(" + currentParty.members.size() + "/5)");
                for (UUID memberId : currentParty.members) {
                    Player member = plugin.getServer().getPlayer(memberId);
                    String name = member != null ? member.getName() : "Offline";
                    String prefix = memberId.equals(currentParty.leader) ? "§6[Leader] §e" : "§7";
                    player.sendMessage(prefix + name);
                }
                break;
                
            case "start":
                if (args.length < 3) {
                    player.sendMessage("§c§lUsage: /dungeon party start <difficulty>");
                    return;
                }
                EnhancedDungeonService.DungeonParty partyForStart = service.getPlayerParty(player);
                if (partyForStart == null) {
                    player.sendMessage("§c§lYou are not in a party!");
                    return;
                }
                if (!partyForStart.leader.equals(player.getUniqueId())) {
                    player.sendMessage("§c§lOnly the party leader can start dungeons!");
                    return;
                }
                String partyDifficulty = args[2].toLowerCase();
                if (service.startPartyDungeon(partyForStart, partyDifficulty)) {
                    player.sendMessage("§a§l✓ Party dungeon started!");
                } else {
                    player.sendMessage("§c§lFailed to start party dungeon!");
                }
                break;
                
            default:
                player.sendMessage("§c§lInvalid party command!");
                break;
        }
    }
}
