package com.soulcraft.dungeons;

import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.Material;
import org.bukkit.Sound;

import java.util.UUID;

/**
 * Handles all dungeon-related events
 */
public class DungeonEventListener implements Listener {
    private final EnhancedDungeonService dungeonService;
    
    public DungeonEventListener(EnhancedDungeonService dungeonService) {
        this.dungeonService = dungeonService;
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();
        
        if (killer == null) return;
        
        // Check if this entity is part of a dungeon
        for (EnhancedDungeonService.DungeonInstance dungeon : dungeonService.getActiveDungeons().values()) {
            for (EnhancedDungeonService.Room room : dungeon.rooms) {
                if (room.entities.contains(entity.getUniqueId())) {
                    // Notify service
                    dungeonService.onMobKilled(entity.getUniqueId());
                    
                    // Bonus drops for dungeon mobs
                    event.getDrops().clear();
                    addDungeonDrops(event, dungeon);
                    
                    // Check if boss
                    if (entity.getUniqueId().equals(dungeon.bossId)) {
                        for (UUID playerId : dungeon.players) {
                            Player player = org.bukkit.Bukkit.getPlayer(playerId);
                            if (player != null) {
                                player.sendTitle("§6§lBOSS DEFEATED!", "§eVictory!", 10, 70, 20);
                                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                            }
                        }
                    }
                    
                    return;
                }
            }
        }
    }
    
    private void addDungeonDrops(EntityDeathEvent event, EnhancedDungeonService.DungeonInstance dungeon) {
        java.util.Random random = new java.util.Random();
        
        // Scale drops based on difficulty
        double dropMultiplier = dungeon.config.lootMultiplier;
        
        // Add gold
        if (random.nextDouble() < 0.6 * dropMultiplier) {
            event.getDrops().add(new org.bukkit.inventory.ItemStack(Material.GOLD_INGOT, 1 + random.nextInt(3)));
        }
        
        // Add diamonds
        if (random.nextDouble() < 0.3 * dropMultiplier) {
            event.getDrops().add(new org.bukkit.inventory.ItemStack(Material.DIAMOND, 1 + random.nextInt(2)));
        }
        
        // Add emeralds
        if (random.nextDouble() < 0.4 * dropMultiplier) {
            event.getDrops().add(new org.bukkit.inventory.ItemStack(Material.EMERALD, 1 + random.nextInt(3)));
        }
        
        // Increase XP
        event.setDroppedExp((int)(event.getDroppedExp() * dropMultiplier));
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Remove player from dungeon on disconnect
        if (dungeonService.isInDungeon(player.getUniqueId())) {
            dungeonService.leaveDungeon(player);
        }
    }
    
    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        
        // Prevent teleporting while in dungeon (except dungeon teleports)
        if (dungeonService.isInDungeon(player.getUniqueId())) {
            if (event.getCause() == PlayerTeleportEvent.TeleportCause.COMMAND) {
                event.setCancelled(true);
                player.sendMessage("§c§lYou cannot teleport while in a dungeon!");
            }
        }
    }
    
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        
        // Prevent block breaking in dungeons (except chests)
        if (dungeonService.isInDungeon(player.getUniqueId())) {
            if (event.getBlock().getType() != Material.CHEST) {
                event.setCancelled(true);
            }
        }
    }
}
