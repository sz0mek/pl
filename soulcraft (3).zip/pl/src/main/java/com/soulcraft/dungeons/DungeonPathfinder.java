package com.soulcraft.dungeons;

import org.bukkit.Location;
import java.util.*;

public class DungeonPathfinder {
    
    public static class PathNode {
        public Location location;
        public PathNode parent;
        public double gCost;
        public double hCost;
        public double fCost;
        
        public PathNode(Location location) {
            this.location = location;
            this.gCost = 0;
            this.hCost = 0;
            this.fCost = 0;
        }
        
        public void calculateFCost() {
            this.fCost = this.gCost + this.hCost;
        }
    }
    
    public static class RoomGraph {
        public List<RoomNode> nodes;
        public Map<RoomNode, List<RoomNode>> connections;
        
        public RoomGraph() {
            this.nodes = new ArrayList<>();
            this.connections = new HashMap<>();
        }
        
        public void addNode(RoomNode node) {
            nodes.add(node);
            connections.putIfAbsent(node, new ArrayList<>());
        }
        
        public void connect(RoomNode from, RoomNode to) {
            connections.get(from).add(to);
            connections.get(to).add(from);
        }
        
        public boolean isConnected(RoomNode start, RoomNode end) {
            if (start.equals(end)) return true;
            
            Set<RoomNode> visited = new HashSet<>();
            Queue<RoomNode> queue = new LinkedList<>();
            queue.add(start);
            visited.add(start);
            
            while (!queue.isEmpty()) {
                RoomNode current = queue.poll();
                
                if (current.equals(end)) {
                    return true;
                }
                
                for (RoomNode neighbor : connections.get(current)) {
                    if (!visited.contains(neighbor)) {
                        visited.add(neighbor);
                        queue.add(neighbor);
                    }
                }
            }
            
            return false;
        }
        
        public List<RoomNode> findPath(RoomNode start, RoomNode end) {
            if (start.equals(end)) {
                return Arrays.asList(start);
            }
            
            Map<RoomNode, RoomNode> cameFrom = new HashMap<>();
            Set<RoomNode> visited = new HashSet<>();
            Queue<RoomNode> queue = new LinkedList<>();
            
            queue.add(start);
            visited.add(start);
            
            while (!queue.isEmpty()) {
                RoomNode current = queue.poll();
                
                if (current.equals(end)) {
                    return reconstructPath(cameFrom, end);
                }
                
                for (RoomNode neighbor : connections.get(current)) {
                    if (!visited.contains(neighbor)) {
                        visited.add(neighbor);
                        queue.add(neighbor);
                        cameFrom.put(neighbor, current);
                    }
                }
            }
            
            return new ArrayList<>();
        }
        
        private List<RoomNode> reconstructPath(Map<RoomNode, RoomNode> cameFrom, RoomNode end) {
            List<RoomNode> path = new ArrayList<>();
            RoomNode current = end;
            
            while (current != null) {
                path.add(0, current);
                current = cameFrom.get(current);
            }
            
            return path;
        }
        
        public boolean validateFullConnectivity() {
            if (nodes.isEmpty()) return true;
            
            RoomNode start = nodes.get(0);
            Set<RoomNode> reachable = new HashSet<>();
            Queue<RoomNode> queue = new LinkedList<>();
            
            queue.add(start);
            reachable.add(start);
            
            while (!queue.isEmpty()) {
                RoomNode current = queue.poll();
                
                for (RoomNode neighbor : connections.get(current)) {
                    if (!reachable.contains(neighbor)) {
                        reachable.add(neighbor);
                        queue.add(neighbor);
                    }
                }
            }
            
            return reachable.size() == nodes.size();
        }
    }
    
    public static class RoomNode {
        public String roomId;
        public Location center;
        public int width;
        public int depth;
        
        public RoomNode(String roomId, Location center, int width, int depth) {
            this.roomId = roomId;
            this.center = center;
            this.width = width;
            this.depth = depth;
        }
        
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof RoomNode)) return false;
            RoomNode other = (RoomNode) obj;
            return this.roomId.equals(other.roomId);
        }
        
        @Override
        public int hashCode() {
            return roomId.hashCode();
        }
    }
    
    public static boolean floodFillValidation(Location start, Set<Location> validLocations, int maxDistance) {
        Set<Location> visited = new HashSet<>();
        Queue<Location> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);
        
        int blocksChecked = 0;
        int maxBlocks = maxDistance * maxDistance * maxDistance;
        
        while (!queue.isEmpty() && blocksChecked < maxBlocks) {
            Location current = queue.poll();
            blocksChecked++;
            
            Location[] neighbors = {
                current.clone().add(1, 0, 0),
                current.clone().add(-1, 0, 0),
                current.clone().add(0, 0, 1),
                current.clone().add(0, 0, -1),
                current.clone().add(0, 1, 0),
                current.clone().add(0, -1, 0)
            };
            
            for (Location neighbor : neighbors) {
                if (!visited.contains(neighbor) && validLocations.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }
        
        return visited.size() >= validLocations.size() * 0.95;
    }
    
    public static double calculateDistance(Location a, Location b) {
        return a.distance(b);
    }
    
    public static Location findNearestDoorway(Location from, List<Location> doorways) {
        Location nearest = null;
        double minDistance = Double.MAX_VALUE;
        
        for (Location doorway : doorways) {
            double distance = calculateDistance(from, doorway);
            if (distance < minDistance) {
                minDistance = distance;
                nearest = doorway;
            }
        }
        
        return nearest;
    }
}
