package com.soulcraft.dungeons;

import org.bukkit.Material;
import org.bukkit.Location;
import java.util.*;

public class RoomTemplate {
    public enum TemplateType {
        COMBAT_ARENA,
        TREASURE_VAULT,
        TRAP_MAZE,
        BOSS_CHAMBER,
        ENTRY_HALL,
        SECRET_GARDEN,
        LIBRARY,
        FORGE
    }
    
    public enum BiomeTheme {
        UNDEAD("Undead Crypt", Material.MOSSY_STONE_BRICKS, Material.SOUL_SAND),
        VOID("Void Realm", Material.END_STONE_BRICKS, Material.OBSIDIAN),
        INFERNO("Inferno", Material.NETHER_BRICKS, Material.NETHERRACK),
        FROZEN("Frozen Wastes", Material.PACKED_ICE, Material.ICE),
        SHADOW("Shadow Domain", Material.BLACKSTONE, Material.POLISHED_BLACKSTONE);
        
        public final String name;
        public final Material wallMaterial;
        public final Material floorMaterial;
        
        BiomeTheme(String name, Material wall, Material floor) {
            this.name = name;
            this.wallMaterial = wall;
            this.floorMaterial = floor;
        }
    }
    
    public static class Doorway {
        public Location location;
        public Direction direction;
        public boolean locked;
        
        public enum Direction {
            NORTH, SOUTH, EAST, WEST
        }
    }
    
    private TemplateType type;
    private BiomeTheme theme;
    private int width;
    private int height;
    private int depth;
    private List<Doorway> doorways;
    private List<Location> mobSpawnPoints;
    private List<Location> chestLocations;
    private List<Location> trapLocations;
    private Location bossSpawnPoint;
    
    public RoomTemplate(TemplateType type, BiomeTheme theme, int width, int height, int depth) {
        this.type = type;
        this.theme = theme;
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.doorways = new ArrayList<>();
        this.mobSpawnPoints = new ArrayList<>();
        this.chestLocations = new ArrayList<>();
        this.trapLocations = new ArrayList<>();
    }
    
    public void addDoorway(Doorway doorway) {
        this.doorways.add(doorway);
    }
    
    public void addMobSpawnPoint(Location loc) {
        this.mobSpawnPoints.add(loc);
    }
    
    public void addChestLocation(Location loc) {
        this.chestLocations.add(loc);
    }
    
    public void addTrapLocation(Location loc) {
        this.trapLocations.add(loc);
    }
    
    public void setBossSpawnPoint(Location loc) {
        this.bossSpawnPoint = loc;
    }
    
    public TemplateType getType() {
        return type;
    }
    
    public BiomeTheme getTheme() {
        return theme;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getDepth() {
        return depth;
    }
    
    public List<Doorway> getDoorways() {
        return doorways;
    }
    
    public List<Location> getMobSpawnPoints() {
        return mobSpawnPoints;
    }
    
    public List<Location> getChestLocations() {
        return chestLocations;
    }
    
    public List<Location> getTrapLocations() {
        return trapLocations;
    }
    
    public Location getBossSpawnPoint() {
        return bossSpawnPoint;
    }
    
    public static RoomTemplate createCombatArena(BiomeTheme theme, int size) {
        RoomTemplate template = new RoomTemplate(TemplateType.COMBAT_ARENA, theme, size, 6, size);
        
        Doorway north = new Doorway();
        north.direction = Doorway.Direction.NORTH;
        north.locked = false;
        template.addDoorway(north);
        
        Doorway south = new Doorway();
        south.direction = Doorway.Direction.SOUTH;
        south.locked = false;
        template.addDoorway(south);
        
        for (int i = 0; i < 6 + (size / 5); i++) {
            template.addMobSpawnPoint(new Location(null, size / 2, 0, size / 2));
        }
        
        return template;
    }
    
    public static RoomTemplate createTreasureVault(BiomeTheme theme, int size) {
        RoomTemplate template = new RoomTemplate(TemplateType.TREASURE_VAULT, theme, size, 6, size);
        
        Doorway entrance = new Doorway();
        entrance.direction = Doorway.Direction.SOUTH;
        entrance.locked = true;
        template.addDoorway(entrance);
        
        int chestCount = 3 + (size / 10);
        for (int i = 0; i < chestCount; i++) {
            template.addChestLocation(new Location(null, 0, 0, 0));
        }
        
        return template;
    }
    
    public static RoomTemplate createBossChamber(BiomeTheme theme, int size) {
        RoomTemplate template = new RoomTemplate(TemplateType.BOSS_CHAMBER, theme, size, 8, size);
        
        Doorway entrance = new Doorway();
        entrance.direction = Doorway.Direction.SOUTH;
        entrance.locked = true;
        template.addDoorway(entrance);
        
        template.setBossSpawnPoint(new Location(null, size / 2, 0, size / 4));
        
        return template;
    }
    
    public static RoomTemplate createEntryHall(BiomeTheme theme, int size) {
        RoomTemplate template = new RoomTemplate(TemplateType.ENTRY_HALL, theme, size, 6, size);
        
        Doorway north = new Doorway();
        north.direction = Doorway.Direction.NORTH;
        north.locked = false;
        template.addDoorway(north);
        
        return template;
    }
}
