// KitManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class KitManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final List<UUID> activePlayers = new ArrayList<>();

    public KitManager(SoulCraftPlugin plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void openKitGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "§6Wybierz Kit");

        // Dodanie gracza do listy aktywnych GUI
        activePlayers.add(player.getUniqueId());

        // Tło
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, filler);
        }

        // Kit 1 (Gracz)
        ItemStack kit1 = new ItemStack(Material.COOKED_CHICKEN);
        ItemMeta kit1Meta = kit1.getItemMeta();
        kit1Meta.setDisplayName("§bKit Gracz");
        kit1Meta.setLore(Arrays.asList(
                "§7Zawiera:",
                "§7- 32 Pieczone Kurczaki",
                "§7- Kamienny Kilof",
                "§7- Kamienny Miecz",
                "§7- Skórzany Hełm",
                "§7Cooldown: 6 godzin"));
        kit1.setItemMeta(kit1Meta);
        gui.setItem(10, kit1);

        // Kit 2 (VIP)
        ItemStack kit2 = new ItemStack(Material.GOLDEN_CARROT);
        ItemMeta kit2Meta = kit2.getItemMeta();
        kit2Meta.setDisplayName("§eKit VIP");
        kit2Meta.setLore(Arrays.asList(
                "§7Zawiera:",
                "§7- 32 Złote Marchewki",
                "§7- Żelazny Kilof",
                "§7- Złoty Miecz",
                "§7- Żelazny Hełm",
                "§7- 2 Kryształy Dusz (Lvl 3)",
                "§7Cooldown: 12 godzin",
                "§7Wymagana ranga: VIP"));
        kit2.setItemMeta(kit2Meta);
        gui.setItem(12, kit2);

        // Kit 3 (SVIP)
        ItemStack kit3 = new ItemStack(Material.GOLDEN_APPLE);
        ItemMeta kit3Meta = kit3.getItemMeta();
        kit3Meta.setDisplayName("§6Kit SVIP");
        kit3Meta.setLore(Arrays.asList(
                "§7Zawiera:",
                "§7- 6 Złotych Jabłek",
                "§7- Diamentowy Kilof",
                "§7- Żelazny Miecz",
                "§7- Diamentowy Hełm",
                "§7- 2 Kryształy Dusz (Lvl 3)",
                "§7Cooldown: 16 godzin",
                "§7Wymagana ranga: SVIP"));
        kit3.setItemMeta(kit3Meta);
        gui.setItem(14, kit3);

        // Kit 4 (SoulGod)
        ItemStack kit4 = new ItemStack(Material.ENCHANTED_GOLDEN_APPLE);
        ItemMeta kit4Meta = kit4.getItemMeta();
        kit4Meta.setDisplayName("§5Kit SoulGod");
        kit4Meta.setLore(Arrays.asList(
                "§7Zawiera:",
                "§7- 6 Enchantowanych Złotych Jabłek",
                "§7- Netherytowy Kilof",
                "§7- Diamentowy Miecz",
                "§7- Netherytowy Hełm",
                "§7- 3 Kryształy Dusz (Lvl 5)",
                "§7Cooldown: 24 godziny",
                "§7Wymagana ranga: SoulGod"));
        kit4.setItemMeta(kit4Meta);
        gui.setItem(16, kit4);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;
        if (!activePlayers.contains(player.getUniqueId()))
            return;

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE)
            return;

        String rank = rankManager.getRank(player);
        long currentTime = System.currentTimeMillis();

        if (clicked.getType() == Material.COOKED_CHICKEN) {
            if (rank.equals("gracz") || rank.equals("vip") || rank.equals("svip") || rank.equals("soulgod")) {
                if (isOnCooldown(player.getUniqueId(), "gracz", 6 * 60 * 60 * 1000L, currentTime))
                    return;
                giveKit1(player);
                cooldowns.put(player.getUniqueId(), currentTime);
                player.sendMessage("§aOdebrałeś kit Gracz! Cooldown: 6 godzin.");
            } else {
                player.sendMessage("§cTen kit jest tylko dla rangi Gracz!");
            }
        } else if (clicked.getType() == Material.GOLDEN_CARROT) {
            if (rank.equals("vip") || rank.equals("svip") || rank.equals("soulgod")) {
                if (isOnCooldown(player.getUniqueId(), "vip", 12 * 60 * 60 * 1000L, currentTime))
                    return;
                giveKit2(player);
                cooldowns.put(player.getUniqueId(), currentTime);
                player.sendMessage("§aOdebrałeś kit VIP! Cooldown: 12 godzin.");
            } else {
                player.sendMessage("§cMusisz mieć rangę VIP, aby odebrać ten kit!");
            }
        } else if (clicked.getType() == Material.GOLDEN_APPLE) {
            if (rank.equals("svip") || rank.equals("soulgod")) {
                if (isOnCooldown(player.getUniqueId(), "svip", 16 * 60 * 60 * 1000L, currentTime))
                    return;
                giveKit3(player);
                cooldowns.put(player.getUniqueId(), currentTime);
                player.sendMessage("§aOdebrałeś kit SVIP! Cooldown: 16 godzin.");
            } else {
                player.sendMessage("§cMusisz mieć rangę SVIP, aby odebrać ten kit!");
            }
        } else if (clicked.getType() == Material.ENCHANTED_GOLDEN_APPLE) {
            if (rank.equals("soulgod")) {
                if (isOnCooldown(player.getUniqueId(), "soulgod", 24 * 60 * 60 * 1000L, currentTime))
                    return;
                giveKit4(player);
                cooldowns.put(player.getUniqueId(), currentTime);
                player.sendMessage("§aOdebrałeś kit SoulGod! Cooldown: 24 godziny.");
            } else {
                player.sendMessage("§cMusisz mieć rangę SoulGod, aby odebrać ten kit!");
            }
        }

        player.closeInventory();
        activePlayers.remove(player.getUniqueId());
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;
        if (!activePlayers.contains(player.getUniqueId()))
            return;
        event.setCancelled(true);
    }

    private boolean isOnCooldown(UUID uuid, String rank, long cooldown, long currentTime) {
        Long lastUse = cooldowns.get(uuid);
        if (lastUse == null)
            return false;
        long timeElapsed = currentTime - lastUse;
        if (timeElapsed < cooldown) {
            long remaining = (cooldown - timeElapsed) / 1000 / 60;
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                player.sendMessage("§cMusisz poczekać " + remaining + " minut przed ponownym odebraniem!");
            }
            return true;
        }
        return false;
    }

    private void giveKit1(Player player) {
        player.getInventory().addItem(
                new ItemStack(Material.COOKED_CHICKEN, 32),
                new ItemStack(Material.STONE_PICKAXE),
                new ItemStack(Material.STONE_SWORD),
                new ItemStack(Material.LEATHER_HELMET));
    }

    private void giveKit2(Player player) {
        player.getInventory().addItem(
                new ItemStack(Material.GOLDEN_CARROT, 32),
                new ItemStack(Material.IRON_PICKAXE),
                new ItemStack(Material.GOLDEN_SWORD),
                new ItemStack(Material.IRON_HELMET),
                plugin.getCommandHandler().createSoulCrystal(3));
        player.getInventory().addItem(new ItemStack(Material.EMERALD)); // Dodatkowy kryształ do ustawienia meta
    }

    private void giveKit3(Player player) {
        player.getInventory().addItem(
                new ItemStack(Material.GOLDEN_APPLE, 6),
                new ItemStack(Material.DIAMOND_PICKAXE),
                new ItemStack(Material.IRON_SWORD),
                new ItemStack(Material.DIAMOND_HELMET),
                plugin.getCommandHandler().createSoulCrystal(3));
        player.getInventory().addItem(new ItemStack(Material.EMERALD)); // Dodatkowy kryształ do ustawienia meta
    }

    private void giveKit4(Player player) {
        player.getInventory().addItem(
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 6),
                new ItemStack(Material.NETHERITE_PICKAXE),
                new ItemStack(Material.DIAMOND_SWORD),
                new ItemStack(Material.NETHERITE_HELMET),
                plugin.getCommandHandler().createSoulCrystal(5));
        player.getInventory().addItem(new ItemStack(Material.EMERALD, 2)); // 2 dodatkowe kryształy do ustawienia meta
    }
}
