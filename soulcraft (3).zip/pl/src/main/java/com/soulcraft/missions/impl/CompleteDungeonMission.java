package com.soulcraft.missions.impl;

import com.soulcraft.missions.Mission;
import org.bukkit.entity.Player;

import java.util.*;

public class CompleteDungeonMission extends Mission {
    private final Map<UUID, Integer> progress = new HashMap<>();
    private final Map<UUID, Boolean> completed = new HashMap<>();
    
    public CompleteDungeonMission(String id, String displayName, String description, MissionType type,
                                 int requiredProgress, List<MissionReward> rewards, String requiredRank) {
        super(id, displayName, description, type, requiredProgress, rewards, requiredRank);
    }
    
    @Override
    public boolean checkProgress(Player player, Object... args) {
        incrementProgress(player.getUniqueId(), 1);
        return true;
    }
    
    @Override
    public int getProgress(UUID playerId) {
        return progress.getOrDefault(playerId, 0);
    }
    
    @Override
    public void setProgress(UUID playerId, int value) {
        progress.put(playerId, value);
    }
    
    @Override
    public void incrementProgress(UUID playerId, int amount) {
        int current = getProgress(playerId);
        setProgress(playerId, Math.min(current + amount, requiredProgress));
    }
    
    @Override
    public boolean isCompleted(UUID playerId) {
        return completed.getOrDefault(playerId, false);
    }
    
    @Override
    public void complete(Player player) {
        completed.put(player.getUniqueId(), true);
        giveRewards(player);
        player.sendMessage("§a§l✔ Ukończono misję: " + displayName);
    }
    
    @Override
    public void giveRewards(Player player) {
        // Handled by MissionManager
    }
    
    @Override
    public void reset(UUID playerId) {
        progress.remove(playerId);
        completed.remove(playerId);
    }
}
