package com.soulcraft.missions;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Event listener for tracking mission progress across all game activities
 */
public class MissionEventListener implements Listener {
    private final SoulCraftPlugin plugin;
    private final MissionManager missionManager;
    private final Map<UUID, Long> playTimestamps = new HashMap<>();
    
    public MissionEventListener(SoulCraftPlugin plugin, MissionManager missionManager) {
        this.plugin = plugin;
        this.missionManager = missionManager;
        startPlayTimeTracker();
    }
    
    /**
     * Track mob kills for missions
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onMobKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null) {
            EntityType mobType = event.getEntityType();
            
            // Track for all kill mobs missions
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.KillMobsMission) {
                    mission.checkProgress(killer, mobType);
                    checkAndCompleteMission(killer, mission);
                }
            });
            
            // Track for boss kill missions
            if (isBoss(event.getEntity())) {
                missionManager.getAllMissions().forEach((id, mission) -> {
                    if (mission instanceof com.soulcraft.missions.impl.KillBossMission ||
                        mission instanceof com.soulcraft.missions.impl.KillSpecificBossMission) {
                        mission.checkProgress(killer, mobType);
                        checkAndCompleteMission(killer, mission);
                    }
                });
            }
        }
    }
    
    /**
     * Track player kills for missions
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerKill(PlayerDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null && killer != event.getEntity()) {
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.KillPlayersMission) {
                    mission.checkProgress(killer);
                    checkAndCompleteMission(killer, mission);
                }
                if (mission instanceof com.soulcraft.missions.impl.WinPvPStreakMission) {
                    mission.checkProgress(killer, true);
                    checkAndCompleteMission(killer, mission);
                }
            });
        }
        
        // Reset PvP streak for the killed player
        if (event.getEntity() != null) {
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.WinPvPStreakMission) {
                    mission.checkProgress(event.getEntity(), false);
                }
            });
        }
    }
    
    /**
     * Track block mining for missions
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!event.isCancelled()) {
            Player player = event.getPlayer();
            
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.MineBlocksMission) {
                    mission.checkProgress(player);
                    checkAndCompleteMission(player, mission);
                }
            });
        }
    }
    
    /**
     * Track crafting for missions
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onCraft(CraftItemEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            int amount = event.getRecipe().getResult().getAmount();
            
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.CraftItemsMission) {
                    mission.checkProgress(player, amount);
                    checkAndCompleteMission(player, mission);
                }
            });
        }
    }
    
    /**
     * Initialize player on join
     */
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        playTimestamps.put(player.getUniqueId(), System.currentTimeMillis());
        
        // Check for tutorial completion mission
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CompleteTutorialMission) {
                // Will be checked when tutorial is completed
            }
        });
    }
    
    /**
     * Start play time tracker for PlayTimeMission
     */
    private void startPlayTimeTracker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getServer().getOnlinePlayers().forEach(player -> {
                    UUID playerId = player.getUniqueId();
                    Long joinTime = playTimestamps.get(playerId);
                    
                    if (joinTime != null) {
                        long minutesPlayed = (System.currentTimeMillis() - joinTime) / 60000;
                        
                        missionManager.getAllMissions().forEach((id, mission) -> {
                            if (mission instanceof com.soulcraft.missions.impl.PlayTimeMission) {
                                mission.checkProgress(player, (int) minutesPlayed);
                                checkAndCompleteMission(player, mission);
                            }
                        });
                    }
                });
            }
        }.runTaskTimer(plugin, 1200L, 1200L); // Check every minute
    }
    
    /**
     * Check if mission is complete and trigger completion
     */
    private void checkAndCompleteMission(Player player, Mission mission) {
        if (!mission.isCompleted(player.getUniqueId()) &&
            mission.getProgress(player.getUniqueId()) >= mission.getRequiredProgress()) {
            mission.complete(player);
            
            // Track for CompleteMissionsMission
            missionManager.getAllMissions().forEach((id, m) -> {
                if (m instanceof com.soulcraft.missions.impl.CompleteMissionsMission) {
                    m.checkProgress(player);
                    if (m.getProgress(player.getUniqueId()) >= m.getRequiredProgress()) {
                        m.complete(player);
                    }
                }
            });
        }
    }
    
    /**
     * Check if entity is a boss
     */
    private boolean isBoss(org.bukkit.entity.Entity entity) {
        // Check if entity has boss metadata or custom name
        return entity.getCustomName() != null && 
               (entity.getCustomName().contains("Boss") || 
                entity.getCustomName().contains("§"));
    }
    
    /**
     * Track souls earned for missions
     */
    public void trackSoulsEarned(Player player, long amount) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.EarnSoulsMission) {
                mission.checkProgress(player, (int) amount);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track souls spent for missions
     */
    public void trackSoulsSpent(Player player, long amount) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.SpendSoulsMission) {
                mission.checkProgress(player, (int) amount);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track ability usage for missions
     */
    public void trackAbilityUse(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.UseAbilitiesMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track dungeon completion for missions
     */
    public void trackDungeonCompletion(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CompleteDungeonMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track loot collection for missions
     */
    public void trackLootCollection(Player player, int amount) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CollectLootMission) {
                mission.checkProgress(player, amount);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track custom item acquisition for missions
     */
    public void trackCustomItemAcquired(Player player, String itemId) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.GetCustomItemMission) {
                mission.checkProgress(player, itemId);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track pet acquisition for missions
     */
    public void trackPetAcquired(Player player, String petType) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.GetPetMission) {
                mission.checkProgress(player, petType);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track pet leveling for missions
     */
    public void trackPetLevelUp(Player player, int newLevel) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.LevelPetMission) {
                mission.checkProgress(player, newLevel);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track ability unlock for missions
     */
    public void trackAbilityUnlock(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.UnlockAbilitiesMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track clan creation/join for missions
     */
    public void trackClanJoined(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CreateClanMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track clan level up for missions
     */
    public void trackClanLevelUp(Player player, int newLevel) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.ClanLevelMission) {
                mission.checkProgress(player, newLevel);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track clan war victory for missions
     */
    public void trackClanWarWin(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.ClanWarsMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track rebirth for missions
     */
    public void trackRebirth(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.RebirthMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track tutorial completion for missions
     */
    public void trackTutorialCompletion(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CompleteTutorialMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track daily mission completion for CompleteAllDailyMission
     */
    public void trackDailyMissionsCompleted(Player player, boolean allCompleted) {
        if (allCompleted) {
            missionManager.getAllMissions().forEach((id, mission) -> {
                if (mission instanceof com.soulcraft.missions.impl.CompleteAllDailyMission) {
                    mission.checkProgress(player);
                    checkAndCompleteMission(player, mission);
                }
            });
        }
    }
    
    /**
     * Track weapon collection for missions
     */
    public void checkWeaponCollection(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CollectAllWeaponsMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track armor collection for missions
     */
    public void checkArmorCollection(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.CollectAllArmorMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
    
    /**
     * Track trading for missions
     */
    public void trackTrade(Player player) {
        missionManager.getAllMissions().forEach((id, mission) -> {
            if (mission instanceof com.soulcraft.missions.impl.TradeItemsMission) {
                mission.checkProgress(player);
                checkAndCompleteMission(player, mission);
            }
        });
    }
}
