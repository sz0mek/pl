package com.soulcraft.missions;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.persistence.PlayerData.MissionProgress;
import com.soulcraft.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.time.*;
import java.util.*;

/**
 * Complete mission system with dynamic generation, daily/weekly/story missions
 */
public class MissionService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final Map<String, MissionTemplate> missionTemplates;
    private final Random random;
    
    private final int DAILY_SLOTS = 5;
    private final int WEEKLY_SLOTS = 3;
    
    public MissionService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionTemplates = new HashMap<>();
        this.random = new Random();
        
        loadMissionTemplates();
        startResetTask();
    }
    
    private void loadMissionTemplates() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load all mission types
        loadMissionType(balance, "kill_mobs", MissionType.KILL_MOBS);
        loadMissionType(balance, "kill_players", MissionType.KILL_PLAYERS);
        loadMissionType(balance, "kill_bosses", MissionType.KILL_BOSSES);
        loadMissionType(balance, "mine_blocks", MissionType.MINE_BLOCKS);
        loadMissionType(balance, "collect_loot", MissionType.COLLECT_LOOT);
        loadMissionType(balance, "complete_dungeons", MissionType.COMPLETE_DUNGEONS);
        loadMissionType(balance, "earn_souls", MissionType.EARN_SOULS);
        loadMissionType(balance, "clan_activities", MissionType.CLAN_ACTIVITIES);
    }
    
    private void loadMissionType(YamlConfiguration balance, String typeKey, MissionType type) {
        String path = "missions.types." + typeKey + ".tiers";
        ConfigurationSection tiersSection = balance.getConfigurationSection(path);
        
        if (tiersSection != null) {
            for (String tier : tiersSection.getKeys(false)) {
                MissionTemplate template = new MissionTemplate();
                template.id = typeKey + "_" + tier;
                template.type = type;
                template.tier = tier;
                template.count = balance.getInt(path + "." + tier + ".count", 0);
                template.amount = balance.getLong(path + "." + tier + ".amount", 0);
                template.reward = balance.getLong(path + "." + tier + ".reward", 0);
                template.xp = balance.getLong(path + "." + tier + ".xp", 0);
                
                missionTemplates.put(template.id, template);
            }
        }
    }
    
    /**
     * Check and reset daily missions
     */
    public void checkDailyReset(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        long lastReset = data.getDailyResetTime();
        
        LocalDate lastResetDate = Instant.ofEpochMilli(lastReset).atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate now = LocalDate.now();
        
        if (now.isAfter(lastResetDate)) {
            // Reset daily missions
            resetDailyMissions(playerId);
            data.setDailyResetTime(System.currentTimeMillis());
        }
    }
    
    /**
     * Check and reset weekly missions
     */
    public void checkWeeklyReset(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        long lastReset = data.getWeeklyResetTime();
        
        LocalDate lastResetDate = Instant.ofEpochMilli(lastReset).atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate now = LocalDate.now();
        
        // Check if it's Monday (week start)
        if (now.getDayOfWeek() == DayOfWeek.MONDAY && now.isAfter(lastResetDate)) {
            // Reset weekly missions
            resetWeeklyMissions(playerId);
            data.setWeeklyResetTime(System.currentTimeMillis());
        }
    }
    
    /**
     * Reset and generate new daily missions
     */
    private void resetDailyMissions(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        
        // Remove old daily missions
        List<String> toRemove = new ArrayList<>();
        for (String missionId : data.getActiveMissions().keySet()) {
            if (missionId.startsWith("daily_")) {
                toRemove.add(missionId);
            }
        }
        toRemove.forEach(id -> data.removeMission(id));
        
        // Generate new daily missions
        for (int i = 0; i < DAILY_SLOTS; i++) {
            generateDailyMission(data, i);
        }
    }
    
    /**
     * Generate a daily mission
     */
    private void generateDailyMission(PlayerData data, int slot) {
        // Pick random mission template
        List<MissionTemplate> templates = new ArrayList<>(missionTemplates.values());
        MissionTemplate template = templates.get(random.nextInt(templates.size()));
        
        String missionId = "daily_" + slot + "_" + System.currentTimeMillis();
        
        // Set expiry to end of day
        LocalDateTime endOfDay = LocalDate.now().plusDays(1).atStartOfDay();
        long expiryTime = endOfDay.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        
        int required = template.count > 0 ? template.count : (int)template.amount;
        MissionProgress progress = new MissionProgress(missionId, required, expiryTime);
        
        data.addActiveMission(missionId, progress);
    }
    
    /**
     * Reset and generate new weekly missions
     */
    private void resetWeeklyMissions(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        
        // Remove old weekly missions
        List<String> toRemove = new ArrayList<>();
        for (String missionId : data.getActiveMissions().keySet()) {
            if (missionId.startsWith("weekly_")) {
                toRemove.add(missionId);
            }
        }
        toRemove.forEach(id -> data.removeMission(id));
        
        // Generate new weekly missions (harder than daily)
        for (int i = 0; i < WEEKLY_SLOTS; i++) {
            generateWeeklyMission(data, i);
        }
    }
    
    /**
     * Generate a weekly mission
     */
    private void generateWeeklyMission(PlayerData data, int slot) {
        // Pick harder mission templates (medium/hard tier)
        List<MissionTemplate> hardTemplates = new ArrayList<>();
        for (MissionTemplate template : missionTemplates.values()) {
            if (template.tier.equals("medium") || template.tier.equals("hard")) {
                hardTemplates.add(template);
            }
        }
        
        if (hardTemplates.isEmpty()) return;
        
        MissionTemplate template = hardTemplates.get(random.nextInt(hardTemplates.size()));
        String missionId = "weekly_" + slot + "_" + System.currentTimeMillis();
        
        // Set expiry to end of week (Sunday)
        LocalDateTime endOfWeek = LocalDate.now().with(DayOfWeek.SUNDAY).atTime(23, 59, 59);
        long expiryTime = endOfWeek.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        
        int required = template.count > 0 ? template.count : (int)template.amount;
        MissionProgress progress = new MissionProgress(missionId, required, expiryTime);
        
        data.addActiveMission(missionId, progress);
    }
    
    /**
     * Progress mission
     */
    public void progressMission(UUID playerId, MissionType type, int amount) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        
        for (Map.Entry<String, MissionProgress> entry : data.getActiveMissions().entrySet()) {
            String missionId = entry.getKey();
            MissionProgress progress = entry.getValue();
            
            // Get mission template
            String templateId = extractTemplateId(missionId);
            MissionTemplate template = missionTemplates.get(templateId);
            
            if (template != null && template.type == type) {
                if (!progress.isComplete() && !progress.isExpired()) {
                    progress.addProgress(amount);
                    
                    // Check completion
                    if (progress.isComplete()) {
                        Player player = Bukkit.getPlayer(playerId);
                        if (player != null) {
                            player.sendMessage("§a§l✓ Mission Complete! §e" + getMissionName(template));
                            player.playSound(player.getLocation(), "ui.toast.challenge_complete", 1.0f, 1.0f);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Claim mission reward
     */
    public boolean claimMissionReward(UUID playerId, String missionId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        MissionProgress progress = data.getMissionProgress(missionId);
        
        if (progress == null || !progress.isComplete()) {
            return false;
        }
        
        // Get template
        String templateId = extractTemplateId(missionId);
        MissionTemplate template = missionTemplates.get(templateId);
        
        if (template == null) return false;
        
        // Give rewards
        economyService.deposit(playerId, template.reward, "Mission reward: " + template.id);
        data.addExperience(template.xp);
        
        // Mark as completed and remove
        data.completeMission(missionId);
        data.removeMission(missionId);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§6§l✦ Reward Claimed! §e+" + template.reward + " souls, +" + template.xp + " XP");
        }
        
        return true;
    }
    
    /**
     * Get active missions for player
     */
    public Map<String, MissionProgress> getActiveMissions(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        return data.getActiveMissions();
    }
    
    /**
     * Get mission name
     */
    private String getMissionName(MissionTemplate template) {
        switch (template.type) {
            case KILL_MOBS:
                return "Kill " + template.count + " mobs";
            case KILL_PLAYERS:
                return "Kill " + template.count + " players";
            case KILL_BOSSES:
                return "Kill " + template.count + " bosses";
            case MINE_BLOCKS:
                return "Mine " + template.count + " blocks";
            case COLLECT_LOOT:
                return "Collect " + template.count + " items";
            case COMPLETE_DUNGEONS:
                return "Complete " + template.count + " dungeons";
            case EARN_SOULS:
                return "Earn " + template.amount + " souls";
            case CLAN_ACTIVITIES:
                return "Contribute " + template.amount + " to clan";
            default:
                return "Unknown mission";
        }
    }
    
    /**
     * Extract template ID from mission ID
     */
    private String extractTemplateId(String missionId) {
        // daily_0_1234567890 -> extract type and tier
        // For now, return a default template
        for (String templateId : missionTemplates.keySet()) {
            if (missionId.contains(templateId.split("_")[0])) {
                return templateId;
            }
        }
        return "";
    }
    
    /**
     * Start reset task
     */
    private void startResetTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                checkDailyReset(player.getUniqueId());
                checkWeeklyReset(player.getUniqueId());
            }
        }, 600L, 6000L); // Check every 5 minutes
    }
    
    /**
     * Mission template
     */
    public static class MissionTemplate {
        public String id;
        public MissionType type;
        public String tier;
        public int count;
        public long amount;
        public long reward;
        public long xp;
    }
    
    /**
     * Mission types
     */
    public enum MissionType {
        KILL_MOBS,
        KILL_PLAYERS,
        KILL_BOSSES,
        MINE_BLOCKS,
        COLLECT_LOOT,
        COMPLETE_DUNGEONS,
        EARN_SOULS,
        CLAN_ACTIVITIES
    }
}
