package com.soulcraft.missions.impl;

import com.soulcraft.missions.Mission;
import org.bukkit.entity.Player;
import java.util.*;

public class CollectAllWeaponsMission extends Mission {
    private final Map<UUID, Set<String>> collectedWeapons = new HashMap<>();
    private final Map<UUID, Boolean> completed = new HashMap<>();
    private static final Set<String> ALL_WEAPONS = Set.of("soul_reaper", "void_blade", "chaos_hammer", "phantom_bow", "dark_staff");
    
    public CollectAllWeaponsMission(String id, String displayName, String description, MissionType type,
                                   int requiredProgress, List<MissionReward> rewards, String requiredRank) {
        super(id, displayName, description, type, requiredProgress, rewards, requiredRank);
    }
    
    @Override
    public boolean checkProgress(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof String) {
            String weaponId = (String) args[0];
            if (ALL_WEAPONS.contains(weaponId)) {
                collectedWeapons.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(weaponId);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int getProgress(UUID playerId) {
        return collectedWeapons.getOrDefault(playerId, new HashSet<>()).size();
    }
    @Override
    public void setProgress(UUID playerId, int value) { }
    @Override
    public void incrementProgress(UUID playerId, int amount) { }
    @Override
    public boolean isCompleted(UUID playerId) { return completed.getOrDefault(playerId, false); }
    @Override
    public void complete(Player player) {
        completed.put(player.getUniqueId(), true);
        giveRewards(player);
        player.sendMessage("§a§l✔ Ukończono misję: " + displayName);
    }
    @Override
    public void giveRewards(Player player) { }
    @Override
    public void reset(UUID playerId) {
        collectedWeapons.remove(playerId);
        completed.remove(playerId);
    }
}
