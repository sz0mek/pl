package com.soulcraft.missions;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public abstract class Mission {
    protected final String id;
    protected final String displayName;
    protected final String description;
    protected final MissionType type;
    protected final int requiredProgress;
    protected final List<MissionReward> rewards;
    protected final String requiredRank;
    
    public Mission(String id, String displayName, String description, MissionType type, 
                   int requiredProgress, List<MissionReward> rewards, String requiredRank) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.type = type;
        this.requiredProgress = requiredProgress;
        this.rewards = rewards;
        this.requiredRank = requiredRank;
    }
    
    public abstract boolean checkProgress(Player player, Object... args);
    public abstract int getProgress(UUID playerId);
    public abstract void setProgress(UUID playerId, int progress);
    public abstract void incrementProgress(UUID playerId, int amount);
    public abstract boolean isCompleted(UUID playerId);
    public abstract void complete(Player player);
    public abstract void giveRewards(Player player);
    public abstract void reset(UUID playerId);
    
    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }
    public MissionType getType() { return type; }
    public int getRequiredProgress() { return requiredProgress; }
    public List<MissionReward> getRewards() { return rewards; }
    public String getRequiredRank() { return requiredRank; }
    
    public enum MissionType {
        DAILY,
        WEEKLY,
        ACHIEVEMENT
    }
    
    public static class MissionReward {
        private final RewardType type;
        private final int amount;
        private final String data;
        
        public MissionReward(RewardType type, int amount, String data) {
            this.type = type;
            this.amount = amount;
            this.data = data;
        }
        
        public RewardType getType() { return type; }
        public int getAmount() { return amount; }
        public String getData() { return data; }
        
        public enum RewardType {
            SOULS,
            MONEY,
            EXPERIENCE,
            ITEM,
            ABILITY_UNLOCK,
            RANK_UPGRADE
        }
    }
}
