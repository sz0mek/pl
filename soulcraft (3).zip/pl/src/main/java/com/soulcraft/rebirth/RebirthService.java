package com.soulcraft.rebirth;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Complete rebirth system with stat bonuses and prestige unlocks
 */
public class RebirthService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final int MAX_REBIRTHS = 10;
    
    // Bonuses per rebirth
    private final double HEALTH_PER_REBIRTH = 0.05;  // 5% HP
    private final double DAMAGE_PER_REBIRTH = 0.03;  // 3% damage
    private final double SPEED_PER_REBIRTH = 0.02;   // 2% speed
    private final double LOOT_PER_REBIRTH = 0.05;    // 5% better loot
    private final double SOULS_PER_REBIRTH = 0.10;   // 10% more souls
    
    private final Map<Integer, RebirthRequirements> requirements;
    private final Map<Integer, List<String>> unlocks;
    
    public RebirthService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.requirements = new HashMap<>();
        this.unlocks = new HashMap<>();
        
        loadRebirthConfig();
    }
    
    private void loadRebirthConfig() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load base requirements for first 3 rebirths
        for (int i = 1; i <= 3; i++) {
            String path = "rebirth.requirements.rebirth_" + i;
            RebirthRequirements req = new RebirthRequirements();
            req.level = balance.getInt(path + ".level", 100);
            req.souls = balance.getLong(path + ".souls", 100000);
            req.missionsCompleted = balance.getInt(path + ".missions_completed", 50);
            req.bossesKilled = balance.getInt(path + ".bosses_killed", 0);
            req.dungeonsCompleted = balance.getInt(path + ".dungeons_completed", 0);
            requirements.put(i, req);
        }
        
        // Calculate scaled requirements for rebirths 4-10
        double soulMultiplier = balance.getDouble("rebirth.requirements.scaling.soul_multiplier", 2.0);
        double missionMultiplier = balance.getDouble("rebirth.requirements.scaling.mission_multiplier", 1.5);
        double bossMultiplier = balance.getDouble("rebirth.requirements.scaling.boss_multiplier", 1.5);
        double dungeonMultiplier = balance.getDouble("rebirth.requirements.scaling.dungeon_multiplier", 1.5);
        
        for (int i = 4; i <= MAX_REBIRTHS; i++) {
            RebirthRequirements prevReq = requirements.get(i - 1);
            RebirthRequirements req = new RebirthRequirements();
            req.level = 100;
            req.souls = (long)(prevReq.souls * soulMultiplier);
            req.missionsCompleted = (int)(prevReq.missionsCompleted * missionMultiplier);
            req.bossesKilled = (int)(prevReq.bossesKilled * bossMultiplier);
            req.dungeonsCompleted = (int)(prevReq.dungeonsCompleted * dungeonMultiplier);
            requirements.put(i, req);
        }
        
        // Load unlocks
        ConfigurationSection unlocksSection = balance.getConfigurationSection("rebirth.unlocks");
        if (unlocksSection != null) {
            for (String key : unlocksSection.getKeys(false)) {
                int rebirthNum = Integer.parseInt(key.replace("rebirth_", ""));
                List<String> unlockList = balance.getStringList("rebirth.unlocks." + key);
                unlocks.put(rebirthNum, unlockList);
            }
        }
    }
    
    /**
     * Check if player can rebirth
     */
    public boolean canRebirth(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        int currentRebirths = data.getRebirths();
        
        if (currentRebirths >= MAX_REBIRTHS) {
            return false;
        }
        
        RebirthRequirements req = requirements.get(currentRebirths + 1);
        if (req == null) return false;
        
        // Check requirements
        if (data.getLevel() < req.level) return false;
        if (data.getSouls() < req.souls) return false;
        if (data.getCompletedMissions().size() < req.missionsCompleted) return false;
        if (data.getBossesKilled() < req.bossesKilled) return false;
        if (data.getDungeonsCompleted() < req.dungeonsCompleted) return false;
        
        return true;
    }
    
    /**
     * Perform rebirth
     */
    public boolean performRebirth(UUID playerId) {
        if (!canRebirth(playerId)) {
            return false;
        }
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        int nextRebirth = data.getRebirths() + 1;
        RebirthRequirements req = requirements.get(nextRebirth);
        
        // Consume souls
        if (!economyService.withdraw(playerId, req.souls, "Rebirth cost")) {
            return false;
        }
        
        // Reset player progress
        int oldLevel = data.getLevel();
        long oldSouls = data.getSouls();
        
        data.setLevel(1);
        data.setExperience(0);
        data.incrementRebirths();
        
        // Keep abilities, pets, items
        // Clear active missions
        data.getActiveMissions().clear();
        
        // Apply unlocks
        List<String> newUnlocks = unlocks.get(nextRebirth);
        if (newUnlocks != null) {
            // Handle unlocks (this would be implemented based on what's unlocked)
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§5§l✦ NEW UNLOCKS:");
                for (String unlock : newUnlocks) {
                    player.sendMessage("  §d• " + unlock);
                }
            }
        }
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§5§l═══════════════════════════");
            player.sendMessage("§5§l✦ REBIRTH COMPLETE! ✦");
            player.sendMessage("§7You are now §d§lRebirth " + nextRebirth);
            player.sendMessage("");
            player.sendMessage("§6§lBonuses:");
            player.sendMessage("  §a+HP: §e" + (int)(getHealthBonus(nextRebirth) * 100) + "%");
            player.sendMessage("  §c+Damage: §e" + (int)(getDamageBonus(nextRebirth) * 100) + "%");
            player.sendMessage("  §b+Speed: §e" + (int)(getSpeedBonus(nextRebirth) * 100) + "%");
            player.sendMessage("  §6+Souls: §e" + (int)(getSoulsBonus(nextRebirth) * 100) + "%");
            player.sendMessage("  §d+Loot: §e" + (int)(getLootBonus(nextRebirth) * 100) + "%");
            player.sendMessage("§5§l═══════════════════════════");
            
            player.getWorld().strikeLightningEffect(player.getLocation());
            player.playSound(player.getLocation(), "entity.ender_dragon.death", 1.0f, 1.0f);
            
            // Broadcast
            Bukkit.broadcastMessage("§5§l✦ " + player.getName() + " has reached Rebirth " + nextRebirth + "!");
        }
        
        return true;
    }
    
    /**
     * Get total health bonus
     */
    public double getHealthBonus(int rebirths) {
        return HEALTH_PER_REBIRTH * rebirths;
    }
    
    /**
     * Get total damage bonus
     */
    public double getDamageBonus(int rebirths) {
        return DAMAGE_PER_REBIRTH * rebirths;
    }
    
    /**
     * Get total speed bonus
     */
    public double getSpeedBonus(int rebirths) {
        return SPEED_PER_REBIRTH * rebirths;
    }
    
    /**
     * Get total loot bonus
     */
    public double getLootBonus(int rebirths) {
        return LOOT_PER_REBIRTH * rebirths;
    }
    
    /**
     * Get total souls bonus
     */
    public double getSoulsBonus(int rebirths) {
        return SOULS_PER_REBIRTH * rebirths;
    }
    
    /**
     * Get requirements for next rebirth
     */
    public RebirthRequirements getRequirements(int rebirthLevel) {
        return requirements.get(rebirthLevel);
    }
    
    /**
     * Get current rebirth bonuses for player
     */
    public RebirthBonuses getBonuses(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        int rebirths = data.getRebirths();
        
        RebirthBonuses bonuses = new RebirthBonuses();
        bonuses.healthBonus = getHealthBonus(rebirths);
        bonuses.damageBonus = getDamageBonus(rebirths);
        bonuses.speedBonus = getSpeedBonus(rebirths);
        bonuses.lootBonus = getLootBonus(rebirths);
        bonuses.soulsBonus = getSoulsBonus(rebirths);
        
        return bonuses;
    }
    
    /**
     * Apply rebirth bonuses to player (called on login/spawn)
     */
    public void applyBonuses(Player player) {
        UUID playerId = player.getUniqueId();
        PlayerData data = dataStore.loadPlayerData(playerId);
        int rebirths = data.getRebirths();
        
        if (rebirths == 0) return;
        
        // Bonuses are applied through stats calculation in other systems
        // (AbilityEventListener, EconomyService, etc.)
    }
    
    /**
     * Rebirth requirements
     */
    public static class RebirthRequirements {
        public int level;
        public long souls;
        public int missionsCompleted;
        public int bossesKilled;
        public int dungeonsCompleted;
    }
    
    /**
     * Rebirth bonuses
     */
    public static class RebirthBonuses {
        public double healthBonus;
        public double damageBonus;
        public double speedBonus;
        public double lootBonus;
        public double soulsBonus;
    }
}
