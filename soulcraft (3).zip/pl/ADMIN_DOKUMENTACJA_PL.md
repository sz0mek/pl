# SoulCraft RPG Plugin - Dokumentacja Administratora (PL)

## 🎮 Przegląd Systemu

SoulCraft RPG to kompleksowy plugin RPG dostarczający **600+ godzin rozgrywki** z 12 unikalnymi umiejętnościami, 5 bossami, 69 customowymi przedmiotami, systemem petów (1-100 lvl), klanami i lochami.

## 📋 Spis Treści
1. [Instalacja i Konfiguracja](#instalacja)
2. [Komendy Administratora](#komendy)
3. [Systemy Główne](#systemy)
4. [Balansowanie](#balans)
5. [Ekonomia i Anti-Cheat](#ekonomia)
6. [Troubleshooting](#troubleshooting)

---

## 🔧 Instalacja i Konfiguracja {#instalacja}

### Wymagania
- **Serwer**: Spigot/Paper 1.21+
- **Java**: 17 lub wyższa
- **RAM**: Minimum 2GB dla ~50 graczy
- **Procesor**: 4 rdzenie zalecane

### Pierwsza Instalacja

1. **Umieść plugin w folderze `plugins/`**
   ```bash
   cp SoulCraftPlugin-1.0.jar /path/to/server/plugins/
   ```

2. **Uruchom serwer** - plugin automatycznie:
   - Utworzy foldery konfiguracyjne
   - Wygeneruje pliki YAML
   - Zainicjalizuje bazę danych
   - Załaduje wszystkie systemy

3. **Sprawdź logi** - powinno pojawić się:
   ```
   [SoulCraft] Plugin enabled successfully!
   [SoulCraft] Loaded 69 custom items
   [SoulCraft] Loaded 10 pet types
   [SoulCraft] Loaded 5 bosses
   [SoulCraft] Database initialized
   ```

### Konfiguracja Podstawowa

**Plik: `plugins/SoulCraft/balance.yml`**

```yaml
# Ekonomia
economy:
  starting_souls: 1000        # Początkowa waluta gracza
  black_matter_rate: 0.01     # Konwersja souls → black matter
  max_transaction: 1000000    # Maksymalna transakcja (anti-exploit)

# Leveling
player:
  max_level: 100
  base_xp: 100               # XP potrzebne na lvl 2
  xp_scaling: 1.15           # Mnożnik XP za każdy level

# Pety
pets:
  max_level: 100
  happiness_decay: 1         # Spadek szczęścia co godzinę
  feeding:
    happiness_gain:
      favorite: 20           # +20 za ulubione jedzenie
      normal: 10             # +10 za normalne jedzenie
    favorite_foods:
      wolf: [RAW_BEEF, COOKED_BEEF, BONE]
      cat: [RAW_COD, COOKED_COD, RAW_SALMON]
      dragon: [GOLDEN_APPLE, ENCHANTED_GOLDEN_APPLE]
```

**Plik: `plugins/SoulCraft/config.yml`**

```yaml
# Systemy główne
features:
  auto_pickup: true
  double_jump: true
  auto_replant: true
  keep_inventory: true

# Lochy
dungeons:
  difficulties:
    easy:
      required_level: 1
      soul_reward: 500
      xp_reward: 100
    medium:
      required_level: 25
      soul_reward: 1500
      xp_reward: 500
    hard:
      required_level: 50
      soul_reward: 5000
      xp_reward: 2000
    nightmare:
      required_level: 75
      soul_reward: 20000
      xp_reward: 10000
```

---

## 🎯 Komendy Administratora {#komendy}

### Panel Admina
```bash
/custom                    # Główny panel administracyjny (GUI)
/admin                     # Alias dla /custom
```

**Panel zawiera:**
- Zarządzanie itemami
- Spawnowanie bossów
- Przyznawanie misji
- Zarządzanie ekonomią
- Statystyki serwera

### Boss Management
```bash
/spawnboss <boss_id> [player]
```

**Dostępne bossy:**
- `soul_eater` - Level 10, 500 HP, Teleportacja
- `void_titan` - Level 25, 1500 HP,召唤 miniony
- `chaos_knight` - Level 50, 3000 HP, Przełączanie stances
- `phantom_lord` - Level 75, 5000 HP, Niewidzialność i spektralne klony
- `dark_emperor` - Level 100, 10000 HP, 3 fazy, masowa magia

**Przykłady:**
```bash
/spawnboss soul_eater              # Spawn przy sobie
/spawnboss dark_emperor Notch      # Spawn przy graczu Notch
```

### Custom Items
```bash
/giveitem <player> <item_id> [amount]
```

**Kategorie itemów:**

**Bronie (16):**
- `void_blade`, `soul_reaper`, `chaos_hammer`, `dark_staff`
- `fire_sword`, `ice_blade`, `thunder_axe`, `poison_dagger`
- `holy_mace`, `cursed_scythe`, `dragon_fang`, `crystal_spear`
- `shadow_dagger`, `storm_blade`, `blood_axe`, `phantom_bow`

**Zbroje (11):**
- `eternal_chestplate`, `shadow_helmet`, `soul_boots`, `void_leggings`
- `dragon_scales`, `frost_helmet`, `demon_boots`, `angel_wings`
- `warrior_plate`, `mage_robes`, `tank_armor`

**Narzędzia (8):**
- `soul_pickaxe`, `void_shovel`, `ender_axe`, `fortune_pickaxe`
- `silk_shovel`, `lumberjack_axe`, `multi_tool`, `auto_fisher`

**Consumables (10):**
- `soul_potion`, `experience_book`, `regeneration_orb`
- `health_potion_large`, `mana_crystal`, `xp_bottle`
- `soul_fragment`, `resurrection_totem`, `energy_drink`, `soul_shard`

**Special (24):**
- `lucky_coin`, `soul_compass`, `speed_crystal`, `strength_talisman`
- `pet_egg_wolf`, `pet_egg_cat`, `pet_egg_dragon`
- `dungeon_key_easy`, `dungeon_key_hard`, `dungeon_key_nightmare`
- `double_xp_token`, `rare_loot_token`, `phoenix_down`, i więcej...

**Przykłady:**
```bash
/giveitem Notch void_blade 1              # Daj legendarne miecz
/giveitem @a soul_potion 5                # Daj wszystkim 5 mikst
/giveitem Steve pet_egg_dragon 1          # Daj jajo smoka
```

### Gameplay Features
```bash
/feature toggle <feature_id> [player]    # Włącz/wyłącz
/feature enable <feature_id> [player]     # Włącz
/feature disable <feature_id> [player]    # Wyłącz
/feature list                             # Lista features
```

**Dostępne features (12):**
1. `auto_pickup` - Automatyczne podnoszenie itemów
2. `double_jump` - Podwójny skok
3. `auto_replant` - Automatyczne sadzenie
4. `keep_inventory` - Zachowaj ekwipunek po śmierci
5. `auto_smelt` - Automatyczne przetapianie
6. `night_vision` - Widzenie nocne
7. `no_fall_damage` - Brak obrażeń od upadku
8. `fast_eat` - Szybkie jedzenie
9. `auto_feed` - Automatyczne karmienie
10. `xp_boost` - Boost XP
11. `money_boost` - Boost pieniędzy
12. `loot_boost` - Boost lootu

**Przykłady:**
```bash
/feature toggle auto_pickup              # Przełącz dla siebie
/feature enable double_jump Notch        # Włącz dla Notch
/feature disable keep_inventory @a       # Wyłącz dla wszystkich
```

### Ekonomia
```bash
/souls give <player> <amount>            # Daj souls
/souls take <player> <amount>            # Zabierz souls
/souls set <player> <amount>             # Ustaw souls
/souls check [player]                    # Sprawdź saldo

/blackmatter give <player> <amount>      # Daj premium currency
/blackmatter take <player> <amount>      # Zabierz
```

**Przykłady:**
```bash
/souls give Notch 10000                  # Daj 10k souls
/souls take @a 500                       # Zabierz wszystkim 500
/blackmatter give Steve 50               # Daj 50 Black Matter
```

### Misje
```bash
/missions assign <player> <mission_type>  # Przypisz misję
/missions complete <player> <mission_id>  # Zakończ misję
/missions reset <player>                  # Reset misji gracza
```

**Typy misji (26):**
- `KILL_MOBS`, `MINE_BLOCKS`, `CRAFT_ITEMS`, `COMPLETE_DUNGEONS`
- `DEFEAT_BOSSES`, `COLLECT_ITEMS`, `TRAVEL_DISTANCE`, `LEVEL_UP`
- I wiele więcej...

### Pety
```bash
/pet spawn <player> <pet_type>           # Spawn peta
/pet level <player> <pet_type> <level>   # Ustaw level peta
/pet remove <player>                     # Usuń peta
```

**Typy petów (10):**
- `wolf` (Lvl 1+) - Wszechstronny bojowy
- `cat` (Lvl 5+) - Szybki i zręczny
- `dragon` (Lvl 50+) - Potężny late-game
- `phoenix` (Lvl 40+) - Regeneracja i wsparcie
- `skeleton` (Lvl 15+) - Łucznik
- `zombie` (Lvl 10+) - Tank
- `turtle` (Lvl 1+) - Defensywny
- `rabbit` (Lvl 1+) - Szybki gatherer
- `bee` (Lvl 20+) - AOE damage
- `fox` (Lvl 25+) - Stealth i critical

---

## 🏛️ Systemy Główne {#systemy}

### 1. System Dungeon (Lochów)

**Mechanika:**
- **4 poziomy trudności**: Easy, Medium, Hard, Nightmare
- **Biomy rotacyjne**: Zmiana codziennie (daily seed)
- **Party system**: 1-5 graczy, shared rewards
- **Proceduralna generacja**: Losowe pokoje, mobs, treasure
- **Boss room**: Końcowy boss na końcu
- **Time limits**: 15min (easy) → 30min (nightmare)

**Konfiguracja lochów:**
```yaml
dungeons:
  difficulties:
    easy:
      required_level: 1
      base_room_size: 10
      mob_level_multiplier: 1.0
      loot_multiplier: 1.0
      soul_reward: 500
      xp_reward: 100
      time_limit: 900        # 15 minut
    nightmare:
      required_level: 75
      base_room_size: 25
      mob_level_multiplier: 3.0
      loot_multiplier: 5.0
      soul_reward: 20000
      xp_reward: 10000
      time_limit: 1800       # 30 minut
```

**Party Commands:**
```bash
/dungeon party create                    # Stwórz party
/dungeon party invite <player>           # Zaproś gracza
/dungeon party accept                    # Akceptuj zaproszenie
/dungeon party decline                   # Odrzuć zaproszenie
/dungeon party leave                     # Opuść party
/dungeon party list                      # Lista członków
/dungeon party start <difficulty>        # Start dungeon (leader only)
```

**Nagrody:**
- Base reward × Time bonus (1.5x za szybkie ukończenie)
- XP skalowane z poziomem trudności
- Custom items (rare/epic/legendary drops)
- Boss-specific loot

### 2. System Petów

**Mechanika:**
- **Poziomy 1-100** z exponential XP scaling
- **Evolution stages**: Baby → Young → Adult → Ancient → Legendary
- **AI Behavior**: Follow, attack enemies, defend owner
- **Skills system**: 4 skills unlock at levels 1, 25, 50, 75
- **Happiness system**: Decay over time, feed to restore
- **Death protection**: Premium feature

**Skalowanie statystyk:**
```
Health = Base + (Growth × Level) × (1 + EvolutionBonus)
Damage = Base + (Growth × Level) × (1 + EvolutionBonus)
Defense = Base + (Growth × Level)

Evolution Bonuses:
- Baby: 0%
- Young: +15%
- Adult: +35%
- Ancient: +65%
- Legendary: +100%
```

**Karmienie:**
```yaml
pets:
  feeding:
    favorite_foods:
      wolf: [RAW_BEEF, COOKED_BEEF, BONE]
      cat: [RAW_COD, COOKED_COD, RAW_SALMON]
      dragon: [GOLDEN_APPLE, ENCHANTED_GOLDEN_APPLE]
      # ... więcej
```

**Commands dla graczy:**
```bash
/pet spawn <type>                        # Spawn peta
/pet despawn                             # Despawn peta
/pet level                               # Sprawdź level
/pet shop                                # Sklep z petami
/pet feed                                # Nakarm (prawy klik z jedzeniem)
```

### 3. System Klanów

**Mechanika:**
- **Hierarchia**: Owner → Officer → Member
- **Leveling system**: Clan XP i poziomy
- **Bank klanowy**: Wspólna ekonomia
- **Territory claiming**: Zajmowanie chunków
- **Clan wars**: PvP między klanami
- **Upgrades**: Klan bonusy

**Konfiguracja:**
```yaml
clans:
  max_members: 50
  max_officers: 5
  base_bank_limit: 100000
  territory:
    max_claims: 10
    cost_per_claim: 5000
  wars:
    declaration_cost: 10000
    duration: 3600           # 1 godzina
```

**Commands:**
```bash
# Polski (gracze)
/klan stworz <nazwa>                     # Stwórz klan
/klan dodaj <gracz>                      # Zaproś
/klan przyjmij                           # Akceptuj
/klan opusc                              # Opuść

# Angielski (admin)
/clan create <owner> <name> <tag>        # Stwórz klan
/clan delete <clan_id>                   # Usuń klan
/clan setlevel <clan_id> <level>         # Ustaw level
```

**Clan Wars:**
- Declare war: `/clan war declare <target_clan>`
- Tracking: Kills/deaths, territory control
- Rewards: Winning clan gets XP, souls, prestige

### 4. System Bossów

**Boss Mechaniki:**

**Soul Eater (Lvl 10):**
- 500 HP
- Teleportacja co 10s
- Life steal aura
- Drop: Soul Fragments, rare weapons

**Void Titan (Lvl 25):**
- 1500 HP
- Summoning voidlings
- Ground slam AOE
- Drop: Void items, epic armor

**Chaos Knight (Lvl 50):**
- 3000 HP
- 3 stances: Berserker, Defender, Assassin
- Switching every 30s
- Drop: Chaos weapons, legendary gear

**Phantom Lord (Lvl 75):**
- 5000 HP
- Invisibility phases
- Spectral clones
- Teleportation strikes
- Drop: Phantom items, mythic gear

**Dark Emperor (Lvl 100):**
- 10000 HP
- **3 Fazy**:
  - Faza 1 (100%-66%): Lightning chains, fire waves
  - Faza 2 (66%-33%): Void rifts, summoning adds
  - Faza 3 (33%-0%): Enrage, all abilities
- Drop: Najlepszy loot, Black Matter, tytularny item

**Spawn Mechanika:**
```bash
/spawnboss <boss_id>                     # Manual spawn
```

Boss automatycznie:
- Skaluje HP z liczbą graczy
- Targetuje najbliższych graczy
- Używa AI patterns
- Dropuje loot po śmierci
- Broadcastuje global message

---

## ⚖️ Balansowanie {#balans}

### Ekonomia

**Źródła Souls:**
- Killing mobs: 10-50 souls
- Completing dungeons: 500-20,000 souls
- Missions: 100-5,000 souls
- Boss kills: 1,000-50,000 souls
- Player trading: Variable

**Wydatki Souls:**
- Custom items: 1,000-100,000 souls
- Abilities: 5,000-50,000 souls
- Clan upgrades: 10,000-500,000 souls
- Pet unlocks: 1,000-25,000 souls

**Black Matter (Premium):**
- Otrzymywanie: Rebirth, boss drops, eventi
- Użycie: Premium features, instant upgrades, cosmetics
- Rate: 100 souls = 1 Black Matter (w sklepie)

### Level Scaling

**Player XP:**
```
Level 1 → 2: 100 XP
Level 2 → 3: 115 XP
Level 3 → 4: 132 XP
...
Level 99 → 100: ~30,000 XP
```

**Pet XP:**
Same formula, ale z happiness bonus:
```
Actual XP = Base XP × (1 + Happiness/100)
```

### Difficulty Curve

**Early Game (Lvl 1-25):**
- Easy dungeons
- Low-tier bosses (Soul Eater)
- Basic pets (Wolf, Cat, Turtle)
- Common/uncommon items

**Mid Game (Lvl 25-50):**
- Medium dungeons
- Mid bosses (Void Titan)
- Advanced pets (Fox, Bee)
- Rare/epic items

**Late Game (Lvl 50-75):**
- Hard dungeons
- Strong bosses (Chaos Knight)
- Premium pets (Dragon, Phoenix)
- Epic/legendary items

**End Game (Lvl 75-100):**
- Nightmare dungeons
- Final bosses (Phantom Lord, Dark Emperor)
- Mythic items
- Clan wars, prestige systems

---

## 💰 Ekonomia i Anti-Cheat {#ekonomia}

### Anti-Exploit Systemy

**1. Transaction Limits:**
```yaml
economy:
  max_transaction: 1000000         # Max jednorazowa transakcja
  daily_limit: 5000000             # Max dziennie
  flagging_threshold: 100000       # Flaga dla admina
```

**2. Audit Log:**
Wszystkie transakcje logowane w `plugins/SoulCraft/economy_audit.log`:
```
[2025-11-01 12:34:56] DEPOSIT: Player123 +50000 souls (source: dungeon_hard)
[2025-11-01 12:35:10] WITHDRAW: Player123 -25000 souls (reason: custom_item_purchase)
[2025-11-01 12:35:20] FLAGGED: Player456 +999999 souls (source: unknown) [SUSPICIOUS]
```

**3. Rate Limiting:**
```java
// Max 10 transakcji na minutę na gracza
if (transactionCount > 10) {
    player.sendMessage("§cToo many transactions! Wait a moment.");
    return false;
}
```

**4. Source Tracking:**
Każda transakcja ma source:
- `dungeon_completion`
- `boss_kill`
- `mission_reward`
- `admin_command`
- `player_trade`
- `unknown` (FLAGGED)

### Monitoring

**Sprawdzenie logów:**
```bash
tail -f plugins/SoulCraft/economy_audit.log
grep FLAGGED plugins/SoulCraft/economy_audit.log
```

**Statystyki:**
```bash
/economy stats                           # Ogólne statystyki
/economy richest                         # Top 10 najbogatszych
/economy total                           # Całkowita ilość souls w ekonomii
```

---

## 🔧 Troubleshooting {#troubleshooting}

### Częste Problemy

**1. Plugin nie startuje**
```
Błąd: "Could not load plugin"
Rozwiązanie:
- Sprawdź wersję Java (minimum 17)
- Sprawdź wersję Spigot (minimum 1.21)
- Zobacz logi: latest.log
```

**2. Brak dostępu do komend**
```
Błąd: "You don't have permission"
Rozwiązanie:
- Daj permission: soulcraft.admin
- Lub OP gracza: /op <player>
```

**3. Dungeon nie generuje się**
```
Błąd: "Failed to generate dungeon"
Rozwiązanie:
- Sprawdź czy jest wolne miejsce (20k+ bloków od spawnu)
- Sprawdź logi na błędy world generation
- Restart serwera
```

**4. Pet nie atakuje**
```
Błąd: Pet stoi w miejscu
Rozwiązanie:
- Sprawdź czy pet ma HP
- Sprawdź czy owner jest zbyt daleko (max 50 bloków)
- Despawn i respawn: /pet despawn, /pet spawn <type>
```

**5. Economy exploity**
```
Błąd: Gracz ma za dużo souls
Rozwiązanie:
- Sprawdź audit log: grep <player> economy_audit.log
- Reset salda: /souls set <player> 0
- Ban jeśli cheat: /ban <player> Economy exploit
```

### Performance

**Optymalizacja dla dużych serwerów (100+ graczy):**

```yaml
# config.yml
performance:
  pet_ai_tick_rate: 20           # Tick co sekundę (było 10)
  dungeon_cleanup_interval: 300  # Cleanup co 5 min
  database_batch_size: 100       # Batch saves
  async_operations: true         # Async database ops
```

**Monitoring:**
```bash
/tps                                     # Server TPS
/memory                                  # Memory usage
/timings                                 # Timing report
```

### Backup i Rollback

**Backup danych:**
```bash
# Manual backup
cp -r plugins/SoulCraft/data plugins/SoulCraft/data_backup_$(date +%Y%m%d)

# Automated backup (cron)
0 4 * * * /path/to/backup_script.sh
```

**Rollback:**
```bash
# Stop server
./stop.sh

# Restore backup
rm -rf plugins/SoulCraft/data
cp -r plugins/SoulCraft/data_backup_YYYYMMDD plugins/SoulCraft/data

# Start server
./start.sh
```

### Support

**Debug mode:**
```yaml
# config.yml
debug:
  enabled: true
  log_transactions: true
  log_pet_ai: false              # UWAGA: Bardzo verbose
  log_dungeon_generation: true
```

**Logi:**
- `logs/latest.log` - Server log
- `plugins/SoulCraft/economy_audit.log` - Ekonomia
- `plugins/SoulCraft/debug.log` - Debug (gdy włączony)

**Wsparcie:**
- Discord: [Link do serwera]
- GitHub Issues: [Link do repo]
- Wiki: [Link do wiki]

---

## 📊 Statystyki i Metryki

### Tracking

Plugin automatycznie śledzi:
- Ilość ukończonych dungeonów
- Ilość pokonanych bossów
- Levele graczy i petów
- Transakcje ekonomiczne
- Clan activity
- Mission completion rates

### Commands
```bash
/stats server                            # Statystyki serwera
/stats player <player>                   # Statystyki gracza
/stats economy                           # Statystyki ekonomii
/stats leaderboard <type>                # Leaderboardy
```

### Leaderboards

Automatyczne leaderboardy dla:
- Highest level
- Richest players
- Most dungeon completions
- Most boss kills
- Top clans
- Pet levels

---

## 🎨 Customizacja

### Własne itemy

Dodaj w `custom_items.yml`:
```yaml
items:
  my_custom_sword:
    material: DIAMOND_SWORD
    name: "§c§lMój Miecz"
    lore:
      - "§7Specjalny miecz admina"
      - "§c+100 DMG"
    damage: 100.0
    attack_speed: 2.0
    rarity: LEGENDARY
    enchantments:
      - SHARPNESS:10
      - UNBREAKING:5
```

### Własne misje

Dodaj w `missions.yml`:
```yaml
missions:
  custom_quest_1:
    type: KILL_MOBS
    target: ZOMBIE
    amount: 100
    reward_souls: 5000
    reward_xp: 1000
    description: "Zabij 100 zombie"
```

### Własne bossy

(Wymaga Java coding - contact developers)

---

## ✅ Checklist Wdrożenia

**Pre-launch:**
- [ ] Plugin zainstalowany i włączony
- [ ] Wszystkie konfiguracje sprawdzone
- [ ] Permissions ustawione
- [ ] Backup system skonfigurowany
- [ ] Performance zoptymalizowany
- [ ] Beta testing zakończony

**Post-launch:**
- [ ] Monitoring ekonomii (pierwsze 24h)
- [ ] Sprawdzenie logów na błędy
- [ ] Feedback od graczy
- [ ] Balance adjustments
- [ ] Documentation dla graczy

---

## 📝 Changelog

**v1.0 (2025-11-01):**
- Initial release
- 69 custom items
- 10 pet types
- 5 bosses with AI
- Party dungeon system
- Clan system
- Full economy with anti-exploit
- 26 mission types
- 12 gameplay features
- Polish localization

---

**Pytania? Problemy? Skontaktuj się z supportem!**

Plugin stworzony z ❤️ dla społeczności Minecraft RPG.
