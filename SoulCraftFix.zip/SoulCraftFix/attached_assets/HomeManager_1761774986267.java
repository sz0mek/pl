// HomeManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HomeManager {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private final Map<Player, TeleportData> teleportingPlayers = new HashMap<>();

    public HomeManager(SoulCraftPlugin plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
    }

    public void setHome(Player player, String homeName) {
        String uuid = player.getUniqueId().toString();
        String rank = rankManager.getRank(player);

        int maxHomes = getMaxHomes(rank);
        int currentHomes = getCurrentHomesCount(uuid);

        if (currentHomes >= maxHomes && !hasHome(uuid, homeName)) {
            player.sendMessage("§cOsiągnąłeś limit domów (" + maxHomes + ") dla rangi " + rank + "!");
            return;
        }

        Location loc = player.getLocation();
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".world", loc.getWorld().getName());
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".x", loc.getX());
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".y", loc.getY());
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".z", loc.getZ());
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".yaw", loc.getYaw());
        plugin.getConfig().set("players." + uuid + ".homes." + homeName + ".pitch", loc.getPitch());
        plugin.saveConfig();

        player.sendMessage("§aDom '" + homeName + "' został ustawiony!");
    }

    public void removeHome(Player player, String homeName) {
        String uuid = player.getUniqueId().toString();

        if (!hasHome(uuid, homeName)) {
            player.sendMessage("§cNie masz domu o nazwie '" + homeName + "'!");
            return;
        }

        plugin.getConfig().set("players." + uuid + ".homes." + homeName, null);
        plugin.saveConfig();
        player.sendMessage("§aDom '" + homeName + "' został usunięty!");
    }

    public void teleportToHome(Player player, String homeName) {
        String uuid = player.getUniqueId().toString();

        if (!hasHome(uuid, homeName)) {
            player.sendMessage("§cNie masz domu o nazwie '" + homeName + "'!");
            return;
        }

        if (teleportingPlayers.containsKey(player)) {
            player.sendMessage("§cJuż się teleportujesz!");
            return;
        }

        Location homeLocation = getHomeLocation(uuid, homeName);
        if (homeLocation == null) {
            player.sendMessage("§cNie można znaleźć lokalizacji domu!");
            return;
        }

        startTeleport(player, homeLocation, homeName);
    }

    private void startTeleport(Player player, Location destination, String homeName) {
        String rank = rankManager.getRank(player);
        int delayTicks;

        switch (rank) {
            case "soulgod":
                delayTicks = 5 * 20;
                break;
            case "svip":
                delayTicks = 10 * 20;
                break;
            case "vip":
                delayTicks = 15 * 20;
                break;
            default:
                delayTicks = 20 * 20;
                break;
        }

        TeleportData data = new TeleportData(delayTicks, player.getLocation());
        teleportingPlayers.put(player, data);

        new BukkitRunnable() {
            int timeLeft = delayTicks / 20;

            @Override
            public void run() {
                if (!teleportingPlayers.containsKey(player)) {
                    this.cancel();
                    return;
                }

                if (!player.getLocation().getBlock().equals(data.initialLocation.getBlock())) {
                    player.sendMessage("§cRuszanie się anuluje teleportację!");
                    teleportingPlayers.remove(player);
                    this.cancel();
                    return;
                }

                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                        new TextComponent(ChatColor.GREEN + "Teleportacja do domu za " + timeLeft + " sekund..."));
                timeLeft--;

                if (timeLeft < 0) {
                    player.teleport(destination);
                    player.sendMessage("§aZostałeś teleportowany do domu '" + homeName + "'!");
                    teleportingPlayers.remove(player);
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private int getMaxHomes(String rank) {
        switch (rank) {
            case "soulgod":
                return 10;
            case "svip":
                return 5;
            case "vip":
                return 3;
            default:
                return 1;
        }
    }

    private int getCurrentHomesCount(String uuid) {
        if (plugin.getConfig().getConfigurationSection("players." + uuid + ".homes") == null) {
            return 0;
        }
        return plugin.getConfig().getConfigurationSection("players." + uuid + ".homes").getKeys(false).size();
    }

    private boolean hasHome(String uuid, String homeName) {
        return plugin.getConfig().contains("players." + uuid + ".homes." + homeName);
    }

    private Location getHomeLocation(String uuid, String homeName) {
        String worldName = plugin.getConfig().getString("players." + uuid + ".homes." + homeName + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null)
            return null;

        double x = plugin.getConfig().getDouble("players." + uuid + ".homes." + homeName + ".x");
        double y = plugin.getConfig().getDouble("players." + uuid + ".homes." + homeName + ".y");
        double z = plugin.getConfig().getDouble("players." + uuid + ".homes." + homeName + ".z");
        float yaw = (float) plugin.getConfig().getDouble("players." + uuid + ".homes." + homeName + ".yaw");
        float pitch = (float) plugin.getConfig().getDouble("players." + uuid + ".homes." + homeName + ".pitch");

        return new Location(world, x, y, z, yaw, pitch);
    }

    public void cancelTeleport(Player player) {
        teleportingPlayers.remove(player);
    }

    public String getHomesString(String uuid) {
        if (plugin.getConfig().getConfigurationSection("players." + uuid + ".homes") == null) {
            return "§cBrak domów";
        }
        Set<String> homes = plugin.getConfig().getConfigurationSection("players." + uuid + ".homes").getKeys(false);
        return String.join(", ", homes);
    }

    private static class TeleportData {
        int delayTicks;
        Location initialLocation;

        TeleportData(int delayTicks, Location initialLocation) {
            this.delayTicks = delayTicks;
            this.initialLocation = initialLocation;
        }
    }
}