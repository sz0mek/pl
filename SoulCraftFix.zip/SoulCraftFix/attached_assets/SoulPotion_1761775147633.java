package com.soulcraft.items.consumables;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class SoulPotion extends CustomItem {
    private final SoulCraftPlugin plugin;

    public SoulPotion(SoulCraftPlugin plugin) {
        super(
            "soul_potion",
            "§5§lEliksir Dusz",
            Material.POTION,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Magiczny Eliksir§7│",
                "§7│ §fEfekty (60s):    §7│",
                "§7│ §cSiła II         §7│",
                "§7│ §aRegenera II     §7│",
                "§7│ §eOdporność       §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §dPPM aby wypić",
                "§d⚔ Model: 4001"
            ),
            4001
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 1200, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 1200, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 1200, 0));
            
            player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation(), 50);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0f, 1.2f);
            player.sendMessage("§5§l✦ Wzmocniony mocą dusz!");
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
