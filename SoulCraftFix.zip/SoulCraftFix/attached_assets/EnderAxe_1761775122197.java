package com.soulcraft.items.tools;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class EnderAxe extends CustomItem {
    public EnderAxe(SoulCraftPlugin plugin) {
        super(
            "ender_axe",
            "§5§lTopór Endera",
            Material.NETHERITE_AXE,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Wymiarowy Topór §7│",
                "§7│ §fZdolności:       §7│",
                "§7│ §dŚcinanie drzew  §7│",
                "§7│ §5Teleportacja    §7│",
                "§7│ §a+100% drewna    §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Aktywne: §5Teleport do drzewa",
                "§d⚔ Model: 3002"
            ),
            3002
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Tree chopping handled by block break events
    }
}
