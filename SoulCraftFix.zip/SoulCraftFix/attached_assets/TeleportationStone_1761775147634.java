package com.soulcraft.items.special;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class TeleportationStone extends CustomItem {
    private final SoulCraftPlugin plugin;

    public TeleportationStone(SoulCraftPlugin plugin) {
        super(
            "teleportation_stone",
            "§d§lKamień Teleportacji",
            Material.ENDER_PEARL,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §dMagiczny Kamień §7│",
                "§7│ §fZdolność:        §7│",
                "§7│ §5Zapisz lokalizację§7│",
                "§7│ §dTeleportuj się  §7│",
                "§7│ §eBez cooldownu   §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ PPM: §dTeleport",
                "§5✦ Shift+PPM: §5Zapisz",
                "§d⚔ Model: 5001"
            ),
            5001
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            if (player.isSneaking()) {
                // Save location
                player.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(plugin, "tp_stone_x"),
                    org.bukkit.persistence.PersistentDataType.DOUBLE,
                    player.getLocation().getX()
                );
                player.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(plugin, "tp_stone_y"),
                    org.bukkit.persistence.PersistentDataType.DOUBLE,
                    player.getLocation().getY()
                );
                player.getPersistentDataContainer().set(
                    new org.bukkit.NamespacedKey(plugin, "tp_stone_z"),
                    org.bukkit.persistence.PersistentDataType.DOUBLE,
                    player.getLocation().getZ()
                );
                player.sendMessage("§d§l✦ Lokalizacja zapisana!");
                player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.5f);
            } else {
                // Teleport
                Double x = player.getPersistentDataContainer().get(
                    new org.bukkit.NamespacedKey(plugin, "tp_stone_x"),
                    org.bukkit.persistence.PersistentDataType.DOUBLE
                );
                
                if (x != null) {
                    Double y = player.getPersistentDataContainer().get(
                        new org.bukkit.NamespacedKey(plugin, "tp_stone_y"),
                        org.bukkit.persistence.PersistentDataType.DOUBLE
                    );
                    Double z = player.getPersistentDataContainer().get(
                        new org.bukkit.NamespacedKey(plugin, "tp_stone_z"),
                        org.bukkit.persistence.PersistentDataType.DOUBLE
                    );
                    
                    org.bukkit.Location loc = new org.bukkit.Location(player.getWorld(), x, y, z);
                    player.teleport(loc);
                    player.getWorld().spawnParticle(Particle.PORTAL, loc, 50);
                    player.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
                    player.sendMessage("§d§l✦ Teleportacja zakończona!");
                } else {
                    player.sendMessage("§c§l✖ Najpierw zapisz lokalizację (Shift+PPM)!");
                }
            }
        }
    }
}
