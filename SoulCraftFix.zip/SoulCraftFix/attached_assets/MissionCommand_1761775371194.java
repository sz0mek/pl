package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.missions.MissionGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MissionCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final MissionGUI missionGUI;
    
    public MissionCommand(SoulCraftPlugin plugin, MissionGUI gui) {
        this.plugin = plugin;
        this.missionGUI = gui;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTa komenda dostępna tylko dla graczy!");
            return true;
        }
        
        missionGUI.openMainMenu(player);
        return true;
    }
}
