package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class LifeSteal extends Ability {
    private final SoulCraftPlugin plugin;
    
    public LifeSteal(SoulCraftPlugin plugin) {
        super("life_steal", "§4§lKradzież Życia", "§7Kradnij 30% zadanych obrażeń jako HP", 0, "svip", 15000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof Double) {
            double damage = (Double) args[0];
            double heal = damage * 0.3;
            player.setHealth(Math.min(player.getHealth() + heal, player.getMaxHealth()));
        }
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
