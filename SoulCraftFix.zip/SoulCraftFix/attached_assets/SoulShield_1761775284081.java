package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SoulShield extends Ability {
    private final SoulCraftPlugin plugin;
    
    public SoulShield(SoulCraftPlugin plugin) {
        super("soul_shield", "§d§lTarcza Duszy", "§7Nietykalność na 3 sekundy", 300, "soulgod", 50000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 4));
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 60, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 60, 3));
        player.setInvulnerable(true);
        
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            player.setInvulnerable(false);
        }, 60L);
        
        player.sendMessage("§d§l✦ TARCZA DUSZY AKTYWNA!");
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
