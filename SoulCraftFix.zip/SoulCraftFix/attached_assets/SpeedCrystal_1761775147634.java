package com.soulcraft.items.consumables;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class SpeedCrystal extends CustomItem {
    public SpeedCrystal(SoulCraftPlugin plugin) {
        super(
            "speed_crystal",
            "§b§lKryształ Prędkości",
            Material.PRISMARINE_CRYSTALS,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §bEnergetyczny    §7│",
                "§7│ §bKryształ        §7│",
                "§7│ §fEfekty (120s):  §7│",
                "§7│ §bPrędkość III   §7│",
                "§7│ §ePośpiech II    §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §bSuper prędkość",
                "§d⚔ Model: 4003"
            ),
            4003
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2400, 2));
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 2400, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 2400, 1));
            
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 30);
            player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);
            player.sendMessage("§b§l✦ Energia przepływa przez twoje ciało!");
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
