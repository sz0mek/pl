package com.soulcraft.bosses.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.bosses.CustomBoss;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ChaosKnight extends CustomBoss {
    private final SoulCraftPlugin plugin;

    public ChaosKnight(SoulCraftPlugin plugin) {
        super(
            "chaos_knight",
            "§c§l✦ Rycerz Chaosu ✦",
            EntityType.ZOMBIE,
            600.0,
            18.0,
            6500
        );
        this.plugin = plugin;
    }

    @Override
    public void onSpawn(LivingEntity boss) {
        boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        boss.getWorld().spawnParticle(Particle.FLAME, boss.getLocation(), 100, 2, 2, 2);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.0f);
    }

    @Override
    public void onTick(LivingEntity boss) {
        // Chaos flames
        if (boss.getTicksLived() % 20 == 0) {
            boss.getWorld().spawnParticle(Particle.LAVA, boss.getLocation().add(0, 1, 0), 15, 1, 1, 1);
            
            // Enrage at low health
            if (boss.getHealth() < getMaxHealth() * 0.3) {
                boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 3, false, false));
                boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2, false, false));
            }
        }
    }

    @Override
    public void onDeath(LivingEntity boss, Player killer) {
        boss.getWorld().spawnParticle(Particle.EXPLOSION, boss.getLocation(), 50, 3, 3, 3);
        boss.getWorld().createExplosion(boss.getLocation(), 0f, false, false);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.8f);
        
        // Drop chaos items
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("chaos_hammer", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("strength_talisman", 3)
        );
    }

    @Override
    public void onAttack(LivingEntity boss, Entity target) {
        if (target instanceof Player player) {
            // Chaos burn
            player.setFireTicks(100);
            player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 100, 0));
            boss.getWorld().playSound(target.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
        }
    }
}
