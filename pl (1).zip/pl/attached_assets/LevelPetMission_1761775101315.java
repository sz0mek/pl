package com.soulcraft.missions.impl;

import com.soulcraft.missions.Mission;
import org.bukkit.entity.Player;
import java.util.*;

public class LevelPetMission extends Mission {
    private final Map<UUID, Integer> progress = new HashMap<>();
    private final Map<UUID, Boolean> completed = new HashMap<>();
    
    public LevelPetMission(String id, String displayName, String description, MissionType type,
                          int requiredProgress, List<MissionReward> rewards, String requiredRank) {
        super(id, displayName, description, type, requiredProgress, rewards, requiredRank);
    }
    
    @Override
    public boolean checkProgress(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof Integer) {
            incrementProgress(player.getUniqueId(), (Integer) args[0]);
            return true;
        }
        return false;
    }
    
    @Override
    public int getProgress(UUID playerId) { return progress.getOrDefault(playerId, 0); }
    
    @Override
    public void setProgress(UUID playerId, int value) { progress.put(playerId, value); }
    
    @Override
    public void incrementProgress(UUID playerId, int amount) {
        setProgress(playerId, Math.min(getProgress(playerId) + amount, requiredProgress));
    }
    
    @Override
    public boolean isCompleted(UUID playerId) { return completed.getOrDefault(playerId, false); }
    
    @Override
    public void complete(Player player) {
        completed.put(player.getUniqueId(), true);
        giveRewards(player);
        player.sendMessage("§a§l✔ Ukończono misję: " + displayName);
    }
    
    @Override
    public void giveRewards(Player player) { }
    
    @Override
    public void reset(UUID playerId) {
        progress.remove(playerId);
        completed.remove(playerId);
    }
}
