package com.soulcraft.bosses;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.core.NotificationService;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BossRegistry implements Listener {
    private static BossRegistry instance;
    private final Map<String, CustomBoss> bosses = new HashMap<>();
    private final Map<UUID, CustomBoss> activeBosses = new HashMap<>();
    private final SoulCraftPlugin plugin;
    private final NotificationService notificationService;

    private BossRegistry(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        this.notificationService = NotificationService.getInstance();
        registerAllBosses();
        startBossTickTask();
    }

    public static BossRegistry getInstance(SoulCraftPlugin plugin) {
        if (instance == null) {
            instance = new BossRegistry(plugin);
        }
        return instance;
    }

    private void registerAllBosses() {
        register(new com.soulcraft.bosses.impl.SoulEater(plugin));
        register(new com.soulcraft.bosses.impl.VoidTitan(plugin));
        register(new com.soulcraft.bosses.impl.ChaosKnight(plugin));
        register(new com.soulcraft.bosses.impl.PhantomLord(plugin));
        register(new com.soulcraft.bosses.impl.DarkEmperor(plugin));
    }

    public void register(CustomBoss boss) {
        bosses.put(boss.getId(), boss);
    }

    public CustomBoss getBoss(String id) {
        return bosses.get(id);
    }

    public LivingEntity spawnBoss(String bossId, Location location) {
        CustomBoss boss = bosses.get(bossId);
        if (boss == null) {
            return null;
        }

        LivingEntity entity = boss.spawn(location);
        if (entity != null) {
            activeBosses.put(entity.getUniqueId(), boss);
            
            // Broadcast spawn message
            notificationService.broadcastTitle(
                "§c§lBOSS SPAWN!",
                "§e" + boss.getDisplayName() + " §7pojawił się!"
            );
            notificationService.broadcastSound(
                org.bukkit.Sound.ENTITY_ENDER_DRAGON_GROWL,
                1.0f,
                0.8f
            );
        }

        return entity;
    }

    @EventHandler
    public void onBossDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        CustomBoss boss = activeBosses.get(entity.getUniqueId());
        
        if (boss != null) {
            Player killer = entity.getKiller();
            if (killer != null) {
                // Award souls
                plugin.getSoulManager().addSouls(
                    killer.getUniqueId().toString(), 
                    boss.getRewardSouls()
                );
                
                // Broadcast death message
                notificationService.broadcastTitle(
                    "§6§lBOSS DEFEATED!",
                    "§e" + boss.getDisplayName() + " §7pokonany przez §a" + killer.getName()
                );
                notificationService.broadcastSound(
                    org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE,
                    1.0f,
                    1.0f
                );
                
                killer.sendMessage(String.format(
                    "§6§l✦ Otrzymujesz §e%d dusz §6za pokonanie §c%s§6!",
                    boss.getRewardSouls(),
                    boss.getDisplayName()
                ));
                
                boss.onDeath(entity, killer);
            }
            
            activeBosses.remove(entity.getUniqueId());
        }
    }

    @EventHandler
    public void onBossAttack(EntityDamageByEntityEvent event) {
        LivingEntity damager = null;
        
        // Handle direct attacks
        if (event.getDamager() instanceof LivingEntity) {
            damager = (LivingEntity) event.getDamager();
        } 
        // Handle projectile attacks
        else if (event.getDamager() instanceof org.bukkit.entity.Projectile) {
            org.bukkit.entity.Projectile projectile = (org.bukkit.entity.Projectile) event.getDamager();
            if (projectile.getShooter() instanceof LivingEntity) {
                damager = (LivingEntity) projectile.getShooter();
            }
        }
        
        if (damager != null) {
            CustomBoss boss = activeBosses.get(damager.getUniqueId());
            if (boss != null) {
                boss.onAttack(damager, event.getEntity());
            }
        }
    }

    private void startBossTickTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, CustomBoss> entry : activeBosses.entrySet()) {
                LivingEntity boss = Bukkit.getEntity(entry.getKey()) instanceof LivingEntity ? 
                    (LivingEntity) Bukkit.getEntity(entry.getKey()) : null;
                
                if (boss != null && boss.isValid()) {
                    entry.getValue().onTick(boss);
                }
            }
        }, 20L, 20L); // Run every second
    }

    public Map<String, CustomBoss> getAllBosses() {
        return new HashMap<>(bosses);
    }

    public Map<UUID, CustomBoss> getActiveBosses() {
        return new HashMap<>(activeBosses);
    }
}
