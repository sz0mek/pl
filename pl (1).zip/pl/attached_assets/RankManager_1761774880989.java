// RankManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public class RankManager {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, String> playerRanks = new HashMap<>();
    private final Map<String, ChatColor> rankColors = new HashMap<>();
    private final Map<String, Map<String, Boolean>> rankPermissions = new HashMap<>();

    public RankManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        initializeRanks();
        loadPlayerRanks();
    }

    private void initializeRanks() {
        // Definicja rang i kolorów
        rankColors.put("gracz", ChatColor.BLUE);
        rankColors.put("vip", ChatColor.YELLOW);
        rankColors.put("svip", ChatColor.GOLD);
        rankColors.put("soulgod", ChatColor.DARK_PURPLE);

        // Inicjalizacja domyślnych permisji (możesz je łatwo rozszerzać)
        rankPermissions.put("gracz", new HashMap<>());
        rankPermissions.get("gracz").put("soulcraft.spawn", true);
        rankPermissions.get("gracz").put("soulcraft.kit.gracz", true);
        rankPermissions.get("gracz").put("soulcraft.ulepsz", true);
        rankPermissions.get("gracz").put("soulcraft.jakgrac", true);
        rankPermissions.get("gracz").put("soulcraft.help", true);
        rankPermissions.get("gracz").put("soulcraft.klan", true); // Podstawowe komendy klanu

        rankPermissions.put("vip", new HashMap<>());
        rankPermissions.get("vip").put("soulcraft.spawn", true);
        rankPermissions.get("vip").put("soulcraft.kit.vip", true);
        rankPermissions.get("vip").put("soulcraft.ulepsz", true);
        rankPermissions.get("vip").put("soulcraft.jakgrac", true);
        rankPermissions.get("vip").put("soulcraft.help", true);
        rankPermissions.get("vip").put("soulcraft.klan", true);

        rankPermissions.put("svip", new HashMap<>());
        rankPermissions.get("svip").put("soulcraft.spawn", true);
        rankPermissions.get("svip").put("soulcraft.kit.svip", true);
        rankPermissions.get("svip").put("soulcraft.ulepsz", true);
        rankPermissions.get("svip").put("soulcraft.jakgrac", true);
        rankPermissions.get("svip").put("soulcraft.help", true);
        rankPermissions.get("svip").put("soulcraft.klan", true);

        rankPermissions.put("soulgod", new HashMap<>());
        rankPermissions.get("soulgod").put("soulcraft.spawn", true);
        rankPermissions.get("soulgod").put("soulcraft.kit.soulgod", true);
        rankPermissions.get("soulgod").put("soulcraft.ulepsz", true);
        rankPermissions.get("soulgod").put("soulcraft.jakgrac", true);
        rankPermissions.get("soulgod").put("soulcraft.help", true);
        rankPermissions.get("soulgod").put("soulcraft.klan", true);
    }

    private void loadPlayerRanks() {
        FileConfiguration config = plugin.getConfig();
        Set<String> uuids = config.getConfigurationSection("players") != null
                ? config.getConfigurationSection("players").getKeys(false).stream().map(String::valueOf).collect(
                        Collectors.toSet())
                : new java.util.HashSet<>();
        for (String uuid : uuids) {
            String rank = config.getString("players." + uuid + ".rank", "gracz");
            playerRanks.put(UUID.fromString(uuid), rank);
        }
    }

    public void setRank(Player player, String rank, long duration) {
        UUID uuid = player.getUniqueId();
        playerRanks.put(uuid, rank);
        plugin.getConfig().set("players." + uuid + ".rank", rank);
        if (duration > 0) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playerRanks.get(uuid).equals(rank)) {
                    setRank(player, "gracz", 0); // Powrót do gracz po czasie
                    player.sendMessage("§cTwoja ranga " + rank + " wygasła!");
                }
            }, duration * 20L * 60); // Konwersja minut na ticki
        }
        plugin.saveConfig();
        updatePermissions(player);
    }

    public String getRank(Player player) {
        return playerRanks.getOrDefault(player.getUniqueId(), "gracz");
    }

    public ChatColor getRankColor(String rank) {
        return rankColors.getOrDefault(rank, ChatColor.WHITE);
    }

    public void updatePermissions(Player player) {
        PermissionAttachment attachment = player.addAttachment(plugin);
        String rank = getRank(player);
        Map<String, Boolean> permissions = rankPermissions.getOrDefault(rank, new HashMap<>());
        for (Map.Entry<String, Boolean> entry : permissions.entrySet()) {
            attachment.setPermission(entry.getKey(), entry.getValue());
        }
    }

    public void addPermission(String rank, String permission, boolean value) {
        rankPermissions.computeIfAbsent(rank, k -> new HashMap<>()).put(permission, value);
    }

    public boolean isValidRank(String rank) {
        return rankColors.containsKey(rank.toLowerCase());
    }
}
