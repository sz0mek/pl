package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AutoFeed extends GameFeature {
    private final SoulCraftPlugin plugin;

    public AutoFeed(SoulCraftPlugin plugin) {
        super(
            "autofeed",
            "§c§lAuto Feed",
            "§7Automatyczne utrzymywanie pełnego głodu"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (canUse(player) && player.getFoodLevel() < 20) {
                    player.setFoodLevel(20);
                    player.setSaturation(20);
                }
            }
        }, 0L, 40L);
    }

    @Override
    public void onDisable() {
        // Task will be cancelled when plugin disables
    }
}
