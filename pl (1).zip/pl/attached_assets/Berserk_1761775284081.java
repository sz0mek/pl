package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Berserk extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Berserk(SoulCraftPlugin plugin) {
        super("berserk", "§4§lBerserk", "§7Siła III + Szybkość III przez 8 sekund", 120, "soulgod", 25000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 160, 2));
        player.sendMessage("§4§l⚔ BERSERK AKTYWNY!");
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
