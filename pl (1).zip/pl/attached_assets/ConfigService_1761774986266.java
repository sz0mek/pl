package com.soulcraft.core;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Map;

public class ConfigService {
    private static ConfigService instance;
    private final SoulCraftPlugin plugin;
    private final Map<String, Object> cache = new HashMap<>();

    private ConfigService(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public static ConfigService getInstance(SoulCraftPlugin plugin) {
        if (instance == null) {
            instance = new ConfigService(plugin);
        }
        return instance;
    }

    public void reload() {
        plugin.reloadConfig();
        cache.clear();
    }

    public String getString(String path, String defaultValue) {
        if (cache.containsKey(path)) {
            return (String) cache.get(path);
        }
        String value = plugin.getConfig().getString(path, defaultValue);
        cache.put(path, value);
        return value;
    }

    public int getInt(String path, int defaultValue) {
        if (cache.containsKey(path)) {
            return (Integer) cache.get(path);
        }
        int value = plugin.getConfig().getInt(path, defaultValue);
        cache.put(path, value);
        return value;
    }

    public double getDouble(String path, double defaultValue) {
        if (cache.containsKey(path)) {
            return (Double) cache.get(path);
        }
        double value = plugin.getConfig().getDouble(path, defaultValue);
        cache.put(path, value);
        return value;
    }

    public boolean getBoolean(String path, boolean defaultValue) {
        if (cache.containsKey(path)) {
            return (Boolean) cache.get(path);
        }
        boolean value = plugin.getConfig().getBoolean(path, defaultValue);
        cache.put(path, value);
        return value;
    }

    public void set(String path, Object value) {
        plugin.getConfig().set(path, value);
        cache.put(path, value);
        plugin.saveConfig();
    }

    public ConfigurationSection getSection(String path) {
        return plugin.getConfig().getConfigurationSection(path);
    }

    public ConfigurationSection createSection(String path) {
        ConfigurationSection section = plugin.getConfig().createSection(path);
        plugin.saveConfig();
        return section;
    }

    public void save() {
        plugin.saveConfig();
    }
}
