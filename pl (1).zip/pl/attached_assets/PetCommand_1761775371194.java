package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PetCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    
    public PetCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTa komenda dostępna tylko dla graczy!");
            return true;
        }
        
        if (args.length == 0) {
            player.sendMessage("§d§l=== DOSTĘPNE PETY ===");
            player.sendMessage("§a/pet spawn <typ> §7- Przywołaj peta");
            player.sendMessage("§7Typy: soul_wolf, void_cat, chaos_dragon, phantom_horse,");
            player.sendMessage("§7eternal_phoenix, dark_spider, crystal_golem, shadow_bat,");
            player.sendMessage("§7frost_fox, blaze_hound");
            return true;
        }
        
        if (args[0].equalsIgnoreCase("spawn") && args.length == 2) {
            String petType = args[1].toLowerCase();
            plugin.getPetManager().spawnPet(player, petType);
            player.sendMessage("§a§lPet przywołany!");
        }
        
        return true;
    }
}
