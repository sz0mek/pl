package com.soulcraft.rebirth;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;

public class RebirthManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Integer> rebirthLevels = new HashMap<>();
    
    public RebirthManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean canRebirth(Player player) {
        int currentRebirth = rebirthLevels.getOrDefault(player.getUniqueId(), 0);
        if (currentRebirth >= 10) return false;
        
        int requiredSouls = getRequiredSouls(currentRebirth + 1);
        return plugin.getSoulManager().getSouls(player.getUniqueId().toString()) >= requiredSouls;
    }
    
    public void performRebirth(Player player) {
        int currentRebirth = rebirthLevels.getOrDefault(player.getUniqueId(), 0);
        int nextRebirth = currentRebirth + 1;
        
        int cost = getRequiredSouls(nextRebirth);
        plugin.getSoulManager().removeSouls(player.getUniqueId().toString(), cost);
        
        rebirthLevels.put(player.getUniqueId(), nextRebirth);
        
        player.setLevel(0);
        player.setExp(0);
        player.sendMessage("§5§l✦ REBIRTH " + nextRebirth + " OSIĄGNIĘTY!");
        player.sendMessage("§dOtrzymujesz bonusy:");
        player.sendMessage("§a• +" + (nextRebirth * 10) + "% Damage");
        player.sendMessage("§a• +" + (nextRebirth * 5) + "% Max HP");
        player.sendMessage("§a• +" + (nextRebirth * 2) + "% Drop Rate");
    }
    
    private int getRequiredSouls(int rebirthLevel) {
        return switch (rebirthLevel) {
            case 1 -> 50000;
            case 2 -> 100000;
            case 3 -> 200000;
            case 4 -> 400000;
            case 5 -> 800000;
            case 6 -> 1500000;
            case 7 -> 3000000;
            case 8 -> 6000000;
            case 9 -> 10000000;
            case 10 -> 20000000;
            default -> Integer.MAX_VALUE;
        };
    }
    
    public int getRebirthLevel(Player player) {
        return rebirthLevels.getOrDefault(player.getUniqueId(), 0);
    }
}
