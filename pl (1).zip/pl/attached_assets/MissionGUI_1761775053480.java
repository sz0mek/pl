package com.soulcraft.missions;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class MissionGUI implements Listener {
    private final SoulCraftPlugin plugin;
    private final MissionManager missionManager;
    private final Map<UUID, String> activeGUI = new HashMap<>();
    
    public MissionGUI(SoulCraftPlugin plugin, MissionManager missionManager) {
        this.plugin = plugin;
        this.missionManager = missionManager;
    }
    
    public void openMainMenu(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "§5§l✦ MISJE ✦");
        activeGUI.put(player.getUniqueId(), "main");
        
        // Filler
        ItemStack filler = createItem(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆", Arrays.asList("§d✨ Magia misji..."));
        for (int i = 0; i < 27; i++) gui.setItem(i, filler);
        
        // Daily Missions
        ItemStack daily = createItem(Material.CLOCK, "§e§l⏰ CODZIENNE MISJE",
            Arrays.asList(
                "§7╭─────────────────────╮",
                "§7│ §fMisje resetujące    §7│",
                "§7│ §esię codziennie      §7│",
                "§7│ §aProcent ukończenia: §7│",
                "§7│ §a" + getCompletionRate(player, Mission.MissionType.DAILY) + "% §7│",
                "§7╰─────────────────────╯",
                "",
                "§e§l➤ KLIKNIJ ABY ZOBACZYĆ!"));
        gui.setItem(11, daily);
        
        // Weekly Missions
        ItemStack weekly = createItem(Material.PAPER, "§6§l📅 TYGODNIOWE MISJE",
            Arrays.asList(
                "§7╭─────────────────────╮",
                "§7│ §fMisje resetujące    §7│",
                "§7│ §6co tydzień          §7│",
                "§7│ §aProcent ukończenia: §7│",
                "§7│ §a" + getCompletionRate(player, Mission.MissionType.WEEKLY) + "% §7│",
                "§7╰─────────────────────╯",
                "",
                "§6§l➤ KLIKNIJ ABY ZOBACZYĆ!"));
        gui.setItem(13, weekly);
        
        // Achievement Missions
        ItemStack achievement = createItem(Material.NETHER_STAR, "§5§l⭐ OSIĄGNIĘCIA",
            Arrays.asList(
                "§7╭─────────────────────╮",
                "§7│ §fOsiągnięcia          §7│",
                "§7│ §5permanentne         §7│",
                "§7│ §aProcent ukończenia: §7│",
                "§7│ §a" + getCompletionRate(player, Mission.MissionType.ACHIEVEMENT) + "% §7│",
                "§7╰─────────────────────╯",
                "",
                "§5§l➤ KLIKNIJ ABY ZOBACZYĆ!"));
        gui.setItem(15, achievement);
        
        player.openInventory(gui);
    }
    
    public void openMissionList(Player player, Mission.MissionType type) {
        List<Mission> missions = missionManager.getMissionsByType(type);
        int size = Math.max(27, ((missions.size() / 9) + 1) * 9);
        if (size > 54) size = 54;
        
        String title = switch (type) {
            case DAILY -> "§e§l⏰ CODZIENNE MISJE";
            case WEEKLY -> "§6§l📅 TYGODNIOWE MISJE";
            case ACHIEVEMENT -> "§5§l⭐ OSIĄGNIĘCIA";
        };
        
        Inventory gui = Bukkit.createInventory(null, size, title);
        activeGUI.put(player.getUniqueId(), "list_" + type.name());
        
        // Filler
        ItemStack filler = createItem(Material.CYAN_STAINED_GLASS_PANE, "§3§l◆", Arrays.asList("§b✨"));
        for (int i = 0; i < size; i++) gui.setItem(i, filler);
        
        // Missions
        int slot = 0;
        for (Mission mission : missions) {
            if (slot >= size - 9) break;
            
            boolean completed = mission.isCompleted(player.getUniqueId());
            int progress = mission.getProgress(player.getUniqueId());
            int required = mission.getRequiredProgress();
            int percent = (int) ((progress / (double) required) * 100);
            
            Material icon = completed ? Material.LIME_DYE : (progress > 0 ? Material.YELLOW_DYE : Material.GRAY_DYE);
            List<String> lore = new ArrayList<>();
            lore.add("§7╭─────────────────────╮");
            lore.add("§7│ " + mission.getDescription() + " §7│");
            lore.add("§7│                      §7│");
            lore.add("§7│ §fPostęp: §a" + progress + "§7/§e" + required + " §7│");
            lore.add("§7│ §fUkończono: §" + (completed ? "a" : "c") + percent + "% §7│");
            lore.add("§7│                      §7│");
            lore.add("§7│ §6Nagrody:            §7│");
            for (Mission.MissionReward reward : mission.getRewards()) {
                String rewardText = switch (reward.getType()) {
                    case SOULS -> "§d+" + reward.getAmount() + " Dusz";
                    case MONEY -> "§6+" + reward.getAmount() + " Hajsu";
                    case EXPERIENCE -> "§a+" + reward.getAmount() + " EXP";
                    case ABILITY_UNLOCK -> "§5Zdolność: " + reward.getData();
                    case RANK_UPGRADE -> "§bRanga: " + reward.getData();
                    default -> "§7" + reward.getAmount();
                };
                lore.add("§7│ §7• " + rewardText + " §7│");
            }
            lore.add("§7╰─────────────────────╯");
            
            if (completed) {
                lore.add("");
                lore.add("§a§l✔ UKOŃCZONO!");
            } else if (progress >= required) {
                lore.add("");
                lore.add("§e§l⚡ GOTOWE DO ODBIORU!");
            }
            
            gui.setItem(slot++, createItem(icon, mission.getDisplayName(), lore));
        }
        
        // Back button
        gui.setItem(size - 5, createItem(Material.ARROW, "§e§l⬅ POWRÓT", Arrays.asList("§7Wróć do głównego menu")));
        
        player.openInventory(gui);
    }
    
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!activeGUI.containsKey(player.getUniqueId())) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        
        String guiType = activeGUI.get(player.getUniqueId());
        
        if (guiType.equals("main")) {
            if (clicked.getType() == Material.CLOCK) {
                openMissionList(player, Mission.MissionType.DAILY);
            } else if (clicked.getType() == Material.PAPER) {
                openMissionList(player, Mission.MissionType.WEEKLY);
            } else if (clicked.getType() == Material.NETHER_STAR) {
                openMissionList(player, Mission.MissionType.ACHIEVEMENT);
            }
        } else if (guiType.startsWith("list_")) {
            if (clicked.getType() == Material.ARROW) {
                openMainMenu(player);
            }
        }
    }
    
    private int getCompletionRate(Player player, Mission.MissionType type) {
        List<Mission> missions = missionManager.getMissionsByType(type);
        if (missions.isEmpty()) return 0;
        
        long completed = missions.stream()
            .filter(m -> m.isCompleted(player.getUniqueId()))
            .count();
        
        return (int) ((completed / (double) missions.size()) * 100);
    }
    
    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }
}
