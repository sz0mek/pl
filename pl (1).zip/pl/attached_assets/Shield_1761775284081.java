package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Shield extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Shield(SoulCraftPlugin plugin) {
        super("shield", "§9§lTarcza", "§7Odporność III przez 10 sekund", 60, "svip", 18000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
        player.sendMessage("§9§l🛡 Aktywowano Tarczę!");
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
