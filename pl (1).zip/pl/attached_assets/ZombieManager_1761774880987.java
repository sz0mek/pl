// ZombieManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class ZombieManager implements Listener {
    private final SoulCraftPlugin plugin;

    public ZombieManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        startZombieSpawning();
    }

    private void startZombieSpawning() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (World world : Bukkit.getWorlds()) {
                if (Math.random() < 0.1) {
                    int x = (int) (Math.random() * 2000 - 1000);
                    int z = (int) (Math.random() * 2000 - 1000);
                    Location loc = world.getHighestBlockAt(x, z).getLocation().add(0, 1, 0);
                    world.getBlockAt(loc).setType(Material.BEDROCK);
                    Bukkit.broadcastMessage("§5Kryształ dusz pojawił się na " + loc.getBlockX() + ", " + loc.getBlockZ()
                            + " w świecie " + world.getName() + "!");
                    spawnZombiesAround(loc);
                }
                if (Math.random() < 0.2) {
                    int x = (int) (Math.random() * 2000 - 1000);
                    int z = (int) (Math.random() * 2000 - 1000);
                    Location loc = world.getHighestBlockAt(x, z).getLocation().add(0, 1, 0);
                    spawnSpecialZombie(loc);
                }
            }
        }, 0L, 20L * 60 * 5);
    }

    public void spawnZombiesAround(Location center) {
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                if (Math.random() < 0.5) {
                    spawnSpecialZombie(center.clone().add(x, 0, z));
                }
            }
        }
    }

    public void spawnSpecialZombie(Location loc) {
        if (loc == null || loc.getWorld() == null)
            return;
        Zombie zombie = loc.getWorld().spawn(loc, Zombie.class);
        zombie.setCustomName("§5Specjalny Zombie");
        zombie.setCustomNameVisible(true);
        zombie.setGlowing(true);
    }

    @EventHandler
    public void onZombieDeath(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Zombie))
            return;
        if (event.getEntity().getCustomName() == null)
            return;
        if (!event.getEntity().getCustomName().contains("Specjalny Zombie"))
            return;

        Player killer = event.getEntity().getKiller();
        if (killer == null)
            return;

        String uuid = killer.getUniqueId().toString();
        // zabezpieczenie przed wielokrotnym dodaniem (jedno wywołanie eventu ->
        // jednokrotna nagroda)
        plugin.getSoulManager().addSouls(uuid, 5);
        killer.sendMessage("§5Zdobyłeś 5 dusz za zabicie specjalnego zombie!");
    }
}
