package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class NoFallDamage extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public NoFallDamage(SoulCraftPlugin plugin) {
        super(
            "nofalldamage",
            "§d§lBrak Obrażeń od Upadku",
            "§7Nie otrzymujesz obrażeń od spadania"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        EntityDamageEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof org.bukkit.entity.Player player)) {
            return;
        }
        
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) {
            return;
        }
        
        if (canUse(player)) {
            event.setCancelled(true);
        }
    }
}
