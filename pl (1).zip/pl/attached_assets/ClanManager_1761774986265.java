// ClanManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.*;

public class ClanManager {
    private final SoulCraftPlugin plugin;
    private final Map<String, String> playerClans = new HashMap<>();
    private final Map<String, List<String>> clanMembers = new HashMap<>();
    private final Map<String, String> invitations = new HashMap<>();

    public ClanManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadClans() {
        ConfigurationSection clansSection = plugin.getConfig().getConfigurationSection("clans");
        if (clansSection != null) {
            for (String clanName : clansSection.getKeys(false)) {
                List<String> members = clansSection.getStringList(clanName + ".members");
                clanMembers.put(clanName, members);
                for (String member : members) {
                    playerClans.put(member, clanName);
                }
            }
        }
    }

    public void createClan(String playerName, String clanName) {
        if (playerClans.containsKey(playerName)) {
            return; // Already in clan
        }
        List<String> members = new ArrayList<>();
        members.add(playerName);
        clanMembers.put(clanName, members);
        playerClans.put(playerName, clanName);
        plugin.getConfig().set("clans." + clanName + ".leader", playerName);
        plugin.getConfig().set("clans." + clanName + ".members", members);
        plugin.saveConfig();
    }

    public void invitePlayer(String inviter, String invited) {
        Player invitedPlayer = Bukkit.getPlayer(invited);
        if (invitedPlayer != null && !playerClans.containsKey(invited)) {
            invitations.put(invited, getClan(inviter));
            invitedPlayer.sendMessage("§aZostales zaproszony do klanu " + getClan(inviter) + " przez " + inviter
                    + "! Uzyj /klan przyjmij aby zaakceptowac.");
            Bukkit.getPlayer(inviter).sendMessage("§aWyslales zaproszenie do klanu dla " + invited + ".");
        }
    }

    public void acceptInvite(String playerName) {
        String clanName = invitations.get(playerName);
        if (clanName != null) {
            List<String> members = clanMembers.get(clanName);
            if (members != null) {
                members.add(playerName);
                playerClans.put(playerName, clanName);
                plugin.getConfig().set("clans." + clanName + ".members", members);
                plugin.saveConfig();
                invitations.remove(playerName);
                Bukkit.getPlayer(playerName).sendMessage("§aDolaczyles do klanu " + clanName + "!");
            }
        }
    }

    public void leaveClan(String playerName) {
        String clanName = playerClans.get(playerName);
        if (clanName == null) {
            Player player = Bukkit.getPlayer(playerName);
            if (player != null) {
                player.sendMessage("§cNie jesteś w żadnym klanie!");
            }
            return;
        }

        String leader = plugin.getConfig().getString("clans." + clanName + ".leader");
        List<String> members = clanMembers.get(clanName);

        if (members != null) {
            members.remove(playerName);
            playerClans.remove(playerName);

            if (leader != null && leader.equals(playerName)) {
                // Lider opuszcza klan - rozwiąż klan
                for (String member : members) {
                    playerClans.remove(member);
                    Player memberPlayer = Bukkit.getPlayer(member);
                    if (memberPlayer != null) {
                        memberPlayer
                                .sendMessage("§cKlan " + clanName + " został rozwiązany, ponieważ lider go opuścił!");
                    }
                }

                plugin.getConfig().set("clans." + clanName, null);
                clanMembers.remove(clanName);

                Player player = Bukkit.getPlayer(playerName);
                if (player != null) {
                    player.sendMessage("§aOpuściłeś i rozwiązałeś klan " + clanName + "!");
                }
            } else {
                // Zwykły członek opuszcza klan
                plugin.getConfig().set("clans." + clanName + ".members", members);
                clanMembers.put(clanName, members);

                Player player = Bukkit.getPlayer(playerName);
                if (player != null) {
                    player.sendMessage("§aOpuściłeś klan " + clanName + "!");
                }

                // Powiadom pozostałych członków
                for (String member : members) {
                    Player memberPlayer = Bukkit.getPlayer(member);
                    if (memberPlayer != null) {
                        memberPlayer.sendMessage("§e" + playerName + " opuścił klan!");
                    }
                }
            }

            plugin.saveConfig();
        }
    }

    public String getClan(String playerName) {
        return playerClans.get(playerName);
    }

    public boolean isInClan(String playerName) {
        return playerClans.containsKey(playerName);
    }
}
