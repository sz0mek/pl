package com.soulcraft.bosses;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.missions.MissionService;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Complete boss system with AI, behavior trees, and multi-phase mechanics
 */
public class BossService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MissionService missionService;
    
    private final Map<String, BossConfig> bossConfigs;
    private final Map<UUID, BossInstance> activeBosses;  // entity UUID -> boss instance
    private final Map<String, Long> lastSpawnTimes;  // boss ID -> last spawn time
    
    public BossService(Plugin plugin, DataStore dataStore, EconomyService economyService, MissionService missionService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionService = missionService;
        this.bossConfigs = new HashMap<>();
        this.activeBosses = new HashMap<>();
        this.lastSpawnTimes = new HashMap<>();
        
        loadBossConfigs();
        startBossAI();
    }
    
    private void loadBossConfigs() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load all 5 bosses
        String[] bossIds = {"soul_eater", "void_titan", "chaos_knight", "phantom_lord", "dark_emperor"};
        
        for (String bossId : bossIds) {
            String path = "bosses." + bossId;
            BossConfig config = new BossConfig();
            
            config.id = bossId;
            config.name = balance.getString(path + ".name");
            config.health = balance.getDouble(path + ".health");
            config.damage = balance.getDouble(path + ".damage");
            config.defense = balance.getDouble(path + ".defense");
            config.speed = balance.getDouble(path + ".speed");
            config.soulReward = balance.getLong(path + ".soul_reward");
            config.spawnCooldown = balance.getInt(path + ".spawn_cooldown");
            
            // Load phases
            ConfigurationSection phasesSection = balance.getConfigurationSection(path + ".phases");
            if (phasesSection != null) {
                for (String phaseKey : phasesSection.getKeys(false)) {
                    BossPhase phase = new BossPhase();
                    String phasePath = path + ".phases." + phaseKey;
                    
                    phase.abilities = balance.getStringList(phasePath + ".abilities");
                    phase.aggroRange = balance.getInt(phasePath + ".aggro_range");
                    phase.damageMultiplier = balance.getDouble(phasePath + ".damage_multiplier", 1.0);
                    
                    config.phases.add(phase);
                }
            }
            
            // Load drops
            ConfigurationSection dropsSection = balance.getConfigurationSection(path + ".special_drops");
            if (dropsSection != null) {
                for (String key : dropsSection.getKeys(false)) {
                    BossDrop drop = new BossDrop();
                    drop.item = balance.getString(path + ".special_drops." + key + ".item");
                    drop.chance = balance.getDouble(path + ".special_drops." + key + ".chance");
                    config.drops.add(drop);
                }
            }
            
            bossConfigs.put(bossId, config);
        }
    }
    
    /**
     * Spawn boss at location
     */
    public LivingEntity spawnBoss(String bossId, Location location) {
        BossConfig config = bossConfigs.get(bossId);
        if (config == null) return null;
        
        // Check cooldown
        Long lastSpawn = lastSpawnTimes.get(bossId);
        if (lastSpawn != null) {
            long timeSince = (System.currentTimeMillis() - lastSpawn) / 1000;
            if (timeSince < config.spawnCooldown) {
                return null;  // Still on cooldown
            }
        }
        
        // Spawn entity based on boss type
        LivingEntity entity = spawnBossEntity(bossId, location);
        if (entity == null) return null;
        
        // Configure entity
        entity.setCustomName("§c§l✦ " + config.name + " ✦");
        entity.setCustomNameVisible(true);
        entity.setRemoveWhenFarAway(false);
        
        // Set stats
        if (entity.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(config.health);
            entity.setHealth(config.health);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(config.damage);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(config.speed * 0.1);
        }
        
        // Create boss instance
        BossInstance instance = new BossInstance();
        instance.bossId = bossId;
        instance.config = config;
        instance.entity = entity;
        instance.currentPhase = 0;
        instance.spawnTime = System.currentTimeMillis();
        instance.participants = new HashSet<>();
        
        activeBosses.put(entity.getUniqueId(), instance);
        lastSpawnTimes.put(bossId, System.currentTimeMillis());
        
        // Announce spawn
        Bukkit.broadcastMessage("§c§l✦ " + config.name + " has spawned at " + 
                                location.getBlockX() + ", " + location.getBlockY() + ", " + location.getBlockZ() + "!");
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.8f);
        }
        
        return entity;
    }
    
    /**
     * Spawn actual boss entity
     */
    private LivingEntity spawnBossEntity(String bossId, Location location) {
        switch (bossId) {
            case "soul_eater":
                return location.getWorld().spawn(location, Wither.class);
            case "void_titan":
                return location.getWorld().spawn(location, IronGolem.class);
            case "chaos_knight":
                Zombie knight = location.getWorld().spawn(location, Zombie.class);
                knight.setAdult();
                knight.getEquipment().setHelmet(new org.bukkit.inventory.ItemStack(Material.NETHERITE_HELMET));
                knight.getEquipment().setChestplate(new org.bukkit.inventory.ItemStack(Material.NETHERITE_CHESTPLATE));
                return knight;
            case "phantom_lord":
                return location.getWorld().spawn(location, Phantom.class);
            case "dark_emperor":
                return location.getWorld().spawn(location, WitherSkeleton.class);
            default:
                return null;
        }
    }
    
    /**
     * Handle boss death
     */
    public void handleBossDeath(UUID entityId, Player killer) {
        BossInstance instance = activeBosses.remove(entityId);
        if (instance == null) return;
        
        BossConfig config = instance.config;
        
        // Announce death
        Bukkit.broadcastMessage("§a§l✓ " + config.name + " has been defeated by " + killer.getName() + "!");
        
        // Distribute rewards to all participants
        for (UUID participantId : instance.participants) {
            Player participant = Bukkit.getPlayer(participantId);
            if (participant != null) {
                // Give souls
                economyService.deposit(participant, config.soulReward, "Boss kill: " + config.name);
                
                // Progress mission
                missionService.progressMission(participantId, MissionService.MissionType.KILL_BOSSES, 1);
                
                // Drop special loot
                for (BossDrop drop : config.drops) {
                    if (Math.random() < drop.chance) {
                        // Would integrate with CustomItemService here
                        participant.sendMessage("§6§l✦ Rare Drop: §e" + drop.item);
                    }
                }
                
                participant.sendMessage("§6§l+§e" + config.soulReward + " souls §7for defeating " + config.name);
            }
        }
        
        // Visual effects
        Location loc = killer.getLocation();
        loc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc, 5);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_DEATH, 2.0f, 1.0f);
    }
    
    /**
     * Add participant to boss fight
     */
    public void addParticipant(UUID entityId, Player player) {
        BossInstance instance = activeBosses.get(entityId);
        if (instance != null) {
            instance.participants.add(player.getUniqueId());
        }
    }
    
    /**
     * Get boss instance
     */
    public BossInstance getBossInstance(UUID entityId) {
        return activeBosses.get(entityId);
    }
    
    /**
     * Check if entity is a boss
     */
    public boolean isBoss(UUID entityId) {
        return activeBosses.containsKey(entityId);
    }
    
    /**
     * Get boss config by ID (stub for command compatibility)
     */
    public BossConfig getBoss(String bossId) {
        return bossConfigs.get(bossId);
    }
    
    /**
     * Boss AI task
     */
    private void startBossAI() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (BossInstance instance : new ArrayList<>(activeBosses.values())) {
                if (instance.entity == null || instance.entity.isDead()) {
                    activeBosses.remove(instance.entity.getUniqueId());
                    continue;
                }
                
                updateBossPhase(instance);
                executeBossAbilities(instance);
            }
        }, 20L, 20L); // Run every second
    }
    
    /**
     * Update boss phase based on health
     */
    private void updateBossPhase(BossInstance instance) {
        double healthPercent = instance.entity.getHealth() / instance.entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        
        int newPhase = 0;
        if (healthPercent <= 0.25) {
            newPhase = Math.min(3, instance.config.phases.size() - 1);
        } else if (healthPercent <= 0.50) {
            newPhase = Math.min(2, instance.config.phases.size() - 1);
        } else if (healthPercent <= 0.75) {
            newPhase = Math.min(1, instance.config.phases.size() - 1);
        }
        
        if (newPhase != instance.currentPhase) {
            instance.currentPhase = newPhase;
            
            // Announce phase change
            BossPhase phase = instance.config.phases.get(newPhase);
            Bukkit.broadcastMessage("§c§l⚠ " + instance.config.name + " enters Phase " + (newPhase + 1) + "!");
            
            // Visual effects
            Location loc = instance.entity.getLocation();
            loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 10);
            loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.8f);
            
            // Apply phase damage multiplier
            if (phase.damageMultiplier > 1.0) {
                double newDamage = instance.config.damage * phase.damageMultiplier;
                instance.entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(newDamage);
            }
        }
    }
    
    /**
     * Execute boss abilities
     */
    private void executeBossAbilities(BossInstance instance) {
        BossPhase phase = instance.config.phases.get(instance.currentPhase);
        
        // Execute random ability
        if (!phase.abilities.isEmpty() && Math.random() < 0.3) {  // 30% chance per second
            String ability = phase.abilities.get(new Random().nextInt(phase.abilities.size()));
            executeBossAbility(instance, ability);
        }
        
        // Find and attack nearby players
        if (instance.entity instanceof Creature) {
            Creature creature = (Creature) instance.entity;
            
            Player nearestPlayer = null;
            double nearestDistance = phase.aggroRange;
            
            for (Entity entity : instance.entity.getNearbyEntities(phase.aggroRange, phase.aggroRange, phase.aggroRange)) {
                if (entity instanceof Player) {
                    Player player = (Player) entity;
                    double distance = instance.entity.getLocation().distance(player.getLocation());
                    
                    if (distance < nearestDistance) {
                        nearestDistance = distance;
                        nearestPlayer = player;
                    }
                }
            }
            
            if (nearestPlayer != null) {
                creature.setTarget(nearestPlayer);
                addParticipant(instance.entity.getUniqueId(), nearestPlayer);
            }
        }
    }
    
    /**
     * Execute specific boss ability
     */
    private void executeBossAbility(BossInstance instance, String ability) {
        Location loc = instance.entity.getLocation();
        
        switch (ability) {
            case "soul_drain":
                // Damage and heal nearby players
                for (Entity entity : instance.entity.getNearbyEntities(10, 10, 10)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.damage(5.0);
                        instance.entity.setHealth(Math.min(
                            instance.entity.getHealth() + 5.0,
                            instance.entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue()
                        ));
                        player.getWorld().spawnParticle(Particle.SOUL, player.getLocation(), 10);
                    }
                }
                break;
                
            case "summon_minions":
                // Spawn minion mobs
                for (int i = 0; i < 3; i++) {
                    loc.getWorld().spawn(loc.clone().add(Math.random() * 5 - 2.5, 0, Math.random() * 5 - 2.5), Zombie.class);
                }
                loc.getWorld().spawnParticle(Particle.PORTAL, loc, 50);
                break;
                
            case "dark_pulse":
                // AoE damage
                for (Entity entity : instance.entity.getNearbyEntities(8, 8, 8)) {
                    if (entity instanceof Player) {
                        ((Player) entity).damage(8.0);
                    }
                }
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc, 20);
                loc.getWorld().playSound(loc, Sound.ENTITY_WITHER_SHOOT, 1.0f, 0.8f);
                break;
                
            case "ground_slam":
                // Knockback
                for (Entity entity : instance.entity.getNearbyEntities(6, 6, 6)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.setVelocity(player.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(2).setY(1));
                        player.damage(10.0);
                    }
                }
                loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 5);
                break;
                
            case "void_pull":
                // Pull players towards boss
                for (Entity entity : instance.entity.getNearbyEntities(15, 15, 15)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.setVelocity(loc.toVector().subtract(player.getLocation().toVector()).normalize());
                    }
                }
                loc.getWorld().spawnParticle(Particle.PORTAL, loc, 30);
                break;
                
            // Add more abilities as needed
        }
    }
    
    /**
     * Boss configuration
     */
    public static class BossConfig {
        public String id;
        public String name;
        public double health;
        public double damage;
        public double defense;
        public double speed;
        public long soulReward;
        public int spawnCooldown;
        public List<BossPhase> phases = new ArrayList<>();
        public List<BossDrop> drops = new ArrayList<>();
    }
    
    /**
     * Boss phase
     */
    public static class BossPhase {
        public List<String> abilities;
        public int aggroRange;
        public double damageMultiplier;
    }
    
    /**
     * Boss drop
     */
    public static class BossDrop {
        public String item;
        public double chance;
    }
    
    /**
     * Active boss instance
     */
    public static class BossInstance {
        public String bossId;
        public BossConfig config;
        public LivingEntity entity;
        public int currentPhase;
        public long spawnTime;
        public Set<UUID> participants;
    }
}
