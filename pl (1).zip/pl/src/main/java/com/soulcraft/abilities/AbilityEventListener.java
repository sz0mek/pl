package com.soulcraft.abilities;

import com.soulcraft.abilities.AbilityService.AbilityConfig;
import com.soulcraft.abilities.AbilityService.AbilityState;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.Random;

/**
 * Complete event listener for all 12 abilities
 */
public class AbilityEventListener implements Listener {
    private final Plugin plugin;
    private final AbilityService abilityService;
    private final Random random;
    
    public AbilityEventListener(Plugin plugin, AbilityService abilityService) {
        this.plugin = plugin;
        this.abilityService = abilityService;
        this.random = new Random();
        
        // Start passive ability task (for regeneration, etc.)
        startPassiveTask();
    }
    
    /**
     * Handle combat abilities
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Player damaging entity
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            LivingEntity victim = (LivingEntity) event.getEntity();
            handleAttackerAbilities(attacker, victim, event);
        }
        
        // Entity damaging player
        if (event.getEntity() instanceof Player) {
            Player defender = (Player) event.getEntity();
            handleDefenderAbilities(defender, event);
        }
    }
    
    /**
     * Handle attacker abilities (when player attacks)
     */
    private void handleAttackerAbilities(Player attacker, LivingEntity victim, EntityDamageByEntityEvent event) {
        double damage = event.getDamage();
        double modifiedDamage = damage;
        
        // Berserk (active) - +50% damage, +30% speed
        if (abilityService.isAbilityActive(attacker, "berserk")) {
            AbilityConfig config = abilityService.getConfig("berserk");
            modifiedDamage *= (1 + config.damageBoost);
            
            // Visual effects
            attacker.getWorld().spawnParticle(Particle.CRIT, victim.getLocation(), 10);
            attacker.playSound(attacker.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.5f);
        }
        
        // Critical Strike (passive) - 25% chance for 2x damage
        if (abilityService.hasAbility(attacker, "critical_strike")) {
            AbilityConfig config = abilityService.getConfig("critical_strike");
            if (random.nextDouble() < config.chance) {
                modifiedDamage *= config.damageMultiplier;
                
                // Visual effects
                victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation(), 20);
                attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
                attacker.sendMessage("§6§l⚔ CRITICAL HIT!");
            }
        }
        
        // Heal on Hit (passive) - 10% of damage as healing
        if (abilityService.hasAbility(attacker, "heal_on_hit")) {
            AbilityConfig config = abilityService.getConfig("heal_on_hit");
            double healAmount = modifiedDamage * config.healPercent;
            healPlayer(attacker, healAmount);
            
            // Visual effects
            attacker.getWorld().spawnParticle(Particle.HEART, attacker.getLocation().add(0, 1, 0), 3);
        }
        
        // Life Steal (passive) - 5% of damage as health
        if (abilityService.hasAbility(attacker, "life_steal")) {
            AbilityConfig config = abilityService.getConfig("life_steal");
            double stealAmount = Math.min(modifiedDamage * config.stealPercent, 
                                         config.damageMultiplier); // Max 4 hearts
            healPlayer(attacker, stealAmount);
            
            // Visual effects
            attacker.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, 
                                            victim.getLocation().add(0, 1, 0), 5);
        }
        
        // Vampirism (active) - Boosted lifesteal + damage
        if (abilityService.isAbilityActive(attacker, "vampirism")) {
            AbilityConfig config = abilityService.getConfig("vampirism");
            modifiedDamage *= (1 + config.damageBoost);
            
            double lifeSteal = modifiedDamage * config.stealPercent;
            healPlayer(attacker, lifeSteal);
            
            // Visual effects
            attacker.getWorld().spawnParticle(Particle.DUST, victim.getLocation(), 20,
                                            new Particle.DustOptions(Color.RED, 1.0f));
        }
        
        // Apply modified damage
        if (modifiedDamage != damage) {
            event.setDamage(modifiedDamage);
        }
    }
    
    /**
     * Handle defender abilities (when player takes damage)
     */
    private void handleDefenderAbilities(Player defender, EntityDamageByEntityEvent event) {
        double damage = event.getDamage();
        double modifiedDamage = damage;
        
        // Dodge (passive) - 15% chance to avoid damage
        if (abilityService.hasAbility(defender, "dodge")) {
            AbilityConfig config = abilityService.getConfig("dodge");
            if (random.nextDouble() < config.chance) {
                event.setCancelled(true);
                
                // Visual effects
                defender.getWorld().spawnParticle(Particle.CLOUD, defender.getLocation(), 20);
                defender.playSound(defender.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.5f);
                defender.sendMessage("§a§l✓ DODGED!");
                return;
            }
        }
        
        // Shield (active) - Absorption
        if (abilityService.isAbilityActive(defender, "shield")) {
            AbilityConfig config = abilityService.getConfig("shield");
            // Absorption is applied when ability activates
            defender.getWorld().spawnParticle(Particle.ENCHANT, 
                                            defender.getLocation(), 15);
        }
        
        // Soul Shield (active) - 50% damage reduction + 30% reflect
        if (abilityService.isAbilityActive(defender, "soul_shield")) {
            AbilityConfig config = abilityService.getConfig("soul_shield");
            modifiedDamage *= (1 - config.damageReduction);
            
            // Reflect damage
            if (event.getDamager() instanceof LivingEntity) {
                LivingEntity attacker = (LivingEntity) event.getDamager();
                double reflectedDamage = damage * config.reflectDamage;
                attacker.damage(reflectedDamage);
                
                // Visual effects
                attacker.getWorld().spawnParticle(Particle.CRIT, 
                                                attacker.getLocation(), 15);
            }
            
            defender.getWorld().spawnParticle(Particle.END_ROD, defender.getLocation(), 20);
        }
        
        // Thorns (passive) - 20% reflect
        if (abilityService.hasAbility(defender, "thorns")) {
            AbilityConfig config = abilityService.getConfig("thorns");
            
            if (event.getDamager() instanceof LivingEntity) {
                LivingEntity attacker = (LivingEntity) event.getDamager();
                double reflectedDamage = damage * config.reflectPercent;
                attacker.damage(reflectedDamage);
                
                // Visual effects
                attacker.getWorld().spawnParticle(Particle.ANGRY_VILLAGER, 
                                                attacker.getLocation().add(0, 1, 0), 5);
            }
        }
        
        // Apply modified damage
        if (modifiedDamage != damage) {
            event.setDamage(modifiedDamage);
        }
    }
    
    /**
     * Handle movement abilities
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        // Speed Burst (active) - 2x speed
        if (abilityService.isAbilityActive(player, "speed_burst")) {
            if (!player.hasPotionEffect(PotionEffectType.SPEED)) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 2, false, false));
            }
        }
        
        // Berserk (active) - Speed boost
        if (abilityService.isAbilityActive(player, "berserk")) {
            if (!player.hasPotionEffect(PotionEffectType.SPEED)) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1, false, false));
            }
        }
    }
    
    /**
     * Sneak to activate abilities
     */
    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        if (!event.isSneaking()) return;
        
        // Check if player is holding specific item to activate ability
        // Or use command-based activation (already handled in AbilityCommand)
    }
    
    /**
     * Passive ability task (runs every second)
     */
    private void startPassiveTask() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                // Regeneration (passive) - 0.5 health per second
                if (abilityService.hasAbility(player, "regeneration")) {
                    AbilityConfig config = abilityService.getConfig("regeneration");
                    healPlayer(player, config.healthPerSecond);
                    
                    // Visual effects (every 5 seconds to avoid spam)
                    if (random.nextInt(5) == 0) {
                        player.getWorld().spawnParticle(Particle.HEART, 
                                                      player.getLocation().add(0, 2, 0), 1);
                    }
                }
                
                // Update active ability effects visually
                Map<String, AbilityState> activeAbilities = abilityService.getActiveAbilities(player);
                for (AbilityState state : activeAbilities.values()) {
                    // Show particles for active abilities
                    if (state.isActive()) {
                        switch (state.abilityId) {
                            case "berserk":
                                player.getWorld().spawnParticle(Particle.FLAME, 
                                                              player.getLocation(), 3);
                                break;
                            case "shield":
                                player.getWorld().spawnParticle(Particle.ENCHANT, 
                                                              player.getLocation(), 5);
                                break;
                            case "soul_shield":
                                player.getWorld().spawnParticle(Particle.END_ROD, 
                                                              player.getLocation(), 8);
                                break;
                            case "speed_burst":
                                player.getWorld().spawnParticle(Particle.CLOUD, 
                                                              player.getLocation(), 2);
                                break;
                            case "vampirism":
                                player.getWorld().spawnParticle(Particle.DUST, 
                                                              player.getLocation(), 5,
                                                              new Particle.DustOptions(Color.fromRGB(139, 0, 0), 1.0f));
                                break;
                        }
                    }
                }
            }
        }, 20L, 20L); // Run every second
    }
    
    /**
     * Heal player safely
     */
    private void healPlayer(Player player, double amount) {
        if (amount <= 0) return;
        
        double maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        double currentHealth = player.getHealth();
        double newHealth = Math.min(currentHealth + amount, maxHealth);
        
        player.setHealth(newHealth);
    }
}
