package com.soulcraft.features;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Complete gameplay features system (12 features)
 */
public class GameplayFeaturesService implements Listener {
    private final Plugin plugin;
    private final DataStore dataStore;
    
    // Double jump tracking
    private final Map<UUID, Long> lastJumpTime = new HashMap<>();
    private final Set<UUID> canDoubleJump = new HashSet<>();
    
    public GameplayFeaturesService(Plugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        
        startPassiveFeatures();
    }
    
    /**
     * Start passive feature tasks
     */
    private void startPassiveFeatures() {
        // Night vision task
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (hasFeature(player, "nightvision")) {
                    if (!player.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 400, 0, false, false));
                    }
                }
            }
        }, 20L, 100L); // Check every 5 seconds
        
        // Auto Feed task
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (hasFeature(player, "autofeed")) {
                    if (player.getFoodLevel() < 15) {
                        // Find food in inventory
                        for (ItemStack item : player.getInventory().getContents()) {
                            if (item != null && isFood(item.getType())) {
                                item.setAmount(item.getAmount() - 1);
                                player.setFoodLevel(Math.min(20, player.getFoodLevel() + 4));
                                player.setSaturation(player.getSaturation() + 2.4f);
                                break;
                            }
                        }
                    }
                }
            }
        }, 20L, 40L); // Check every 2 seconds
    }
    
    /**
     * Check if player has feature
     */
    public boolean hasFeature(Player player, String featureId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.hasFeature(featureId);
    }
    
    /**
     * Toggle feature for player
     */
    public void toggleFeature(Player player, String featureId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        boolean current = data.hasFeature(featureId);
        data.setFeature(featureId, !current);
        
        player.sendMessage(current ? "§c§l✗ Disabled: §7" + featureId : "§a§l✓ Enabled: §e" + featureId);
    }
    
    /**
     * AUTO PICKUP - Pick up items automatically
     */
    @EventHandler
    public void onItemSpawn(org.bukkit.event.player.PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeature(player, "autopickup")) {
            // Auto pickup is handled by Bukkit naturally
            // Could add custom radius or filtering logic here
        }
    }
    
    /**
     * DOUBLE JUMP - Jump twice in air
     */
    @EventHandler
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }
        
        if (hasFeature(player, "doublejump")) {
            event.setCancelled(true);
            player.setAllowFlight(false);
            player.setFlying(false);
            
            player.setVelocity(player.getLocation().getDirection().multiply(1.2).setY(1));
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 0.5f, 1.5f);
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 10);
            
            canDoubleJump.remove(player.getUniqueId());
        }
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        if (!hasFeature(player, "doublejump")) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        
        if (player.isOnGround()) {
            player.setAllowFlight(true);
            canDoubleJump.add(player.getUniqueId());
        }
    }
    
    /**
     * AUTO REPLANT - Automatically replant crops
     */
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        
        if (hasFeature(player, "autoreplant")) {
            Material type = block.getType();
            
            // Check if it's a fully grown crop
            if (type == Material.WHEAT && block.getData() == 7) {
                replantCrop(block, Material.WHEAT_SEEDS);
            } else if (type == Material.CARROTS && block.getData() == 7) {
                replantCrop(block, Material.CARROT);
            } else if (type == Material.POTATOES && block.getData() == 7) {
                replantCrop(block, Material.POTATO);
            } else if (type == Material.BEETROOTS && block.getData() == 3) {
                replantCrop(block, Material.BEETROOT_SEEDS);
            }
        }
        
        // AUTO SMELT - Automatically smelt ores
        if (hasFeature(player, "autosmelt")) {
            Material smeltedType = getSmeltedType(block.getType());
            if (smeltedType != null) {
                event.setDropItems(false);
                block.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(smeltedType, 1));
                player.giveExp(1);
            }
        }
    }
    
    private void replantCrop(Block block, Material seedType) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            block.setType(getSeedBlockType(seedType));
        }, 1L);
    }
    
    private Material getSeedBlockType(Material seedType) {
        switch (seedType) {
            case WHEAT_SEEDS: return Material.WHEAT;
            case CARROT: return Material.CARROTS;
            case POTATO: return Material.POTATOES;
            case BEETROOT_SEEDS: return Material.BEETROOTS;
            default: return Material.AIR;
        }
    }
    
    private Material getSmeltedType(Material ore) {
        switch (ore) {
            case IRON_ORE:
            case DEEPSLATE_IRON_ORE:
                return Material.IRON_INGOT;
            case GOLD_ORE:
            case DEEPSLATE_GOLD_ORE:
            case NETHER_GOLD_ORE:
                return Material.GOLD_INGOT;
            case COPPER_ORE:
            case DEEPSLATE_COPPER_ORE:
                return Material.COPPER_INGOT;
            default:
                return null;
        }
    }
    
    /**
     * KEEP INVENTORY - Keep items on death
     */
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        
        if (hasFeature(player, "keepinventory")) {
            event.setKeepInventory(true);
            event.setKeepLevel(true);
            event.getDrops().clear();
        }
    }
    
    /**
     * NO FALL DAMAGE - Prevent fall damage
     */
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        
        Player player = (Player) event.getEntity();
        
        if (hasFeature(player, "nofalldamage")) {
            if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                event.setCancelled(true);
            }
        }
    }
    
    /**
     * FAST EAT - Eat 3x faster
     */
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeature(player, "fasteat")) {
            // Eating speed is handled by client
            // Could give bonus saturation/food level
        }
    }
    
    /**
     * XP BOOST - 2x XP
     */
    @EventHandler
    public void onExpChange(PlayerExpChangeEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeature(player, "xpboost")) {
            event.setAmount(event.getAmount() * 2);
        }
    }
    
    /**
     * MONEY BOOST - +50 souls per kill
     */
    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        
        if (hasFeature(killer, "moneyboost")) {
            // Would integrate with EconomyService
            // economyService.deposit(killer, 50, "Money Boost");
        }
    }
    
    /**
     * LOOT BOOST - 2x loot
     */
    @EventHandler
    public void onLootGenerate(org.bukkit.event.world.LootGenerateEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        
        Player player = (Player) event.getEntity();
        
        if (hasFeature(player, "lootboost")) {
            List<ItemStack> loot = event.getLoot();
            List<ItemStack> bonusLoot = new ArrayList<>();
            
            for (ItemStack item : loot) {
                bonusLoot.add(item.clone());
            }
            
            loot.addAll(bonusLoot);
        }
    }
    
    /**
     * Get all features (stub for command compatibility)
     */
    public java.util.Map<String, Object> getAllFeatures() {
        return new java.util.HashMap<>();
    }
    
    /**
     * Get feature by ID (stub for command compatibility)
     */
    public Object getFeature(String featureId) {
        return null;
    }
    
    /**
     * Check if feature is enabled globally (stub for command compatibility)
     */
    public boolean isFeatureEnabled(String featureId) {
        return false;
    }
    
    /**
     * Toggle feature globally (stub for command compatibility)
     */
    public void toggleFeature(String featureId, boolean enabled) {
        // Stub method for command compatibility
    }
    
    /**
     * Check if material is food
     */
    private boolean isFood(Material material) {
        switch (material) {
            case BREAD:
            case COOKED_BEEF:
            case COOKED_PORKCHOP:
            case COOKED_CHICKEN:
            case COOKED_MUTTON:
            case COOKED_RABBIT:
            case COOKED_COD:
            case COOKED_SALMON:
            case APPLE:
            case GOLDEN_APPLE:
            case ENCHANTED_GOLDEN_APPLE:
            case MELON_SLICE:
            case SWEET_BERRIES:
            case GLOW_BERRIES:
            case CARROT:
            case POTATO:
            case BAKED_POTATO:
            case BEETROOT:
            case DRIED_KELP:
            case COOKIE:
            case PUMPKIN_PIE:
                return true;
            default:
                return false;
        }
    }
}
