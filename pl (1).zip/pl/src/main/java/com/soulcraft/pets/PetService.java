package com.soulcraft.pets;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.persistence.PlayerData.PetData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Complete pet system with leveling 1-100, evolution, and AI
 */
public class PetService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final Map<String, PetTypeConfig> petTypes;
    private final Map<UUID, LivingEntity> activePets; // player UUID -> pet entity
    
    private final int MAX_LEVEL = 100;
    private final int BASE_XP = 100;
    private final double XP_SCALING = 1.15;
    
    public PetService(Plugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.petTypes = new HashMap<>();
        this.activePets = new HashMap<>();
        
        loadPetTypes();
        startPetAITask();
    }
    
    private void loadPetTypes() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        String[] types = {"wolf", "cat", "dragon", "phoenix"};
        
        for (String type : types) {
            String path = "pets.types." + type;
            PetTypeConfig config = new PetTypeConfig();
            
            config.id = type;
            config.baseDamage = balance.getDouble(path + ".base_damage");
            config.baseHealth = balance.getDouble(path + ".base_health");
            config.baseSpeed = balance.getDouble(path + ".base_speed");
            config.growthDamage = balance.getDouble(path + ".growth_damage");
            config.growthHealth = balance.getDouble(path + ".growth_health");
            config.special = balance.getString(path + ".special", "");
            config.unlocksAtLevel = balance.getInt(path + ".unlocks_at_level", 1);
            
            petTypes.put(type, config);
        }
    }
    
    /**
     * Calculate XP required for level
     */
    public long getRequiredXP(int level) {
        if (level >= MAX_LEVEL) return 0;
        return (long)(BASE_XP * Math.pow(XP_SCALING, level - 1));
    }
    
    /**
     * Get pet data for player
     */
    public PetData getPetData(UUID playerId, String petType) {
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        PetData petData = playerData.getPet(petType);
        
        if (petData == null) {
            petData = new PetData();
            playerData.setPet(petType, petData);
        }
        
        return petData;
    }
    
    /**
     * Add XP to pet
     */
    public void addPetXP(UUID playerId, String petType, long amount) {
        PetData petData = getPetData(playerId, petType);
        
        int oldLevel = petData.getLevel();
        petData.addExperience(amount);
        
        // Check for level up
        while (petData.getLevel() < MAX_LEVEL) {
            long required = getRequiredXP(petData.getLevel());
            if (petData.getExperience() >= required) {
                petData.setExperience(petData.getExperience() - required);
                petData.setLevel(petData.getLevel() + 1);
                
                // Check for evolution
                checkEvolution(playerId, petType, petData);
            } else {
                break;
            }
        }
        
        int newLevel = petData.getLevel();
        if (newLevel > oldLevel) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§6§lPET LEVEL UP! §e" + petType + " is now level " + newLevel);
                player.playSound(player.getLocation(), "entity.player.levelup", 1.0f, 1.5f);
                
                // Update active pet stats
                LivingEntity petEntity = activePets.get(playerId);
                if (petEntity != null) {
                    updatePetStats(petEntity, petType, petData);
                }
            }
        }
    }
    
    /**
     * Check and apply evolution
     */
    private void checkEvolution(UUID playerId, String petType, PetData petData) {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        int level = petData.getLevel();
        String newStage = null;
        
        if (level >= 100) {
            newStage = "Legendary";
        } else if (level >= 75) {
            newStage = "Elite";
        } else if (level >= 50) {
            newStage = "Adult";
        } else if (level >= 25) {
            newStage = "Juvenile";
        }
        
        if (newStage != null && !newStage.equals(petData.getEvolutionStage())) {
            petData.setEvolutionStage(newStage);
            
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§5§l✦ PET EVOLVED! §d" + petType + " → " + newStage);
                player.playSound(player.getLocation(), "entity.ender_dragon.growl", 1.0f, 1.0f);
                player.getWorld().strikeLightningEffect(player.getLocation());
            }
        }
    }
    
    /**
     * Spawn pet for player
     */
    public boolean spawnPet(Player player, String petType) {
        UUID playerId = player.getUniqueId();
        
        // Check if player already has pet active
        if (activePets.containsKey(playerId)) {
            despawnPet(player);
        }
        
        // Check if pet type is unlocked
        PetTypeConfig config = petTypes.get(petType);
        if (config == null) return false;
        
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        if (playerData.getLevel() < config.unlocksAtLevel) {
            player.sendMessage("§c§lRequires level " + config.unlocksAtLevel + " to unlock this pet!");
            return false;
        }
        
        // Get pet data
        PetData petData = getPetData(playerId, petType);
        
        // Spawn entity
        LivingEntity entity = spawnPetEntity(player.getLocation(), petType);
        if (entity == null) return false;
        
        // Configure entity
        updatePetStats(entity, petType, petData);
        entity.setCustomName("§6" + player.getName() + "'s " + petType + " §7[Lv." + petData.getLevel() + "]");
        entity.setCustomNameVisible(true);
        
        // Make pet follow player
        if (entity instanceof Tameable) {
            ((Tameable) entity).setTamed(true);
            ((Tameable) entity).setOwner(player);
        }
        
        activePets.put(playerId, entity);
        playerData.setActivePet(petType);
        
        player.sendMessage("§a§l✓ Spawned pet: §e" + petType + " §7[Level " + petData.getLevel() + "]");
        return true;
    }
    
    /**
     * Spawn actual pet entity
     */
    private LivingEntity spawnPetEntity(Location location, String petType) {
        switch (petType.toLowerCase()) {
            case "wolf":
                return location.getWorld().spawn(location, Wolf.class);
            case "cat":
                return location.getWorld().spawn(location, Cat.class);
            case "dragon":
                return location.getWorld().spawn(location, EnderDragon.class);
            case "phoenix":
                return location.getWorld().spawn(location, Blaze.class); // Using blaze as phoenix
            default:
                return null;
        }
    }
    
    /**
     * Update pet stats based on level
     */
    private void updatePetStats(LivingEntity entity, String petType, PetData petData) {
        PetTypeConfig config = petTypes.get(petType);
        if (config == null) return;
        
        int level = petData.getLevel();
        
        // Calculate stats
        double health = config.baseHealth + (config.growthHealth * level);
        double damage = config.baseDamage + (config.growthDamage * level);
        double speed = config.baseSpeed;
        
        // Apply evolution bonuses
        String evolution = petData.getEvolutionStage();
        double evolutionBonus = 0;
        
        switch (evolution) {
            case "Juvenile":
                evolutionBonus = 0.25;
                break;
            case "Adult":
                evolutionBonus = 0.5;
                break;
            case "Elite":
                evolutionBonus = 0.75;
                break;
            case "Legendary":
                evolutionBonus = 1.0;
                break;
        }
        
        health *= (1 + evolutionBonus);
        damage *= (1 + evolutionBonus);
        
        // Apply stats
        if (entity.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
            entity.setHealth(health);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(speed * 0.1);
        }
        
        // Apply special abilities
        applyPetSpecial(entity, config.special);
    }
    
    /**
     * Apply special pet abilities
     */
    private void applyPetSpecial(LivingEntity entity, String special) {
        if (special == null || special.isEmpty()) return;
        
        switch (special.toLowerCase()) {
            case "stealth_bonus":
                entity.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
                break;
            case "resurrection":
                // Resurrection will be handled in death event
                break;
        }
    }
    
    /**
     * Despawn pet
     */
    public void despawnPet(Player player) {
        UUID playerId = player.getUniqueId();
        LivingEntity pet = activePets.remove(playerId);
        
        if (pet != null) {
            pet.remove();
            player.sendMessage("§7Pet despawned.");
        }
        
        PlayerData playerData = dataStore.loadPlayerData(playerId);
        playerData.setActivePet(null);
    }
    
    /**
     * Get active pet
     */
    public LivingEntity getActivePet(UUID playerId) {
        return activePets.get(playerId);
    }
    
    /**
     * Pet AI task
     */
    private void startPetAITask() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, LivingEntity> entry : activePets.entrySet()) {
                UUID playerId = entry.getKey();
                LivingEntity pet = entry.getValue();
                
                Player owner = Bukkit.getPlayer(playerId);
                if (owner == null || !owner.isOnline()) {
                    pet.remove();
                    activePets.remove(playerId);
                    continue;
                }
                
                // Make pet follow owner if too far
                double distance = pet.getLocation().distance(owner.getLocation());
                if (distance > 15) {
                    pet.teleport(owner.getLocation());
                }
                
                // Pet attacks nearby enemies
                if (pet instanceof Creature) {
                    Creature creature = (Creature) pet;
                    
                    // Find nearest enemy
                    LivingEntity nearestEnemy = null;
                    double nearestDistance = 10.0;
                    
                    for (Entity entity : pet.getNearbyEntities(10, 10, 10)) {
                        if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                            LivingEntity livingEntity = (LivingEntity) entity;
                            double dist = pet.getLocation().distance(livingEntity.getLocation());
                            
                            if (dist < nearestDistance) {
                                nearestDistance = dist;
                                nearestEnemy = livingEntity;
                            }
                        }
                    }
                    
                    if (nearestEnemy != null) {
                        creature.setTarget(nearestEnemy);
                    }
                }
            }
        }, 20L, 20L); // Run every second
    }
    
    /**
     * Cleanup when player logs out
     */
    public void cleanup(UUID playerId) {
        LivingEntity pet = activePets.remove(playerId);
        if (pet != null) {
            pet.remove();
        }
    }
    
    /**
     * Pet type configuration
     */
    public static class PetTypeConfig {
        public String id;
        public double baseDamage;
        public double baseHealth;
        public double baseSpeed;
        public double growthDamage;
        public double growthHealth;
        public String special;
        public int unlocksAtLevel;
    }
}
