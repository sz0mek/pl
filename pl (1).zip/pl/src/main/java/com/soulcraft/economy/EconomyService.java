package com.soulcraft.economy;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Complete economy system with transactions, anti-duplication, and logging
 */
public class EconomyService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final ConcurrentHashMap<UUID, TransactionLock> transactionLocks;
    
    public EconomyService(Plugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.transactionLocks = new ConcurrentHashMap<>();
    }
    
    /**
     * Get player's soul balance
     */
    public long getBalance(UUID playerId) {
        PlayerData data = dataStore.loadPlayerData(playerId);
        return data.getSouls();
    }
    
    /**
     * Get player's soul balance
     */
    public long getBalance(Player player) {
        return getBalance(player.getUniqueId());
    }
    
    /**
     * Check if player has enough souls
     */
    public boolean hasEnough(UUID playerId, long amount) {
        return getBalance(playerId) >= amount;
    }
    
    /**
     * Check if player has enough souls
     */
    public boolean hasEnough(Player player, long amount) {
        return hasEnough(player.getUniqueId(), amount);
    }
    
    /**
     * Add souls to player (thread-safe)
     */
    public boolean deposit(UUID playerId, long amount, String reason) {
        if (amount <= 0) return false;
        
        TransactionLock lock = getLock(playerId);
        synchronized (lock) {
            try {
                PlayerData data = dataStore.loadPlayerData(playerId);
                long oldBalance = data.getSouls();
                data.addSouls(amount);
                long newBalance = data.getSouls();
                
                logTransaction(playerId, TransactionType.DEPOSIT, amount, oldBalance, newBalance, reason);
                return true;
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error depositing souls for " + playerId, e);
                return false;
            }
        }
    }
    
    /**
     * Add souls to player
     */
    public boolean deposit(Player player, long amount, String reason) {
        return deposit(player.getUniqueId(), amount, reason);
    }
    
    /**
     * Remove souls from player (thread-safe with rollback)
     */
    public boolean withdraw(UUID playerId, long amount, String reason) {
        if (amount <= 0) return false;
        
        TransactionLock lock = getLock(playerId);
        synchronized (lock) {
            try {
                PlayerData data = dataStore.loadPlayerData(playerId);
                long oldBalance = data.getSouls();
                
                if (oldBalance < amount) {
                    return false; // Insufficient funds
                }
                
                boolean success = data.removeSouls(amount);
                if (success) {
                    long newBalance = data.getSouls();
                    logTransaction(playerId, TransactionType.WITHDRAW, amount, oldBalance, newBalance, reason);
                }
                return success;
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error withdrawing souls for " + playerId, e);
                return false;
            }
        }
    }
    
    /**
     * Remove souls from player
     */
    public boolean withdraw(Player player, long amount, String reason) {
        return withdraw(player.getUniqueId(), amount, reason);
    }
    
    /**
     * Transfer souls between players (atomic transaction)
     */
    public boolean transfer(UUID from, UUID to, long amount, String reason) {
        if (amount <= 0) return false;
        if (from.equals(to)) return false;
        
        // Lock both players to prevent deadlock (always lock in UUID order)
        UUID first = from.compareTo(to) < 0 ? from : to;
        UUID second = from.compareTo(to) < 0 ? to : from;
        
        TransactionLock lock1 = getLock(first);
        TransactionLock lock2 = getLock(second);
        
        synchronized (lock1) {
            synchronized (lock2) {
                try {
                    PlayerData fromData = dataStore.loadPlayerData(from);
                    PlayerData toData = dataStore.loadPlayerData(to);
                    
                    if (fromData.getSouls() < amount) {
                        return false; // Insufficient funds
                    }
                    
                    long fromOldBalance = fromData.getSouls();
                    long toOldBalance = toData.getSouls();
                    
                    fromData.removeSouls(amount);
                    toData.addSouls(amount);
                    
                    long fromNewBalance = fromData.getSouls();
                    long toNewBalance = toData.getSouls();
                    
                    logTransaction(from, TransactionType.TRANSFER_OUT, amount, fromOldBalance, fromNewBalance, 
                                 "Transfer to " + to + ": " + reason);
                    logTransaction(to, TransactionType.TRANSFER_IN, amount, toOldBalance, toNewBalance, 
                                 "Transfer from " + from + ": " + reason);
                    
                    return true;
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Error transferring souls from " + from + " to " + to, e);
                    return false;
                }
            }
        }
    }
    
    /**
     * Set player balance (admin only, logs for audit)
     */
    public void setBalance(UUID playerId, long amount, String reason) {
        TransactionLock lock = getLock(playerId);
        synchronized (lock) {
            PlayerData data = dataStore.loadPlayerData(playerId);
            long oldBalance = data.getSouls();
            data.setSouls(amount);
            
            logTransaction(playerId, TransactionType.ADMIN_SET, amount, oldBalance, amount, reason);
        }
    }
    
    /**
     * Format souls amount for display
     */
    public String format(long amount) {
        if (amount >= 1_000_000_000) {
            return String.format("%.1fB", amount / 1_000_000_000.0);
        } else if (amount >= 1_000_000) {
            return String.format("%.1fM", amount / 1_000_000.0);
        } else if (amount >= 1_000) {
            return String.format("%.1fK", amount / 1_000.0);
        }
        return String.valueOf(amount);
    }
    
    /**
     * Get or create transaction lock for player
     */
    private TransactionLock getLock(UUID playerId) {
        return transactionLocks.computeIfAbsent(playerId, k -> new TransactionLock());
    }
    
    /**
     * Log transaction for audit trail
     */
    private void logTransaction(UUID playerId, TransactionType type, long amount, 
                                long oldBalance, long newBalance, String reason) {
        // In production, this would go to a database for audit
        plugin.getLogger().info(String.format(
            "ECONOMY: %s | Player: %s | Type: %s | Amount: %d | Old: %d | New: %d | Reason: %s",
            System.currentTimeMillis(), playerId, type, amount, oldBalance, newBalance, reason
        ));
    }
    
    /**
     * Transaction lock class
     */
    private static class TransactionLock {
        // Empty class used for synchronized locking
    }
    
    /**
     * Transaction types for logging
     */
    public enum TransactionType {
        DEPOSIT,
        WITHDRAW,
        TRANSFER_IN,
        TRANSFER_OUT,
        ADMIN_SET
    }
}
