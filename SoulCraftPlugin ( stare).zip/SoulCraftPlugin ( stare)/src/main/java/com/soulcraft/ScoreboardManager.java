// ScoreboardManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ScoreboardManager {
    private final SoulCraftPlugin plugin;

    public ScoreboardManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::updateScoreboards, 0L, 20L);
    }

    public void updateScoreboards() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateScoreboard(player);
        }
    }

    private void updateScoreboard(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("soulcraft", "dummy", "§6§lSOULCRAFT");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String date = sdf.format(new Date());

        String rank = plugin.getConfig().getString("players." + player.getUniqueId() + ".rank", "Gracz");
        String clan = plugin.getClanManager().getClan(player.getName());
        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId().toString());
        long playTime = player.getStatistic(Statistic.PLAY_ONE_MINUTE) / 1200; // minutes
        int online = Bukkit.getOnlinePlayers().size();
        int souls = plugin.getSoulManager().getSouls(player.getUniqueId().toString());
        int kills = plugin.getConfig().getInt("players." + player.getUniqueId() + ".kills", 0);
        int blackMatter = plugin.getEconomyManager().getBlackMatter(player.getUniqueId().toString());

        Score dateScore = obj.getScore("§7" + date);
        dateScore.setScore(10);
        Score nickScore = obj.getScore("§e👤 §f" + player.getName());
        nickScore.setScore(9);
        Score rankScore = obj.getScore("§a🏆 §f" + rank);
        rankScore.setScore(8);
        Score clanScore = obj.getScore("§b⚔ §f" + (clan != null ? clan : "Brak"));
        clanScore.setScore(7);
        Score balanceScore = obj.getScore("§6💰 §f" + balance);
        balanceScore.setScore(6);
        Score playTimeScore = obj.getScore("§9⏰ §f" + playTime + " min");
        playTimeScore.setScore(5);
        Score onlineScore = obj.getScore("§c👥 §f" + online);
        onlineScore.setScore(4);
        Score soulsScore = obj.getScore("§5✨ §f" + souls);
        soulsScore.setScore(3);
        Score killsScore = obj.getScore("§4☠ §f" + kills);
        killsScore.setScore(2);
        Score blackMatterScore = obj.getScore("§0🖤 §f" + blackMatter);
        blackMatterScore.setScore(1);

        player.setScoreboard(board);
    }
}
