package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.*;

public class WarpManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private final Set<UUID> activeMainPlayers = new HashSet<>();
    private final Set<UUID> activeSelectPlayers = new HashSet<>();
    private final Set<UUID> activeEditPlayers = new HashSet<>();
    private final Set<UUID> playersCreatingWarp = new HashSet<>();
    private final Map<UUID, TeleportData> teleportingPlayers = new HashMap<>();

    public WarpManager(SoulCraftPlugin plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
    }

    public void openMainWarpGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new MainWarpHolder(), 27, "§5§l✦ SYSTEM WARPÓW ✦");
        activeMainPlayers.add(player.getUniqueId());

        // Piękne wypełnienie - magiczny gradient
        ItemStack purpleFiller = createCustomItem(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆", Arrays.asList("§d✨ Magiczna energia..."));
        ItemStack blackFiller = createCustomItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◇", Arrays.asList("§8⚫ Mroczna moc..."));
        
        // Wzór wypełnienia - piękny gradient
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i >= 18) {
                gui.setItem(i, purpleFiller); // Górny i dolny rząd
            } else if (i % 9 == 0 || i % 9 == 8) {
                gui.setItem(i, blackFiller); // Boki
            } else {
                gui.setItem(i, purpleFiller); // Środek
            }
        }

        // WYBIERZ WARP - lewy przycisk
        ItemStack selectWarp = createCustomItem(Material.ENDER_PEARL, 
            "§a§l🌟 WYBIERZ WARP 🌟",
            Arrays.asList(
                "§7╭─────────────────────╮",
                "§7│ §fTeleportuj się do   §7│",
                "§7│ §austawionych warpów  §7│",
                "§7│ §eDostępne dla każdego §7│",
                "§7╰─────────────────────╯",
                "",
                "§a§l➤ KLIKNIJ ABY WYBRAĆ!"));
        gui.setItem(11, selectWarp);

        // Efekty wokół przycisku
        ItemStack greenFrame = createCustomItem(Material.LIME_STAINED_GLASS_PANE, "§a§l✦ §2Energia teleportacji §a§l✦", 
            Arrays.asList("§7Gotowy do podróży..."));
        gui.setItem(10, greenFrame);
        gui.setItem(12, greenFrame);
        gui.setItem(19, greenFrame);
        gui.setItem(20, greenFrame);

        // EDYTUJ WARP - prawy przycisk (tylko dla OP)
        if (player.hasPermission("soulcraft.op")) {
            ItemStack editWarp = createCustomItem(Material.COMMAND_BLOCK,
                "§c§l⚙️ EDYTUJ WARPY ⚙️",
                Arrays.asList(
                    "§7╭─────────────────────╮",
                    "§7│ §fZarządzaj warpami:  §7│",
                    "§7│ §e• Twórz nowe        §7│",
                    "§7│ §e• Edytuj istniejące §7│",
                    "§7│ §e• Usuń niepotrzebne §7│",
                    "§7╰─────────────────────╯",
                    "",
                    "§c§l⚠ TYLKO DLA ADMINISTRATORÓW",
                    "",
                    "§c§l➤ KLIKNIJ ABY ZARZĄDZAĆ!"));
            gui.setItem(15, editWarp);

            // Efekty wokół przycisku
            ItemStack redFrame = createCustomItem(Material.RED_STAINED_GLASS_PANE, "§c§l✦ §4Moc administratora §c§l✦",
                Arrays.asList("§7Kontrola nad przestrzenią..."));
            gui.setItem(14, redFrame);
            gui.setItem(16, redFrame);
            gui.setItem(23, redFrame);
            gui.setItem(24, redFrame);
        }

        player.openInventory(gui);
    }

    public void openSelectWarpGUI(Player player) {
        Map<String, WarpData> warps = loadWarps();
        int size = Math.max(27, ((warps.size() / 9) + 1) * 9);
        if (size > 54) size = 54;
        
        Inventory gui = Bukkit.createInventory(new SelectWarpHolder(), size, "§a§l🌟 WYBIERZ WARP 🌟");
        activeSelectPlayers.add(player.getUniqueId());

        // Wypełnienie
        ItemStack filler = createCustomItem(Material.CYAN_STAINED_GLASS_PANE, "§3§l◆", Arrays.asList("§b✨ Aura teleportacji..."));
        for (int i = 0; i < size; i++) {
            gui.setItem(i, filler);
        }

        // Warpy
        int slot = 0;
        for (Map.Entry<String, WarpData> entry : warps.entrySet()) {
            if (slot >= size - 9) break; // Zostaw miejsce na przyciski na dole
            
            WarpData warpData = entry.getValue();
            ItemStack warpItem = createCustomItem(Material.BEACON,
                "§e§l⚡ " + warpData.displayName + " ⚡",
                Arrays.asList(
                    "§7╭─────────────────────╮",
                    "§7│ §fŚwiat: §b" + warpData.world + " §7│",
                    "§7│ §fX: §a" + (int)warpData.x + " §7Z: §a" + (int)warpData.z + " §7│",
                    "§7│ §fY: §a" + (int)warpData.y + "               §7│",
                    "§7╰─────────────────────╯",
                    "",
                    "§6§lCooldown zależny od rangi:",
                    "§7• §5SoulGod: §a5 sekund",
                    "§7• §6SVIP: §a10 sekund", 
                    "§7• §eVIP: §a15 sekund",
                    "§7• §bGracz: §a20 sekund",
                    "",
                    "§a§l➤ KLIKNIJ ABY SIĘ TELEPORTOWAĆ!"));
            gui.setItem(slot++, warpItem);
        }

        // Przycisk powrotu
        ItemStack back = createCustomItem(Material.ARROW,
            "§e§l⬅ POWRÓT",
            Arrays.asList("§7Wróć do głównego menu"));
        gui.setItem(size - 5, back);

        // Przycisk zamknij
        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ",
            Arrays.asList("§7Zamknij menu"));
        gui.setItem(size - 1, close);

        player.openInventory(gui);
    }

    public void openEditWarpGUI(Player player) {
        Map<String, WarpData> warps = loadWarps();
        int size = Math.max(27, ((warps.size() / 9) + 2) * 9);
        if (size > 54) size = 54;
        
        Inventory gui = Bukkit.createInventory(new EditWarpHolder(), size, "§c§l⚙️ EDYTUJ WARPY ⚙️");
        activeEditPlayers.add(player.getUniqueId());

        // Wypełnienie
        ItemStack filler = createCustomItem(Material.ORANGE_STAINED_GLASS_PANE, "§6§l◆", Arrays.asList("§e⚙️ Panel administracyjny..."));
        for (int i = 0; i < size; i++) {
            gui.setItem(i, filler);
        }

        // Istniejące warpy
        int slot = 0;
        for (Map.Entry<String, WarpData> entry : warps.entrySet()) {
            if (slot >= size - 18) break; // Zostaw miejsce na przyciski
            
            WarpData warpData = entry.getValue();
            ItemStack warpItem = createCustomItem(Material.COMPASS,
                "§6§l📍 " + warpData.displayName + " 📍",
                Arrays.asList(
                    "§7╭─────────────────────╮",
                    "§7│ §fID: §e" + entry.getKey() + " §7│",
                    "§7│ §fŚwiat: §b" + warpData.world + " §7│", 
                    "§7│ §fLokalizacja:        §7│",
                    "§7│ §a  X: " + (int)warpData.x + " Y: " + (int)warpData.y + " Z: " + (int)warpData.z + " §7│",
                    "§7╰─────────────────────╯",
                    "",
                    "§e§l⚠ OPCJE EDYCJI:",
                    "§7• §aLPM: Teleportuj się tutaj",
                    "§7• §cPPM: Usuń ten warp",
                    "§7• §eMiddle: Zmień lokalizację"));
            gui.setItem(slot++, warpItem);
        }

        // PRZYCISK TWORZENIA NOWEGO WARPU
        ItemStack createNew = createCustomItem(Material.NETHER_STAR,
            "§a§l✨ STWÓRZ NOWY WARP ✨",
            Arrays.asList(
                "§7╭─────────────────────╮",
                "§7│ §fUtwórz nowy punkt   §7│",
                "§7│ §ateleportacji w tym  §7│",
                "§7│ §amiejscu gdzie stoisz §7│",
                "§7╰─────────────────────╯",
                "",
                "§a§l➤ KLIKNIJ ABY UTWORZYĆ!"));
        gui.setItem(size - 14, createNew);

        // Efekty wokół przycisku
        ItemStack sparkle = createCustomItem(Material.GLOWSTONE_DUST, "§e§l✦ §6Iskra tworzenia §e§l✦",
            Arrays.asList("§7Nowa magia w powietrzu..."));
        gui.setItem(size - 15, sparkle);
        gui.setItem(size - 13, sparkle);
        gui.setItem(size - 23, sparkle);
        gui.setItem(size - 5, sparkle);

        // Przycisk powrotu  
        ItemStack back = createCustomItem(Material.ARROW,
            "§e§l⬅ POWRÓT", 
            Arrays.asList("§7Wróć do głównego menu"));
        gui.setItem(size - 9, back);

        // Przycisk zamknij
        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ",
            Arrays.asList("§7Zamknij menu"));
        gui.setItem(size - 1, close);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        
        if (holder instanceof MainWarpHolder) {
            handleMainWarpClick(event, player);
        } else if (holder instanceof SelectWarpHolder) {
            handleSelectWarpClick(event, player);
        } else if (holder instanceof EditWarpHolder) {
            handleEditWarpClick(event, player);
        }
    }

    private void handleMainWarpClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (raw == 11) { // Wybierz warp
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openSelectWarpGUI(player), 1L);
        } else if (raw == 15 && player.hasPermission("soulcraft.op")) { // Edytuj warp
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openEditWarpGUI(player), 1L);
        }
    }

    private void handleSelectWarpClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        // Przycisk powrotu
        if (clicked.getType() == Material.ARROW) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openMainWarpGUI(player), 1L);
            return;
        }

        // Przycisk zamknij
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeSelectPlayers.remove(player.getUniqueId());
            return;
        }

        // Teleportacja do warpu
        if (clicked.getType() == Material.BEACON) {
            String warpName = extractWarpName(clicked);
            if (warpName != null) {
                teleportToWarp(player, warpName);
            }
        }
    }

    private void handleEditWarpClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        // Stwórz nowy warp
        if (clicked.getType() == Material.NETHER_STAR) {
            startWarpCreation(player);
            return;
        }

        // Przycisk powrotu
        if (clicked.getType() == Material.ARROW) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openMainWarpGUI(player), 1L);
            return;
        }

        // Przycisk zamknij
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeEditPlayers.remove(player.getUniqueId());
            return;
        }

        // Obsługa istniejących warpów
        if (clicked.getType() == Material.COMPASS) {
            String warpName = extractWarpNameFromEdit(clicked);
            if (warpName != null) {
                if (event.isLeftClick()) {
                    // Teleportuj do warpu
                    teleportToWarp(player, warpName);
                } else if (event.isRightClick()) {
                    // Usuń warp
                    deleteWarp(player, warpName);
                } else if (event.getClick().name().contains("MIDDLE")) {
                    // Zmień lokalizację
                    updateWarpLocation(player, warpName);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof MainWarpHolder || holder instanceof SelectWarpHolder || holder instanceof EditWarpHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getView().getTopInventory().getSize()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof MainWarpHolder) {
            activeMainPlayers.remove(player.getUniqueId());
        } else if (holder instanceof SelectWarpHolder) {
            activeSelectPlayers.remove(player.getUniqueId());
        } else if (holder instanceof EditWarpHolder) {
            activeEditPlayers.remove(player.getUniqueId());
        }
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!playersCreatingWarp.contains(player.getUniqueId())) return;
        
        event.setCancelled(true);
        playersCreatingWarp.remove(player.getUniqueId());
        
        String warpName = event.getMessage().trim();
        
        // Walidacja nazwy
        if (warpName.length() < 2 || warpName.length() > 20) {
            player.sendMessage("§c§l❌ Nazwa warpu musi mieć od 2 do 20 znaków!");
            return;
        }
        
        if (!warpName.matches("[a-zA-Z0-9_]+")) {
            player.sendMessage("§c§l❌ Nazwa może zawierać tylko litery, cyfry i podkreślniki!");
            return;
        }
        
        // Sprawdź czy warp już istnieje
        if (plugin.getConfig().contains("warps." + warpName.toLowerCase())) {
            player.sendMessage("§c§l❌ Warp o tej nazwie już istnieje!");
            return;
        }
        
        // Stwórz warp
        Bukkit.getScheduler().runTask(plugin, () -> {
            Location loc = player.getLocation();
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".displayName", warpName);
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".world", loc.getWorld().getName());
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".x", loc.getX());
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".y", loc.getY());
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".z", loc.getZ());
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".yaw", loc.getYaw());
            plugin.getConfig().set("warps." + warpName.toLowerCase() + ".pitch", loc.getPitch());
            plugin.saveConfig();
            
            player.sendMessage("§a§l✅ ═══════════════════════════════ ✅");
            player.sendMessage("§a§l    🌟 WARP UTWORZONY POMYŚLNIE! 🌟");
            player.sendMessage("§f    Nazwa: §e" + warpName);
            player.sendMessage("§f    Lokalizacja: §a" + (int)loc.getX() + ", " + (int)loc.getY() + ", " + (int)loc.getZ());
            player.sendMessage("§a§l✅ ═══════════════════════════════ ✅");
        });
    }

    private void startWarpCreation(Player player) {
        playersCreatingWarp.add(player.getUniqueId());
        player.closeInventory();
        player.sendMessage("§6§l✨ ═══════════════════════════════ ✨");
        player.sendMessage("§e§l    📝 TWORZENIE NOWEGO WARPU 📝");
        player.sendMessage("§f    Wpisz nazwę warpu na chacie:");
        player.sendMessage("§7    • Od 2 do 20 znaków");
        player.sendMessage("§7    • Tylko litery, cyfry i _");
        player.sendMessage("§7    • Lokalizacja: gdzie teraz stoisz");
        player.sendMessage("§6§l✨ ═══════════════════════════════ ✨");
    }

    private void teleportToWarp(Player player, String warpName) {
        if (teleportingPlayers.containsKey(player.getUniqueId())) {
            player.sendMessage("§c§l⚠ Już się teleportujesz!");
            return;
        }

        WarpData warpData = loadWarps().get(warpName);
        if (warpData == null) {
            player.sendMessage("§c§l❌ Warp nie istnieje!");
            return;
        }

        World world = Bukkit.getWorld(warpData.world);
        if (world == null) {
            player.sendMessage("§c§l❌ Świat warpu nie istnieje!");
            return;
        }

        Location destination = new Location(world, warpData.x, warpData.y, warpData.z, warpData.yaw, warpData.pitch);
        startTeleport(player, destination, warpData.displayName);
        
        player.closeInventory();
        activeSelectPlayers.remove(player.getUniqueId());
    }

    private void startTeleport(Player player, Location destination, String warpName) {
        String rank = rankManager.getRank(player);
        int delayTicks;
        
        switch (rank) {
            case "soulgod": delayTicks = 5 * 20; break;
            case "svip": delayTicks = 10 * 20; break;
            case "vip": delayTicks = 15 * 20; break;
            default: delayTicks = 20 * 20; break;
        }

        TeleportData data = new TeleportData(delayTicks, player.getLocation());
        teleportingPlayers.put(player.getUniqueId(), data);

        new BukkitRunnable() {
            int timeLeft = delayTicks / 20;

            @Override
            public void run() {
                if (!teleportingPlayers.containsKey(player.getUniqueId())) {
                    this.cancel();
                    return;
                }

                if (!player.getLocation().equals(data.initialLocation)) {
                    player.sendMessage("§c§l⚠ Ruszanie się anuluje teleportację!");
                    teleportingPlayers.remove(player.getUniqueId());
                    this.cancel();
                    return;
                }

                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacyText(ChatColor.GOLD + "✦ Teleportacja do " + warpName + " za " + timeLeft + " sekund... ✦"));
                timeLeft--;

                if (timeLeft < 0) {
                    player.teleport(destination);
                    player.sendMessage("§a§l✅ Pomyślnie przeteleportowano do warpu: §e" + warpName + "§a!");
                    teleportingPlayers.remove(player.getUniqueId());
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void deleteWarp(Player player, String warpName) {
        plugin.getConfig().set("warps." + warpName, null);
        plugin.saveConfig();
        
        player.sendMessage("§c§l🗑️ Usunięto warp: §f" + warpName);
        
        // Odśwież GUI
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, () -> openEditWarpGUI(player), 1L);
    }

    private void updateWarpLocation(Player player, String warpName) {
        Location loc = player.getLocation();
        plugin.getConfig().set("warps." + warpName + ".world", loc.getWorld().getName());
        plugin.getConfig().set("warps." + warpName + ".x", loc.getX());
        plugin.getConfig().set("warps." + warpName + ".y", loc.getY());
        plugin.getConfig().set("warps." + warpName + ".z", loc.getZ());
        plugin.getConfig().set("warps." + warpName + ".yaw", loc.getYaw());
        plugin.getConfig().set("warps." + warpName + ".pitch", loc.getPitch());
        plugin.saveConfig();
        
        player.sendMessage("§a§l📍 Zaktualizowano lokalizację warpu: §e" + warpName);
        
        // Odśwież GUI
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, () -> openEditWarpGUI(player), 1L);
    }

    private Map<String, WarpData> loadWarps() {
        Map<String, WarpData> warps = new LinkedHashMap<>();
        if (!plugin.getConfig().contains("warps")) return warps;
        
        for (String key : plugin.getConfig().getConfigurationSection("warps").getKeys(false)) {
            String displayName = plugin.getConfig().getString("warps." + key + ".displayName", key);
            String world = plugin.getConfig().getString("warps." + key + ".world", "world");
            double x = plugin.getConfig().getDouble("warps." + key + ".x", 0);
            double y = plugin.getConfig().getDouble("warps." + key + ".y", 100);
            double z = plugin.getConfig().getDouble("warps." + key + ".z", 0);
            float yaw = (float) plugin.getConfig().getDouble("warps." + key + ".yaw", 0);
            float pitch = (float) plugin.getConfig().getDouble("warps." + key + ".pitch", 0);
            
            warps.put(key, new WarpData(displayName, world, x, y, z, yaw, pitch));
        }
        
        return warps;
    }

    private String extractWarpName(ItemStack item) {
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return null;
        String displayName = item.getItemMeta().getDisplayName();
        // Extract from "§e§l⚡ NAME ⚡"
        displayName = ChatColor.stripColor(displayName).replace("⚡", "").trim();
        
        // Find matching warp by display name
        for (Map.Entry<String, WarpData> entry : loadWarps().entrySet()) {
            if (entry.getValue().displayName.equals(displayName)) {
                return entry.getKey();
            }
        }
        return null;
    }

    private String extractWarpNameFromEdit(ItemStack item) {
        if (!item.hasItemMeta() || !item.getItemMeta().hasLore()) return null;
        List<String> lore = item.getItemMeta().getLore();
        for (String line : lore) {
            if (line.contains("§fID: §e")) {
                return ChatColor.stripColor(line).replace("ID: ", "").trim();
            }
        }
        return null;
    }

    private ItemStack createCustomItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public void cancelTeleport(Player player) {
        teleportingPlayers.remove(player.getUniqueId());
    }

    private static class WarpData {
        final String displayName;
        final String world;
        final double x, y, z;
        final float yaw, pitch;

        WarpData(String displayName, String world, double x, double y, double z, float yaw, float pitch) {
            this.displayName = displayName;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    private static class TeleportData {
        int delayTicks;
        Location initialLocation;

        TeleportData(int delayTicks, Location initialLocation) {
            this.delayTicks = delayTicks;
            this.initialLocation = initialLocation;
        }
    }

    // Inventory Holders
    private static class MainWarpHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    private static class SelectWarpHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    private static class EditWarpHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}