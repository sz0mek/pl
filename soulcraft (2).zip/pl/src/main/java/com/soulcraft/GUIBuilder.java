package com.soulcraft.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GUIBuilder {
    private final Inventory inventory;
    private final int size;

    private GUIBuilder(String title, int rows, InventoryHolder holder) {
        this.size = rows * 9;
        this.inventory = Bukkit.createInventory(holder, size, title);
    }

    public static GUIBuilder create(String title, int rows) {
        return new GUIBuilder(title, rows, null);
    }

    public static GUIBuilder create(String title, int rows, InventoryHolder holder) {
        return new GUIBuilder(title, rows, holder);
    }

    public GUIBuilder fillBorder(Material material, String displayName) {
        ItemStack border = createItem(material, displayName);
        
        for (int i = 0; i < 9; i++) {
            inventory.setItem(i, border);
            inventory.setItem(size - 9 + i, border);
        }
        
        for (int i = 1; i < (size / 9) - 1; i++) {
            inventory.setItem(i * 9, border);
            inventory.setItem(i * 9 + 8, border);
        }
        
        return this;
    }

    public GUIBuilder fillAll(Material material, String displayName) {
        ItemStack filler = createItem(material, displayName);
        for (int i = 0; i < size; i++) {
            inventory.setItem(i, filler);
        }
        return this;
    }

    public GUIBuilder fillRow(int row, Material material, String displayName) {
        ItemStack filler = createItem(material, displayName);
        int start = row * 9;
        for (int i = start; i < start + 9; i++) {
            if (i < size) {
                inventory.setItem(i, filler);
            }
        }
        return this;
    }

    public GUIBuilder setItem(int slot, Material material, String displayName, List<String> lore) {
        ItemStack item = createItem(material, displayName, lore);
        inventory.setItem(slot, item);
        return this;
    }

    public GUIBuilder setItem(int slot, ItemStack item) {
        inventory.setItem(slot, item);
        return this;
    }

    public GUIBuilder addGlowingEffect(int slot) {
        ItemStack item = inventory.getItem(slot);
        if (item != null) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.addEnchant(Enchantment.UNBREAKING, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                item.setItemMeta(meta);
            }
        }
        return this;
    }

    public GUIBuilder setBackButton(Material material, String displayName, List<String> lore) {
        ItemStack back = createItem(material, displayName, lore);
        inventory.setItem(size - 5, back);
        return this;
    }

    public GUIBuilder setCloseButton(Material material, String displayName, List<String> lore) {
        ItemStack close = createItem(material, displayName, lore);
        inventory.setItem(size - 1, close);
        return this;
    }

    public GUIBuilder createBeautifulPattern() {
        Material[] purpleGradient = {
            Material.PURPLE_STAINED_GLASS_PANE,
            Material.MAGENTA_STAINED_GLASS_PANE,
            Material.PINK_STAINED_GLASS_PANE
        };
        
        for (int i = 0; i < size; i++) {
            int row = i / 9;
            int col = i % 9;
            
            if (row == 0 || row == (size / 9) - 1) {
                inventory.setItem(i, createItem(purpleGradient[col % 3], "§5§l◆"));
            } else if (col == 0 || col == 8) {
                inventory.setItem(i, createItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◇"));
            }
        }
        
        return this;
    }

    public Inventory build() {
        return inventory;
    }

    public static ItemStack createItem(Material material, String displayName) {
        return createItem(material, displayName, new ArrayList<>());
    }

    public static ItemStack createItem(Material material, String displayName, String... lore) {
        return createItem(material, displayName, Arrays.asList(lore));
    }

    public static ItemStack createItem(Material material, String displayName, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            if (displayName != null && !displayName.isEmpty()) {
                meta.setDisplayName(displayName);
            }
            if (lore != null && !lore.isEmpty()) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        
        return item;
    }

    public static ItemStack createGlowingItem(Material material, String displayName, List<String> lore) {
        ItemStack item = createItem(material, displayName, lore);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static List<String> createPolishBox(String... lines) {
        List<String> box = new ArrayList<>();
        int maxLength = 0;
        for (String line : lines) {
            maxLength = Math.max(maxLength, line.length());
        }
        
        box.add("§7╭" + "─".repeat(maxLength + 2) + "╮");
        for (String line : lines) {
            int padding = maxLength - line.length();
            box.add("§7│ " + line + " ".repeat(padding) + " §7│");
        }
        box.add("§7╰" + "─".repeat(maxLength + 2) + "╯");
        
        return box;
    }
}
