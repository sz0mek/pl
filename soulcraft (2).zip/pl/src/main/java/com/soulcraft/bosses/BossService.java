package com.soulcraft.bosses;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.missions.MissionService;
import com.soulcraft.achievements.AchievementManager;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Complete boss system with AI, behavior trees, and multi-phase mechanics
 */
public class BossService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MissionService missionService;
    private final AchievementManager achievementManager;
    
    private final Map<String, BossConfig> bossConfigs;
    private final Map<UUID, BossInstance> activeBosses;  // entity UUID -> boss instance
    private final Map<String, Long> lastSpawnTimes;  // boss ID -> last spawn time
    private final Map<UUID, Long> lastAbilityUse;  // boss UUID -> last ability timestamp
    private final int ARENA_RADIUS = 50;  // Arena boundary radius
    
    public BossService(Plugin plugin, DataStore dataStore, EconomyService economyService, MissionService missionService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionService = missionService;
        this.achievementManager = null; // Will be initialized later if needed
        this.bossConfigs = new HashMap<>();
        this.activeBosses = new HashMap<>();
        this.lastSpawnTimes = new HashMap<>();
        this.lastAbilityUse = new HashMap<>();
        
        loadBossConfigs();
        startBossAI();
        startArenaEnforcement();
        startAntiCheeseSystem();
    }
    
    private void loadBossConfigs() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load all 5 bosses
        String[] bossIds = {"soul_eater", "void_titan", "chaos_knight", "phantom_lord", "dark_emperor"};
        
        for (String bossId : bossIds) {
            String path = "bosses." + bossId;
            BossConfig config = new BossConfig();
            
            config.id = bossId;
            config.name = balance.getString(path + ".name");
            config.health = balance.getDouble(path + ".health");
            config.damage = balance.getDouble(path + ".damage");
            config.defense = balance.getDouble(path + ".defense");
            config.speed = balance.getDouble(path + ".speed");
            config.soulReward = balance.getLong(path + ".soul_reward");
            config.spawnCooldown = balance.getInt(path + ".spawn_cooldown");
            
            // Load phases
            ConfigurationSection phasesSection = balance.getConfigurationSection(path + ".phases");
            if (phasesSection != null) {
                for (String phaseKey : phasesSection.getKeys(false)) {
                    BossPhase phase = new BossPhase();
                    String phasePath = path + ".phases." + phaseKey;
                    
                    phase.abilities = balance.getStringList(phasePath + ".abilities");
                    phase.aggroRange = balance.getInt(phasePath + ".aggro_range");
                    phase.damageMultiplier = balance.getDouble(phasePath + ".damage_multiplier", 1.0);
                    
                    config.phases.add(phase);
                }
            }
            
            // Load drops
            ConfigurationSection dropsSection = balance.getConfigurationSection(path + ".special_drops");
            if (dropsSection != null) {
                for (String key : dropsSection.getKeys(false)) {
                    BossDrop drop = new BossDrop();
                    drop.item = balance.getString(path + ".special_drops." + key + ".item");
                    drop.chance = balance.getDouble(path + ".special_drops." + key + ".chance");
                    config.drops.add(drop);
                }
            }
            
            bossConfigs.put(bossId, config);
        }
    }
    
    /**
     * Spawn boss at location
     */
    public LivingEntity spawnBoss(String bossId, Location location) {
        BossConfig config = bossConfigs.get(bossId);
        if (config == null) return null;
        
        // Check cooldown
        Long lastSpawn = lastSpawnTimes.get(bossId);
        if (lastSpawn != null) {
            long timeSince = (System.currentTimeMillis() - lastSpawn) / 1000;
            if (timeSince < config.spawnCooldown) {
                return null;  // Still on cooldown
            }
        }
        
        // Spawn entity based on boss type
        LivingEntity entity = spawnBossEntity(bossId, location);
        if (entity == null) return null;
        
        // Configure entity
        entity.setCustomName("§c§l✦ " + config.name + " ✦");
        entity.setCustomNameVisible(true);
        entity.setRemoveWhenFarAway(false);
        
        // Set stats
        if (entity.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(config.health);
            entity.setHealth(config.health);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(config.damage);
        }
        
        if (entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(config.speed * 0.1);
        }
        
        // Create boss instance
        BossInstance instance = new BossInstance();
        instance.bossId = bossId;
        instance.config = config;
        instance.entity = entity;
        instance.currentPhase = 0;
        instance.spawnTime = System.currentTimeMillis();
        instance.participants = new HashSet<>();
        instance.arenaCenter = location.clone();
        instance.lastAbilityTick = 0;
        
        // Create boss bar
        BossBar bossBar = Bukkit.createBossBar(
            "§c§l" + config.name,
            getBarColor(bossId),
            BarStyle.SEGMENTED_10
        );
        bossBar.setProgress(1.0);
        instance.bossBar = bossBar;
        
        // Add nearby players to boss bar
        for (Entity e : entity.getNearbyEntities(100, 100, 100)) {
            if (e instanceof Player) {
                bossBar.addPlayer((Player) e);
            }
        }
        
        activeBosses.put(entity.getUniqueId(), instance);
        lastSpawnTimes.put(bossId, System.currentTimeMillis());
        
        // Announce spawn with title
        String coords = location.getBlockX() + ", " + location.getBlockY() + ", " + location.getBlockZ();
        Bukkit.broadcastMessage("§c§l§m━━━━━━━━━━━━━━━━━━━━━");
        Bukkit.broadcastMessage("§c§l⚠ BOSS SPAWN: " + config.name + " §c§l⚠");
        Bukkit.broadcastMessage("§7Location: §e" + coords);
        Bukkit.broadcastMessage("§c§l§m━━━━━━━━━━━━━━━━━━━━━");
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle("§c§lBOSS SPAWN!", "§e" + config.name, 10, 70, 20);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.8f);
        }
        
        // Spawn effects
        spawnBossEffects(location, bossId);
        
        return entity;
    }
    
    /**
     * Spawn actual boss entity
     */
    private LivingEntity spawnBossEntity(String bossId, Location location) {
        switch (bossId) {
            case "soul_eater":
                return location.getWorld().spawn(location, Wither.class);
            case "void_titan":
                return location.getWorld().spawn(location, IronGolem.class);
            case "chaos_knight":
                Zombie knight = location.getWorld().spawn(location, Zombie.class);
                knight.setAdult();
                knight.getEquipment().setHelmet(new org.bukkit.inventory.ItemStack(Material.NETHERITE_HELMET));
                knight.getEquipment().setChestplate(new org.bukkit.inventory.ItemStack(Material.NETHERITE_CHESTPLATE));
                return knight;
            case "phantom_lord":
                return location.getWorld().spawn(location, Phantom.class);
            case "dark_emperor":
                return location.getWorld().spawn(location, WitherSkeleton.class);
            default:
                return null;
        }
    }
    
    /**
     * Handle boss death
     */
    public void handleBossDeath(UUID entityId, Player killer) {
        BossInstance instance = activeBosses.remove(entityId);
        if (instance == null) return;
        
        BossConfig config = instance.config;
        Location deathLoc = instance.entity.getLocation();
        
        // Remove boss bar
        if (instance.bossBar != null) {
            instance.bossBar.removeAll();
            instance.bossBar.setVisible(false);
        }
        
        // Announce death with title
        Bukkit.broadcastMessage("§a§l§m━━━━━━━━━━━━━━━━━━━━━");
        Bukkit.broadcastMessage("§a§l✓ " + config.name + " DEFEATED! §a§l✓");
        Bukkit.broadcastMessage("§7Slain by: §e§l" + killer.getName());
        Bukkit.broadcastMessage("§a§l§m━━━━━━━━━━━━━━━━━━━━━");
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle("§a§lVICTORY!", config.name + " §edefeated!", 10, 70, 20);
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        }
        
        // Distribute rewards to all participants
        long combatTime = (System.currentTimeMillis() - instance.spawnTime) / 1000;
        for (UUID participantId : instance.participants) {
            Player participant = Bukkit.getPlayer(participantId);
            if (participant != null) {
                // Give souls with bonus for main killer
                long souls = config.soulReward;
                if (participant.equals(killer)) {
                    souls = (long)(souls * 1.5); // 50% bonus for killer
                }
                economyService.deposit(participant, souls, "Boss kill: " + config.name);
                
                // Progress mission
                missionService.progressMission(participantId, MissionService.MissionType.KILL_BOSSES, 1);
                
                // Grant achievement (if achievement manager is available)
                if (achievementManager != null) {
                    achievementManager.unlockAchievement(participant, "boss_" + config.id);
                }
                
                // Drop special loot
                for (BossDrop drop : config.drops) {
                    if (Math.random() < drop.chance) {
                        participant.sendMessage("§6§l★ Rare Drop: §e" + drop.item + " §6§l★");
                        participant.playSound(participant.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
                    }
                }
                
                participant.sendMessage("§6§l+§e" + souls + " souls §7(Boss: " + config.name + ")");
                participant.sendMessage("§7Combat Time: §e" + combatTime + "s");
            }
        }
        
        // Epic death effects
        for (int i = 0; i < 5; i++) {
            final int iteration = i;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                deathLoc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, deathLoc, 3, 2, 2, 2);
                deathLoc.getWorld().spawnParticle(Particle.FIREWORK, deathLoc, 50, 3, 3, 3, 0.1);
                deathLoc.getWorld().playSound(deathLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f + iteration * 0.1f);
            }, i * 10L);
        }
        
        // Cleanup
        lastAbilityUse.remove(entityId);
    }
    
    /**
     * Add participant to boss fight
     */
    public void addParticipant(UUID entityId, Player player) {
        BossInstance instance = activeBosses.get(entityId);
        if (instance != null) {
            instance.participants.add(player.getUniqueId());
        }
    }
    
    /**
     * Get boss instance
     */
    public BossInstance getBossInstance(UUID entityId) {
        return activeBosses.get(entityId);
    }
    
    /**
     * Check if entity is a boss
     */
    public boolean isBoss(UUID entityId) {
        return activeBosses.containsKey(entityId);
    }
    
    /**
     * Get boss config by ID (stub for command compatibility)
     */
    public BossConfig getBoss(String bossId) {
        return bossConfigs.get(bossId);
    }
    
    /**
     * Boss AI task
     */
    private void startBossAI() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (BossInstance instance : new ArrayList<>(activeBosses.values())) {
                if (instance.entity == null || instance.entity.isDead()) {
                    if (instance.bossBar != null) {
                        instance.bossBar.removeAll();
                    }
                    activeBosses.remove(instance.entity.getUniqueId());
                    continue;
                }
                
                // Update boss bar
                updateBossBar(instance);
                
                // Update phase
                updateBossPhase(instance);
                
                // Execute abilities
                executeBossAbilities(instance);
                
                // Environmental effects
                spawnEnvironmentalEffects(instance);
                
                // Increment ability tick
                instance.lastAbilityTick++;
            }
        }, 20L, 20L); // Run every second
    }
    
    /**
     * Arena enforcement - keep players and boss within arena
     */
    private void startArenaEnforcement() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (BossInstance instance : activeBosses.values()) {
                if (instance.entity == null || instance.entity.isDead()) continue;
                
                Location center = instance.arenaCenter;
                
                // Keep boss in arena
                if (instance.entity.getLocation().distance(center) > ARENA_RADIUS) {
                    Vector direction = center.toVector().subtract(instance.entity.getLocation().toVector()).normalize();
                    instance.entity.setVelocity(direction.multiply(2));
                }
                
                // Keep players in arena (with barrier effect)
                for (UUID participantId : instance.participants) {
                    Player player = Bukkit.getPlayer(participantId);
                    if (player != null && player.getLocation().distance(center) > ARENA_RADIUS) {
                        Vector direction = center.toVector().subtract(player.getLocation().toVector()).normalize();
                        player.setVelocity(direction.multiply(1.5).setY(0.5));
                        player.sendMessage("§c§l⚠ You cannot escape the boss arena!");
                        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 2.0f);
                        player.getWorld().spawnParticle(Particle.BLOCK, player.getLocation(), 10, 1, 1, 1, Material.BARRIER.createBlockData());
                    }
                }
            }
        }, 10L, 10L); // Run every 0.5 seconds
    }
    
    /**
     * Anti-cheese system - prevent exploits
     */
    private void startAntiCheeseSystem() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (BossInstance instance : activeBosses.values()) {
                if (instance.entity == null || instance.entity.isDead()) continue;
                
                for (UUID participantId : new HashSet<>(instance.participants)) {
                    Player player = Bukkit.getPlayer(participantId);
                    if (player == null) continue;
                    
                    double distance = player.getLocation().distance(instance.entity.getLocation());
                    
                    // Prevent flying/elytra cheese
                    if (player.isGliding() || (player.isFlying() && player.getGameMode() != GameMode.CREATIVE)) {
                        player.setGliding(false);
                        player.setAllowFlight(false);
                        player.setFlying(false);
                        player.sendMessage("§c§l⚠ Flight is disabled in boss fights!");
                        player.damage(5.0);
                    }
                    
                    // Prevent towering cheese (too high above boss)
                    if (player.getLocation().getY() - instance.entity.getLocation().getY() > 10) {
                        player.damage(10.0);
                        player.sendMessage("§c§l⚠ Stop towering! Fight the boss properly!");
                        player.getWorld().spawnParticle(Particle.LAVA, player.getLocation(), 20);
                    }
                    
                    // Prevent camping (too far)
                    if (distance > ARENA_RADIUS * 0.8) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                        player.sendMessage("§c§l⚠ Get closer to the boss!");
                    }
                }
            }
        }, 40L, 40L); // Run every 2 seconds
    }
    
    /**
     * Update boss bar
     */
    private void updateBossBar(BossInstance instance) {
        if (instance.bossBar == null) return;
        
        double healthPercent = instance.entity.getHealth() / 
            instance.entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        instance.bossBar.setProgress(Math.max(0, Math.min(1, healthPercent)));
        
        // Update color based on phase
        instance.bossBar.setColor(getBarColorByHealth(healthPercent));
        
        // Add nearby players
        for (Entity e : instance.entity.getNearbyEntities(100, 100, 100)) {
            if (e instanceof Player && !instance.bossBar.getPlayers().contains(e)) {
                instance.bossBar.addPlayer((Player) e);
            }
        }
        
        // Remove far players
        for (Player p : new ArrayList<>(instance.bossBar.getPlayers())) {
            if (p.getLocation().distance(instance.entity.getLocation()) > 100) {
                instance.bossBar.removePlayer(p);
            }
        }
    }
    
    /**
     * Get boss bar color by ID
     */
    private BarColor getBarColor(String bossId) {
        switch (bossId) {
            case "soul_eater": return BarColor.PURPLE;
            case "void_titan": return BarColor.BLUE;
            case "chaos_knight": return BarColor.RED;
            case "phantom_lord": return BarColor.WHITE;
            case "dark_emperor": return BarColor.PINK;
            default: return BarColor.RED;
        }
    }
    
    /**
     * Get boss bar color by health
     */
    private BarColor getBarColorByHealth(double healthPercent) {
        if (healthPercent > 0.75) return BarColor.GREEN;
        if (healthPercent > 0.50) return BarColor.YELLOW;
        if (healthPercent > 0.25) return BarColor.RED;
        return BarColor.PURPLE; // Enrage
    }
    
    /**
     * Spawn boss-specific effects on spawn
     */
    private void spawnBossEffects(Location location, String bossId) {
        World world = location.getWorld();
        
        switch (bossId) {
            case "soul_eater":
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, location, 200, 3, 3, 3, 0.1);
                world.spawnParticle(Particle.SOUL, location, 100, 2, 2, 2, 0.05);
                break;
            case "void_titan":
                world.spawnParticle(Particle.PORTAL, location, 300, 4, 4, 4, 1.0);
                world.spawnParticle(Particle.REVERSE_PORTAL, location, 100, 2, 2, 2);
                break;
            case "chaos_knight":
                world.spawnParticle(Particle.FLAME, location, 200, 3, 3, 3, 0.1);
                world.spawnParticle(Particle.LAVA, location, 50, 2, 2, 2);
                break;
            case "phantom_lord":
                world.spawnParticle(Particle.CLOUD, location, 250, 4, 4, 4, 0.1);
                world.spawnParticle(Particle.ENCHANT, location, 100, 2, 2, 2);
                break;
            case "dark_emperor":
                world.spawnParticle(Particle.EXPLOSION, location, 100, 5, 5, 5);
                world.spawnParticle(Particle.SMOKE, location, 200, 3, 3, 3, 0.1);
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, location, 150, 4, 4, 4, 0.1);
                break;
        }
    }
    
    /**
     * Spawn environmental effects for each boss
     */
    private void spawnEnvironmentalEffects(BossInstance instance) {
        if (instance.lastAbilityTick % 3 != 0) return; // Every 3 seconds
        
        Location loc = instance.entity.getLocation();
        World world = loc.getWorld();
        
        switch (instance.bossId) {
            case "soul_eater":
                world.spawnParticle(Particle.SOUL, loc.clone().add(0, 1, 0), 10, 1, 1, 1, 0.02);
                break;
            case "void_titan":
                world.spawnParticle(Particle.PORTAL, loc.clone().add(0, 2, 0), 15, 1.5, 1.5, 1.5, 0.5);
                break;
            case "chaos_knight":
                world.spawnParticle(Particle.FLAME, loc.clone().add(0, 1, 0), 12, 0.8, 0.8, 0.8);
                break;
            case "phantom_lord":
                world.spawnParticle(Particle.CLOUD, loc.clone().add(0, 1.5, 0), 8, 0.5, 0.5, 0.5, 0.01);
                break;
            case "dark_emperor":
                world.spawnParticle(Particle.SMOKE, loc.clone().add(0, 2, 0), 20, 2, 2, 2, 0.05);
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(0, 1, 0), 10, 1, 1, 1, 0.01);
                break;
        }
    }
    
    /**
     * Update boss phase based on health
     */
    private void updateBossPhase(BossInstance instance) {
        double healthPercent = instance.entity.getHealth() / instance.entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        
        int newPhase = 0;
        if (healthPercent <= 0.25) {
            newPhase = Math.min(3, instance.config.phases.size() - 1);
        } else if (healthPercent <= 0.50) {
            newPhase = Math.min(2, instance.config.phases.size() - 1);
        } else if (healthPercent <= 0.75) {
            newPhase = Math.min(1, instance.config.phases.size() - 1);
        }
        
        if (newPhase != instance.currentPhase) {
            instance.currentPhase = newPhase;
            
            // Announce phase change
            BossPhase phase = instance.config.phases.get(newPhase);
            Bukkit.broadcastMessage("§c§l⚠ " + instance.config.name + " enters Phase " + (newPhase + 1) + "!");
            
            // Visual effects
            Location loc = instance.entity.getLocation();
            loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 10);
            loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.8f);
            
            // Apply phase damage multiplier
            if (phase.damageMultiplier > 1.0) {
                double newDamage = instance.config.damage * phase.damageMultiplier;
                instance.entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(newDamage);
            }
        }
    }
    
    /**
     * Execute boss abilities
     */
    private void executeBossAbilities(BossInstance instance) {
        BossPhase phase = instance.config.phases.get(instance.currentPhase);
        
        // Execute random ability
        if (!phase.abilities.isEmpty() && Math.random() < 0.3) {  // 30% chance per second
            String ability = phase.abilities.get(new Random().nextInt(phase.abilities.size()));
            executeBossAbility(instance, ability);
        }
        
        // Find and attack nearby players
        if (instance.entity instanceof Creature) {
            Creature creature = (Creature) instance.entity;
            
            Player nearestPlayer = null;
            double nearestDistance = phase.aggroRange;
            
            for (Entity entity : instance.entity.getNearbyEntities(phase.aggroRange, phase.aggroRange, phase.aggroRange)) {
                if (entity instanceof Player) {
                    Player player = (Player) entity;
                    double distance = instance.entity.getLocation().distance(player.getLocation());
                    
                    if (distance < nearestDistance) {
                        nearestDistance = distance;
                        nearestPlayer = player;
                    }
                }
            }
            
            if (nearestPlayer != null) {
                creature.setTarget(nearestPlayer);
                addParticipant(instance.entity.getUniqueId(), nearestPlayer);
            }
        }
    }
    
    /**
     * Execute specific boss ability
     */
    private void executeBossAbility(BossInstance instance, String ability) {
        Location loc = instance.entity.getLocation();
        World world = loc.getWorld();
        
        switch (ability) {
            // Soul Eater Abilities
            case "soul_drain":
                for (Entity entity : instance.entity.getNearbyEntities(12, 12, 12)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.damage(6.0);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                        instance.entity.setHealth(Math.min(
                            instance.entity.getHealth() + 8.0,
                            instance.entity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue()
                        ));
                        world.spawnParticle(Particle.SOUL, player.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);
                    }
                }
                world.playSound(loc, Sound.ENTITY_PHANTOM_BITE, 1.5f, 0.7f);
                break;
                
            case "summon_minions":
                int minions = instance.currentPhase >= 2 ? 5 : 3;
                for (int i = 0; i < minions; i++) {
                    Location spawnLoc = loc.clone().add(Math.random() * 6 - 3, 0, Math.random() * 6 - 3);
                    Zombie minion = world.spawn(spawnLoc, Zombie.class);
                    minion.setCustomName("§8Soul Minion");
                    minion.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999, 1));
                }
                world.spawnParticle(Particle.PORTAL, loc, 80, 2, 2, 2, 0.5);
                world.playSound(loc, Sound.ENTITY_ZOMBIE_VILLAGER_CONVERTED, 1.0f, 0.8f);
                break;
                
            case "dark_pulse":
                for (Entity entity : instance.entity.getNearbyEntities(10, 10, 10)) {
                    if (entity instanceof Player) {
                        ((Player) entity).damage(10.0);
                        ((Player) entity).addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 1));
                    }
                }
                world.spawnParticle(Particle.SWEEP_ATTACK, loc, 30, 3, 1, 3);
                world.playSound(loc, Sound.ENTITY_WITHER_SHOOT, 1.5f, 0.6f);
                break;
                
            case "soul_explosion":
                // Phase 3 ultimate
                world.spawnParticle(Particle.EXPLOSION, loc, 50, 4, 2, 4);
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 200, 5, 3, 5, 0.2);
                for (Entity entity : instance.entity.getNearbyEntities(15, 15, 15)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.damage(15.0);
                        player.setVelocity(player.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(3).setY(1.5));
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 200, 2));
                    }
                }
                world.playSound(loc, Sound.ENTITY_WITHER_DEATH, 2.0f, 0.5f);
                break;
                
            // Void Titan Abilities
            case "ground_slam":
                for (Entity entity : instance.entity.getNearbyEntities(8, 8, 8)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.setVelocity(player.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(2.5).setY(1.2));
                        player.damage(12.0);
                    }
                }
                world.spawnParticle(Particle.EXPLOSION, loc, 10, 2, 0.5, 2);
                world.spawnParticle(Particle.BLOCK, loc, 100, 3, 0.5, 3, Material.STONE.createBlockData());
                world.playSound(loc, Sound.ENTITY_IRON_GOLEM_ATTACK, 2.0f, 0.5f);
                break;
                
            case "void_pull":
                for (Entity entity : instance.entity.getNearbyEntities(20, 20, 20)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        Vector direction = loc.toVector().subtract(player.getLocation().toVector()).normalize().multiply(1.5);
                        player.setVelocity(direction);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
                    }
                }
                world.spawnParticle(Particle.PORTAL, loc, 100, 3, 3, 3, 1.0);
                world.playSound(loc, Sound.ENTITY_ENDERMAN_SCREAM, 1.5f, 0.6f);
                break;
                
            case "titan_roar":
                for (Entity entity : instance.entity.getNearbyEntities(25, 25, 25)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.damage(8.0);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 200, 1));
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 200, 1));
                    }
                }
                world.playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 2.0f, 0.4f);
                break;
                
            case "void_storm":
                // Phase 3 ultimate
                for (int i = 0; i < 10; i++) {
                    final int iteration = i;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Location randomLoc = loc.clone().add(
                            Math.random() * 20 - 10,
                            5,
                            Math.random() * 20 - 10
                        );
                        world.spawnParticle(Particle.PORTAL, randomLoc, 50, 1, 1, 1, 0.5);
                        for (Entity entity : world.getNearbyEntities(randomLoc, 4, 10, 4)) {
                            if (entity instanceof Player) {
                                ((Player) entity).damage(12.0);
                            }
                        }
                    }, i * 10L);
                }
                world.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 2.0f, 0.5f);
                break;
                
            // Chaos Knight Abilities
            case "charge_attack":
                Player target = findNearestPlayer(instance, 20);
                if (target != null) {
                    Vector direction = target.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(2);
                    instance.entity.setVelocity(direction);
                    target.damage(14.0);
                    target.setVelocity(direction.multiply(1.5).setY(0.8));
                    target.setFireTicks(100);
                    world.spawnParticle(Particle.FLAME, loc, 30, 1, 1, 1, 0.1);
                    world.playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.8f);
                }
                break;
                
            case "chaos_strike":
                for (Entity entity : instance.entity.getNearbyEntities(6, 6, 6)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.damage(16.0);
                        player.setFireTicks(140);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 120, 0));
                    }
                }
                world.spawnParticle(Particle.LAVA, loc, 40, 2, 1, 2);
                world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.2f);
                break;
                
            case "whirlwind":
                for (int i = 0; i < 8; i++) {
                    final int angle = i * 45;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        double radian = Math.toRadians(angle);
                        Location spinLoc = loc.clone().add(Math.cos(radian) * 5, 0, Math.sin(radian) * 5);
                        world.spawnParticle(Particle.SWEEP_ATTACK, spinLoc, 5, 0.5, 0.5, 0.5);
                        for (Entity entity : world.getNearbyEntities(spinLoc, 3, 3, 3)) {
                            if (entity instanceof Player) {
                                ((Player) entity).damage(8.0);
                            }
                        }
                    }, i * 2L);
                }
                world.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.8f);
                break;
                
            case "chaos_nova":
                // Phase 3 berserk
                instance.entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 300, 2));
                instance.entity.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 300, 3));
                world.spawnParticle(Particle.EXPLOSION, loc, 30, 5, 2, 5);
                for (Entity entity : instance.entity.getNearbyEntities(12, 12, 12)) {
                    if (entity instanceof Player) {
                        ((Player) entity).damage(18.0);
                        ((Player) entity).setVelocity(new Vector(0, 2, 0));
                    }
                }
                world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.6f);
                break;
                
            // Phantom Lord Abilities
            case "phantom_arrow":
                Player arrowTarget = findNearestPlayer(instance, 30);
                if (arrowTarget != null) {
                    Arrow arrow = world.spawn(loc.clone().add(0, 1.5, 0), Arrow.class);
                    arrow.setVelocity(arrowTarget.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(2));
                    arrow.setDamage(10.0);
                    arrow.addCustomEffect(new PotionEffect(PotionEffectType.LEVITATION, 60, 1), true);
                    world.spawnParticle(Particle.CLOUD, loc, 10, 0.5, 0.5, 0.5);
                }
                break;
                
            case "teleport":
                Player teleTarget = findNearestPlayer(instance, 25);
                if (teleTarget != null) {
                    Location behindTarget = teleTarget.getLocation().add(
                        teleTarget.getLocation().getDirection().multiply(-3)
                    );
                    world.spawnParticle(Particle.PORTAL, loc, 50, 1, 1, 1);
                    instance.entity.teleport(behindTarget);
                    world.spawnParticle(Particle.PORTAL, behindTarget, 50, 1, 1, 1);
                    world.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
                }
                break;
                
            case "shadow_clone":
                for (int i = 0; i < 2; i++) {
                    Location cloneLoc = loc.clone().add(Math.random() * 8 - 4, 0, Math.random() * 8 - 4);
                    Phantom clone = world.spawn(cloneLoc, Phantom.class);
                    clone.setCustomName("§7Shadow Clone");
                    clone.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999, 2));
                    world.spawnParticle(Particle.SMOKE, cloneLoc, 30, 1, 1, 1);
                }
                world.playSound(loc, Sound.ENTITY_PHANTOM_SWOOP, 1.0f, 0.8f);
                break;
                
            case "arrow_rain":
                // Phase 3 ultimate
                for (int i = 0; i < 20; i++) {
                    final int iteration = i;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Location rainLoc = loc.clone().add(
                            Math.random() * 16 - 8,
                            10,
                            Math.random() * 16 - 8
                        );
                        Arrow arrow = world.spawn(rainLoc, Arrow.class);
                        arrow.setVelocity(new Vector(0, -1, 0));
                        arrow.setDamage(8.0);
                    }, i * 5L);
                }
                world.playSound(loc, Sound.ENTITY_ARROW_SHOOT, 2.0f, 0.8f);
                break;
                
            // Dark Emperor Abilities
            case "dark_bolt":
                Player boltTarget = findNearestPlayer(instance, 30);
                if (boltTarget != null) {
                    boltTarget.getWorld().strikeLightningEffect(boltTarget.getLocation());
                    boltTarget.damage(20.0);
                    boltTarget.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 200, 3));
                    world.spawnParticle(Particle.SMOKE, boltTarget.getLocation(), 50, 1, 2, 1);
                }
                world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.7f);
                break;
                
            case "summon_guards":
                int guards = instance.currentPhase >= 2 ? 4 : 2;
                for (int i = 0; i < guards; i++) {
                    WitherSkeleton guard = world.spawn(
                        loc.clone().add(Math.random() * 6 - 3, 0, Math.random() * 6 - 3),
                        WitherSkeleton.class
                    );
                    guard.setCustomName("§8Dark Guard");
                    guard.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 999999, 2));
                }
                world.spawnParticle(Particle.SMOKE, loc, 100, 3, 3, 3, 0.1);
                world.playSound(loc, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.2f);
                break;
                
            case "curse_aura":
                for (Entity entity : instance.entity.getNearbyEntities(15, 15, 15)) {
                    if (entity instanceof Player) {
                        Player player = (Player) entity;
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 120, 2));
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 120, 2));
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 120, 1));
                    }
                }
                world.spawnParticle(Particle.SMOKE, loc, 80, 4, 2, 4, 0.1);
                world.playSound(loc, Sound.ENTITY_WITHER_AMBIENT, 1.5f, 0.5f);
                break;
                
            case "meteor_strike":
                for (int i = 0; i < 5; i++) {
                    final int iteration = i;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Location meteorLoc = loc.clone().add(
                            Math.random() * 20 - 10,
                            15,
                            Math.random() * 20 - 10
                        );
                        world.spawnParticle(Particle.FLAME, meteorLoc, 100, 1, 1, 1, 0.1);
                        world.spawnParticle(Particle.LAVA, meteorLoc, 50, 1, 1, 1);
                        world.createExplosion(meteorLoc, 4.0f, false, false);
                        for (Entity entity : world.getNearbyEntities(meteorLoc, 5, 10, 5)) {
                            if (entity instanceof Player) {
                                ((Player) entity).damage(18.0);
                                ((Player) entity).setFireTicks(200);
                            }
                        }
                    }, i * 20L);
                }
                world.playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 2.0f, 0.5f);
                break;
                
            case "apocalypse":
                // Phase 4 ultimate
                instance.entity.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 400, 4));
                instance.entity.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 400, 5));
                instance.entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 400, 2));
                
                for (int i = 0; i < 30; i++) {
                    final int iteration = i;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Location explosionLoc = loc.clone().add(
                            Math.random() * 25 - 12.5,
                            Math.random() * 5,
                            Math.random() * 25 - 12.5
                        );
                        world.spawnParticle(Particle.EXPLOSION, explosionLoc, 20, 2, 2, 2);
                        world.spawnParticle(Particle.SOUL_FIRE_FLAME, explosionLoc, 50, 2, 2, 2, 0.1);
                        for (Entity entity : world.getNearbyEntities(explosionLoc, 4, 4, 4)) {
                            if (entity instanceof Player) {
                                ((Player) entity).damage(15.0);
                            }
                        }
                    }, i * 5L);
                }
                world.playSound(loc, Sound.ENTITY_WITHER_DEATH, 2.0f, 0.3f);
                Bukkit.broadcastMessage("§4§l✦ THE DARK EMPEROR UNLEASHES APOCALYPSE! ✦");
                break;
        }
    }
    
    /**
     * Find nearest player to boss
     */
    private Player findNearestPlayer(BossInstance instance, double range) {
        Player nearest = null;
        double nearestDist = range;
        
        for (Entity entity : instance.entity.getNearbyEntities(range, range, range)) {
            if (entity instanceof Player) {
                double dist = instance.entity.getLocation().distance(entity.getLocation());
                if (dist < nearestDist) {
                    nearestDist = dist;
                    nearest = (Player) entity;
                }
            }
        }
        
        return nearest;
    }
    
    /**
     * Boss configuration
     */
    public static class BossConfig {
        public String id;
        public String name;
        public double health;
        public double damage;
        public double defense;
        public double speed;
        public long soulReward;
        public int spawnCooldown;
        public List<BossPhase> phases = new ArrayList<>();
        public List<BossDrop> drops = new ArrayList<>();
    }
    
    /**
     * Boss phase
     */
    public static class BossPhase {
        public List<String> abilities;
        public int aggroRange;
        public double damageMultiplier;
    }
    
    /**
     * Boss drop
     */
    public static class BossDrop {
        public String item;
        public double chance;
    }
    
    /**
     * Active boss instance
     */
    public static class BossInstance {
        public String bossId;
        public BossConfig config;
        public LivingEntity entity;
        public int currentPhase;
        public long spawnTime;
        public Set<UUID> participants;
        public BossBar bossBar;
        public Location arenaCenter;
        public int lastAbilityTick;
    }
}
