package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.profile.ProfileGUI;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ProfileCommand implements CommandExecutor {
    
    private final ProfileGUI profileGUI;
    
    public ProfileCommand(ProfileGUI profileGUI) {
        this.profileGUI = profileGUI;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTylko gracze mogą używać tej komendy!");
            return true;
        }
        
        Player target = player;
        if (args.length > 0) {
            target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage("§cGracz nie jest online!");
                return true;
            }
        }
        
        profileGUI.openProfile(player, target);
        return true;
    }
}
