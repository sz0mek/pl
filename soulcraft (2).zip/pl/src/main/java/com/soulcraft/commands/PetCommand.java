package com.soulcraft.commands;

import com.soulcraft.pets.PetService;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class PetCommand implements CommandExecutor {
    private final Plugin plugin;
    private final PetService petService;
    private final DataStore dataStore;
    
    public PetCommand(Plugin plugin, PetService petService, DataStore dataStore) {
        this.plugin = plugin;
        this.petService = petService;
        this.dataStore = dataStore;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command is only for players!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (args.length == 0) {
            petService.getGUI().openMainMenu(player);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "spawn":
                if (args.length < 2) {
                    player.sendMessage("§c§lUsage: /pet spawn <type>");
                    return true;
                }
                handleSpawn(player, args[1]);
                break;
                
            case "despawn":
                petService.despawnPet(player);
                break;
                
            case "feed":
                handleFeed(player);
                break;
                
            case "rename":
                if (args.length < 2) {
                    player.sendMessage("§c§lUsage: /pet rename <name>");
                    return true;
                }
                handleRename(player, String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)));
                break;
                
            case "info":
                handleInfo(player);
                break;
                
            case "protection":
                handleProtection(player);
                break;
                
            case "list":
                handleList(player);
                break;
                
            case "gui":
                petService.getGUI().openMainMenu(player);
                break;
                
            default:
                sendHelp(player);
                break;
        }
        
        return true;
    }
    
    private void handleSpawn(Player player, String petType) {
        boolean success = petService.spawnPet(player, petType.toLowerCase());
        if (!success) {
            player.sendMessage("§c§lFailed to spawn pet! Make sure it's unlocked and the type is correct.");
        }
    }
    
    private void handleFeed(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        
        if (hand.getType() == Material.AIR) {
            player.sendMessage("§c§lHold food in your hand to feed your pet!");
            return;
        }
        
        LivingEntity pet = petService.getActivePet(player.getUniqueId());
        if (pet == null) {
            player.sendMessage("§c§lYou don't have an active pet!");
            return;
        }
        
        petService.feedPet(player, hand);
    }
    
    private void handleRename(Player player, String newName) {
        PlayerData playerData = dataStore.loadPlayerData(player.getUniqueId());
        String activePetType = playerData.getActivePet();
        
        if (activePetType == null) {
            player.sendMessage("§c§lYou don't have an active pet!");
            return;
        }
        
        PlayerData.PetData petData = playerData.getPet(activePetType);
        if (petData == null) {
            player.sendMessage("§c§lError: Pet data not found!");
            return;
        }
        
        petData.setCustomName(newName);
        
        LivingEntity pet = petService.getActivePet(player.getUniqueId());
        if (pet != null) {
            String evolutionColor = getEvolutionColor(petData.getEvolutionStage());
            pet.setCustomName(evolutionColor + newName + " §7[Lv." + petData.getLevel() + "] §f♥");
        }
        
        player.sendMessage("§a§l✓ Pet renamed to: §e" + newName);
        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 1.0f, 1.0f);
    }
    
    private void handleInfo(Player player) {
        PlayerData playerData = dataStore.loadPlayerData(player.getUniqueId());
        String activePetType = playerData.getActivePet();
        
        if (activePetType == null) {
            player.sendMessage("§c§lYou don't have an active pet!");
            return;
        }
        
        PlayerData.PetData petData = playerData.getPet(activePetType);
        if (petData == null) {
            player.sendMessage("§c§lError: Pet data not found!");
            return;
        }
        
        player.sendMessage("§6§l════════ PET INFO ════════");
        player.sendMessage("§7Type: §e" + capitalize(activePetType));
        player.sendMessage("§7Name: §e" + (petData.getCustomName() != null ? petData.getCustomName() : "None"));
        player.sendMessage("§7Level: §e" + petData.getLevel() + " §7/ 100");
        player.sendMessage("§7Evolution: " + getEvolutionColor(petData.getEvolutionStage()) + petData.getEvolutionStage());
        
        long required = petService.getRequiredXP(petData.getLevel());
        int xpPercent = required > 0 ? (int)((petData.getExperience() / (double)required) * 100) : 100;
        player.sendMessage("§7XP: §e" + petData.getExperience() + " §7/ §e" + required + " §7(" + xpPercent + "%)");
        
        player.sendMessage("§7Happiness: §e" + petData.getHappiness() + "%");
        player.sendMessage("§7XP Bonus: §e+" + petData.getHappiness() + "%");
        player.sendMessage("§7Skills Unlocked: §e" + petData.getUnlockedSkills().size());
        player.sendMessage("§7Deaths: §c" + petData.getDeaths());
        player.sendMessage("§7Death Protection: " + (petData.hasDeathProtection() ? "§a✓" : "§c✗"));
        player.sendMessage("§6§l══════════════════════════");
    }
    
    private void handleProtection(Player player) {
        PlayerData playerData = dataStore.loadPlayerData(player.getUniqueId());
        String activePetType = playerData.getActivePet();
        
        if (activePetType == null) {
            player.sendMessage("§c§lYou don't have an active pet!");
            return;
        }
        
        PlayerData.PetData petData = playerData.getPet(activePetType);
        if (petData == null) {
            player.sendMessage("§c§lError: Pet data not found!");
            return;
        }
        
        if (petData.getLevel() < 60) {
            player.sendMessage("§c§lDeath Protection unlocks at level 60!");
            return;
        }
        
        if (petData.hasDeathProtection()) {
            player.sendMessage("§c§lYour pet already has death protection active!");
            return;
        }
        
        long cost = 50000;
        if (playerData.getSouls() < cost) {
            player.sendMessage("§c§lNot enough souls! Required: §e" + cost);
            return;
        }
        
        playerData.removeSouls(cost);
        petData.setDeathProtection(true);
        
        player.sendMessage("§a§l✓ Death Protection activated! (1 use)");
        player.sendMessage("§7Your pet will survive one fatal hit.");
        player.playSound(player.getLocation(), Sound.BLOCK_BELL_USE, 1.0f, 1.0f);
    }
    
    private void handleList(Player player) {
        player.sendMessage("§6§l════ AVAILABLE PET TYPES ════");
        player.sendMessage("§a• Wolf §7- Combat pet (Unlocks: Lv.1)");
        player.sendMessage("§a• Cat §7- Agility pet (Unlocks: Lv.1)");
        player.sendMessage("§a• Rabbit §7- Lucky pet (Unlocks: Lv.5)");
        player.sendMessage("§a• Bee §7- Poison pet (Unlocks: Lv.8)");
        player.sendMessage("§a• Zombie §7- Tank pet (Unlocks: Lv.10)");
        player.sendMessage("§a• Fox §7- Cunning pet (Unlocks: Lv.12)");
        player.sendMessage("§a• Skeleton §7- Ranger pet (Unlocks: Lv.15)");
        player.sendMessage("§a• Turtle §7- Guardian pet (Unlocks: Lv.20)");
        player.sendMessage("§a• Phoenix §7- Support pet (Unlocks: Lv.40)");
        player.sendMessage("§a• Dragon §7- Legendary pet (Unlocks: Lv.50)");
        player.sendMessage("§7");
        player.sendMessage("§7Use §e/pet gui §7to manage your pets!");
        player.sendMessage("§6§l════════════════════════════");
    }
    
    private void sendHelp(Player player) {
        player.sendMessage("§6§l════ PET COMMANDS ════");
        player.sendMessage("§e/pet §7- Open pet management GUI");
        player.sendMessage("§e/pet spawn <type> §7- Spawn a pet");
        player.sendMessage("§e/pet despawn §7- Despawn active pet");
        player.sendMessage("§e/pet feed §7- Feed pet (hold food)");
        player.sendMessage("§e/pet rename <name> §7- Rename pet");
        player.sendMessage("§e/pet info §7- View pet details");
        player.sendMessage("§e/pet protection §7- Activate death protection");
        player.sendMessage("§e/pet list §7- List all pet types");
        player.sendMessage("§6§l═══════════════════════");
    }
    
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    
    private String getEvolutionColor(String stage) {
        switch (stage) {
            case "Baby": return "§f";
            case "Young": return "§a";
            case "Adult": return "§9";
            case "Ancient": return "§5";
            case "Legendary": return "§6§l";
            default: return "§7";
        }
    }
}
