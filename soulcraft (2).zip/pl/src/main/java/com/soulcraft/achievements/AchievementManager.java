package com.soulcraft.achievements;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;

public class AchievementManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Achievement> achievements = new HashMap<>();
    private final Map<UUID, Set<String>> playerAchievements = new HashMap<>();
    
    public AchievementManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        registerAchievements();
    }
    
    private void registerAchievements() {
        // Delegated to Mission System - Achievements are missions with type ACHIEVEMENT
    }
    
    public void unlockAchievement(Player player, String achievementId) {
        playerAchievements.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(achievementId);
        player.sendMessage("§5§l⭐ OSIĄGNIĘCIE: " + achievementId);
    }
    
    public boolean hasAchievement(Player player, String achievementId) {
        return playerAchievements.getOrDefault(player.getUniqueId(), new HashSet<>()).contains(achievementId);
    }
    
    public int getAchievementCount(Player player) {
        return playerAchievements.getOrDefault(player.getUniqueId(), new HashSet<>()).size();
    }
    
    static class Achievement {
        final String id, name, description;
        final int rewardSouls;
        
        Achievement(String id, String name, String description, int rewardSouls) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.rewardSouls = rewardSouls;
        }
    }
}
