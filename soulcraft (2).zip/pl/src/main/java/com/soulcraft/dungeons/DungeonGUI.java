package com.soulcraft.dungeons;

import com.soulcraft.gui.GUIBuilder;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Comprehensive GUI system for dungeons with party management
 */
public class DungeonGUI implements Listener, InventoryHolder {
    private final EnhancedDungeonService dungeonService;
    private final DataStore dataStore;
    private final Player player;
    private String currentMenu = "main";
    
    public DungeonGUI(EnhancedDungeonService dungeonService, DataStore dataStore) {
        this.dungeonService = dungeonService;
        this.dataStore = dataStore;
        this.player = null;
    }
    
    /**
     * Main dungeon menu - dungeon selection and party management
     */
    public void openDungeonSelection(Player player) {
        Inventory gui = GUIBuilder.create("§5§l✦ Dungeon Menu ✦", 6, this)
            .fillBorder(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆")
            .build();
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        int playerLevel = data.getLevel();
        
        // Easy Dungeon
        ItemStack easyDungeon = createDungeonItem(
            Material.WOODEN_SWORD,
            "§a§lEasy Dungeon",
            "easy",
            1,
            "10x10 rooms",
            "300 souls, 50 XP",
            playerLevel >= 1
        );
        gui.setItem(10, easyDungeon);
        
        // Medium Dungeon
        ItemStack mediumDungeon = createDungeonItem(
            Material.STONE_SWORD,
            "§e§lMedium Dungeon",
            "medium",
            15,
            "15x15 rooms",
            "800 souls, 150 XP",
            playerLevel >= 15
        );
        gui.setItem(12, mediumDungeon);
        
        // Hard Dungeon
        ItemStack hardDungeon = createDungeonItem(
            Material.IRON_SWORD,
            "§6§lHard Dungeon",
            "hard",
            30,
            "20x20 rooms",
            "2,000 souls, 300 XP",
            playerLevel >= 30
        );
        gui.setItem(14, hardDungeon);
        
        // Nightmare Dungeon
        ItemStack nightmareDungeon = createDungeonItem(
            Material.DIAMOND_SWORD,
            "§c§lNightmare Dungeon",
            "nightmare",
            45,
            "30x30 rooms",
            "5,000 souls, 600 XP",
            playerLevel >= 45
        );
        gui.setItem(16, nightmareDungeon);
        
        // Chaos Dungeon
        ItemStack chaosDungeon = createDungeonItem(
            Material.NETHERITE_SWORD,
            "§4§lChaos Dungeon",
            "chaos",
            60,
            "40x40 rooms",
            "12,000 souls, 1,200 XP",
            playerLevel >= 60
        );
        gui.setItem(28, chaosDungeon);
        
        // Party Management Button
        EnhancedDungeonService.DungeonParty party = dungeonService.getPlayerParty(player);
        ItemStack partyButton;
        if (party == null) {
            partyButton = GUIBuilder.createGlowingItem(
                Material.PLAYER_HEAD,
                "§b§lParty Management",
                Arrays.asList(
                    "§7Click to manage your party",
                    "§7",
                    "§7You are not in a party",
                    "§7",
                    "§a§l→ Click to create or join party!"
                )
            );
        } else {
            boolean isLeader = party.leader.equals(player.getUniqueId());
            partyButton = GUIBuilder.createGlowingItem(
                Material.PLAYER_HEAD,
                "§b§lParty Management",
                Arrays.asList(
                    "§7Click to manage your party",
                    "§7",
                    "§7Members: §e" + party.members.size() + "/5",
                    "§7Role: §e" + (isLeader ? "Leader" : "Member"),
                    "§7",
                    "§a§l→ Click to view party options!"
                )
            );
        }
        gui.setItem(31, partyButton);
        
        // Info item
        ItemStack info = GUIBuilder.createItem(
            Material.BOOK,
            "§d§lDungeon Info",
            "§7Complete dungeons for rewards!",
            "§7",
            "§eFeatures:",
            "§7• Procedurally generated rooms",
            "§7• Time-limited challenges",
            "§7• Party support (up to 5 players)",
            "§7• Daily seed changes",
            "§7• Leaderboard tracking",
            "§7",
            "§aTip: Team up for harder dungeons!"
        );
        gui.setItem(30, info);
        
        // Statistics
        int completions = data.getDungeonsCompleted();
        ItemStack stats = GUIBuilder.createItem(
            Material.WRITABLE_BOOK,
            "§6§lYour Statistics",
            "§7Dungeons Completed: §e" + completions,
            "§7Current Level: §e" + playerLevel,
            "§7",
            "§7Complete more dungeons to",
            "§7unlock higher difficulties!"
        );
        gui.setItem(32, stats);
        
        // Close button
        ItemStack close = GUIBuilder.createItem(Material.BARRIER, "§c§lClose", "§7Click to close");
        gui.setItem(49, close);
        
        player.openInventory(gui);
    }
    
    /**
     * Party management GUI
     */
    public void openPartyManagement(Player player) {
        Inventory gui = GUIBuilder.create("§b§l✦ Party Management ✦", 6, this)
            .fillBorder(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "§b§l◆")
            .build();
        
        EnhancedDungeonService.DungeonParty party = dungeonService.getPlayerParty(player);
        
        if (party == null) {
            // No party - show create option
            ItemStack createParty = GUIBuilder.createGlowingItem(
                Material.EMERALD,
                "§a§lCreate Party",
                Arrays.asList(
                    "§7Start your own dungeon party!",
                    "§7",
                    "§7You will become the party leader",
                    "§7and can invite up to 4 other players.",
                    "§7",
                    "§a§l→ Click to create party!"
                )
            );
            gui.setItem(22, createParty);
            
            ItemStack info = GUIBuilder.createItem(
                Material.BOOK,
                "§e§lParty System",
                "§7Create or join a party to",
                "§7tackle dungeons together!",
                "§7",
                "§eParty Benefits:",
                "§7• Shared rewards",
                "§7• Better loot chances",
                "§7• Tackle harder dungeons",
                "§7• More fun with friends!",
                "§7",
                "§7Max party size: §e5 players"
            );
            gui.setItem(31, info);
        } else {
            // Has party - show party details
            boolean isLeader = party.leader.equals(player.getUniqueId());
            
            // Party info
            ItemStack partyInfo = GUIBuilder.createItem(
                Material.PAPER,
                "§6§lParty Information",
                "§7Leader: §e" + Bukkit.getOfflinePlayer(party.leader).getName(),
                "§7Members: §e" + party.members.size() + "/5",
                "§7Your Role: §e" + (isLeader ? "Leader" : "Member"),
                "§7",
                "§7Party is ready for dungeons!"
            );
            gui.setItem(4, partyInfo);
            
            // Display party members
            int slot = 19;
            for (UUID memberId : party.members) {
                Player member = Bukkit.getPlayer(memberId);
                String memberName = member != null ? member.getName() : Bukkit.getOfflinePlayer(memberId).getName();
                boolean online = member != null && member.isOnline();
                
                ItemStack memberItem = GUIBuilder.createItem(
                    online ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
                    (memberId.equals(party.leader) ? "§6§l★ " : "§7") + memberName,
                    "§7Status: " + (online ? "§aOnline" : "§cOffline"),
                    "§7Role: " + (memberId.equals(party.leader) ? "§6Leader" : "§7Member"),
                    "§7",
                    memberId.equals(party.leader) ? "§6Party Leader" : "§7Party Member"
                );
                gui.setItem(slot++, memberItem);
                if (slot == 26) break;
            }
            
            // Leader-only options
            if (isLeader) {
                // Invite player
                ItemStack invite = GUIBuilder.createGlowingItem(
                    Material.WRITABLE_BOOK,
                    "§a§lInvite Player",
                    Arrays.asList(
                        "§7Invite a player to your party",
                        "§7",
                        "§7Use command:",
                        "§e/dungeon party invite <player>",
                        "§7",
                        "§7Party slots: §e" + party.members.size() + "/5"
                    )
                );
                gui.setItem(38, invite);
                
                // Start dungeon
                ItemStack startDungeon = GUIBuilder.createGlowingItem(
                    Material.DIAMOND,
                    "§5§lStart Party Dungeon",
                    Arrays.asList(
                        "§7Start a dungeon with your party",
                        "§7",
                        "§7All online members will be",
                        "§7teleported to the dungeon.",
                        "§7",
                        "§a§l→ Click to choose difficulty!"
                    )
                );
                gui.setItem(40, startDungeon);
                
                // Disband party
                ItemStack disband = GUIBuilder.createItem(
                    Material.BARRIER,
                    "§c§lDisband Party",
                    "§7Disband the party",
                    "§7",
                    "§c§l⚠ This cannot be undone!",
                    "§7",
                    "§c§l→ Click to disband"
                );
                gui.setItem(42, disband);
            }
            
            // Leave party button (non-leaders)
            if (!isLeader) {
                ItemStack leave = GUIBuilder.createItem(
                    Material.BARRIER,
                    "§c§lLeave Party",
                    "§7Leave the current party",
                    "§7",
                    "§7You can rejoin if invited again.",
                    "§7",
                    "§c§l→ Click to leave"
                );
                gui.setItem(40, leave);
            }
        }
        
        // Back button
        ItemStack back = GUIBuilder.createItem(Material.ARROW, "§7« Back", "§7Return to dungeon menu");
        gui.setItem(45, back);
        
        // Close button
        ItemStack close = GUIBuilder.createItem(Material.BARRIER, "§c§lClose", "§7Click to close");
        gui.setItem(49, close);
        
        player.openInventory(gui);
    }
    
    /**
     * Party dungeon difficulty selection
     */
    public void openPartyDungeonSelection(Player player) {
        EnhancedDungeonService.DungeonParty party = dungeonService.getPlayerParty(player);
        if (party == null || !party.leader.equals(player.getUniqueId())) {
            player.sendMessage("§c§lOnly the party leader can start dungeons!");
            return;
        }
        
        Inventory gui = GUIBuilder.create("§5§l✦ Select Party Dungeon ✦", 4, this)
            .fillBorder(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆")
            .build();
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        int playerLevel = data.getLevel();
        
        // Easy
        gui.setItem(10, createPartyDungeonItem(Material.WOODEN_SWORD, "§a§lEasy Dungeon", "easy", 1, playerLevel >= 1));
        // Medium
        gui.setItem(12, createPartyDungeonItem(Material.STONE_SWORD, "§e§lMedium Dungeon", "medium", 15, playerLevel >= 15));
        // Hard
        gui.setItem(14, createPartyDungeonItem(Material.IRON_SWORD, "§6§lHard Dungeon", "hard", 30, playerLevel >= 30));
        // Nightmare
        gui.setItem(16, createPartyDungeonItem(Material.DIAMOND_SWORD, "§c§lNightmare Dungeon", "nightmare", 45, playerLevel >= 45));
        // Chaos
        gui.setItem(28, createPartyDungeonItem(Material.NETHERITE_SWORD, "§4§lChaos Dungeon", "chaos", 60, playerLevel >= 60));
        
        // Back button
        ItemStack back = GUIBuilder.createItem(Material.ARROW, "§7« Back", "§7Return to party management");
        gui.setItem(31, back);
        
        player.openInventory(gui);
    }
    
    /**
     * Active dungeon GUI - shows progress and options
     */
    public void openActiveDungeonGUI(Player player) {
        if (!dungeonService.isInDungeon(player.getUniqueId())) {
            player.sendMessage("§c§lYou are not in a dungeon!");
            return;
        }
        
        EnhancedDungeonService.DungeonInstance dungeon = null;
        for (EnhancedDungeonService.DungeonInstance d : dungeonService.getActiveDungeons().values()) {
            if (d.players.contains(player.getUniqueId())) {
                dungeon = d;
                break;
            }
        }
        
        if (dungeon == null) return;
        
        Inventory gui = GUIBuilder.create("§5§l✦ Dungeon Progress ✦", 4, this)
            .fillBorder(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆")
            .build();
        
        long elapsed = (System.currentTimeMillis() - dungeon.startTime) / 1000;
        long remaining = dungeon.timeLimit - elapsed;
        int minutes = (int)(remaining / 60);
        int seconds = (int)(remaining % 60);
        
        // Progress info
        ItemStack progress = GUIBuilder.createItem(
            Material.MAP,
            "§6§lDungeon Progress",
            "§7Difficulty: §e" + dungeon.difficulty.toUpperCase(),
            "§7Biome: §e" + dungeon.biome.name,
            "§7",
            "§7Rooms Cleared: §a" + dungeon.roomsCleared + "/" + dungeon.rooms.size(),
            "§7Mobs Killed: §c" + dungeon.mobsKilled + "/" + dungeon.totalMobs,
            "§7",
            "§7Time Remaining: §e" + minutes + "m " + seconds + "s"
        );
        gui.setItem(13, progress);
        
        // Party info if in party
        if (dungeon.partySize > 1) {
            ItemStack partyInfo = GUIBuilder.createItem(
                Material.PLAYER_HEAD,
                "§b§lParty Dungeon",
                "§7Party Size: §e" + dungeon.partySize + " players",
                "§7",
                "§7Working together to clear",
                "§7this challenging dungeon!"
            );
            gui.setItem(11, partyInfo);
        }
        
        // Rewards preview
        ItemStack rewards = GUIBuilder.createGlowingItem(
            Material.GOLD_INGOT,
            "§e§lRewards",
            Arrays.asList(
                "§7Clear this dungeon to receive:",
                "§7",
                "§6§l+ " + dungeon.config.soulReward + " Souls",
                "§a§l+ " + dungeon.config.xpReward + " XP",
                "§7",
                "§7Bonus loot: §e" + (int)(dungeon.config.lootMultiplier * 100) + "% multiplier",
                "§7",
                "§aComplete faster for time bonus!"
            )
        );
        gui.setItem(15, rewards);
        
        // Leave dungeon (forfeit)
        ItemStack leave = GUIBuilder.createItem(
            Material.BARRIER,
            "§c§lLeave Dungeon",
            "§7Exit the dungeon",
            "§7",
            "§c§l⚠ You will forfeit all rewards!",
            "§7",
            "§c§l→ Click to leave"
        );
        gui.setItem(31, leave);
        
        player.openInventory(gui);
    }
    
    private ItemStack createDungeonItem(Material material, String name, String difficultyId, int levelReq, String roomSize, String reward, boolean unlocked) {
        List<String> lore = new ArrayList<>();
        lore.add("§7");
        lore.add("§7Required Level: §e" + levelReq);
        lore.add("§7Room Size: §e" + roomSize);
        lore.add("§7Reward: §e" + reward);
        lore.add("§7");
        
        EnhancedDungeonService.DifficultyConfig config = dungeonService.getDifficulties().get(difficultyId);
        if (config != null) {
            int timeMinutes = getTimeLimit(difficultyId) / 60;
            lore.add("§7Time Limit: §e" + timeMinutes + " minutes");
            lore.add("§7Difficulty: §c" + config.mobLevelMultiplier + "x");
            lore.add("§7Loot Bonus: §6" + (int)(config.lootMultiplier * 100) + "%");
            lore.add("§7");
        }
        
        if (unlocked) {
            lore.add("§a§l✓ UNLOCKED");
            lore.add("§7Click to enter solo!");
            return GUIBuilder.createGlowingItem(material, name, lore);
        } else {
            lore.add("§c§l✗ LOCKED");
            lore.add("§7Reach level " + levelReq + " to unlock");
            return GUIBuilder.createItem(material, name, lore);
        }
    }
    
    private ItemStack createPartyDungeonItem(Material material, String name, String difficultyId, int levelReq, boolean unlocked) {
        List<String> lore = new ArrayList<>();
        lore.add("§7Required Level: §e" + levelReq);
        lore.add("§7");
        
        if (unlocked) {
            lore.add("§a§l✓ Click to start!");
            return GUIBuilder.createGlowingItem(material, name, lore);
        } else {
            lore.add("§c§l✗ LOCKED - Level " + levelReq);
            return GUIBuilder.createItem(material, name, lore);
        }
    }
    
    private int getTimeLimit(String difficulty) {
        switch (difficulty) {
            case "easy": return 900;
            case "medium": return 1200;
            case "hard": return 1800;
            case "nightmare": return 2400;
            case "chaos": return 3000;
            default: return 900;
        }
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getInventory().getHolder() != this) return;
        
        event.setCancelled(true);
        
        Player player = (Player) event.getWhoClicked();
        ItemStack clicked = event.getCurrentItem();
        
        if (clicked == null || clicked.getType() == Material.AIR) return;
        if (!clicked.hasItemMeta() || !clicked.getItemMeta().hasDisplayName()) return;
        
        String displayName = clicked.getItemMeta().getDisplayName();
        String inventoryTitle = event.getView().getTitle();
        boolean isPartyDungeonMenu = inventoryTitle.contains("Select Party Dungeon");
        
        // Handle clicks based on menu
        if (displayName.contains("Close")) {
            player.closeInventory();
        } else if (displayName.contains("Back")) {
            handleBackButton(player);
        } else if (displayName.contains("Easy Dungeon")) {
            handleDungeonStart(player, "easy", isPartyDungeonMenu);
        } else if (displayName.contains("Medium Dungeon")) {
            handleDungeonStart(player, "medium", isPartyDungeonMenu);
        } else if (displayName.contains("Hard Dungeon")) {
            handleDungeonStart(player, "hard", isPartyDungeonMenu);
        } else if (displayName.contains("Nightmare Dungeon")) {
            handleDungeonStart(player, "nightmare", isPartyDungeonMenu);
        } else if (displayName.contains("Chaos Dungeon")) {
            handleDungeonStart(player, "chaos", isPartyDungeonMenu);
        } else if (displayName.contains("Party Management")) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), 
                () -> openPartyManagement(player), 1L);
        } else if (displayName.contains("Create Party")) {
            handleCreateParty(player);
        } else if (displayName.contains("Start Party Dungeon")) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), 
                () -> openPartyDungeonSelection(player), 1L);
        } else if (displayName.contains("Leave Party")) {
            handleLeaveParty(player);
        } else if (displayName.contains("Disband Party")) {
            handleDisbandParty(player);
        } else if (displayName.contains("Leave Dungeon")) {
            handleLeaveDungeon(player);
        }
    }
    
    private void handleBackButton(Player player) {
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), 
            () -> openDungeonSelection(player), 1L);
    }
    
    private void handleDungeonStart(Player player, String difficulty) {
        handleDungeonStart(player, difficulty, false);
    }
    
    private void handleDungeonStart(Player player, String difficulty, boolean isPartyDungeon) {
        player.closeInventory();
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        EnhancedDungeonService.DifficultyConfig config = dungeonService.getDifficulties().get(difficulty);
        
        if (config != null && data.getLevel() < config.requiredLevel) {
            player.sendMessage("§c§lYou need level " + config.requiredLevel + " for this dungeon!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return;
        }
        
        if (isPartyDungeon) {
            // Starting party dungeon
            EnhancedDungeonService.DungeonParty party = dungeonService.getPlayerParty(player);
            if (party != null) {
                dungeonService.startPartyDungeon(party, difficulty);
            }
        } else {
            // Starting solo dungeon
            dungeonService.startDungeon(player, difficulty);
        }
    }
    
    private void handleCreateParty(Player player) {
        EnhancedDungeonService.DungeonParty party = dungeonService.createParty(player);
        if (party != null) {
            player.closeInventory();
            player.sendMessage("§a§l✓ Party created! You are the leader.");
            player.sendMessage("§7Use §e/dungeon party invite <player> §7to invite others!");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), 
                () -> openPartyManagement(player), 10L);
        } else {
            player.sendMessage("§c§lYou are already in a party!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        }
    }
    
    private void handleLeaveParty(Player player) {
        if (dungeonService.leaveParty(player)) {
            player.closeInventory();
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.8f);
        }
    }
    
    private void handleDisbandParty(Player player) {
        EnhancedDungeonService.DungeonParty party = dungeonService.getPlayerParty(player);
        if (party != null && party.leader.equals(player.getUniqueId())) {
            // Notify all members
            for (UUID memberId : party.members) {
                Player member = Bukkit.getPlayer(memberId);
                if (member != null) {
                    member.sendMessage("§c§lThe party has been disbanded!");
                    member.playSound(member.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
                }
            }
            // Disband by having everyone leave
            for (UUID memberId : new ArrayList<>(party.members)) {
                Player member = Bukkit.getPlayer(memberId);
                if (member != null) {
                    dungeonService.leaveParty(member);
                }
            }
            player.closeInventory();
        }
    }
    
    private void handleLeaveDungeon(Player player) {
        player.closeInventory();
        dungeonService.leaveDungeon(player);
        player.sendMessage("§c§lYou forfeited the dungeon!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.8f);
    }
    
    @Override
    public Inventory getInventory() {
        return null;
    }
}
