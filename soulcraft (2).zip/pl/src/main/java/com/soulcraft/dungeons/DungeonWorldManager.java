package com.soulcraft.dungeons;

import org.bukkit.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DungeonWorldManager {
    private final Plugin plugin;
    private World soulRealm;
    private final Map<String, Set<Chunk>> activeInstanceChunks;
    private static final String WORLD_NAME = "SoulRealm";
    
    public DungeonWorldManager(Plugin plugin) {
        this.plugin = plugin;
        this.activeInstanceChunks = new ConcurrentHashMap<>();
        initializeSoulRealm();
    }
    
    private void initializeSoulRealm() {
        soulRealm = Bukkit.getWorld(WORLD_NAME);
        
        if (soulRealm == null) {
            plugin.getLogger().info("Creating dedicated dungeon world: " + WORLD_NAME);
            
            WorldCreator creator = new WorldCreator(WORLD_NAME);
            creator.environment(World.Environment.NORMAL);
            creator.type(WorldType.FLAT);
            creator.generateStructures(false);
            creator.generator(new VoidWorldGenerator());
            
            soulRealm = creator.createWorld();
            
            if (soulRealm != null) {
                soulRealm.setDifficulty(Difficulty.HARD);
                soulRealm.setSpawnFlags(false, false);
                soulRealm.setKeepSpawnInMemory(true);
                soulRealm.setAutoSave(false);
                soulRealm.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                soulRealm.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
                soulRealm.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                soulRealm.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
                soulRealm.setTime(18000);
                
                plugin.getLogger().info("SoulRealm created successfully!");
            } else {
                plugin.getLogger().severe("Failed to create SoulRealm world!");
            }
        } else {
            plugin.getLogger().info("SoulRealm world already exists - using existing world");
            soulRealm.setKeepSpawnInMemory(true);
        }
    }
    
    public World getSoulRealm() {
        return soulRealm;
    }
    
    public Location allocateInstanceSpace(String instanceId, int requiredSize) {
        if (soulRealm == null) {
            plugin.getLogger().severe("SoulRealm is null! Cannot allocate space");
            return null;
        }
        
        Random random = new Random(instanceId.hashCode());
        int x = random.nextInt(10000) * 1000;
        int z = random.nextInt(10000) * 1000;
        
        Location baseLocation = new Location(soulRealm, x, 100, z);
        
        int chunkRadius = (requiredSize / 16) + 2;
        Set<Chunk> chunks = new HashSet<>();
        
        int centerChunkX = baseLocation.getBlockX() >> 4;
        int centerChunkZ = baseLocation.getBlockZ() >> 4;
        
        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                Chunk chunk = soulRealm.getChunkAt(centerChunkX + dx, centerChunkZ + dz);
                chunk.setForceLoaded(true);
                chunks.add(chunk);
            }
        }
        
        activeInstanceChunks.put(instanceId, chunks);
        
        return baseLocation;
    }
    
    public void cleanupInstance(String instanceId) {
        Set<Chunk> chunks = activeInstanceChunks.remove(instanceId);
        
        if (chunks != null) {
            for (Chunk chunk : chunks) {
                for (org.bukkit.entity.Entity entity : chunk.getEntities()) {
                    if (!(entity instanceof org.bukkit.entity.Player)) {
                        entity.remove();
                    }
                }
                
                chunk.setForceLoaded(false);
            }
            
            plugin.getLogger().info("Cleaned up " + chunks.size() + " chunks for instance " + instanceId);
        }
    }
    
    public boolean isSoulRealm(World world) {
        return world != null && world.equals(soulRealm);
    }
    
    public void shutdown() {
        plugin.getLogger().info("Shutting down DungeonWorldManager...");
        
        for (String instanceId : new HashSet<>(activeInstanceChunks.keySet())) {
            cleanupInstance(instanceId);
        }
        
        if (soulRealm != null) {
            soulRealm.setKeepSpawnInMemory(false);
        }
    }
    
    public static class VoidWorldGenerator extends ChunkGenerator {
        @Override
        public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
            return createChunkData(world);
        }
        
        @Override
        public boolean canSpawn(World world, int x, int z) {
            return true;
        }
    }
}
