package com.soulcraft.dungeons;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.missions.MissionService;
import com.soulcraft.leaderboards.LeaderboardManager;
import com.soulcraft.bosses.BossService;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.attribute.Attribute;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.meta.ItemMeta;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EnhancedDungeonService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MissionService missionService;
    private final LeaderboardManager leaderboardManager;
    private final DungeonWorldManager worldManager;
    private BossService bossService;
    
    private final Map<String, DifficultyConfig> difficulties;
    private final Map<String, DungeonInstance> activeDungeons;
    private final Map<String, DungeonParty> parties;
    private final Map<UUID, String> playerParties;
    private final Map<UUID, PartyInvite> pendingInvites;
    private final Map<UUID, Long> fastestTimes;
    private long dailySeed;
    private final Random random;
    
    private static final int TIME_LIMIT_EASY = 1200;
    private static final int TIME_LIMIT_MEDIUM = 1800;
    private static final int TIME_LIMIT_HARD = 2400;
    private static final int TIME_LIMIT_NIGHTMARE = 3000;
    private static final int TIME_LIMIT_CHAOS = 3600;
    
    public EnhancedDungeonService(Plugin plugin, DataStore dataStore, EconomyService economyService, 
                                 MissionService missionService, LeaderboardManager leaderboardManager) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionService = missionService;
        this.leaderboardManager = leaderboardManager;
        this.worldManager = new DungeonWorldManager(plugin);
        this.difficulties = new HashMap<>();
        this.activeDungeons = new ConcurrentHashMap<>();
        this.parties = new ConcurrentHashMap<>();
        this.playerParties = new ConcurrentHashMap<>();
        this.pendingInvites = new ConcurrentHashMap<>();
        this.fastestTimes = new ConcurrentHashMap<>();
        this.random = new Random();
        
        loadDungeonConfig();
        updateDailySeed();
        startDungeonTimers();
        startDailySeedUpdate();
    }
    
    public void setBossService(BossService bossService) {
        this.bossService = bossService;
    }
    
    public Map<String, DifficultyConfig> getDifficulties() {
        return difficulties;
    }
    
    private void loadDungeonConfig() {
        registerDifficulty("easy", 1, 15, 5, 1.5, 2.0, 500, 100);
        registerDifficulty("medium", 15, 20, 7, 2.5, 3.0, 1500, 300);
        registerDifficulty("hard", 30, 25, 10, 4.0, 4.5, 4000, 700);
        registerDifficulty("nightmare", 45, 30, 12, 6.0, 6.0, 10000, 1500);
        registerDifficulty("chaos", 60, 35, 15, 9.0, 8.0, 25000, 3000);
    }
    
    private void registerDifficulty(String id, int level, int roomSize, int roomCount,
                                   double mobMult, double lootMult, long souls, long xp) {
        DifficultyConfig config = new DifficultyConfig();
        config.id = id;
        config.requiredLevel = level;
        config.baseRoomSize = roomSize;
        config.roomCount = roomCount;
        config.mobLevelMultiplier = mobMult;
        config.lootMultiplier = lootMult;
        config.soulReward = souls;
        config.xpReward = xp;
        difficulties.put(id, config);
    }
    
    private void updateDailySeed() {
        LocalDate today = LocalDate.now();
        dailySeed = today.toEpochDay() * 31337;
    }
    
    private void startDailySeedUpdate() {
        new BukkitRunnable() {
            @Override
            public void run() {
                updateDailySeed();
                Bukkit.broadcastMessage("§5§l✦ Daily dungeons have been reset!");
            }
        }.runTaskTimer(plugin, 20L * 60, 20L * 3600 * 24);
    }
    
    public boolean startDungeon(Player player, String difficulty) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) {
            player.sendMessage("§c§lInvalid dungeon difficulty!");
            return false;
        }
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        if (data.getLevel() < config.requiredLevel) {
            player.sendMessage("§c§lRequires level " + config.requiredLevel + "!");
            return false;
        }
        
        if (isInDungeon(player.getUniqueId())) {
            player.sendMessage("§c§lYou are already in a dungeon!");
            return false;
        }
        
        DungeonInstance dungeon = generateDungeon(difficulty, Arrays.asList(player.getUniqueId()));
        if (dungeon == null) {
            player.sendMessage("§c§lFailed to generate dungeon! Please try again.");
            return false;
        }
        
        activeDungeons.put(dungeon.instanceId, dungeon);
        
        teleportToDungeon(player, dungeon);
        startDungeonTimer(dungeon);
        
        player.sendMessage("§5§l✦ Entered " + difficulty.toUpperCase() + " Dungeon");
        player.sendMessage("§7Biome: §e" + dungeon.biome.name);
        player.sendMessage("§7Time Limit: §e" + (dungeon.timeLimit / 60) + " minutes");
        player.sendMessage("§7Rooms: §e" + dungeon.rooms.size());
        player.playSound(player.getLocation(), Sound.BLOCK_END_PORTAL_SPAWN, 1.0f, 1.0f);
        
        return true;
    }
    
    private DungeonInstance generateDungeon(String difficulty, List<UUID> players) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) return null;
        
        DungeonInstance dungeon = new DungeonInstance();
        dungeon.instanceId = UUID.randomUUID().toString();
        dungeon.difficulty = difficulty;
        dungeon.config = config;
        dungeon.players = new HashSet<>(players);
        dungeon.startTime = System.currentTimeMillis();
        dungeon.partySize = players.size();
        dungeon.timeLimit = getTimeLimit(difficulty);
        
        RoomTemplate.BiomeTheme[] themes = RoomTemplate.BiomeTheme.values();
        dungeon.biome = themes[(int)(Math.abs(dailySeed) % themes.length)];
        
        int requiredSpace = config.roomCount * (config.baseRoomSize + 50);
        Location baseLocation = worldManager.allocateInstanceSpace(dungeon.instanceId, requiredSpace);
        
        if (baseLocation == null) {
            plugin.getLogger().severe("Failed to allocate space for dungeon " + dungeon.instanceId);
            return null;
        }
        
        dungeon.entranceLocation = baseLocation;
        
        if (!generateRoomsWithTemplates(dungeon)) {
            plugin.getLogger().warning("Failed to generate rooms for dungeon " + dungeon.instanceId);
            worldManager.cleanupInstance(dungeon.instanceId);
            return null;
        }
        
        if (!validateRoomConnectivity(dungeon)) {
            plugin.getLogger().warning("Room connectivity validation failed for dungeon " + dungeon.instanceId);
            worldManager.cleanupInstance(dungeon.instanceId);
            return null;
        }
        
        populateRoomsAdvanced(dungeon);
        
        return dungeon;
    }
    
    private boolean generateRoomsWithTemplates(DungeonInstance dungeon) {
        Random rng = new Random(dailySeed + dungeon.difficulty.hashCode());
        int roomCount = dungeon.config.roomCount;
        Location current = dungeon.entranceLocation.clone();
        int spacing = dungeon.config.baseRoomSize + 30;
        
        RoomTemplate.TemplateType[] combatTypes = {
            RoomTemplate.TemplateType.COMBAT_ARENA,
            RoomTemplate.TemplateType.TRAP_MAZE,
            RoomTemplate.TemplateType.LIBRARY,
            RoomTemplate.TemplateType.FORGE
        };
        
        for (int i = 0; i < roomCount; i++) {
            RoomTemplate.TemplateType type;
            int size = dungeon.config.baseRoomSize + rng.nextInt(5);
            
            if (i == 0) {
                type = RoomTemplate.TemplateType.ENTRY_HALL;
            } else if (i == roomCount - 1) {
                type = RoomTemplate.TemplateType.BOSS_CHAMBER;
                size = (int)(size * 1.5);
            } else {
                double rand = rng.nextDouble();
                if (rand < 0.5) {
                    type = combatTypes[rng.nextInt(combatTypes.length)];
                } else if (rand < 0.7) {
                    type = RoomTemplate.TemplateType.TREASURE_VAULT;
                } else {
                    type = RoomTemplate.TemplateType.SECRET_GARDEN;
                }
            }
            
            RoomTemplate template;
            switch (type) {
                case ENTRY_HALL:
                    template = RoomTemplate.createEntryHall(dungeon.biome, size);
                    break;
                case BOSS_CHAMBER:
                    template = RoomTemplate.createBossChamber(dungeon.biome, size);
                    break;
                case TREASURE_VAULT:
                    template = RoomTemplate.createTreasureVault(dungeon.biome, size);
                    break;
                default:
                    template = RoomTemplate.createCombatArena(dungeon.biome, size);
                    break;
            }
            
            Room room = createRoomFromTemplate(current, template, dungeon, rng);
            if (room == null) {
                return false;
            }
            
            dungeon.rooms.add(room);
            
            if (i < roomCount - 1) {
                current = calculateNextRoomPosition(current, spacing, i, roomCount, rng);
            }
        }
        
        connectRoomsWithCorridors(dungeon);
        return true;
    }
    
    private Location calculateNextRoomPosition(Location current, int spacing, int roomIndex, int total, Random rng) {
        double angle = (2 * Math.PI * roomIndex) / total;
        angle += (rng.nextDouble() - 0.5) * Math.PI / 4;
        
        int dx = (int)(Math.cos(angle) * spacing);
        int dz = (int)(Math.sin(angle) * spacing);
        
        return current.clone().add(dx, 0, dz);
    }
    
    private Room createRoomFromTemplate(Location location, RoomTemplate template, DungeonInstance dungeon, Random rng) {
        Room room = new Room();
        room.location = location.clone();
        room.type = convertTemplateTypeToRoomType(template.getType());
        room.size = template.getWidth();
        room.cleared = (template.getType() == RoomTemplate.TemplateType.ENTRY_HALL);
        room.template = template;
        
        buildRoomStructure(room, dungeon);
        
        return room;
    }
    
    private RoomType convertTemplateTypeToRoomType(RoomTemplate.TemplateType templateType) {
        switch (templateType) {
            case ENTRY_HALL: return RoomType.ENTRY;
            case BOSS_CHAMBER: return RoomType.BOSS;
            case TREASURE_VAULT: return RoomType.TREASURE;
            case TRAP_MAZE: return RoomType.TRAP;
            case SECRET_GARDEN: return RoomType.SECRET;
            default: return RoomType.COMBAT;
        }
    }
    
    private void buildRoomStructure(Room room, DungeonInstance dungeon) {
        Location loc = room.location;
        int size = room.size;
        
        Material wallMaterial = dungeon.biome.wallMaterial;
        Material floorMaterial = dungeon.biome.floorMaterial;
        Material ceiling = Material.STONE;
        
        int height = room.template != null ? room.template.getHeight() : 6;
        
        for (int x = 0; x < size; x++) {
            for (int z = 0; z < size; z++) {
                Block floor = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() - 1, loc.getBlockZ() + z);
                floor.setType(floorMaterial);
                
                Block ceilingBlock = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() + height, loc.getBlockZ() + z);
                ceilingBlock.setType(ceiling);
            }
        }
        
        for (int y = 0; y < height; y++) {
            for (int i = 0; i < size; i++) {
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ()).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ() + size - 1).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + size - 1, loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
            }
        }
        
        for (int x = 1; x < size - 1; x++) {
            for (int z = 1; z < size - 1; z++) {
                for (int y = 0; y < height; y++) {
                    Block block = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() + y, loc.getBlockZ() + z);
                    block.setType(Material.AIR);
                }
            }
        }
        
        int lightCount = size / 4;
        for (int i = 0; i < lightCount; i++) {
            int lx = 2 + random.nextInt(size - 4);
            int lz = 2 + random.nextInt(size - 4);
            Block lightBlock = loc.getWorld().getBlockAt(loc.getBlockX() + lx, loc.getBlockY() + height - 2, loc.getBlockZ() + lz);
            lightBlock.setType(Material.GLOWSTONE);
        }
    }
    
    private void connectRoomsWithCorridors(DungeonInstance dungeon) {
        for (int i = 0; i < dungeon.rooms.size() - 1; i++) {
            Room current = dungeon.rooms.get(i);
            Room next = dungeon.rooms.get(i + 1);
            buildEnhancedCorridor(current, next, dungeon);
        }
        
        if (dungeon.rooms.size() > 3) {
            int extras = Math.min(2, dungeon.rooms.size() - 3);
            for (int i = 0; i < extras; i++) {
                int idx1 = 1 + random.nextInt(dungeon.rooms.size() - 2);
                int idx2 = 1 + random.nextInt(dungeon.rooms.size() - 2);
                if (idx1 != idx2 && Math.abs(idx1 - idx2) > 1) {
                    buildEnhancedCorridor(dungeon.rooms.get(idx1), dungeon.rooms.get(idx2), dungeon);
                }
            }
        }
    }
    
    private void buildEnhancedCorridor(Room from, Room to, DungeonInstance dungeon) {
        Location start = from.location.clone().add(from.size / 2, 0, from.size / 2);
        Location end = to.location.clone().add(to.size / 2, 0, to.size / 2);
        
        Material corridorMaterial = dungeon.biome.floorMaterial;
        Material wallMaterial = dungeon.biome.wallMaterial;
        
        int x1 = start.getBlockX();
        int z1 = start.getBlockZ();
        int x2 = end.getBlockX();
        int z2 = end.getBlockZ();
        
        int midX = (x1 + x2) / 2;
        
        for (int x = Math.min(x1, midX); x <= Math.max(x1, midX); x++) {
            buildCorridorSegment(x, start.getBlockY(), z1, corridorMaterial, wallMaterial);
        }
        
        for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
            buildCorridorSegment(midX, start.getBlockY(), z, corridorMaterial, wallMaterial);
        }
        
        for (int x = Math.min(midX, x2); x <= Math.max(midX, x2); x++) {
            buildCorridorSegment(x, start.getBlockY(), z2, corridorMaterial, wallMaterial);
        }
    }
    
    private void buildCorridorSegment(int x, int y, int z, Material floor, Material wall) {
        World world = worldManager.getSoulRealm();
        if (world == null) return;
        
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                world.getBlockAt(x + dx, y - 1, z + dz).setType(floor);
                world.getBlockAt(x + dx, y, z + dz).setType(Material.AIR);
                world.getBlockAt(x + dx, y + 1, z + dz).setType(Material.AIR);
                world.getBlockAt(x + dx, y + 2, z + dz).setType(Material.AIR);
                world.getBlockAt(x + dx, y + 4, z + dz).setType(wall);
            }
        }
        
        world.getBlockAt(x - 2, y, z).setType(wall);
        world.getBlockAt(x - 2, y + 1, z).setType(wall);
        world.getBlockAt(x - 2, y + 2, z).setType(wall);
        world.getBlockAt(x + 2, y, z).setType(wall);
        world.getBlockAt(x + 2, y + 1, z).setType(wall);
        world.getBlockAt(x + 2, y + 2, z).setType(wall);
    }
    
    private boolean validateRoomConnectivity(DungeonInstance dungeon) {
        if (dungeon.rooms.isEmpty()) return false;
        
        DungeonPathfinder.RoomGraph graph = new DungeonPathfinder.RoomGraph();
        Map<Room, DungeonPathfinder.RoomNode> roomToNode = new HashMap<>();
        
        for (Room room : dungeon.rooms) {
            DungeonPathfinder.RoomNode node = new DungeonPathfinder.RoomNode(
                room.location.toString(),
                room.location.clone().add(room.size / 2, 0, room.size / 2),
                room.size,
                room.size
            );
            graph.addNode(node);
            roomToNode.put(room, node);
        }
        
        for (int i = 0; i < dungeon.rooms.size() - 1; i++) {
            Room current = dungeon.rooms.get(i);
            Room next = dungeon.rooms.get(i + 1);
            graph.connect(roomToNode.get(current), roomToNode.get(next));
        }
        
        boolean isConnected = graph.validateFullConnectivity();
        
        if (!isConnected) {
            plugin.getLogger().warning("Dungeon connectivity validation failed!");
        }
        
        return isConnected;
    }
    
    private void populateRoomsAdvanced(DungeonInstance dungeon) {
        for (int i = 0; i < dungeon.rooms.size(); i++) {
            Room room = dungeon.rooms.get(i);
            boolean isBossRoom = (i == dungeon.rooms.size() - 1);
            
            switch (room.type) {
                case COMBAT:
                    spawnTieredMobs(room, dungeon, false);
                    break;
                case TREASURE:
                    spawnEnhancedChests(room, dungeon);
                    spawnTieredMobs(room, dungeon, false);
                    break;
                case TRAP:
                    createAdvancedTraps(room, dungeon);
                    spawnTieredMobs(room, dungeon, false);
                    break;
                case BOSS:
                    spawnMultiPhaseBoss(room, dungeon);
                    break;
                case SECRET:
                    spawnSecretRewards(room, dungeon);
                    break;
            }
        }
    }
    
    private void spawnTieredMobs(Room room, DungeonInstance dungeon, boolean isElite) {
        int baseMobCount = 4 + random.nextInt(6);
        int partyScaling = (int)((dungeon.partySize - 1) * 2.5);
        int mobCount = baseMobCount + partyScaling;
        
        MobTier tier = getMobTierForDifficulty(dungeon.difficulty);
        
        for (int i = 0; i < mobCount; i++) {
            Location spawnLoc = room.location.clone().add(
                3 + random.nextInt(room.size - 6),
                0,
                3 + random.nextInt(room.size - 6)
            );
            
            EntityType mobType = selectMobFromTier(tier, dungeon.biome);
            LivingEntity mob = spawnEnhancedMob(spawnLoc, mobType, dungeon, isElite || random.nextDouble() < 0.15);
            
            if (mob != null) {
                room.entities.add(mob.getUniqueId());
                dungeon.totalMobs++;
            }
        }
    }
    
    private MobTier getMobTierForDifficulty(String difficulty) {
        switch (difficulty) {
            case "easy": return MobTier.TIER_1;
            case "medium": return MobTier.TIER_2;
            case "hard": return MobTier.TIER_3;
            case "nightmare": return MobTier.TIER_4;
            case "chaos": return MobTier.TIER_5;
            default: return MobTier.TIER_1;
        }
    }
    
    private EntityType selectMobFromTier(MobTier tier, RoomTemplate.BiomeTheme biome) {
        List<EntityType> tierMobs = tier.getMobs();
        return tierMobs.get(random.nextInt(tierMobs.size()));
    }
    
    private LivingEntity spawnEnhancedMob(Location loc, EntityType type, DungeonInstance dungeon, boolean isElite) {
        try {
            LivingEntity mob = (LivingEntity) loc.getWorld().spawnEntity(loc, type);
            if (mob == null) return null;
            
            double multiplier = dungeon.config.mobLevelMultiplier * (1.0 + (dungeon.partySize - 1) * 0.4);
            if (isElite) multiplier *= 1.8;
            
            if (mob.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                double health = mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() * multiplier;
                mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
                mob.setHealth(health);
            }
            
            if (mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
                double damage = mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).getValue() * multiplier;
                mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
            }
            
            if (mob.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
                double speed = mob.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).getValue() * 1.15;
                mob.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(speed);
            }
            
            String prefix = isElite ? "§6§l[ELITE] " : "§c";
            int level = (int)(dungeon.config.requiredLevel * multiplier);
            mob.setCustomName(prefix + "[Lv" + level + "] " + type.name().replace("_", " "));
            mob.setCustomNameVisible(true);
            
            if (isElite) {
                mob.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, false, false));
                mob.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, false, false));
                mob.setGlowing(true);
            }
            
            return mob;
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to spawn enhanced mob: " + type + " - " + e.getMessage());
            return null;
        }
    }
    
    private void spawnMultiPhaseBoss(Room room, DungeonInstance dungeon) {
        Location bossLoc = room.location.clone().add(room.size / 2, 0, room.size / 2);
        
        BossData bossData = getBossDataForDifficulty(dungeon.difficulty);
        
        try {
            LivingEntity boss = (LivingEntity) room.location.getWorld().spawnEntity(bossLoc, bossData.type);
            if (boss == null) return;
            
            double healthMultiplier = dungeon.config.mobLevelMultiplier * 3.5 * (1.0 + (dungeon.partySize - 1) * 0.6);
            
            if (boss.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                double health = bossData.baseHealth * healthMultiplier;
                boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
                boss.setHealth(health);
            }
            
            if (boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
                double damage = bossData.baseDamage * healthMultiplier * 0.6;
                boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
            }
            
            if (boss.getAttribute(Attribute.GENERIC_KNOCKBACK_RESISTANCE) != null) {
                boss.getAttribute(Attribute.GENERIC_KNOCKBACK_RESISTANCE).setBaseValue(0.8);
            }
            
            boss.setCustomName(bossData.name);
            boss.setCustomNameVisible(true);
            boss.setGlowing(true);
            
            boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, false, false));
            boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, false, false));
            boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false));
            
            room.entities.add(boss.getUniqueId());
            dungeon.bossId = boss.getUniqueId();
            dungeon.totalMobs++;
            
            startBossPhaseSystem(boss, dungeon, bossData);
            
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to spawn boss: " + e.getMessage());
        }
    }
    
    private void startBossPhaseSystem(LivingEntity boss, DungeonInstance dungeon, BossData bossData) {
        new BukkitRunnable() {
            int phase = 1;
            double lastHealthPercent = 100.0;
            
            @Override
            public void run() {
                if (boss.isDead() || !boss.isValid()) {
                    this.cancel();
                    return;
                }
                
                double currentHealth = boss.getHealth();
                double maxHealth = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
                double healthPercent = (currentHealth / maxHealth) * 100.0;
                
                if (healthPercent < 70 && phase == 1) {
                    phase = 2;
                    triggerBossPhase2(boss, dungeon);
                } else if (healthPercent < 40 && phase == 2) {
                    phase = 3;
                    triggerBossPhase3(boss, dungeon);
                } else if (healthPercent < 15 && phase == 3) {
                    phase = 4;
                    triggerBossEnrage(boss, dungeon);
                }
                
                lastHealthPercent = healthPercent;
            }
        }.runTaskTimer(plugin, 40L, 40L);
    }
    
    private void triggerBossPhase2(LivingEntity boss, DungeonInstance dungeon) {
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle("§c§lPHASE 2", "§eThe boss grows stronger!", 10, 50, 10);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.8f);
            }
        }
        
        boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 3, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, false, false));
        
        spawnBossMiniions(boss.getLocation(), dungeon, 3);
    }
    
    private void triggerBossPhase3(LivingEntity boss, DungeonInstance dungeon) {
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle("§4§lPHASE 3", "§cDangerous abilities activated!", 10, 50, 10);
                player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.0f);
            }
        }
        
        boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1, false, false));
        
        spawnBossMiniions(boss.getLocation(), dungeon, 5);
    }
    
    private void triggerBossEnrage(LivingEntity boss, DungeonInstance dungeon) {
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle("§4§l§k!!!§r §4ENRAGED §k!!!", "§cFINAL STAND!", 10, 60, 10);
                player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 1.0f, 0.5f);
            }
        }
        
        boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 5, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 3, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        
        boss.getWorld().createExplosion(boss.getLocation(), 0.0f, false, false);
    }
    
    private void spawnBossMiniions(Location bossLoc, DungeonInstance dungeon, int count) {
        MobTier tier = getMobTierForDifficulty(dungeon.difficulty);
        
        for (int i = 0; i < count; i++) {
            Location minionLoc = bossLoc.clone().add(
                (random.nextDouble() - 0.5) * 10,
                0,
                (random.nextDouble() - 0.5) * 10
            );
            
            EntityType mobType = selectMobFromTier(tier, dungeon.biome);
            spawnEnhancedMob(minionLoc, mobType, dungeon, true);
        }
    }
    
    private BossData getBossDataForDifficulty(String difficulty) {
        BossData data = new BossData();
        switch (difficulty) {
            case "easy":
                data.type = EntityType.ZOMBIE;
                data.name = "§c§l[BOSS] Crypt Guardian";
                data.baseHealth = 300;
                data.baseDamage = 15;
                break;
            case "medium":
                data.type = EntityType.SKELETON;
                data.name = "§c§l[BOSS] Bone Lord";
                data.baseHealth = 600;
                data.baseDamage = 25;
                break;
            case "hard":
                data.type = EntityType.WITHER_SKELETON;
                data.name = "§c§l[BOSS] Shadow Reaper";
                data.baseHealth = 1200;
                data.baseDamage = 40;
                break;
            case "nightmare":
                data.type = EntityType.RAVAGER;
                data.name = "§4§l[BOSS] Nightmare Beast";
                data.baseHealth = 2500;
                data.baseDamage = 60;
                break;
            case "chaos":
                data.type = EntityType.WARDEN;
                data.name = "§4§l§k[§r§4§lCHAOS LORD§k]";
                data.baseHealth = 5000;
                data.baseDamage = 100;
                break;
            default:
                data.type = EntityType.ZOMBIE;
                data.name = "§c§l[BOSS] Unknown";
                data.baseHealth = 200;
                data.baseDamage = 10;
        }
        return data;
    }
    
    private void spawnEnhancedChests(Room room, DungeonInstance dungeon) {
        int chestCount = 3 + random.nextInt(4) + (int)(dungeon.config.lootMultiplier / 2);
        
        for (int i = 0; i < chestCount; i++) {
            Location chestLoc = room.location.clone().add(
                3 + random.nextInt(room.size - 6),
                0,
                3 + random.nextInt(room.size - 6)
            );
            
            Block block = chestLoc.getBlock();
            block.setType(random.nextDouble() < 0.3 ? Material.ENDER_CHEST : Material.CHEST);
            
            if (block.getState() instanceof Chest) {
                Chest chest = (Chest) block.getState();
                populateEnhancedChest(chest, dungeon);
                room.chests.add(chestLoc);
            }
        }
    }
    
    private void populateEnhancedChest(Chest chest, DungeonInstance dungeon) {
        int itemCount = 5 + random.nextInt(8);
        double lootMult = dungeon.config.lootMultiplier;
        
        for (int i = 0; i < itemCount; i++) {
            double roll = random.nextDouble();
            ItemStack item = null;
            
            if (roll < 0.15 * lootMult) {
                item = new ItemStack(Material.DIAMOND, 2 + random.nextInt(6));
            } else if (roll < 0.25 * lootMult) {
                item = new ItemStack(Material.EMERALD, 3 + random.nextInt(10));
            } else if (roll < 0.35 * lootMult) {
                item = new ItemStack(Material.GOLD_INGOT, 5 + random.nextInt(15));
            } else if (roll < 0.45) {
                Material[] enchantedItems = {
                    Material.DIAMOND_SWORD, Material.DIAMOND_PICKAXE, 
                    Material.DIAMOND_AXE, Material.BOW
                };
                item = new ItemStack(enchantedItems[random.nextInt(enchantedItems.length)]);
                addRandomEnchantments(item, dungeon.difficulty);
            } else if (roll < 0.55) {
                Material[] armor = {
                    Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE,
                    Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS
                };
                item = new ItemStack(armor[random.nextInt(armor.length)]);
                addRandomEnchantments(item, dungeon.difficulty);
            } else {
                Material[] basic = {Material.IRON_INGOT, Material.COAL, Material.REDSTONE, 
                                   Material.LAPIS_LAZULI, Material.QUARTZ};
                item = new ItemStack(basic[random.nextInt(basic.length)], 10 + random.nextInt(30));
            }
            
            if (item != null) {
                chest.getInventory().addItem(item);
            }
        }
        
        chest.update();
    }
    
    private void addRandomEnchantments(ItemStack item, String difficulty) {
        int enchantCount = 1;
        int enchantLevel = 1;
        
        switch (difficulty) {
            case "medium":
                enchantCount = 2;
                enchantLevel = 2;
                break;
            case "hard":
                enchantCount = 3;
                enchantLevel = 3;
                break;
            case "nightmare":
                enchantCount = 4;
                enchantLevel = 4;
                break;
            case "chaos":
                enchantCount = 5;
                enchantLevel = 5;
                break;
        }
        
        List<Enchantment> possibleEnchants = getPossibleEnchantments(item.getType());
        Collections.shuffle(possibleEnchants);
        
        for (int i = 0; i < Math.min(enchantCount, possibleEnchants.size()); i++) {
            Enchantment enchant = possibleEnchants.get(i);
            int level = Math.min(enchantLevel, enchant.getMaxLevel());
            item.addUnsafeEnchantment(enchant, level);
        }
    }
    
    private List<Enchantment> getPossibleEnchantments(Material material) {
        List<Enchantment> enchants = new ArrayList<>();
        
        if (material.name().contains("SWORD")) {
            enchants.addAll(Arrays.asList(
                Enchantment.SHARPNESS, Enchantment.BANE_OF_ARTHROPODS, Enchantment.SMITE,
                Enchantment.FIRE_ASPECT, Enchantment.KNOCKBACK, Enchantment.SWEEPING_EDGE
            ));
        } else if (material.name().contains("BOW")) {
            enchants.addAll(Arrays.asList(
                Enchantment.POWER, Enchantment.FLAME, Enchantment.PUNCH,
                Enchantment.INFINITY
            ));
        } else if (material.name().contains("HELMET") || material.name().contains("CHESTPLATE") ||
                   material.name().contains("LEGGINGS") || material.name().contains("BOOTS")) {
            enchants.addAll(Arrays.asList(
                Enchantment.PROTECTION, Enchantment.FIRE_PROTECTION,
                Enchantment.BLAST_PROTECTION, Enchantment.PROJECTILE_PROTECTION,
                Enchantment.THORNS
            ));
        } else if (material.name().contains("PICKAXE") || material.name().contains("AXE") ||
                   material.name().contains("SHOVEL")) {
            enchants.addAll(Arrays.asList(
                Enchantment.EFFICIENCY, Enchantment.FORTUNE, Enchantment.UNBREAKING
            ));
        }
        
        if (enchants.isEmpty()) {
            enchants.add(Enchantment.UNBREAKING);
        }
        
        return enchants;
    }
    
    private void createAdvancedTraps(Room room, DungeonInstance dungeon) {
        int trapCount = 4 + random.nextInt(6);
        
        for (int i = 0; i < trapCount; i++) {
            Location trapLoc = room.location.clone().add(
                2 + random.nextInt(room.size - 4),
                0,
                2 + random.nextInt(room.size - 4)
            );
            
            double trapType = random.nextDouble();
            if (trapType < 0.25) {
                trapLoc.getBlock().setType(Material.TNT);
            } else if (trapType < 0.45) {
                trapLoc.getBlock().setType(Material.MAGMA_BLOCK);
            } else if (trapType < 0.65) {
                trapLoc.getBlock().setType(Material.COBWEB);
            } else if (trapType < 0.80) {
                trapLoc.getBlock().setType(Material.SOUL_SAND);
                trapLoc.clone().add(0, 1, 0).getBlock().setType(Material.FIRE);
            } else {
                trapLoc.getBlock().setType(Material.TRIPWIRE);
            }
        }
    }
    
    private void spawnSecretRewards(Room room, DungeonInstance dungeon) {
        Location center = room.location.clone().add(room.size / 2, 0, room.size / 2);
        Block block = center.getBlock();
        block.setType(Material.CHEST);
        
        if (block.getState() instanceof Chest) {
            Chest chest = (Chest) block.getState();
            
            chest.getInventory().addItem(new ItemStack(Material.DIAMOND, 5 + random.nextInt(10)));
            chest.getInventory().addItem(new ItemStack(Material.EMERALD, 10 + random.nextInt(20)));
            chest.getInventory().addItem(new ItemStack(Material.GOLD_INGOT, 15 + random.nextInt(30)));
            
            ItemStack enchantedBook = new ItemStack(Material.ENCHANTED_BOOK);
            chest.getInventory().addItem(enchantedBook);
            
            chest.update();
            room.chests.add(center);
        }
    }
    
    private int getTimeLimit(String difficulty) {
        switch (difficulty) {
            case "easy": return TIME_LIMIT_EASY;
            case "medium": return TIME_LIMIT_MEDIUM;
            case "hard": return TIME_LIMIT_HARD;
            case "nightmare": return TIME_LIMIT_NIGHTMARE;
            case "chaos": return TIME_LIMIT_CHAOS;
            default: return 1200;
        }
    }
    
    private void teleportToDungeon(Player player, DungeonInstance dungeon) {
        Location spawnLoc = dungeon.entranceLocation.clone().add(
            dungeon.rooms.get(0).size / 2,
            1,
            dungeon.rooms.get(0).size / 2
        );
        player.teleport(spawnLoc);
    }
    
    private void startDungeonTimer(DungeonInstance dungeon) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!activeDungeons.containsKey(dungeon.instanceId)) {
                    this.cancel();
                    return;
                }
                
                long elapsed = (System.currentTimeMillis() - dungeon.startTime) / 1000;
                long remaining = dungeon.timeLimit - elapsed;
                
                if (remaining <= 0) {
                    failDungeon(dungeon);
                    this.cancel();
                    return;
                }
                
                if (remaining % 300 == 0 && remaining > 0) {
                    for (UUID playerId : dungeon.players) {
                        Player player = Bukkit.getPlayer(playerId);
                        if (player != null) {
                            player.sendMessage("§e§l✦ Time Remaining: §c" + (remaining / 60) + " minutes");
                        }
                    }
                }
                
                if (dungeon.bossId != null) {
                    org.bukkit.entity.Entity bossEntity = Bukkit.getEntity(dungeon.bossId);
                    if (bossEntity == null || bossEntity.isDead()) {
                        completeDungeon(dungeon);
                        this.cancel();
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }
    
    private void failDungeon(DungeonInstance dungeon) {
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle("§c§lDUNGEON FAILED", "§7Time ran out!", 20, 100, 20);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_DEATH, 1.0f, 0.5f);
                player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            }
        }
        
        cleanupDungeon(dungeon);
    }
    
    private void completeDungeon(DungeonInstance dungeon) {
        long completionTime = (System.currentTimeMillis() - dungeon.startTime) / 1000;
        
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle("§a§lDUNGEON COMPLETE!", "§eVictory!", 20, 100, 20);
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                
                giveRewards(player, dungeon, completionTime);
                
                player.sendMessage("§5§l§m━━━━━━━━━━━━━━━━━━━━━");
                player.sendMessage("§6§l✦ DUNGEON COMPLETED ✦");
                player.sendMessage("§7Difficulty: §e" + dungeon.difficulty.toUpperCase());
                player.sendMessage("§7Time: §e" + (completionTime / 60) + "m " + (completionTime % 60) + "s");
                player.sendMessage("§7Mobs Killed: §e" + dungeon.mobsKilled);
                player.sendMessage("§5§l§m━━━━━━━━━━━━━━━━━━━━━");
                
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                }, 100L);
            }
        }
        
        cleanupDungeon(dungeon);
    }
    
    private void giveRewards(Player player, DungeonInstance dungeon, long completionTime) {
        double partyMultiplier = 1.0 + (dungeon.partySize - 1) * 0.2;
        double speedBonus = completionTime < dungeon.timeLimit / 2 ? 1.5 : 1.0;
        
        long souls = (long)(dungeon.config.soulReward * partyMultiplier * speedBonus);
        long xp = (long)(dungeon.config.xpReward * partyMultiplier * speedBonus);
        
        economyService.deposit(player.getUniqueId(), souls, "Dungeon reward");
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        data.setExperience(data.getExperience() + xp);
        dataStore.savePlayerData(player.getUniqueId());
        
        player.sendMessage("§6§l+ " + souls + " Souls");
        player.sendMessage("§a§l+ " + xp + " XP");
        
        if (speedBonus > 1.0) {
            player.sendMessage("§e§l★ Speed Bonus: §a+50%");
        }
        
        if (missionService != null) {
            missionService.progressMission(player.getUniqueId(), com.soulcraft.missions.MissionService.MissionType.COMPLETE_DUNGEONS, 1);
        }
    }
    
    private void cleanupDungeon(DungeonInstance dungeon) {
        activeDungeons.remove(dungeon.instanceId);
        worldManager.cleanupInstance(dungeon.instanceId);
    }
    
    public boolean isInDungeon(UUID playerId) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            if (dungeon.players.contains(playerId)) {
                return true;
            }
        }
        return false;
    }
    
    public void leaveDungeon(Player player) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            if (dungeon.players.remove(player.getUniqueId())) {
                player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                player.sendMessage("§7You left the dungeon.");
                
                if (dungeon.players.isEmpty()) {
                    cleanupDungeon(dungeon);
                }
                return;
            }
        }
    }
    
    public void onMobKilled(UUID mobId) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            for (Room room : dungeon.rooms) {
                if (room.entities.contains(mobId)) {
                    dungeon.mobsKilled++;
                    room.entities.remove(mobId);
                    
                    boolean roomCleared = true;
                    for (UUID entityId : room.entities) {
                        org.bukkit.entity.Entity entity = Bukkit.getEntity(entityId);
                        if (entity != null && entity.isValid() && !entity.isDead()) {
                            roomCleared = false;
                            break;
                        }
                    }
                    
                    if (roomCleared && !room.cleared) {
                        room.cleared = true;
                        dungeon.roomsCleared++;
                        
                        for (UUID playerId : dungeon.players) {
                            Player player = Bukkit.getPlayer(playerId);
                            if (player != null) {
                                player.sendMessage("§a§l✓ Room Cleared! §7(" + dungeon.roomsCleared + "/" + dungeon.rooms.size() + ")");
                                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
                            }
                        }
                    }
                    
                    return;
                }
            }
        }
    }
    
    private void startDungeonTimers() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (DungeonInstance dungeon : new ArrayList<>(activeDungeons.values())) {
                    long elapsed = (System.currentTimeMillis() - dungeon.startTime) / 1000;
                    if (elapsed > dungeon.timeLimit + 60) {
                        cleanupDungeon(dungeon);
                    }
                }
            }
        }.runTaskTimer(plugin, 200L, 200L);
    }
    
    public DungeonParty createParty(Player leader) {
        if (playerParties.containsKey(leader.getUniqueId())) {
            return null;
        }
        
        String partyId = UUID.randomUUID().toString();
        DungeonParty party = new DungeonParty();
        party.id = partyId;
        party.leader = leader.getUniqueId();
        party.members.add(leader.getUniqueId());
        party.createdTime = System.currentTimeMillis();
        parties.put(partyId, party);
        playerParties.put(leader.getUniqueId(), partyId);
        return party;
    }
    
    public boolean inviteToParty(Player inviter, Player target) {
        String partyId = playerParties.get(inviter.getUniqueId());
        if (partyId == null) {
            inviter.sendMessage("§c§lYou are not in a party!");
            return false;
        }
        
        DungeonParty party = parties.get(partyId);
        if (party == null) return false;
        
        if (!party.leader.equals(inviter.getUniqueId())) {
            inviter.sendMessage("§c§lOnly the party leader can invite players!");
            return false;
        }
        
        if (party.members.size() >= 5) {
            inviter.sendMessage("§c§lParty is full! (Max 5 players)");
            return false;
        }
        
        if (playerParties.containsKey(target.getUniqueId())) {
            inviter.sendMessage("§c§l" + target.getName() + " is already in a party!");
            return false;
        }
        
        if (pendingInvites.containsKey(target.getUniqueId())) {
            inviter.sendMessage("§c§l" + target.getName() + " already has a pending invite!");
            return false;
        }
        
        PartyInvite invite = new PartyInvite();
        invite.partyId = partyId;
        invite.inviter = inviter.getUniqueId();
        invite.target = target.getUniqueId();
        invite.timestamp = System.currentTimeMillis();
        pendingInvites.put(target.getUniqueId(), invite);
        
        inviter.sendMessage("§a§l✓ Invited " + target.getName() + " to your party!");
        target.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
        target.sendMessage("§e§l✦ PARTY INVITE ✦");
        target.sendMessage("§7" + inviter.getName() + " invited you to their dungeon party!");
        target.sendMessage("§a/dungeon party accept §7- Accept invite");
        target.sendMessage("§c/dungeon party decline §7- Decline invite");
        target.sendMessage("§7Expires in 60 seconds");
        target.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
        target.playSound(target.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        
        new BukkitRunnable() {
            @Override
            public void run() {
                PartyInvite current = pendingInvites.get(target.getUniqueId());
                if (current != null && current.timestamp == invite.timestamp) {
                    pendingInvites.remove(target.getUniqueId());
                    target.sendMessage("§c§lParty invite expired!");
                }
            }
        }.runTaskLater(plugin, 1200L);
        
        return true;
    }
    
    public boolean acceptPartyInvite(Player player) {
        PartyInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            player.sendMessage("§c§lYou don't have any pending party invites!");
            return false;
        }
        
        DungeonParty party = parties.get(invite.partyId);
        if (party == null) {
            player.sendMessage("§c§lThis party no longer exists!");
            return false;
        }
        
        if (party.members.size() >= 5) {
            player.sendMessage("§c§lThis party is now full!");
            return false;
        }
        
        party.members.add(player.getUniqueId());
        playerParties.put(player.getUniqueId(), party.id);
        
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage("§a§l✓ " + player.getName() + " joined the party! §7(" + party.members.size() + "/5)");
                member.playSound(member.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
            }
        }
        
        return true;
    }
    
    public boolean declinePartyInvite(Player player) {
        PartyInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            player.sendMessage("§c§lYou don't have any pending party invites!");
            return false;
        }
        
        player.sendMessage("§7You declined the party invite.");
        
        Player inviter = Bukkit.getPlayer(invite.inviter);
        if (inviter != null) {
            inviter.sendMessage("§c" + player.getName() + " declined your party invite.");
        }
        
        return true;
    }
    
    public boolean leaveParty(Player player) {
        String partyId = playerParties.remove(player.getUniqueId());
        if (partyId == null) {
            player.sendMessage("§c§lYou are not in a party!");
            return false;
        }
        
        DungeonParty party = parties.get(partyId);
        if (party == null) return false;
        
        party.members.remove(player.getUniqueId());
        
        if (party.leader.equals(player.getUniqueId())) {
            if (party.members.isEmpty()) {
                parties.remove(partyId);
            } else {
                UUID newLeader = party.members.iterator().next();
                party.leader = newLeader;
                
                Player newLeaderPlayer = Bukkit.getPlayer(newLeader);
                if (newLeaderPlayer != null) {
                    newLeaderPlayer.sendMessage("§e§lYou are now the party leader!");
                }
            }
        }
        
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage("§c" + player.getName() + " left the party. §7(" + party.members.size() + "/5)");
            }
        }
        
        player.sendMessage("§7You left the party.");
        return true;
    }
    
    public DungeonParty getPlayerParty(Player player) {
        String partyId = playerParties.get(player.getUniqueId());
        return partyId != null ? parties.get(partyId) : null;
    }
    
    public boolean startPartyDungeon(DungeonParty party, String difficulty) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) return false;
        
        List<Player> onlineMembers = new ArrayList<>();
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null && member.isOnline()) {
                PlayerData data = dataStore.loadPlayerData(memberId);
                if (data.getLevel() < config.requiredLevel) {
                    member.sendMessage("§c§lYou need level " + config.requiredLevel + "!");
                    return false;
                }
                onlineMembers.add(member);
            }
        }
        
        DungeonInstance dungeon = generateDungeon(difficulty, new ArrayList<>(party.members));
        if (dungeon == null) {
            return false;
        }
        
        dungeon.partySize = party.members.size();
        activeDungeons.put(dungeon.instanceId, dungeon);
        
        for (Player member : onlineMembers) {
            teleportToDungeon(member, dungeon);
            member.sendMessage("§5§l✦ Party Dungeon Started!");
        }
        
        startDungeonTimer(dungeon);
        return true;
    }
    
    public Map<String, DungeonInstance> getActiveDungeons() {
        return activeDungeons;
    }
    
    public void shutdown() {
        for (DungeonInstance dungeon : new ArrayList<>(activeDungeons.values())) {
            for (UUID playerId : dungeon.players) {
                Player player = Bukkit.getPlayer(playerId);
                if (player != null) {
                    player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                }
            }
            cleanupDungeon(dungeon);
        }
        
        worldManager.shutdown();
    }
    
    public static class DifficultyConfig {
        public String id;
        public int requiredLevel;
        public int baseRoomSize;
        public int roomCount;
        public double mobLevelMultiplier;
        public double lootMultiplier;
        public long soulReward;
        public long xpReward;
    }
    
    public static class DungeonInstance {
        public String instanceId;
        public String difficulty;
        public DifficultyConfig config;
        public RoomTemplate.BiomeTheme biome;
        public Set<UUID> players;
        public List<Room> rooms = new ArrayList<>();
        public long startTime;
        public int timeLimit;
        public int partySize;
        public int roomsCleared = 0;
        public int mobsKilled = 0;
        public int totalMobs = 0;
        public UUID bossId;
        public Location entranceLocation;
    }
    
    public static class Room {
        public Location location;
        public RoomType type;
        public int size;
        public boolean cleared;
        public List<UUID> entities = new ArrayList<>();
        public List<Location> chests = new ArrayList<>();
        public RoomTemplate template;
    }
    
    public enum RoomType {
        ENTRY, COMBAT, TREASURE, TRAP, BOSS, SECRET
    }
    
    public static class DungeonParty {
        public String id;
        public UUID leader;
        public Set<UUID> members = new HashSet<>();
        public long createdTime;
    }
    
    public static class PartyInvite {
        public String partyId;
        public UUID inviter;
        public UUID target;
        public long timestamp;
    }
    
    public static class BiomeConfig {
        public String name;
        public String theme;
        public List<String> mobs;
    }
    
    public static class BossData {
        public EntityType type;
        public String name;
        public double baseHealth;
        public double baseDamage;
    }
    
    public enum MobTier {
        TIER_1(Arrays.asList(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER)),
        TIER_2(Arrays.asList(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CAVE_SPIDER, EntityType.CREEPER)),
        TIER_3(Arrays.asList(EntityType.WITHER_SKELETON, EntityType.BLAZE, EntityType.ENDERMAN, EntityType.STRAY)),
        TIER_4(Arrays.asList(EntityType.PIGLIN_BRUTE, EntityType.RAVAGER, EntityType.VEX, EntityType.PHANTOM)),
        TIER_5(Arrays.asList(EntityType.PIGLIN_BRUTE, EntityType.RAVAGER, EntityType.HOGLIN, EntityType.ZOGLIN));
        
        private final List<EntityType> mobs;
        
        MobTier(List<EntityType> mobs) {
            this.mobs = mobs;
        }
        
        public List<EntityType> getMobs() {
            return mobs;
        }
    }
}
