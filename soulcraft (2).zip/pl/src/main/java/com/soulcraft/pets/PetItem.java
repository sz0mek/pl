package com.soulcraft.pets;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class PetItem {
    
    private static final Map<String, PetItemData> PET_ITEMS = new HashMap<>();
    
    static {
        PET_ITEMS.put("soul_wolf", new PetItemData(
            "§5§lWILK DUSZ",
            Material.BONE,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §dWilk Dusz",
                "§7Typ: §eAtakujący",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +10% DMG",
                "§a• +5% Szybkość ataku",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("dragon_spirit", new PetItemData(
            "§4§lDUCH SMOKA",
            Material.DRAGON_BREATH,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §4Duch Smoka",
                "§7Typ: §eMagiczny",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +15% EXP",
                "§a• +10% Regeneracja HP",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("chaos_cat", new PetItemData(
            "§6§lKOT CHAOSU",
            Material.STRING,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §6Kot Chaosu",
                "§7Typ: §eSzybki",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +20% Szybkość biegu",
                "§a• +10% Unik",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("void_phantom", new PetItemData(
            "§0§lFANTOM PUSTKI",
            Material.PHANTOM_MEMBRANE,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §0Fantom Pustki",
                "§7Typ: §eMroczny",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +15% DMG w nocy",
                "§a• +10% Dusz z mobów",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("fire_phoenix", new PetItemData(
            "§c§lFENIKS OGNIA",
            Material.BLAZE_POWDER,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §cFeniks Ognia",
                "§7Typ: §eŻywiołowy",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• Odporność na ogień",
                "§a• +15% DMG od ognia",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("ice_guardian", new PetItemData(
            "§b§lSTRAŻNIK LODU",
            Material.ICE,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §bStrażnik Lodu",
                "§7Typ: §eObrońca",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +10% DEF",
                "§a• Spowolnienie wrogów",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("thunder_bird", new PetItemData(
            "§e§lPTAK PIORUNÓW",
            Material.FEATHER,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §ePtak Piorunów",
                "§7Typ: §eŻywiołowy",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• Szansa na piorun przy ataku",
                "§a• +15% Krytyczny cios",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("earth_golem", new PetItemData(
            "§2§lGOLEM ZIEMI",
            Material.MOSSY_COBBLESTONE,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §2Golem Ziemi",
                "§7Typ: §eTankujący",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +20% HP",
                "§a• +5% Regeneracja",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("shadow_raven", new PetItemData(
            "§8§lWRONA CIENI",
            Material.BLACK_DYE,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §8Wrona Cieni",
                "§7Typ: §eMroczny",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +12% Szansa na dodge",
                "§a• +10% Kradzione HP",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
        
        PET_ITEMS.put("light_fairy", new PetItemData(
            "§f§lWIĘŻNIATA ŚWIATŁA",
            Material.GLOWSTONE_DUST,
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Pet: §fWięźniata Światła",
                "§7Typ: §eLeczący",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Bonusy:",
                "§a• +15% Efektywność leczenia",
                "§a• Pasywna regeneracja HP",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ PPM aby aktywować"
            )
        ));
    }
    
    public static ItemStack createPetItem(String petId) {
        PetItemData data = PET_ITEMS.get(petId);
        if (data == null) return null;
        
        ItemStack item = new ItemStack(data.material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(data.displayName);
        meta.setLore(data.lore);
        
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(org.bukkit.Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), "pet-id"),
            org.bukkit.persistence.PersistentDataType.STRING,
            petId
        );
        
        item.setItemMeta(meta);
        return item;
    }
    
    public static String getPetId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        
        org.bukkit.NamespacedKey key = new org.bukkit.NamespacedKey(
            org.bukkit.Bukkit.getPluginManager().getPlugin("SoulCraftPlugin"), "pet-id");
        
        return item.getItemMeta().getPersistentDataContainer().get(key, org.bukkit.persistence.PersistentDataType.STRING);
    }
    
    private static class PetItemData {
        String displayName;
        Material material;
        java.util.List<String> lore;
        
        PetItemData(String displayName, Material material, java.util.List<String> lore) {
            this.displayName = displayName;
            this.material = material;
            this.lore = lore;
        }
    }
}
