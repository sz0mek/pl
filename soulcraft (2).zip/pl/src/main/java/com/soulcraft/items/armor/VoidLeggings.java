package com.soulcraft.items.armor;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class VoidLeggings extends CustomItem {
    public VoidLeggings(SoulCraftPlugin plugin) {
        super(
            "void_leggings",
            "§5§lSpodnie Pustki",
            Material.NETHERITE_LEGGINGS,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Pancerz Otchłani§7│",
                "§7│ §fBonusy:          §7│",
                "§7│ §dPrędkość II     §7│",
                "§7│ §5Odporność        §7│",
                "§7│ §5+18 Ochrony     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §5Pustka daje moc",
                "§d⚔ Model: 2003"
            ),
            2003
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 300, 1));
            player.sendMessage("§5§l✦ Pustka przyspiesza twoje kroki!");
            event.setCancelled(true);
        }
    }
}
