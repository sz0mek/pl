package com.soulcraft.clans;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.clans.ClanService;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ClanGUI implements InventoryHolder {
    
    private final SoulCraftPlugin plugin;
    private final ClanService clanService;
    private final DataStore dataStore;
    
    public ClanGUI(SoulCraftPlugin plugin, ClanService clanService, DataStore dataStore) {
        this.plugin = plugin;
        this.clanService = clanService;
        this.dataStore = dataStore;
    }
    
    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(this, 54, "§c§l❖ SYSTEM KLANÓW ❖");
        
        fillBorders(inv);
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        String clanId = data.getClanId();
        
        if (clanId != null && !clanId.isEmpty()) {
            openClanManagement(player, clanId);
        } else {
            ItemStack create = createItem(Material.EMERALD_BLOCK,
                "§a§l+ STWÓRZ KLAN",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Stwórz własny klan!",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Koszt: §e1000 hajsu",
                    "§7Minimalna długość nazwy: §e3 znaki",
                    "§7Maksymalna długość nazwy: §e16 znaków",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§a§l➤ KLIKNIJ ABY STWORZYĆ"
                ));
            inv.setItem(21, create);
            
            ItemStack list = createItem(Material.BOOK,
                "§e§l📋 LISTA KLANÓW",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Przeglądaj dostępne klany",
                    "§7i dołącz do jednego z nich!",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§a§l➤ KLIKNIJ ABY PRZEGLĄDAĆ"
                ));
            inv.setItem(23, list);
            
            ItemStack info = createItem(Material.KNOWLEDGE_BOOK,
                "§b§l📖 INFORMACJE O KLANACH",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Klany to grupy graczy",
                    "§7którzy wspólnie grają!",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Korzyści:",
                    "§a• Wspólny skarbiec",
                    "§a• System leveli klanu",
                    "§a• Baza klanu (chunk)",
                    "§a• Wojny klanowe",
                    "§a• Ranking klanów",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
                ));
            inv.setItem(40, info);
        }
        
        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);
    }
    
    public void openClanManagement(Player player, String clanName) {
        Inventory inv = Bukkit.createInventory(this, 54, "§c§l❖ KLAN: §e" + clanName + " §c❖");
        
        fillBorders(inv);
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        boolean isLeader = false;
        
        ItemStack clanInfo = createItem(Material.WHITE_BANNER,
            "§c§lINFORMACJE O KLANIE",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Nazwa: §e" + clanName,
                "§7Poziom: §a" + getClanLevel(clanName),
                "§7Członków: §b" + getClanMemberCount(clanName) + "§7/§b20",
                "§7Skarbiec: §6" + getClanTreasury(clanName) + " hajsu",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(4, clanInfo);
        
        ItemStack members = createItem(Material.PLAYER_HEAD,
            "§b§l👥 CZŁONKOWIE",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Przeglądaj członków klanu",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ KLIKNIJ"
            ));
        inv.setItem(19, members);
        
        if (isLeader) {
            ItemStack invite = createItem(Material.WRITABLE_BOOK,
                "§a§l+ ZAPROŚ GRACZA",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Zaproś gracza do klanu",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§e§l⊙ KLIKNIJ"
                ));
            inv.setItem(21, invite);
            
            ItemStack kick = createItem(Material.IRON_DOOR,
                "§c§l- WYRZUĆ CZŁONKA",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Wyrzuć gracza z klanu",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§e§l⊙ KLIKNIJ"
                ));
            inv.setItem(23, kick);
            
            ItemStack settings = createItem(Material.COMPARATOR,
                "§e§l⚙ USTAWIENIA",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Zarządzaj ustawieniami klanu",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§e§l⊙ KLIKNIJ"
                ));
            inv.setItem(25, settings);
        }
        
        ItemStack treasury = createItem(Material.GOLD_BLOCK,
            "§6§l💰 SKARBIEC",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Zarządzaj skarbcem klanu",
                "§7Aktualne saldo: §e" + getClanTreasury(clanName),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ KLIKNIJ"
            ));
        inv.setItem(28, treasury);
        
        ItemStack base = createItem(Material.GRASS_BLOCK,
            "§a§l🏠 BAZA KLANU",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Teleportuj się do bazy klanu",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ KLIKNIJ"
            ));
        inv.setItem(30, base);
        
        ItemStack wars = createItem(Material.DIAMOND_SWORD,
            "§c§l⚔ WOJNY KLANOWE",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Wypowiedz wojnę innemu klanowi!",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ KLIKNIJ"
            ));
        inv.setItem(32, wars);
        
        ItemStack ranking = createItem(Material.DIAMOND,
            "§b§l🏆 RANKING KLANÓW",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Sprawdź ranking wszystkich klanów",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§e§l⊙ KLIKNIJ"
            ));
        inv.setItem(34, ranking);
        
        ItemStack leave = createItem(Material.BARRIER,
            "§c§l✖ OPUŚĆ KLAN",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§cOPUŚĆ KLAN: §e" + clanName,
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                isLeader ? "§c§lUWAGA: Jesteś liderem!" : "§7Opuścisz klan",
                "§e§l⊙ KLIKNIJ ABY OPUŚCIĆ"
            ));
        inv.setItem(49, leave);
        
        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);
    }
    
    private int getClanLevel(String clanName) {
        return 1;
    }
    
    private int getClanMemberCount(String clanName) {
        return 1;
    }
    
    private long getClanTreasury(String clanName) {
        return 0;
    }
    
    private void fillBorders(Inventory inv) {
        ItemStack red = createItem(Material.RED_STAINED_GLASS_PANE, "§c§l◆", Arrays.asList());
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◆", Arrays.asList());
        
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, red);
            inv.setItem(45 + i, red);
        }
        
        for (int i = 9; i < 45; i += 9) {
            inv.setItem(i, black);
            inv.setItem(i + 8, black);
        }
    }
    
    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }
    
    @Override
    public Inventory getInventory() {
        return null;
    }
}
