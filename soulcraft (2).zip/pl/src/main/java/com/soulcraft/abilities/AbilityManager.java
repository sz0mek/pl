package com.soulcraft.abilities;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.impl.*;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.*;

public class AbilityManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Ability> abilities = new HashMap<>();
    private final Map<UUID, Set<String>> unlockedAbilities = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    
    public AbilityManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        registerAbilities();
    }
    
    private void registerAbilities() {
        abilities.put("heal_on_hit", new HealOnHit(plugin));
        abilities.put("dodge", new Dodge(plugin));
        abilities.put("speed_burst", new SpeedBurst(plugin));
        abilities.put("critical_strike", new CriticalStrike(plugin));
        abilities.put("life_steal", new LifeSteal(plugin));
        abilities.put("thorns", new Thorns(plugin));
        abilities.put("regeneration", new Regeneration(plugin));
        abilities.put("shield", new Shield(plugin));
        abilities.put("berserk", new Berserk(plugin));
        abilities.put("lucky", new Lucky(plugin));
        abilities.put("vampirism", new Vampirism(plugin));
        abilities.put("soul_shield", new SoulShield(plugin));
    }
    
    public boolean unlockAbility(Player player, String abilityId) {
        unlockedAbilities.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(abilityId);
        player.sendMessage("§a§l✔ Odblokowano zdolność: " + abilities.get(abilityId).getDisplayName());
        return true;
    }
    
    public boolean hasAbility(Player player, String abilityId) {
        return unlockedAbilities.getOrDefault(player.getUniqueId(), new HashSet<>()).contains(abilityId);
    }
    
    public boolean isOnCooldown(Player player, String abilityId) {
        Map<String, Long> playerCooldowns = cooldowns.get(player.getUniqueId());
        if (playerCooldowns == null) return false;
        Long cooldownEnd = playerCooldowns.get(abilityId);
        return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
    }
    
    public void setCooldown(Player player, String abilityId, int seconds) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
            .put(abilityId, System.currentTimeMillis() + (seconds * 1000L));
    }
    
    public Ability getAbility(String id) {
        return abilities.get(id);
    }
    
    public Set<String> getUnlockedAbilities(Player player) {
        return unlockedAbilities.getOrDefault(player.getUniqueId(), new HashSet<>());
    }
    
    public SoulCraftPlugin getPlugin() {
        return plugin;
    }
}
