package com.soulcraft.abilities;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Complete ability system with cooldowns, event listeners, and synergy
 */
public class AbilityService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final Map<String, AbilityConfig> abilityConfigs;
    private final Map<UUID, Map<String, AbilityState>> playerStates;
    
    public AbilityService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.abilityConfigs = new HashMap<>();
        this.playerStates = new HashMap<>();
        
        loadAbilityConfigs();
    }
    
    private void loadAbilityConfigs() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load all 12 abilities
        String[] abilities = {
            "berserk", "critical_strike", "dodge", "heal_on_hit",
            "life_steal", "lucky", "regeneration", "shield",
            "soul_shield", "speed_burst", "thorns", "vampirism"
        };
        
        for (String abilityId : abilities) {
            AbilityConfig config = new AbilityConfig();
            String path = "abilities." + abilityId;
            
            config.id = abilityId;
            config.name = balance.getString(path + ".name");
            config.cooldown = balance.getInt(path + ".cooldown", 0);
            config.duration = balance.getInt(path + ".duration", 0);
            config.soulCost = balance.getInt(path + ".soul_cost", 0);
            config.levelRequired = balance.getInt(path + ".level_required", 0);
            
            // Ability-specific stats
            config.damageBoost = balance.getDouble(path + ".damage_boost", 0);
            config.speedBoost = balance.getDouble(path + ".speed_boost", 0);
            config.chance = balance.getDouble(path + ".chance", 0);
            config.damageMultiplier = balance.getDouble(path + ".damage_multiplier", 0);
            config.healPercent = balance.getDouble(path + ".heal_percent", 0);
            config.stealPercent = balance.getDouble(path + ".steal_percent", 0);
            config.lootBonus = balance.getDouble(path + ".loot_bonus", 0);
            config.rareDropChance = balance.getDouble(path + ".rare_drop_chance", 0);
            config.healthPerSecond = balance.getDouble(path + ".health_per_second", 0);
            config.absorptionAmount = balance.getDouble(path + ".absorption_amount", 0);
            config.damageReduction = balance.getDouble(path + ".damage_reduction", 0);
            config.reflectDamage = balance.getDouble(path + ".reflect_damage", 0);
            config.reflectPercent = balance.getDouble(path + ".reflect_percent", 0);
            config.speedMultiplier = balance.getDouble(path + ".speed_multiplier", 0);
            config.maxHealPerHit = balance.getDouble(path + ".max_heal_per_hit", 0);
            
            abilityConfigs.put(abilityId, config);
        }
    }
    
    /**
     * Check if player can unlock ability
     */
    public boolean canUnlock(Player player, String abilityId) {
        AbilityConfig config = abilityConfigs.get(abilityId);
        if (config == null) return false;
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        
        if (data.hasAbility(abilityId)) return false;
        if (data.getLevel() < config.levelRequired) return false;
        if (!economyService.hasEnough(player, config.soulCost)) return false;
        
        return true;
    }
    
    /**
     * Unlock ability for player
     */
    public boolean unlockAbility(Player player, String abilityId) {
        if (!canUnlock(player, abilityId)) return false;
        
        AbilityConfig config = abilityConfigs.get(abilityId);
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        
        if (!economyService.withdraw(player, config.soulCost, "Unlock ability: " + config.name)) {
            return false;
        }
        
        data.unlockAbility(abilityId);
        return true;
    }
    
    /**
     * Check if player has ability unlocked
     */
    public boolean hasAbility(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.hasAbility(abilityId);
    }
    
    /**
     * Check if ability is on cooldown
     */
    public boolean isOnCooldown(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.isAbilityOnCooldown(abilityId);
    }
    
    /**
     * Get remaining cooldown in seconds
     */
    public int getRemainingCooldown(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        Long cooldownEnd = data.getAbilityCooldowns().get(abilityId);
        
        if (cooldownEnd == null) return 0;
        
        long remaining = cooldownEnd - System.currentTimeMillis();
        if (remaining <= 0) return 0;
        
        return (int)(remaining / 1000);
    }
    
    /**
     * Activate ability
     */
    public boolean activateAbility(Player player, String abilityId) {
        if (!hasAbility(player, abilityId)) return false;
        if (isOnCooldown(player, abilityId)) return false;
        
        AbilityConfig config = abilityConfigs.get(abilityId);
        if (config == null) return false;
        
        // Set cooldown
        if (config.cooldown > 0) {
            PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
            data.setAbilityCooldown(abilityId, System.currentTimeMillis() + (config.cooldown * 1000L));
        }
        
        // Apply ability-specific effects
        applyAbilityEffects(player, abilityId, config);
        
        // Start ability effect tracking
        if (config.duration > 0) {
            startAbilityEffect(player, abilityId, config);
        }
        
        return true;
    }
    
    /**
     * Apply ability-specific effects when activated
     */
    private void applyAbilityEffects(Player player, String abilityId, AbilityConfig config) {
        switch (abilityId) {
            case "berserk":
                // +50% damage, +30% speed
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.STRENGTH, 
                    config.duration * 20, 
                    2, false, false));
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SPEED, 
                    config.duration * 20, 
                    1, false, false));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.8f);
                player.sendMessage("§4§l⚔ BERSERK ACTIVATED!");
                player.getWorld().spawnParticle(org.bukkit.Particle.FLAME, player.getLocation(), 30, 0.5, 1, 0.5);
                break;
                
            case "shield":
                // Apply absorption hearts (10 hearts)
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.ABSORPTION, 
                    config.duration * 20, 
                    (int)(config.absorptionAmount / 4) - 1, false, false));
                player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_SHIELD_BLOCK, 1.0f, 1.0f);
                player.sendMessage("§9§l🛡 SHIELD ACTIVATED!");
                player.getWorld().spawnParticle(org.bukkit.Particle.ENCHANT, player.getLocation(), 50, 1, 1, 1);
                break;
                
            case "soul_shield":
                // Apply strong absorption and resistance
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.ABSORPTION, 
                    config.duration * 20, 
                    4, false, false));
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.RESISTANCE, 
                    config.duration * 20, 
                    1, false, false));
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
                player.sendMessage("§d§l✨ SOUL SHIELD ACTIVATED!");
                player.getWorld().spawnParticle(org.bukkit.Particle.END_ROD, player.getLocation(), 100, 1, 1, 1);
                break;
                
            case "speed_burst":
                // Apply speed boost
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SPEED, 
                    config.duration * 20, 
                    3, false, false));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 2.0f);
                player.sendMessage("§e§l⚡ SPEED BURST ACTIVATED!");
                player.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, player.getLocation(), 40, 0.5, 0.5, 0.5, 0.1);
                break;
                
            case "vampirism":
                // Apply strength and visual effects
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.STRENGTH, 
                    config.duration * 20, 
                    0, false, false));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
                player.sendMessage("§5§l🩸 VAMPIRISM ACTIVATED!");
                player.getWorld().spawnParticle(org.bukkit.Particle.DUST, player.getLocation(), 60, 1, 1, 1,
                    new org.bukkit.Particle.DustOptions(org.bukkit.Color.fromRGB(139, 0, 0), 2.0f));
                break;
        }
    }
    
    /**
     * Start ability effect (for active abilities with duration)
     */
    private void startAbilityEffect(Player player, String abilityId, AbilityConfig config) {
        UUID playerId = player.getUniqueId();
        
        AbilityState state = new AbilityState();
        state.abilityId = abilityId;
        state.startTime = System.currentTimeMillis();
        state.endTime = state.startTime + (config.duration * 1000L);
        state.config = config;
        
        Map<String, AbilityState> states = playerStates.computeIfAbsent(playerId, k -> new HashMap<>());
        states.put(abilityId, state);
        
        // Schedule end
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            endAbilityEffect(playerId, abilityId);
        }, config.duration * 20L); // Convert to ticks
    }
    
    /**
     * End ability effect
     */
    private void endAbilityEffect(UUID playerId, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(playerId);
        if (states != null) {
            states.remove(abilityId);
        }
    }
    
    /**
     * Check if ability is currently active
     */
    public boolean isAbilityActive(Player player, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(player.getUniqueId());
        if (states == null) return false;
        
        AbilityState state = states.get(abilityId);
        if (state == null) return false;
        
        return System.currentTimeMillis() < state.endTime;
    }
    
    /**
     * Get ability config
     */
    public AbilityConfig getConfig(String abilityId) {
        return abilityConfigs.get(abilityId);
    }
    
    /**
     * Get active ability state
     */
    public AbilityState getActiveState(Player player, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(player.getUniqueId());
        if (states == null) return null;
        return states.get(abilityId);
    }
    
    /**
     * Get all active abilities for player
     */
    public Map<String, AbilityState> getActiveAbilities(Player player) {
        return playerStates.getOrDefault(player.getUniqueId(), new HashMap<>());
    }
    
    /**
     * Cleanup when player logs out
     */
    public void cleanup(UUID playerId) {
        playerStates.remove(playerId);
    }
    
    /**
     * Ability configuration
     */
    public static class AbilityConfig {
        public String id;
        public String name;
        public int cooldown;
        public int duration;
        public int soulCost;
        public int levelRequired;
        
        // Combat stats
        public double damageBoost;
        public double speedBoost;
        public double chance;
        public double damageMultiplier;
        public double healPercent;
        public double stealPercent;
        public double lootBonus;
        public double rareDropChance;
        public double healthPerSecond;
        public double absorptionAmount;
        public double damageReduction;
        public double reflectDamage;
        public double reflectPercent;
        public double speedMultiplier;
        public double maxHealPerHit;
    }
    
    /**
     * Active ability state
     */
    public static class AbilityState {
        public String abilityId;
        public long startTime;
        public long endTime;
        public AbilityConfig config;
        
        public boolean isActive() {
            return System.currentTimeMillis() < endTime;
        }
        
        public int getRemainingSeconds() {
            long remaining = endTime - System.currentTimeMillis();
            return remaining > 0 ? (int)(remaining / 1000) : 0;
        }
    }
}
