package com.soulcraft.abilities;

import org.bukkit.entity.Player;

public abstract class Ability {
    protected final String id;
    protected final String displayName;
    protected final String description;
    protected final int cooldownSeconds;
    protected final String requiredRank;
    protected final int unlockCost;
    
    public Ability(String id, String displayName, String description, int cooldownSeconds, 
                   String requiredRank, int unlockCost) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.cooldownSeconds = cooldownSeconds;
        this.requiredRank = requiredRank;
        this.unlockCost = unlockCost;
    }
    
    public abstract void activate(Player player, Object... args);
    public abstract boolean canUse(Player player);
    
    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }
    public int getCooldownSeconds() { return cooldownSeconds; }
    public String getRequiredRank() { return requiredRank; }
    public int getUnlockCost() { return unlockCost; }
}
