package com.soulcraft.missions;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class MissionData {
    private final SoulCraftPlugin plugin;
    private File dataFile;
    private FileConfiguration data;
    
    public MissionData(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        setupDataFile();
    }
    
    private void setupDataFile() {
        dataFile = new File(plugin.getDataFolder(), "missions.yml");
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }
    
    public void saveProgress(UUID playerId, String missionId, int progress) {
        data.set("progress." + playerId + "." + missionId, progress);
        saveFile();
    }
    
    public int getProgress(UUID playerId, String missionId) {
        return data.getInt("progress." + playerId + "." + missionId, 0);
    }
    
    public void markCompleted(UUID playerId, String missionId) {
        data.set("completed." + playerId + "." + missionId, System.currentTimeMillis());
        saveFile();
    }
    
    public boolean isCompleted(UUID playerId, String missionId) {
        return data.contains("completed." + playerId + "." + missionId);
    }
    
    public void resetDaily(UUID playerId) {
        if (data.contains("progress." + playerId)) {
            for (String key : data.getConfigurationSection("progress." + playerId).getKeys(false)) {
                if (key.startsWith("daily_")) {
                    data.set("progress." + playerId + "." + key, null);
                }
            }
        }
        saveFile();
    }
    
    private void saveFile() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
