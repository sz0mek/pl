package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class FastEat extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public FastEat(SoulCraftPlugin plugin) {
        super(
            "fasteat",
            "§a§lSzybkie Jedzenie",
            "§7Szybsze jedzenie i picie"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        PlayerItemConsumeEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onEat(PlayerItemConsumeEvent event) {
        if (!canUse(event.getPlayer())) {
            return;
        }
        
        // Instant saturation restore
        event.getPlayer().setFoodLevel(20);
        event.getPlayer().setSaturation(20);
    }
}
