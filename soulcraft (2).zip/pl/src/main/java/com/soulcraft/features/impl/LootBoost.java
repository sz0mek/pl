package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class LootBoost extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public LootBoost(SoulCraftPlugin plugin) {
        super(
            "lootboost",
            "§5§lBoost Lootu",
            "§7Podwójny loot z mobów i bloków"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        EntityDeathEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        if (!(event.getEntity().getKiller() instanceof Player)) {
            return;
        }
        
        Player killer = (Player) event.getEntity().getKiller();
        if (!canUse(killer)) {
            return;
        }
        
        List<ItemStack> extraDrops = new ArrayList<>();
        for (ItemStack drop : event.getDrops()) {
            extraDrops.add(drop.clone());
        }
        
        event.getDrops().addAll(extraDrops);
        killer.sendMessage("§5§l✦ Loot Boost aktywny! (2x przedmioty)");
    }
}
