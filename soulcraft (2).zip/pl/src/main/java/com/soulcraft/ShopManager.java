package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class ShopManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Set<UUID> activeMainPlayers = new HashSet<>();
    private final Set<UUID> activeCategoryPlayers = new HashSet<>();
    private final Map<String, Map<Material, ShopItem>> categories = new LinkedHashMap<>();

    public ShopManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        initializeShop();
    }

    private void initializeShop() {
        // KATEGORIA: BROŃ I NARZĘDZIA
        Map<Material, ShopItem> weaponsTools = new LinkedHashMap<>();
        weaponsTools.put(Material.DIAMOND_SWORD, new ShopItem(500, 400, "Potężny miecz diamentowy"));
        weaponsTools.put(Material.NETHERITE_SWORD, new ShopItem(1500, 1200, "Najlepszy miecz w grze"));
        weaponsTools.put(Material.DIAMOND_PICKAXE, new ShopItem(300, 240, "Szybkie kopanie diamentów"));
        weaponsTools.put(Material.NETHERITE_PICKAXE, new ShopItem(800, 640, "Niezniszczalny kilof"));
        weaponsTools.put(Material.DIAMOND_AXE, new ShopItem(300, 240, "Szybkie ścinanie drzew"));
        weaponsTools.put(Material.BOW, new ShopItem(50, 40, "Klasyczny łuk"));
        weaponsTools.put(Material.CROSSBOW, new ShopItem(80, 64, "Potężna kusza"));
        categories.put("Broń & Narzędzia", weaponsTools);

        // KATEGORIA: JEDZENIE I MIKSTURY
        Map<Material, ShopItem> food = new LinkedHashMap<>();
        food.put(Material.COOKED_BEEF, new ShopItem(5, 3, "Najlepsze jedzenie"));
        food.put(Material.GOLDEN_APPLE, new ShopItem(50, 40, "Magiczne właściwości"));
        food.put(Material.ENCHANTED_GOLDEN_APPLE, new ShopItem(500, 400, "Legendarny przedmiot"));
        food.put(Material.COOKED_CHICKEN, new ShopItem(4, 2, "Szybka regeneracja"));
        food.put(Material.BREAD, new ShopItem(2, 1, "Podstawowe pożywienie"));
        categories.put("Jedzenie & Mikstury", food);

        // KATEGORIA: MATERIAŁY BUDOWLANE
        Map<Material, ShopItem> building = new LinkedHashMap<>();
        building.put(Material.STONE, new ShopItem(1, 1, "Podstawowy materiał"));
        building.put(Material.OAK_WOOD, new ShopItem(2, 1, "Drewno dębowe"));
        building.put(Material.COBBLESTONE, new ShopItem(1, 1, "Bruk kamienny"));
        building.put(Material.GLASS, new ShopItem(3, 2, "Przezroczyste szkło"));
        building.put(Material.IRON_BLOCK, new ShopItem(90, 70, "Blok żelaza"));
        building.put(Material.DIAMOND_BLOCK, new ShopItem(900, 700, "Cenny blok diamentów"));
        categories.put("Materiały Budowlane", building);

        // KATEGORIA: RZADKIE PRZEDMIOTY
        Map<Material, ShopItem> rare = new LinkedHashMap<>();
        rare.put(Material.NETHERITE_INGOT, new ShopItem(1000, 800, "Najrzadszy materiał"));
        rare.put(Material.DIAMOND, new ShopItem(100, 80, "Cenny diament"));
        rare.put(Material.EMERALD, new ShopItem(150, 120, "Szmaragd handlarski"));
        rare.put(Material.NETHER_STAR, new ShopItem(2000, 1600, "Gwiazda Netheru"));
        rare.put(Material.DRAGON_EGG, new ShopItem(5000, 4000, "Jajo smoka - unikalne"));
        categories.put("Rzadkie Przedmioty", rare);

        // KATEGORIA: WOJNA I OBRONA  
        Map<Material, ShopItem> combat = new LinkedHashMap<>();
        combat.put(Material.ARROW, new ShopItem(1, 1, "Podstawowa strzała"));
        combat.put(Material.SPECTRAL_ARROW, new ShopItem(5, 3, "Widmowa strzała"));
        combat.put(Material.DIAMOND_HELMET, new ShopItem(200, 160, "Ochrona głowy"));
        combat.put(Material.DIAMOND_CHESTPLATE, new ShopItem(320, 256, "Ochrona torsu"));
        combat.put(Material.DIAMOND_LEGGINGS, new ShopItem(280, 224, "Ochrona nóg"));
        combat.put(Material.DIAMOND_BOOTS, new ShopItem(160, 128, "Ochrona stóp"));
        combat.put(Material.SHIELD, new ShopItem(100, 80, "Tarcza ochronna"));
        categories.put("Wojna & Obrona", combat);
        
        Map<Material, ShopItem> pets = new LinkedHashMap<>();
        pets.put(Material.BONE, new ShopItem(500, 400, "Pet: Wilk Dusz"));
        pets.put(Material.DRAGON_BREATH, new ShopItem(1500, 1200, "Pet: Duch Smoka"));
        pets.put(Material.STRING, new ShopItem(600, 480, "Pet: Kot Chaosu"));
        pets.put(Material.PHANTOM_MEMBRANE, new ShopItem(1200, 960, "Pet: Fantom Pustki"));
        pets.put(Material.BLAZE_POWDER, new ShopItem(800, 640, "Pet: Feniks Ognia"));
        categories.put("Pety", pets);
        
        Map<Material, ShopItem> boosters = new LinkedHashMap<>();
        boosters.put(Material.EXPERIENCE_BOTTLE, new ShopItem(250, 200, "Booster EXP x2 (1h)"));
        boosters.put(Material.GOLD_NUGGET, new ShopItem(250, 200, "Booster Hajsu x2 (1h)"));
        boosters.put(Material.GHAST_TEAR, new ShopItem(400, 320, "Booster Dusz x2 (1h)"));
        boosters.put(Material.NETHER_STAR, new ShopItem(1000, 800, "Mega Booster x3 (30min)"));
        categories.put("Boostery", boosters);
        
        Map<Material, ShopItem> cosmetics = new LinkedHashMap<>();
        cosmetics.put(Material.LEATHER_HELMET, new ShopItem(100, 80, "Czapka - Czerwona"));
        cosmetics.put(Material.PUMPKIN, new ShopItem(150, 120, "Dynia na głowę"));
        cosmetics.put(Material.PLAYER_HEAD, new ShopItem(300, 240, "Losowa głowa gracza"));
        cosmetics.put(Material.FIREWORK_ROCKET, new ShopItem(50, 40, "Fajerwerki"));
        categories.put("Kosmetyki", cosmetics);
        
        Map<Material, ShopItem> tools = new LinkedHashMap<>();
        tools.put(Material.IRON_PICKAXE, new ShopItem(200, 160, "Kilof Dusz - +50% drop"));
        tools.put(Material.GOLDEN_SWORD, new ShopItem(350, 280, "Miecz Chaosu - lifesteal"));
        tools.put(Material.DIAMOND_HOE, new ShopItem(400, 320, "Motyka Błogosławiona"));
        categories.put("Narzędzia Specjalne", tools);
        
        Map<Material, ShopItem> keys = new LinkedHashMap<>();
        keys.put(Material.TRIPWIRE_HOOK, new ShopItem(500, 400, "Klucz Brązowy"));
        keys.put(Material.IRON_NUGGET, new ShopItem(1000, 800, "Klucz Srebrny"));
        keys.put(Material.GOLD_INGOT, new ShopItem(2000, 1600, "Klucz Złoty"));
        keys.put(Material.DIAMOND, new ShopItem(5000, 4000, "Klucz Diamentowy"));
        keys.put(Material.NETHER_STAR, new ShopItem(10000, 8000, "Klucz Legendarny"));
        categories.put("Klucze do Skrzyń", keys);
    }

    public void openShopGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new ShopMainHolder(), 54, "§6§l🏪 SKLEP SOULCRAFT 🏪");
        activeMainPlayers.add(player.getUniqueId());

        // Piękne wypełnienie - złoty gradient
        ItemStack goldFiller = createCustomItem(Material.YELLOW_STAINED_GLASS_PANE, "§e§l◆", Arrays.asList("§6✨ Złoty blask sklepu..."));
        ItemStack orangeFiller = createCustomItem(Material.ORANGE_STAINED_GLASS_PANE, "§6§l◇", Arrays.asList("§e💰 Energia handlu..."));
        
        // Wzór wypełnienia
        for (int i = 0; i < 54; i++) {
            if (i < 9 || i >= 45) {
                gui.setItem(i, goldFiller); // Górny i dolny rząd
            } else if (i % 9 == 0 || i % 9 == 8) {
                gui.setItem(i, orangeFiller); // Boki
            } else {
                gui.setItem(i, goldFiller); // Środek
            }
        }

        // SALDO GRACZA - na górze, centralnie
        long balance = plugin.getEconomyService().getBalance(player.getUniqueId());
        ItemStack balanceItem = createCustomItem(Material.GOLD_INGOT,
            "§6§l💰 TWÓJ BALANS 💰",
            Arrays.asList(
                "§7╭─────────────────╮",
                "§7│ §fAktualne saldo: §7│",
                "§7│ §6§l    " + String.format("%.0f", (double)balance) + " hajsu    §7│",
                "§7╰─────────────────╯",
                "",
                "§e💡 Kup i sprzedawaj przedmioty",
                "§e💡 aby zwiększyć swój majątek!"));
        gui.setItem(4, balanceItem);

        // KATEGORIE SKLEPU
        int[] slots = {10, 12, 14, 16, 19, 21, 23, 25, 28, 30}; // Rozłożone sloty
        Material[] icons = {
            Material.DIAMOND_SWORD,    // Broń & Narzędzia  
            Material.GOLDEN_APPLE,     // Jedzenie & Mikstury
            Material.STONE,           // Materiały Budowlane
            Material.EMERALD,         // Rzadkie Przedmioty
            Material.DIAMOND_HELMET,  // Wojna & Obrona
            Material.BONE,            // Pety
            Material.EXPERIENCE_BOTTLE, // Boostery
            Material.FIREWORK_ROCKET, // Kosmetyki
            Material.IRON_PICKAXE,    // Narzędzia Specjalne
            Material.TRIPWIRE_HOOK    // Klucze
        };
        
        String[] descriptions = {
            "Potężne bronie i użyteczne narzędzia",
            "Pożywienie i magiczne mikstury", 
            "Wszystko do budowy i dekoracji",
            "Najcenniejsze skarby świata",
            "Pancerze i sprzęt bojowy",
            "Wierni towarzysze w przygodach",
            "Zwiększ swoje zyski!",
            "Unikalne dodatki kosmetyczne",
            "Specjalne narzędzia z bonusami",
            "Otwieraj tajemnicze skrzynie"
        };

        int categoryIndex = 0;
        for (String categoryName : categories.keySet()) {
            if (categoryIndex >= slots.length) break;
            
            ItemStack categoryItem = createCustomItem(icons[categoryIndex],
                "§e§l📦 " + categoryName.toUpperCase() + " 📦",
                Arrays.asList(
                    "§7╭─────────────────────────╮",
                    "§7│ §f" + descriptions[categoryIndex] + " §7│",
                    "§7│                         §7│",
                    "§7│ §aPrzedmioty: §f" + categories.get(categoryName).size() + "          §7│",
                    "§7╰─────────────────────────╯",
                    "",
                    "§a§l➤ KLIKNIJ ABY PRZEGLĄDAĆ!"));
            gui.setItem(slots[categoryIndex], categoryItem);

            // Efekty wokół kategorii
            ItemStack sparkle = createCustomItem(Material.GLOWSTONE_DUST, "§e§l✦", Arrays.asList("§6Magiczny blask..."));
            if (slots[categoryIndex] - 9 >= 0) gui.setItem(slots[categoryIndex] - 9, sparkle);
            if (slots[categoryIndex] + 9 < 54) gui.setItem(slots[categoryIndex] + 9, sparkle);
            
            categoryIndex++;
        }

        // INSTRUKCJE
        ItemStack instructions = createCustomItem(Material.BOOK,
            "§b§l📚 JAK KORZYSTAĆ ZE SKLEPU 📚",
            Arrays.asList(
                "§7╭─────────────────────────╮",
                "§7│ §fInstrukcje obsługi:     §7│",
                "§7│                         §7│", 
                "§7│ §a• LPM §7= Kup przedmiot   §7│",
                "§7│ §c• PPM §7= Sprzedaj        §7│",
                "§7│ §e• Wybierz kategorię      §7│",
                "§7│ §e• Sprawdź swój balans    §7│",
                "§7╰─────────────────────────╯"));
        gui.setItem(49, instructions);

        // PRZYCISK ZAMKNIJ
        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ SKLEP",
            Arrays.asList("§7Zamknij interfejs sklepu"));
        gui.setItem(53, close);

        player.openInventory(gui);
    }

    public void openCategoryGUI(Player player, String categoryName) {
        Map<Material, ShopItem> items = categories.get(categoryName);
        if (items == null) return;

        int size = Math.max(54, ((items.size() / 9) + 1) * 9);
        if (size > 54) size = 54;
        
        Inventory gui = Bukkit.createInventory(new ShopCategoryHolder(categoryName), size, 
            "§e§l📦 " + categoryName.toUpperCase() + " 📦");
        activeCategoryPlayers.add(player.getUniqueId());

        // Wypełnienie
        ItemStack filler = createCustomItem(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "§b§l◆", 
            Arrays.asList("§3✨ " + categoryName + "..."));
        for (int i = 0; i < size; i++) {
            gui.setItem(i, filler);
        }

        // SALDO - na górze
        long balance = plugin.getEconomyService().getBalance(player.getUniqueId());
        ItemStack balanceItem = createCustomItem(Material.GOLD_NUGGET,
            "§6💰 Balans: §f" + String.format("%.0f", (double)balance) + " hajsu",
            Arrays.asList("§7Twoje aktualne środki"));
        gui.setItem(4, balanceItem);

        // Przedmioty kategorii
        int slot = 9; // Zaczynamy od drugiego rzędu
        for (Map.Entry<Material, ShopItem> entry : items.entrySet()) {
            if (slot >= size - 9) break; // Zostaw miejsce na przyciski na dole
            
            Material material = entry.getKey();
            ShopItem shopItem = entry.getValue();
            
            ItemStack item = createCustomItem(material,
                "§f§l" + formatMaterialName(material),
                Arrays.asList(
                    "§7╭─────────────────────╮",
                    "§7│ §f" + shopItem.description + " §7│",
                    "§7│                     §7│",
                    "§7│ §aCena kupna: §f" + String.format("%.0f", shopItem.buyPrice) + " hajsu §7│",
                    "§7│ §cCena sprzedaży: §f" + String.format("%.0f", shopItem.sellPrice) + " hajsu §7│",
                    "§7╰─────────────────────╯",
                    "",
                    balance >= shopItem.buyPrice ? 
                        "§a§l✓ LPM: KUP za " + String.format("%.0f", shopItem.buyPrice) + " hajsu" :
                        "§c§l✗ Za mało hajsu do kupna",
                    "§e§l$ PPM: SPRZEDAJ za " + String.format("%.0f", shopItem.sellPrice) + " hajsu"));
            gui.setItem(slot++, item);
        }

        // Przyciski na dole
        ItemStack back = createCustomItem(Material.ARROW,
            "§e§l⬅ POWRÓT DO KATEGORII",
            Arrays.asList("§7Wróć do głównego menu sklepu"));
        gui.setItem(size - 5, back);

        ItemStack close = createCustomItem(Material.BARRIER,
            "§c§l✖ ZAMKNIJ",
            Arrays.asList("§7Zamknij sklep"));
        gui.setItem(size - 1, close);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        
        if (holder instanceof ShopMainHolder) {
            handleMainShopClick(event, player);
        } else if (holder instanceof ShopCategoryHolder) {
            handleCategoryClick(event, player);
        }
    }

    private void handleMainShopClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;
        
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        // Przycisk zamknij
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeMainPlayers.remove(player.getUniqueId());
            return;
        }

        // Kategorie sklepu
        String categoryName = getCategoryFromSlot(raw);
        if (categoryName != null) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
        }
    }

    private void handleCategoryClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) return;

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        // Przycisk powrotu
        if (clicked.getType() == Material.ARROW) {
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openShopGUI(player), 1L);
            return;
        }

        // Przycisk zamknij
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activeCategoryPlayers.remove(player.getUniqueId());
            return;
        }

        // Skip non-shop items
        if (raw < 9 || clicked.getType() == Material.LIGHT_BLUE_STAINED_GLASS_PANE || 
            clicked.getType() == Material.GOLD_NUGGET) return;

        // Handel
        ShopCategoryHolder categoryHolder = (ShopCategoryHolder) event.getView().getTopInventory().getHolder();
        String categoryName = categoryHolder.getCategoryName();
        Map<Material, ShopItem> items = categories.get(categoryName);
        if (items == null) return;

        Material material = clicked.getType();
        ShopItem shopItem = items.get(material);
        if (shopItem == null) return;

        UUID uuid = player.getUniqueId();
        long balance = plugin.getEconomyService().getBalance(uuid);

        if (event.isLeftClick()) {
            // KUPOWANIE
            if (balance >= shopItem.buyPrice) {
                boolean success = plugin.getEconomyService().withdraw(uuid, shopItem.buyPrice, "Shop purchase");
                if (success) {
                    player.getInventory().addItem(new ItemStack(material, 1));
                    
                    player.sendMessage("§a§l💰 ═══════════════════════════════ 💰");
                    player.sendMessage("§a§l    ✓ ZAKUP POMYŚLNY! ✓");
                    player.sendMessage("§f    Przedmiot: §e" + formatMaterialName(material));
                    player.sendMessage("§f    Zapłacono: §c" + String.format("%.0f", shopItem.buyPrice) + " hajsu");
                    player.sendMessage("§f    Pozostało: §a" + String.format("%.0f", (double)(balance - Math.round(shopItem.buyPrice))) + " hajsu");
                    player.sendMessage("§a§l💰 ═══════════════════════════════ 💰");
                    
                    // Odśwież GUI
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
                } else {
                    player.sendMessage("§cWystąpił błąd podczas transakcji!");
                }
            } else {
                double needed = shopItem.buyPrice - balance;
                player.sendMessage("§c§l💸 ═══════════════════════════════ 💸");
                player.sendMessage("§c§l    ✗ ZA MAŁO HAJSU! ✗");
                player.sendMessage("§f    Potrzebujesz: §e" + String.format("%.0f", shopItem.buyPrice) + " hajsu");
                player.sendMessage("§f    Masz: §c" + String.format("%.0f", (double)balance) + " hajsu");
                player.sendMessage("§f    Brakuje Ci: §4" + String.format("%.0f", needed) + " hajsu");
                player.sendMessage("§c§l💸 ═══════════════════════════════ 💸");
            }
            
        } else if (event.isRightClick()) {
            // SPRZEDAWANIE
            if (player.getInventory().contains(material)) {
                player.getInventory().removeItem(new ItemStack(material, 1));
                boolean success = plugin.getEconomyService().deposit(uuid, shopItem.sellPrice, "Shop sale");
                if (success) {
                    player.sendMessage("§e§l💰 ═══════════════════════════════ 💰");
                    player.sendMessage("§e§l    ✓ SPRZEDAŻ POMYŚLNA! ✓");
                    player.sendMessage("§f    Przedmiot: §e" + formatMaterialName(material));
                    player.sendMessage("§f    Otrzymano: §a" + String.format("%.0f", shopItem.sellPrice) + " hajsu");
                    player.sendMessage("§f    Masz teraz: §a" + String.format("%.0f", (double)(balance + Math.round(shopItem.sellPrice))) + " hajsu");
                    player.sendMessage("§e§l💰 ═══════════════════════════════ 💰");
                    
                    // Odśwież GUI
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> openCategoryGUI(player, categoryName), 1L);
                } else {
                    // Give item back if transaction failed
                    player.getInventory().addItem(new ItemStack(material, 1));
                    player.sendMessage("§cWystąpił błąd podczas transakcji!");
                }
            } else {
                player.sendMessage("§c§l📦 ═══════════════════════════════ 📦");
                player.sendMessage("§c§l    ✗ BRAK PRZEDMIOTU! ✗");
                player.sendMessage("§f    Nie masz §e" + formatMaterialName(material));
                player.sendMessage("§f    w swoim ekwipunku!");
                player.sendMessage("§c§l📦 ═══════════════════════════════ 📦");
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ShopMainHolder || holder instanceof ShopCategoryHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getView().getTopInventory().getSize()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ShopMainHolder) {
            activeMainPlayers.remove(player.getUniqueId());
        } else if (holder instanceof ShopCategoryHolder) {
            activeCategoryPlayers.remove(player.getUniqueId());
        }
    }

    private String getCategoryFromSlot(int slot) {
        switch (slot) {
            case 10: return "Broń & Narzędzia";
            case 12: return "Jedzenie & Mikstury";
            case 14: return "Materiały Budowlane";
            case 16: return "Rzadkie Przedmioty";
            case 19: return "Wojna & Obrona";
            case 21: return "Pety";
            case 23: return "Boostery";
            case 25: return "Kosmetyki";
            case 28: return "Narzędzia Specjalne";
            case 30: return "Klucze do Skrzyń";
            default: return null;
        }
    }

    private String formatMaterialName(Material material) {
        return material.name().toLowerCase().replace("_", " ");
    }

    private ItemStack createCustomItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static class ShopItem {
        final double buyPrice;
        final double sellPrice;
        final String description;

        ShopItem(double buyPrice, double sellPrice, String description) {
            this.buyPrice = buyPrice;
            this.sellPrice = sellPrice;
            this.description = description;
        }
    }

    private static class ShopMainHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() { return null; }
    }

    private static class ShopCategoryHolder implements InventoryHolder {
        private final String categoryName;
        
        public ShopCategoryHolder(String categoryName) {
            this.categoryName = categoryName;
        }
        
        public String getCategoryName() {
            return categoryName;
        }
        
        @Override
        public Inventory getInventory() { return null; }
    }
}