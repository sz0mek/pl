// PlayerListener.java
package com.soulcraft;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerListener implements Listener {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;

    public PlayerListener(SoulCraftPlugin plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        String uuid = event.getPlayer().getUniqueId().toString();
        if (!plugin.getConfig().contains("players." + uuid + ".souls"))
            plugin.getConfig().set("players." + uuid + ".souls", 100);
        if (!plugin.getConfig().contains("players." + uuid + ".balance"))
            plugin.getConfig().set("players." + uuid + ".balance", 0.0);
        if (!plugin.getConfig().contains("players." + uuid + ".kills"))
            plugin.getConfig().set("players." + uuid + ".kills", 0);
        if (!plugin.getConfig().contains("players." + uuid + ".rank"))
            plugin.getConfig().set("players." + uuid + ".rank", "gracz");
        if (!plugin.getConfig().contains("players." + uuid + ".healthLevel"))
            plugin.getConfig().set("players." + uuid + ".healthLevel", 0);
        if (!plugin.getConfig().contains("players." + uuid + ".name"))
            plugin.getConfig().set("players." + uuid + ".name", event.getPlayer().getName());
        if (!plugin.getConfig().contains("players." + uuid + ".blackMatter"))
            plugin.getConfig().set("players." + uuid + ".blackMatter", 0);
        plugin.saveConfig();

        int level = plugin.getConfig().getInt("players." + uuid + ".healthLevel", 0);
        event.getPlayer().setMaxHealth(20 + level * 2);
        event.getPlayer().setHealth(event.getPlayer().getMaxHealth());
        rankManager.updatePermissions(event.getPlayer());
    }
}
