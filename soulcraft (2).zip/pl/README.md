# SoulCraft RPG Plugin

A comprehensive Minecraft Spigot plugin with RPG features including abilities, bosses, dungeons, pets, clans, and missions.

## 🚀 Quick Start on Replit

### Building the Plugin

Simply click the **Run** button at the top of the page, or execute:
```bash
./build.sh
```

The compiled plugin JAR will be located at:
```
target/SoulCraftPlugin-1.0.jar
```

### Installation

1. Build the plugin using the method above
2. Download the `SoulCraftPlugin-1.0.jar` from the `target` folder
3. Place it in your Minecraft server's `plugins` folder
4. Restart your Minecraft server

## 📋 Requirements

- **Minecraft Server**: Spigot/Paper 1.21 or compatible
- **Java**: 17 or higher (Java 19 with GraalVM is included in this Replit)

## 🎮 Features

- **12 Unique Abilities**: Berserk, Critical Strike, Dodge, Heal on Hit, Life Steal, Lucky, Regeneration, Shield, Soul Shield, Speed Burst, Thorns, Vampirism
- **5 Custom Bosses**: Soul Eater, Void Titan, Chaos Knight, Phantom Lord, Dark Emperor
- **50+ Custom Items**: Weapons, armor, tools, and consumables
- **Pet System**: Leveling from 1-100
- **Clan System**: Create and manage clans
- **Mission System**: Complete quests for rewards
- **Dungeon System**: Procedurally generated dungeons
- **Rebirth System**: Progress through rebirths for stat bonuses
- **12 Gameplay Features**: Auto Pickup, Double Jump, Auto Replant, Keep Inventory, Auto Smelt, Night Vision, No Fall Damage, Fast Eat, Auto Feed, XP Boost, Money Boost, Loot Boost

## 📁 Project Structure

```
src/main/
├── java/com/soulcraft/     # Java source files
│   ├── SoulCraftPlugin.java
│   ├── abilities/
│   ├── bosses/
│   ├── items/
│   ├── missions/
│   └── ...
└── resources/              # Configuration files
    ├── plugin.yml
    ├── config.yml
    └── missions.yml
```

## ⚙️ Configuration

Edit `src/main/resources/config.yml` to customize:
- Boss rewards and spawn cooldowns
- Feature toggles and multipliers
- Resource pack settings

## 📝 Development Status

**Note**: This plugin contains skeletal structures for all systems. Full implementation of game mechanics, event handlers, and persistence layers is required before production use.

See `replit.md` for detailed development notes and architecture documentation.

## 🛠️ Technology Stack

- **Language**: Java 17
- **Build Tool**: Maven 3.8.6
- **Target API**: Spigot 1.21-R0.1-SNAPSHOT
- **Runtime**: Java 19 (GraalVM CE 22.3.1)
- **Build Time**: ~10-15 seconds

## 📄 License

This is a custom Minecraft plugin project.
