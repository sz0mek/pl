package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.bosses.BossService;
import com.soulcraft.dungeons.DungeonService;
import com.soulcraft.events.EventOrchestrator;
import com.soulcraft.items.CustomItemRegistry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class AdminCommand implements CommandExecutor {
    
    private final SoulCraftPlugin plugin;
    private final EconomyService economyService;
    private final BossService bossService;
    private final DungeonService dungeonService;
    private final EventOrchestrator eventOrchestrator;
    private final CustomItemRegistry itemRegistry;
    
    public AdminCommand(SoulCraftPlugin plugin, EconomyService economyService, BossService bossService,
                       DungeonService dungeonService, EventOrchestrator eventOrchestrator, CustomItemRegistry itemRegistry) {
        this.plugin = plugin;
        this.economyService = economyService;
        this.bossService = bossService;
        this.dungeonService = dungeonService;
        this.eventOrchestrator = eventOrchestrator;
        this.itemRegistry = itemRegistry;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("soulcraft.admin")) {
            sender.sendMessage("§cBrak uprawnień!");
            return true;
        }
        
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "reload":
                handleReload(sender);
                break;
            case "give":
                handleGive(sender, args);
                break;
            case "souls":
                handleSouls(sender, args);
                break;
            case "dungeon":
                handleDungeon(sender, args);
                break;
            case "boss":
                handleBoss(sender, args);
                break;
            case "event":
                handleEvent(sender, args);
                break;
            default:
                sendHelp(sender);
        }
        
        return true;
    }
    
    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        sender.sendMessage("§a§l[ADMIN] §fPrzeładowano config pluginu!");
        Bukkit.broadcastMessage("§6§l[ADMIN] §eKonfiguracja została przeładowana przez " + sender.getName());
    }
    
    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cUżycie: /admin give <gracz> <item> [ilość]");
            return;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage("§cGracz nie jest online!");
            return;
        }
        
        String itemId = args[2];
        int amount = args.length > 3 ? Integer.parseInt(args[3]) : 1;
        
        ItemStack item = null;
        com.soulcraft.items.CustomItem customItem = itemRegistry.getItem(itemId);
        if (customItem != null) {
            item = customItem.create(amount);
        } else {
            try {
                Material material = Material.valueOf(itemId.toUpperCase());
                item = new ItemStack(material, amount);
            } catch (IllegalArgumentException e) {
                sender.sendMessage("§cNieznany przedmiot: " + itemId);
                return;
            }
        }
        
        target.getInventory().addItem(item);
        sender.sendMessage("§a§l[ADMIN] §fDano " + amount + "x " + itemId + " dla " + target.getName());
        target.sendMessage("§a§l[ADMIN] §fOtrzymałeś " + amount + "x " + itemId);
    }
    
    private void handleSouls(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage("§cUżycie: /admin souls <add|set|remove> <gracz> <ilość>");
            return;
        }
        
        String action = args[1].toLowerCase();
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage("§cGracz nie jest online!");
            return;
        }
        
        long amount = Long.parseLong(args[3]);
        
        switch (action) {
            case "add":
                economyService.deposit(target.getUniqueId(), amount, "Admin add");
                sender.sendMessage("§a§l[ADMIN] §fDodano " + amount + " dusz dla " + target.getName());
                target.sendMessage("§a§l[ADMIN] §fOtrzymałeś " + amount + " dusz!");
                break;
            case "set":
                long current = economyService.getBalance(target.getUniqueId());
                if (current > amount) {
                    economyService.withdraw(target.getUniqueId(), current - amount, "Admin set");
                } else {
                    economyService.deposit(target.getUniqueId(), amount - current, "Admin set");
                }
                sender.sendMessage("§a§l[ADMIN] §fUstawiono " + amount + " dusz dla " + target.getName());
                target.sendMessage("§a§l[ADMIN] §fTwoje dusze zostały ustawione na " + amount);
                break;
            case "remove":
                economyService.withdraw(target.getUniqueId(), amount, "Admin remove");
                sender.sendMessage("§a§l[ADMIN] §fUsunięto " + amount + " dusz dla " + target.getName());
                target.sendMessage("§c§l[ADMIN] §fStracono " + amount + " dusz");
                break;
            default:
                sender.sendMessage("§cUżycie: add, set, lub remove");
        }
    }
    
    private void handleDungeon(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cUżycie: /admin dungeon <info>");
            return;
        }
        
        String action = args[1].toLowerCase();
        
        if (action.equals("info")) {
            sender.sendMessage("§a§l[ADMIN] §fSystem dungeonów aktywny!");
            sender.sendMessage("§7Użyj /dungeon aby zobaczyć dostępne dungeony");
        }
    }
    
    private void handleBoss(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cUżycie: /admin boss <info>");
            return;
        }
        
        String action = args[1].toLowerCase();
        
        if (action.equals("info")) {
            sender.sendMessage("§a§l[ADMIN] §fSystem bossów aktywny!");
            sender.sendMessage("§7Użyj /spawnboss <boss_id> aby przywołać bossa");
            sender.sendMessage("§7Dostępne bossy: chaos_knight, dark_emperor, phantom_lord,");
            sender.sendMessage("§7soul_eater, void_titan, shadow_lord, dragon_of_souls, void_titan_boss");
        }
    }
    
    private void handleEvent(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cUżycie: /admin event <start|stop|list> [nazwa]");
            return;
        }
        
        String action = args[1].toLowerCase();
        
        if (action.equals("start") && args.length > 2) {
            String eventName = args[2];
            eventOrchestrator.startEvent(eventName);
            sender.sendMessage("§a§l[ADMIN] §fUruchomiono event: " + eventName);
            Bukkit.broadcastMessage("§6§l[EVENT] §e" + eventName + " §fzostał uruchomiony!");
        } else if (action.equals("stop")) {
            eventOrchestrator.stopAllEvents();
            sender.sendMessage("§a§l[ADMIN] §fZatrzymano wszystkie eventy!");
        } else if (action.equals("list")) {
            sender.sendMessage("§6§l[ADMIN] §fDostępne eventy:");
            eventOrchestrator.listEvents().forEach(event -> 
                sender.sendMessage("§e- " + event)
            );
        }
    }
    
    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage("§6§l         ADMIN KOMENDY");
        sender.sendMessage("§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage("§e/admin reload §7- Przeładuj config");
        sender.sendMessage("§e/admin give <gracz> <item> [ilość] §7- Daj przedmiot");
        sender.sendMessage("§e/admin souls <add|set|remove> <gracz> <ilość> §7- Zarządzaj duszami");
        sender.sendMessage("§e/admin dungeon info §7- Info o systemie dungeonów");
        sender.sendMessage("§e/admin boss info §7- Info o systemie bossów");
        sender.sendMessage("§e/admin event <start|stop|list> [nazwa] §7- Zarządzaj eventami");
        sender.sendMessage("§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    }
}
