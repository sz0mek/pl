package com.soulcraft.dungeons;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.missions.MissionService;
import com.soulcraft.leaderboards.LeaderboardManager;
import com.soulcraft.bosses.BossService;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.attribute.Attribute;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Complete procedural dungeon generation system with 5 difficulty tiers
 * Features: Procedural generation, room templates, corridors, portals, time limits, party support
 */
public class DungeonService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MissionService missionService;
    private final LeaderboardManager leaderboardManager;
    private BossService bossService;
    
    private final Map<String, DifficultyConfig> difficulties;
    private final List<BiomeConfig> biomes;
    private final Map<String, DungeonInstance> activeDungeons;
    private final Map<String, DungeonParty> parties;
    private final Map<UUID, String> playerParties; // UUID -> Party ID mapping
    private final Map<UUID, PartyInvite> pendingInvites; // UUID -> Invite
    private final Map<UUID, Long> fastestTimes;
    private long dailySeed;
    private final Random random;
    
    private static final int TIME_LIMIT_EASY = 900;
    private static final int TIME_LIMIT_MEDIUM = 1200;
    private static final int TIME_LIMIT_HARD = 1800;
    private static final int TIME_LIMIT_NIGHTMARE = 2400;
    private static final int TIME_LIMIT_CHAOS = 3000;
    
    public DungeonService(Plugin plugin, DataStore dataStore, EconomyService economyService, MissionService missionService, LeaderboardManager leaderboardManager) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionService = missionService;
        this.leaderboardManager = leaderboardManager;
        this.difficulties = new HashMap<>();
        this.biomes = new ArrayList<>();
        this.activeDungeons = new ConcurrentHashMap<>();
        this.parties = new ConcurrentHashMap<>();
        this.playerParties = new ConcurrentHashMap<>();
        this.pendingInvites = new ConcurrentHashMap<>();
        this.fastestTimes = new ConcurrentHashMap<>();
        this.random = new Random();
        
        loadDungeonConfig();
        updateDailySeed();
        startDungeonTimers();
        startDailySeedUpdate();
    }
    
    public void setBossService(BossService bossService) {
        this.bossService = bossService;
    }
    
    private void loadDungeonConfig() {
        registerDifficulty("easy", 1, 10, 1.0, 1.0, 500, 100);
        registerDifficulty("medium", 20, 15, 1.5, 1.5, 1500, 300);
        registerDifficulty("hard", 35, 20, 2.0, 2.5, 3500, 600);
        registerDifficulty("nightmare", 50, 30, 3.0, 4.0, 8000, 1200);
        registerDifficulty("chaos", 75, 40, 5.0, 6.0, 20000, 2500);
        
        registerBiome("Undead Crypt", "undead", new String[]{"ZOMBIE", "SKELETON", "WITHER_SKELETON"});
        registerBiome("Void Realm", "void", new String[]{"ENDERMAN", "ENDERMITE", "SHULKER"});
        registerBiome("Inferno", "fire", new String[]{"BLAZE", "MAGMA_CUBE", "WITHER_SKELETON"});
        registerBiome("Frozen Wastes", "ice", new String[]{"STRAY", "POLAR_BEAR", "ZOMBIE"});
        registerBiome("Shadow Domain", "shadow", new String[]{"PHANTOM", "VEX", "WITCH"});
    }
    
    private void registerDifficulty(String id, int level, int roomSize, double mobMult, double lootMult, long souls, long xp) {
        DifficultyConfig config = new DifficultyConfig();
        config.id = id;
        config.requiredLevel = level;
        config.baseRoomSize = roomSize;
        config.mobLevelMultiplier = mobMult;
        config.lootMultiplier = lootMult;
        config.soulReward = souls;
        config.xpReward = xp;
        difficulties.put(id, config);
    }
    
    private void registerBiome(String name, String theme, String[] mobs) {
        BiomeConfig biome = new BiomeConfig();
        biome.name = name;
        biome.theme = theme;
        biome.mobs = Arrays.asList(mobs);
        biomes.add(biome);
    }
    
    private void updateDailySeed() {
        LocalDate today = LocalDate.now();
        dailySeed = today.toEpochDay() * 31337;
    }
    
    private void startDailySeedUpdate() {
        new BukkitRunnable() {
            @Override
            public void run() {
                updateDailySeed();
                Bukkit.broadcastMessage("§5§l✦ Daily dungeons have been reset!");
            }
        }.runTaskTimer(plugin, 20L * 60, 20L * 3600 * 24);
    }
    
    public DungeonParty createParty(Player leader) {
        // Check if already in party
        if (playerParties.containsKey(leader.getUniqueId())) {
            return null;
        }
        
        String partyId = UUID.randomUUID().toString();
        DungeonParty party = new DungeonParty();
        party.id = partyId;
        party.leader = leader.getUniqueId();
        party.members.add(leader.getUniqueId());
        party.createdTime = System.currentTimeMillis();
        parties.put(partyId, party);
        playerParties.put(leader.getUniqueId(), partyId);
        return party;
    }
    
    public boolean inviteToParty(Player inviter, Player target) {
        String partyId = playerParties.get(inviter.getUniqueId());
        if (partyId == null) {
            inviter.sendMessage("§c§lYou are not in a party!");
            return false;
        }
        
        DungeonParty party = parties.get(partyId);
        if (party == null) return false;
        
        if (!party.leader.equals(inviter.getUniqueId())) {
            inviter.sendMessage("§c§lOnly the party leader can invite players!");
            return false;
        }
        
        if (party.members.size() >= 5) {
            inviter.sendMessage("§c§lParty is full! (Max 5 players)");
            return false;
        }
        
        if (playerParties.containsKey(target.getUniqueId())) {
            inviter.sendMessage("§c§l" + target.getName() + " is already in a party!");
            return false;
        }
        
        if (pendingInvites.containsKey(target.getUniqueId())) {
            inviter.sendMessage("§c§l" + target.getName() + " already has a pending invite!");
            return false;
        }
        
        // Create invite
        PartyInvite invite = new PartyInvite();
        invite.partyId = partyId;
        invite.inviter = inviter.getUniqueId();
        invite.target = target.getUniqueId();
        invite.timestamp = System.currentTimeMillis();
        pendingInvites.put(target.getUniqueId(), invite);
        
        // Notify both players
        inviter.sendMessage("§a§l✓ Invited " + target.getName() + " to your party!");
        target.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
        target.sendMessage("§e§l✦ PARTY INVITE ✦");
        target.sendMessage("§7" + inviter.getName() + " invited you to their dungeon party!");
        target.sendMessage("§a/dungeon party accept §7- Accept invite");
        target.sendMessage("§c/dungeon party decline §7- Decline invite");
        target.sendMessage("§7Expires in 60 seconds");
        target.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
        target.playSound(target.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        
        // Auto-expire after 60 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                PartyInvite current = pendingInvites.get(target.getUniqueId());
                if (current != null && current.timestamp == invite.timestamp) {
                    pendingInvites.remove(target.getUniqueId());
                    target.sendMessage("§c§lParty invite expired!");
                }
            }
        }.runTaskLater(plugin, 1200L); // 60 seconds
        
        return true;
    }
    
    public boolean acceptPartyInvite(Player player) {
        PartyInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            player.sendMessage("§c§lYou don't have any pending party invites!");
            return false;
        }
        
        DungeonParty party = parties.get(invite.partyId);
        if (party == null) {
            player.sendMessage("§c§lThis party no longer exists!");
            return false;
        }
        
        if (party.members.size() >= 5) {
            player.sendMessage("§c§lThis party is now full!");
            return false;
        }
        
        // Add to party
        party.members.add(player.getUniqueId());
        playerParties.put(player.getUniqueId(), party.id);
        
        // Notify all party members
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage("§a§l✓ " + player.getName() + " joined the party! §7(" + party.members.size() + "/5)");
                member.playSound(member.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
            }
        }
        
        return true;
    }
    
    public boolean declinePartyInvite(Player player) {
        PartyInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            player.sendMessage("§c§lYou don't have any pending party invites!");
            return false;
        }
        
        player.sendMessage("§7You declined the party invite.");
        
        Player inviter = Bukkit.getPlayer(invite.inviter);
        if (inviter != null) {
            inviter.sendMessage("§c" + player.getName() + " declined your party invite.");
        }
        
        return true;
    }
    
    public boolean leaveParty(Player player) {
        String partyId = playerParties.remove(player.getUniqueId());
        if (partyId == null) {
            player.sendMessage("§c§lYou are not in a party!");
            return false;
        }
        
        DungeonParty party = parties.get(partyId);
        if (party == null) return false;
        
        party.members.remove(player.getUniqueId());
        
        // If leader left, disband or transfer leadership
        if (party.leader.equals(player.getUniqueId())) {
            if (party.members.isEmpty()) {
                // Disband party
                parties.remove(partyId);
            } else {
                // Transfer to first remaining member
                UUID newLeader = party.members.iterator().next();
                party.leader = newLeader;
                
                Player newLeaderPlayer = Bukkit.getPlayer(newLeader);
                if (newLeaderPlayer != null) {
                    newLeaderPlayer.sendMessage("§e§lYou are now the party leader!");
                }
            }
        }
        
        // Notify remaining members
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) {
                member.sendMessage("§c" + player.getName() + " left the party. §7(" + party.members.size() + "/5)");
            }
        }
        
        player.sendMessage("§7You left the party.");
        return true;
    }
    
    public DungeonParty getPlayerParty(Player player) {
        String partyId = playerParties.get(player.getUniqueId());
        return partyId != null ? parties.get(partyId) : null;
    }
    
    public boolean joinParty(Player player, String partyId) {
        DungeonParty party = parties.get(partyId);
        if (party == null) return false;
        if (party.members.size() >= 5) return false;
        party.members.add(player.getUniqueId());
        playerParties.put(player.getUniqueId(), partyId);
        return true;
    }
    
    public boolean startDungeon(Player player, String difficulty) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) {
            player.sendMessage("§c§lInvalid dungeon difficulty!");
            return false;
        }
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        if (data.getLevel() < config.requiredLevel) {
            player.sendMessage("§c§lRequires level " + config.requiredLevel + "!");
            return false;
        }
        
        if (isInDungeon(player.getUniqueId())) {
            player.sendMessage("§c§lYou are already in a dungeon!");
            return false;
        }
        
        DungeonInstance dungeon = generateDungeon(difficulty, Arrays.asList(player.getUniqueId()));
        activeDungeons.put(dungeon.instanceId, dungeon);
        
        teleportToDungeon(player, dungeon);
        startDungeonTimer(dungeon);
        
        player.sendMessage("§5§l✦ Entered " + difficulty.toUpperCase() + " Dungeon");
        player.sendMessage("§7Biome: §e" + dungeon.biome.name);
        player.sendMessage("§7Time Limit: §e" + (dungeon.timeLimit / 60) + " minutes");
        player.playSound(player.getLocation(), Sound.BLOCK_END_PORTAL_SPAWN, 1.0f, 1.0f);
        
        return true;
    }
    
    public boolean startPartyDungeon(DungeonParty party, String difficulty) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) return false;
        
        List<Player> onlineMembers = new ArrayList<>();
        for (UUID memberId : party.members) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null && member.isOnline()) {
                PlayerData data = dataStore.loadPlayerData(memberId);
                if (data.getLevel() < config.requiredLevel) {
                    member.sendMessage("§c§lYou need level " + config.requiredLevel + "!");
                    return false;
                }
                onlineMembers.add(member);
            }
        }
        
        DungeonInstance dungeon = generateDungeon(difficulty, new ArrayList<>(party.members));
        dungeon.partySize = party.members.size();
        activeDungeons.put(dungeon.instanceId, dungeon);
        
        for (Player member : onlineMembers) {
            teleportToDungeon(member, dungeon);
            member.sendMessage("§5§l✦ Party Dungeon Started!");
        }
        
        startDungeonTimer(dungeon);
        return true;
    }
    
    private DungeonInstance generateDungeon(String difficulty, List<UUID> players) {
        DungeonInstance dungeon = new DungeonInstance();
        dungeon.instanceId = UUID.randomUUID().toString();
        dungeon.difficulty = difficulty;
        dungeon.config = difficulties.get(difficulty);
        dungeon.players = new HashSet<>(players);
        dungeon.startTime = System.currentTimeMillis();
        dungeon.biome = biomes.get((int)(dailySeed % biomes.size()));
        dungeon.partySize = players.size();
        
        int timeLimit = getTimeLimit(difficulty);
        dungeon.timeLimit = timeLimit;
        
        World world = Bukkit.getWorlds().get(0);
        int x = random.nextInt(10000) + 20000;
        int z = random.nextInt(10000) + 20000;
        dungeon.entranceLocation = new Location(world, x, 100, z);
        
        generateRooms(dungeon);
        connectRooms(dungeon);
        populateRooms(dungeon);
        createPortals(dungeon);
        
        return dungeon;
    }
    
    private int getTimeLimit(String difficulty) {
        switch (difficulty) {
            case "easy": return TIME_LIMIT_EASY;
            case "medium": return TIME_LIMIT_MEDIUM;
            case "hard": return TIME_LIMIT_HARD;
            case "nightmare": return TIME_LIMIT_NIGHTMARE;
            case "chaos": return TIME_LIMIT_CHAOS;
            default: return 900;
        }
    }
    
    private void generateRooms(DungeonInstance dungeon) {
        Random rng = new Random(dailySeed + dungeon.difficulty.hashCode());
        int roomCount = 5 + rng.nextInt(6);
        
        Location current = dungeon.entranceLocation.clone();
        
        for (int i = 0; i < roomCount; i++) {
            RoomType type;
            if (i == 0) {
                type = RoomType.ENTRY;
            } else if (i == roomCount - 1) {
                type = RoomType.BOSS;
            } else {
                double rand = rng.nextDouble();
                if (rand < 0.5) type = RoomType.COMBAT;
                else if (rand < 0.7) type = RoomType.TREASURE;
                else if (rand < 0.85) type = RoomType.TRAP;
                else type = RoomType.SECRET;
            }
            
            Room room = createRoom(current, type, dungeon, rng);
            dungeon.rooms.add(room);
            
            current = current.clone().add(
                (rng.nextBoolean() ? 1 : -1) * (dungeon.config.baseRoomSize + 20),
                0,
                (rng.nextBoolean() ? 1 : -1) * (dungeon.config.baseRoomSize + 20)
            );
        }
    }
    
    private Room createRoom(Location location, RoomType type, DungeonInstance dungeon, Random rng) {
        Room room = new Room();
        room.location = location.clone();
        room.type = type;
        room.size = dungeon.config.baseRoomSize + rng.nextInt(5);
        room.cleared = (type == RoomType.ENTRY);
        
        buildRoomStructure(room, dungeon);
        
        return room;
    }
    
    private void buildRoomStructure(Room room, DungeonInstance dungeon) {
        Location loc = room.location;
        int size = room.size;
        
        Material wallMaterial = getWallMaterial(dungeon.biome.theme);
        Material floorMaterial = getFloorMaterial(dungeon.biome.theme);
        Material ceiling = Material.STONE;
        
        for (int x = 0; x < size; x++) {
            for (int z = 0; z < size; z++) {
                Block floor = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() - 1, loc.getBlockZ() + z);
                floor.setType(floorMaterial);
                
                Block ceilingBlock = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() + 5, loc.getBlockZ() + z);
                ceilingBlock.setType(ceiling);
            }
        }
        
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i < size; i++) {
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ()).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ() + size - 1).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + size - 1, loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
            }
        }
        
        for (int x = 1; x < size - 1; x++) {
            for (int z = 1; z < size - 1; z++) {
                for (int y = 0; y < 5; y++) {
                    Block block = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() + y, loc.getBlockZ() + z);
                    block.setType(Material.AIR);
                }
            }
        }
        
        if (random.nextDouble() < 0.3) {
            for (int i = 0; i < 2 + random.nextInt(3); i++) {
                int lx = 1 + random.nextInt(size - 2);
                int lz = 1 + random.nextInt(size - 2);
                Block torchBlock = loc.getWorld().getBlockAt(loc.getBlockX() + lx, loc.getBlockY() + 2, loc.getBlockZ() + lz);
                torchBlock.setType(Material.TORCH);
            }
        }
    }
    
    private Material getWallMaterial(String theme) {
        switch (theme.toLowerCase()) {
            case "undead": return Material.MOSSY_STONE_BRICKS;
            case "void": return Material.END_STONE_BRICKS;
            case "fire": return Material.NETHER_BRICKS;
            case "ice": return Material.PACKED_ICE;
            case "shadow": return Material.BLACKSTONE;
            default: return Material.STONE_BRICKS;
        }
    }
    
    private Material getFloorMaterial(String theme) {
        switch (theme.toLowerCase()) {
            case "undead": return Material.SOUL_SAND;
            case "void": return Material.OBSIDIAN;
            case "fire": return Material.NETHERRACK;
            case "ice": return Material.ICE;
            case "shadow": return Material.POLISHED_BLACKSTONE;
            default: return Material.STONE;
        }
    }
    
    private void connectRooms(DungeonInstance dungeon) {
        for (int i = 0; i < dungeon.rooms.size() - 1; i++) {
            Room current = dungeon.rooms.get(i);
            Room next = dungeon.rooms.get(i + 1);
            buildCorridor(current, next, dungeon);
        }
    }
    
    private void buildCorridor(Room from, Room to, DungeonInstance dungeon) {
        Location start = from.location.clone().add(from.size / 2, 0, from.size / 2);
        Location end = to.location.clone().add(to.size / 2, 0, to.size / 2);
        
        Material corridorMaterial = getFloorMaterial(dungeon.biome.theme);
        Material wallMaterial = getWallMaterial(dungeon.biome.theme);
        
        int x1 = start.getBlockX();
        int z1 = start.getBlockZ();
        int x2 = end.getBlockX();
        int z2 = end.getBlockZ();
        
        int midX = (x1 + x2) / 2;
        
        for (int x = Math.min(x1, midX); x <= Math.max(x1, midX); x++) {
            buildCorridorSegment(x, start.getBlockY(), z1, corridorMaterial, wallMaterial);
        }
        
        for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
            buildCorridorSegment(midX, start.getBlockY(), z, corridorMaterial, wallMaterial);
        }
        
        for (int x = Math.min(midX, x2); x <= Math.max(midX, x2); x++) {
            buildCorridorSegment(x, start.getBlockY(), z2, corridorMaterial, wallMaterial);
        }
    }
    
    private void buildCorridorSegment(int x, int y, int z, Material floor, Material wall) {
        World world = Bukkit.getWorlds().get(0);
        
        world.getBlockAt(x, y - 1, z).setType(floor);
        world.getBlockAt(x, y, z).setType(Material.AIR);
        world.getBlockAt(x, y + 1, z).setType(Material.AIR);
        world.getBlockAt(x, y + 2, z).setType(Material.AIR);
        
        world.getBlockAt(x - 1, y, z).setType(wall);
        world.getBlockAt(x + 1, y, z).setType(wall);
        world.getBlockAt(x - 1, y + 1, z).setType(wall);
        world.getBlockAt(x + 1, y + 1, z).setType(wall);
        world.getBlockAt(x, y + 3, z).setType(wall);
    }
    
    private void populateRooms(DungeonInstance dungeon) {
        for (Room room : dungeon.rooms) {
            switch (room.type) {
                case COMBAT:
                    spawnMobs(room, dungeon);
                    break;
                case TREASURE:
                    spawnChests(room, dungeon);
                    break;
                case TRAP:
                    createTraps(room, dungeon);
                    break;
                case BOSS:
                    spawnBoss(room, dungeon);
                    break;
                case SECRET:
                    spawnSecretRewards(room, dungeon);
                    break;
            }
        }
    }
    
    private void spawnMobs(Room room, DungeonInstance dungeon) {
        int baseMobCount = 3 + random.nextInt(5);
        int mobCount = baseMobCount + (dungeon.partySize - 1);
        
        for (int i = 0; i < mobCount; i++) {
            String mobType = dungeon.biome.mobs.get(random.nextInt(dungeon.biome.mobs.size()));
            Location spawnLoc = room.location.clone().add(
                2 + random.nextInt(room.size - 4),
                0,
                2 + random.nextInt(room.size - 4)
            );
            
            try {
                EntityType type = EntityType.valueOf(mobType.toUpperCase());
                LivingEntity mob = (LivingEntity) room.location.getWorld().spawnEntity(spawnLoc, type);
                
                if (mob != null) {
                    double multiplier = dungeon.config.mobLevelMultiplier * (1.0 + (dungeon.partySize - 1) * 0.3);
                    
                    if (mob.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
                        double health = mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() * multiplier;
                        mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
                        mob.setHealth(health);
                    }
                    
                    if (mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
                        double damage = mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).getValue() * multiplier;
                        mob.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
                    }
                    
                    mob.setCustomName("§c§l[Lv" + (int)(dungeon.config.requiredLevel * multiplier) + "] " + mobType);
                    mob.setCustomNameVisible(true);
                    
                    room.entities.add(mob.getUniqueId());
                    dungeon.totalMobs++;
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to spawn mob: " + mobType);
            }
        }
    }
    
    private void spawnChests(Room room, DungeonInstance dungeon) {
        int chestCount = 2 + random.nextInt(3);
        
        for (int i = 0; i < chestCount; i++) {
            Location chestLoc = room.location.clone().add(
                2 + random.nextInt(room.size - 4),
                0,
                2 + random.nextInt(room.size - 4)
            );
            
            Block block = chestLoc.getBlock();
            block.setType(Material.CHEST);
            
            if (block.getState() instanceof Chest) {
                Chest chest = (Chest) block.getState();
                populateChest(chest, dungeon);
                room.chests.add(chestLoc);
            }
        }
    }
    
    private void populateChest(Chest chest, DungeonInstance dungeon) {
        int itemCount = 3 + random.nextInt(5);
        
        for (int i = 0; i < itemCount; i++) {
            double roll = random.nextDouble() * dungeon.config.lootMultiplier;
            ItemStack item;
            
            if (roll < 0.3) {
                item = new ItemStack(Material.GOLD_INGOT, 1 + random.nextInt(8));
            } else if (roll < 0.5) {
                item = new ItemStack(Material.DIAMOND, 1 + random.nextInt(4));
            } else if (roll < 0.7) {
                item = new ItemStack(Material.EMERALD, 1 + random.nextInt(6));
            } else {
                Material[] items = {Material.IRON_INGOT, Material.COAL, Material.REDSTONE, Material.LAPIS_LAZULI};
                item = new ItemStack(items[random.nextInt(items.length)], 4 + random.nextInt(16));
            }
            
            chest.getInventory().addItem(item);
        }
        
        chest.update();
    }
    
    private void createTraps(Room room, DungeonInstance dungeon) {
        int trapCount = 2 + random.nextInt(4);
        
        for (int i = 0; i < trapCount; i++) {
            Location trapLoc = room.location.clone().add(
                2 + random.nextInt(room.size - 4),
                0,
                2 + random.nextInt(room.size - 4)
            );
            
            double trapType = random.nextDouble();
            if (trapType < 0.4) {
                trapLoc.getBlock().setType(Material.TNT);
            } else if (trapType < 0.7) {
                trapLoc.getBlock().setType(Material.MAGMA_BLOCK);
            } else {
                trapLoc.getBlock().setType(Material.COBWEB);
            }
        }
    }
    
    private void spawnBoss(Room room, DungeonInstance dungeon) {
        Location bossLoc = room.location.clone().add(room.size / 2, 0, room.size / 2);
        
        EntityType bossType;
        String bossName;
        
        switch (dungeon.difficulty) {
            case "easy":
                bossType = EntityType.ZOMBIE;
                bossName = "§c§l[BOSS] Crypt Guardian";
                break;
            case "medium":
                bossType = EntityType.SKELETON;
                bossName = "§c§l[BOSS] Bone Lord";
                break;
            case "hard":
                bossType = EntityType.WITHER_SKELETON;
                bossName = "§c§l[BOSS] Nether Knight";
                break;
            case "nightmare":
                bossType = EntityType.ENDERMAN;
                bossName = "§c§l[BOSS] Void Walker";
                break;
            case "chaos":
                bossType = EntityType.RAVAGER;
                bossName = "§c§l[BOSS] Chaos Beast";
                break;
            default:
                bossType = EntityType.ZOMBIE;
                bossName = "§c§l[BOSS] Dungeon Boss";
        }
        
        LivingEntity boss = (LivingEntity) bossLoc.getWorld().spawnEntity(bossLoc, bossType);
        boss.setCustomName(bossName);
        boss.setCustomNameVisible(true);
        
        double bossMultiplier = dungeon.config.mobLevelMultiplier * 5.0 * (1.0 + (dungeon.partySize - 1) * 0.5);
        
        if (boss.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            double health = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() * bossMultiplier;
            boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
            boss.setHealth(health);
        }
        
        if (boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            double damage = boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).getValue() * bossMultiplier;
            boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
        }
        
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999, 1));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 999999, 2));
        
        room.entities.add(boss.getUniqueId());
        dungeon.bossId = boss.getUniqueId();
        dungeon.totalMobs++;
    }
    
    private void spawnSecretRewards(Room room, DungeonInstance dungeon) {
        Location centerLoc = room.location.clone().add(room.size / 2, 0, room.size / 2);
        
        centerLoc.getBlock().setType(Material.CHEST);
        if (centerLoc.getBlock().getState() instanceof Chest) {
            Chest chest = (Chest) centerLoc.getBlock().getState();
            
            int bonusItems = 5 + random.nextInt(8);
            for (int i = 0; i < bonusItems; i++) {
                chest.getInventory().addItem(new ItemStack(Material.DIAMOND, 1 + random.nextInt(3)));
                chest.getInventory().addItem(new ItemStack(Material.EMERALD, 2 + random.nextInt(4)));
            }
            
            chest.update();
        }
    }
    
    private void createPortals(DungeonInstance dungeon) {
        Room entry = dungeon.rooms.get(0);
        Location portalLoc = entry.location.clone().add(entry.size / 2, 0, entry.size / 2);
        
        portalLoc.getBlock().setType(Material.NETHER_PORTAL);
        dungeon.entrancePortal = portalLoc;
        
        Room boss = dungeon.rooms.get(dungeon.rooms.size() - 1);
        Location exitLoc = boss.location.clone().add(boss.size / 2, 0, boss.size - 2);
        
        exitLoc.getBlock().setType(Material.END_PORTAL_FRAME);
        dungeon.exitPortal = exitLoc;
    }
    
    private void teleportToDungeon(Player player, DungeonInstance dungeon) {
        Location spawn = dungeon.entranceLocation.clone().add(dungeon.config.baseRoomSize / 2, 1, dungeon.config.baseRoomSize / 2);
        player.teleport(spawn);
    }
    
    private void startDungeonTimer(DungeonInstance dungeon) {
        new BukkitRunnable() {
            int elapsed = 0;
            
            @Override
            public void run() {
                if (!activeDungeons.containsKey(dungeon.instanceId)) {
                    cancel();
                    return;
                }
                
                elapsed++;
                int remaining = dungeon.timeLimit - elapsed;
                
                if (remaining <= 0) {
                    failDungeon(dungeon);
                    cancel();
                    return;
                }
                
                if (remaining == 300 || remaining == 60 || remaining == 30) {
                    for (UUID playerId : dungeon.players) {
                        Player player = Bukkit.getPlayer(playerId);
                        if (player != null) {
                            player.sendMessage("§e§l⏰ Time remaining: " + (remaining / 60) + ":" + String.format("%02d", remaining % 60));
                            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
    
    private void startDungeonTimers() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (DungeonInstance dungeon : activeDungeons.values()) {
                    checkRoomCleared(dungeon);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
    
    private void checkRoomCleared(DungeonInstance dungeon) {
        for (Room room : dungeon.rooms) {
            if (!room.cleared) {
                boolean allDead = true;
                for (UUID entityId : room.entities) {
                    Entity entity = Bukkit.getEntity(entityId);
                    if (entity != null && entity.isValid() && !entity.isDead()) {
                        allDead = false;
                        break;
                    }
                }
                
                if (allDead && !room.entities.isEmpty()) {
                    room.cleared = true;
                    dungeon.roomsCleared++;
                    
                    for (UUID playerId : dungeon.players) {
                        Player player = Bukkit.getPlayer(playerId);
                        if (player != null) {
                            player.sendMessage("§a§l✓ Room cleared! (" + dungeon.roomsCleared + "/" + dungeon.rooms.size() + ")");
                            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                        }
                    }
                }
            }
        }
        
        if (dungeon.bossId != null) {
            Entity boss = Bukkit.getEntity(dungeon.bossId);
            if (boss == null || boss.isDead()) {
                completeDungeon(dungeon);
            }
        }
    }
    
    public void onMobKilled(UUID dungeonMobId) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            for (Room room : dungeon.rooms) {
                if (room.entities.contains(dungeonMobId)) {
                    dungeon.mobsKilled++;
                    return;
                }
            }
        }
    }
    
    public boolean isInDungeon(UUID playerId) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            if (dungeon.players.contains(playerId)) {
                return true;
            }
        }
        return false;
    }
    
    public void leaveDungeon(Player player) {
        for (DungeonInstance dungeon : activeDungeons.values()) {
            if (dungeon.players.contains(player.getUniqueId())) {
                dungeon.players.remove(player.getUniqueId());
                player.teleport(player.getWorld().getSpawnLocation());
                player.sendMessage("§c§lYou have left the dungeon!");
                
                if (dungeon.players.isEmpty()) {
                    cleanupDungeon(dungeon);
                }
                return;
            }
        }
    }
    
    private void completeDungeon(DungeonInstance dungeon) {
        long duration = (System.currentTimeMillis() - dungeon.startTime) / 1000;
        
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                giveRewards(player, dungeon, duration);
                player.teleport(player.getWorld().getSpawnLocation());
                
                player.sendTitle("§a§lDUNGEON COMPLETE!", "§e" + duration + "s", 10, 70, 20);
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                
                leaderboardManager.addDungeonCompletion(player);
            }
        }
        
        cleanupDungeon(dungeon);
        activeDungeons.remove(dungeon.instanceId);
    }
    
    private void failDungeon(DungeonInstance dungeon) {
        for (UUID playerId : dungeon.players) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§c§l✗ DUNGEON FAILED - Time Limit Reached!");
                player.teleport(player.getWorld().getSpawnLocation());
            }
        }
        
        cleanupDungeon(dungeon);
        activeDungeons.remove(dungeon.instanceId);
    }
    
    private void giveRewards(Player player, DungeonInstance dungeon, long duration) {
        long baseReward = dungeon.config.soulReward;
        double timeBonus = 1.0;
        
        if (duration < dungeon.timeLimit * 0.5) {
            timeBonus = 1.5;
        } else if (duration < dungeon.timeLimit * 0.75) {
            timeBonus = 1.25;
        }
        
        long totalReward = (long)(baseReward * timeBonus);
        
        economyService.deposit(player, totalReward, "Dungeon completion: " + dungeon.difficulty);
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        data.addExperience(dungeon.config.xpReward);
        data.incrementDungeonsCompleted();
        
        missionService.progressMission(player.getUniqueId(), MissionService.MissionType.COMPLETE_DUNGEONS, 1);
        
        player.sendMessage("§6§l✦ REWARDS ✦");
        player.sendMessage("§e+" + totalReward + " souls §7(x" + String.format("%.1f", timeBonus) + " time bonus)");
        player.sendMessage("§e+" + dungeon.config.xpReward + " XP");
        player.sendMessage("§7Time: §e" + duration + "s");
        
        Long fastest = fastestTimes.get(player.getUniqueId());
        if (fastest == null || duration < fastest) {
            fastestTimes.put(player.getUniqueId(), duration);
            player.sendMessage("§d§l✦ NEW PERSONAL RECORD!");
        }
    }
    
    private void cleanupDungeon(DungeonInstance dungeon) {
        for (Room room : dungeon.rooms) {
            for (UUID entityId : room.entities) {
                Entity entity = Bukkit.getEntity(entityId);
                if (entity != null) {
                    entity.remove();
                }
            }
        }
    }
    
    public Map<String, DifficultyConfig> getDifficulties() {
        return difficulties;
    }
    
    public Map<String, DungeonInstance> getActiveDungeons() {
        return activeDungeons;
    }
    
    public static class DifficultyConfig {
        public String id;
        public int requiredLevel;
        public int baseRoomSize;
        public double mobLevelMultiplier;
        public double lootMultiplier;
        public long soulReward;
        public long xpReward;
    }
    
    public static class BiomeConfig {
        public String name;
        public String theme;
        public List<String> mobs;
    }
    
    public static class DungeonInstance {
        public String instanceId;
        public String difficulty;
        public DifficultyConfig config;
        public BiomeConfig biome;
        public Set<UUID> players = new HashSet<>();
        public List<Room> rooms = new ArrayList<>();
        public Location entranceLocation;
        public Location entrancePortal;
        public Location exitPortal;
        public long startTime;
        public int timeLimit;
        public int partySize = 1;
        public int roomsCleared = 0;
        public int mobsKilled = 0;
        public int totalMobs = 0;
        public UUID bossId;
    }
    
    public static class Room {
        public Location location;
        public RoomType type;
        public int size;
        public boolean cleared = false;
        public List<UUID> entities = new ArrayList<>();
        public List<Location> chests = new ArrayList<>();
    }
    
    public enum RoomType {
        ENTRY, COMBAT, TREASURE, BOSS, SECRET, TRAP
    }
    
    public static class DungeonParty {
        public String id;
        public UUID leader;
        public Set<UUID> members = new HashSet<>();
        public long createdTime;
    }
    
    public static class PartyInvite {
        public String partyId;
        public UUID inviter;
        public UUID target;
        public long timestamp;
    }
}
