package com.soulcraft.commands;

import com.soulcraft.ranks.RankSystem;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RankCommand implements CommandExecutor {
    
    private final RankSystem rankSystem;
    
    public RankCommand(RankSystem rankSystem) {
        this.rankSystem = rankSystem;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cTa komenda może być wykonana tylko przez gracza!");
            return true;
        }
        
        Player player = (Player) sender;
        rankSystem.openRankGUI(player);
        return true;
    }
}
