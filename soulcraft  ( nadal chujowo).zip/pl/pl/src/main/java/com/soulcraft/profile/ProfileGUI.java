package com.soulcraft.profile;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.persistence.PlayerData.PetData;
import com.soulcraft.RankManager;
import com.soulcraft.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ProfileGUI implements InventoryHolder {
    
    private final SoulCraftPlugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final RankManager rankManager;
    
    public ProfileGUI(SoulCraftPlugin plugin, DataStore dataStore, EconomyService economyService, RankManager rankManager) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.rankManager = rankManager;
    }
    
    public void openProfile(Player viewer, Player target) {
        Inventory inv = Bukkit.createInventory(this, 54, "§6§l✦ PROFIL: §e" + target.getName() + " §6✦");
        
        PlayerData data = dataStore.loadPlayerData(target.getUniqueId());
        String rank = rankManager.getRank(target);
        UUID uuid = target.getUniqueId();
        long souls = economyService.getBalance(uuid);
        double money = 0.0;
        
        fillBorders(inv);
        
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta headMeta = (SkullMeta) head.getItemMeta();
        headMeta.setOwningPlayer(target);
        headMeta.setDisplayName("§6§l" + target.getName());
        headMeta.setLore(Arrays.asList(
            "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
            "§7Status: §a● Online",
            "§7Ranga: §e" + rank.toUpperCase(),
            "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
        ));
        head.setItemMeta(headMeta);
        inv.setItem(4, head);
        
        ItemStack levelItem = createItem(Material.EXPERIENCE_BOTTLE, 
            "§a§l⚡ POZIOM",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Aktualny poziom: §e" + data.getLevel(),
                "§7Doświadczenie: §b" + data.getExperience() + " §7/§b " + getExpForNextLevel(data.getLevel()),
                "§7Postęp: " + getProgressBar((int)data.getExperience(), getExpForNextLevel(data.getLevel())),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(10, levelItem);
        
        ItemStack economyItem = createItem(Material.GOLD_INGOT,
            "§6§l$ EKONOMIA",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Hajs: §e" + String.format("%.2f", money) + " zł",
                "§7Dusze: §d" + souls + " ✦",
                "§7Czarna Materia: §5" + data.getBlackMatter(),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(12, economyItem);
        
        ItemStack statsItem = createItem(Material.DIAMOND_SWORD,
            "§c§l⚔ STATYSTYKI",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7HP: §c" + String.format("%.1f", target.getHealth()) + " §7/§c " + String.format("%.1f", target.getMaxHealth()),
                "§7DMG: §c+" + calculateDamageBonus(data) + "%",
                "§7DEF: §9+" + calculateDefenseBonus(data) + "%",
                "§7CRIT: §e" + calculateCritChance(data) + "%",
                "§7SPD: §a+" + calculateSpeedBonus(data) + "%",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(14, statsItem);
        
        ItemStack clanItem;
        String clanId = data.getClanId();
        if (clanId != null && !clanId.isEmpty()) {
            clanItem = createItem(Material.WHITE_BANNER,
                "§5§l❖ KLAN",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7ID Klanu: §e" + clanId,
                    "§7Rola: §bCzłonek",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
                ));
        } else {
            clanItem = createItem(Material.GRAY_BANNER,
                "§7§l❖ KLAN",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Status: §cBrak klanu",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
                ));
        }
        inv.setItem(16, clanItem);
        
        Map<String, PetData> pets = data.getPets();
        String activePet = data.getActivePet();
        ItemStack petItem;
        if (activePet != null && pets.containsKey(activePet)) {
            PetData petData = pets.get(activePet);
            petItem = createItem(Material.BONE,
                "§b§l♥ PET AKTYWNY",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Typ: §e" + activePet.toUpperCase(),
                    "§7Poziom: §a" + petData.getLevel(),
                    "§7Szczęście: §d" + petData.getHappiness() + "%",
                    "§7Bonus EXP: §b+" + (petData.getLevel() / 10) + "%",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§e§l⊙ §7Kliknij aby zobaczyć szczegóły"
                ));
        } else {
            petItem = createItem(Material.BONE,
                "§7§l♥ PET",
                Arrays.asList(
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "§7Status: §cBrak aktywnego peta",
                    "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
                ));
        }
        inv.setItem(28, petItem);
        
        ItemStack bossItem = createItem(Material.WITHER_SKELETON_SKULL,
            "§4§l☠ BOSSY",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Zabitych bossów: §c" + data.getBossesKilled(),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(30, bossItem);
        
        ItemStack dungeonItem = createItem(Material.IRON_DOOR,
            "§5§l⚔ DUNGEONY",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Ukończonych: §a" + data.getDungeonsCompleted(),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(32, dungeonItem);
        
        ItemStack rebirthItem = createItem(Material.NETHER_STAR,
            "§d§l★ REBIRTH",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Poziom Rebirth: §d" + data.getRebirths(),
                "§7Bonus HP: §c+" + (data.getRebirths() * 5) + "%",
                "§7Bonus DMG: §c+" + (data.getRebirths() * 3) + "%",
                "§7Bonus SPD: §a+" + (data.getRebirths() * 2) + "%",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(34, rebirthItem);
        
        ItemStack achievementsItem = createItem(Material.DIAMOND,
            "§b§l✦ OSIĄGNIĘCIA",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Odblokowano: §e0 §7/§e100",
                "§7Punkty: §b0",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(40, achievementsItem);
        
        viewer.openInventory(inv);
        viewer.playSound(viewer.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.2f);
    }
    
    private void fillBorders(Inventory inv) {
        ItemStack gold = createItem(Material.YELLOW_STAINED_GLASS_PANE, "§6§l◆", Arrays.asList());
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◆", Arrays.asList());
        
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, gold);
            inv.setItem(45 + i, gold);
        }
        
        for (int i = 9; i < 45; i += 9) {
            inv.setItem(i, black);
            inv.setItem(i + 8, black);
        }
    }
    
    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }
    
    private int getExpForNextLevel(int level) {
        return 100 + (level * 50);
    }
    
    private String getProgressBar(int current, int max) {
        int bars = 20;
        int filled = (int) ((double) current / max * bars);
        StringBuilder bar = new StringBuilder("§a");
        for (int i = 0; i < bars; i++) {
            if (i < filled) {
                bar.append("█");
            } else if (i == filled) {
                bar.append("§7");
            }
            if (i >= filled) {
                bar.append("█");
            }
        }
        bar.append(" §e").append((int) ((double) current / max * 100)).append("%");
        return bar.toString();
    }
    
    private int calculateDamageBonus(PlayerData data) {
        return data.getRebirths() * 3;
    }
    
    private int calculateDefenseBonus(PlayerData data) {
        return data.getLevel() / 5;
    }
    
    private int calculateCritChance(PlayerData data) {
        return 5 + (data.getLevel() / 10);
    }
    
    private int calculateSpeedBonus(PlayerData data) {
        return data.getRebirths() * 2;
    }
    
    @Override
    public Inventory getInventory() {
        return null;
    }
}
