package com.soulcraft.ranks;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class RankSystem implements InventoryHolder {
    
    private final SoulCraftPlugin plugin;
    private final DataStore dataStore;
    private final Map<String, Rank> ranks = new LinkedHashMap<>();
    
    public RankSystem(SoulCraftPlugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        initializeRanks();
    }
    
    private void initializeRanks() {
        ranks.put("gracz", new Rank("gracz", "§7Gracz", "§7", Material.IRON_INGOT, 
            1.0, 1.0, 1.0, 
            Arrays.asList("soulcraft.feature.autopickup", "soulcraft.feature.doublejump"),
            Arrays.asList("§7Podstawowa ranga", "§7Dostęp do podstawowych funkcji")));
        
        ranks.put("vip", new Rank("vip", "§eVIP", "§e", Material.GOLD_INGOT,
            1.25, 1.25, 1.15,
            Arrays.asList("soulcraft.feature.autopickup", "soulcraft.feature.doublejump", 
                         "soulcraft.feature.fasteat", "soulcraft.feature.nightvision"),
            Arrays.asList("§eRanga VIP", "§7Bonusy:", "§a+25% EXP", "§a+25% Hajsu", "§a+15% Dusz", 
                         "§7Dodatkowe funkcje gameplay")));
        
        ranks.put("svip+", new Rank("svip+", "§6SVIP+", "§6", Material.DIAMOND,
            1.5, 1.5, 1.3,
            Arrays.asList("soulcraft.feature.autopickup", "soulcraft.feature.doublejump",
                         "soulcraft.feature.fasteat", "soulcraft.feature.nightvision",
                         "soulcraft.feature.autosmelt", "soulcraft.feature.xpboost"),
            Arrays.asList("§6Ranga SVIP+", "§7Bonusy:", "§a+50% EXP", "§a+50% Hajsu", "§a+30% Dusz",
                         "§7Wszystkie funkcje VIP", "§7+ Auto Smelt, XP Boost")));
        
        ranks.put("soulgod", new Rank("soulgod", "§d§lSOULGOD", "§d§l", Material.NETHER_STAR,
            2.0, 2.0, 1.75,
            Arrays.asList("soulcraft.feature.*", "soulcraft.item.use"),
            Arrays.asList("§d§lRanga SOULGOD", "§7Bonusy:", "§a+100% EXP", "§a+100% Hajsu", "§a+75% Dusz",
                         "§7Wszystkie funkcje gameplay!", "§7Dostęp do custom itemów")));
        
        ranks.put("admin", new Rank("admin", "§c§lADMIN", "§c§l", Material.COMMAND_BLOCK,
            3.0, 3.0, 2.5,
            Arrays.asList("soulcraft.*"),
            Arrays.asList("§c§lRanga ADMIN", "§7Pełny dostęp do pluginu", "§a+200% EXP", "§a+200% Hajsu", "§a+150% Dusz")));
    }
    
    public void openRankGUI(Player player) {
        Inventory inv = Bukkit.createInventory(this, 54, "§6§l✦ RANGI SOULCRAFT ✦");
        
        fillBorders(inv);
        
        String currentRank = plugin.getRankManager().getRank(player);
        
        ItemStack info = createItem(Material.BOOK, "§b§lINFORMACJE O RANGACH",
            Arrays.asList(
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Twoja aktualnaranga:",
                "§e" + ranks.get(currentRank).getDisplayName(),
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "§7Rangi dają bonusy do:",
                "§a• Zdobywanego EXP",
                "§a• Zdobywanego hajsu",
                "§a• Zdobywanych dusz",
                "§a• Dostępu do funkcji",
                "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            ));
        inv.setItem(4, info);
        
        int[] slots = {20, 22, 24, 30, 32};
        int index = 0;
        
        for (Map.Entry<String, Rank> entry : ranks.entrySet()) {
            if (index >= slots.length) break;
            
            Rank rank = entry.getValue();
            boolean hasRank = currentRank.equals(entry.getKey());
            
            List<String> lore = new ArrayList<>(rank.getDescription());
            lore.add("");
            if (hasRank) {
                lore.add("§a§l✓ AKTUALNIE POSIADASZ TĘ RANGĘ");
            } else {
                lore.add("§7Kontakt z adminem aby uzyskać");
            }
            
            ItemStack item = createItem(rank.getIcon(), 
                (hasRank ? "§a§l✓ " : "") + rank.getDisplayName(),
                lore);
            
            if (hasRank) {
                item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.INFINITY, 1);
                ItemMeta meta = item.getItemMeta();
                meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
                item.setItemMeta(meta);
            }
            
            inv.setItem(slots[index], item);
            index++;
        }
        
        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.2f);
    }
    
    public Rank getRank(String rankId) {
        return ranks.getOrDefault(rankId, ranks.get("gracz"));
    }
    
    public void setPlayerRank(Player player, String rankId) {
        if (!ranks.containsKey(rankId)) return;
        
        plugin.getRankManager().setRank(player, rankId, 0);
        
        Rank rank = ranks.get(rankId);
        player.sendMessage("§a§l[RANGI] §fTwoja ranga została zmieniona na " + rank.getDisplayName());
        Bukkit.broadcastMessage("§6§l[RANGI] §e" + player.getName() + " §fotrzymał rangę " + rank.getDisplayName() + "§f!");
    }
    
    private void fillBorders(Inventory inv) {
        ItemStack gold = createItem(Material.YELLOW_STAINED_GLASS_PANE, "§6§l◆", Arrays.asList());
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, "§0§l◆", Arrays.asList());
        
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, gold);
            inv.setItem(45 + i, gold);
        }
        
        for (int i = 9; i < 45; i += 9) {
            inv.setItem(i, black);
            inv.setItem(i + 8, black);
        }
    }
    
    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }
    
    @Override
    public Inventory getInventory() {
        return null;
    }
    
    public static class Rank {
        private final String id;
        private final String displayName;
        private final String prefix;
        private final Material icon;
        private final double expMultiplier;
        private final double moneyMultiplier;
        private final double soulsMultiplier;
        private final List<String> permissions;
        private final List<String> description;
        
        public Rank(String id, String displayName, String prefix, Material icon,
                   double expMult, double moneyMult, double soulsMult,
                   List<String> permissions, List<String> description) {
            this.id = id;
            this.displayName = displayName;
            this.prefix = prefix;
            this.icon = icon;
            this.expMultiplier = expMult;
            this.moneyMultiplier = moneyMult;
            this.soulsMultiplier = soulsMult;
            this.permissions = permissions;
            this.description = description;
        }
        
        public String getId() { return id; }
        public String getDisplayName() { return displayName; }
        public String getPrefix() { return prefix; }
        public Material getIcon() { return icon; }
        public double getExpMultiplier() { return expMultiplier; }
        public double getMoneyMultiplier() { return moneyMultiplier; }
        public double getSoulsMultiplier() { return soulsMultiplier; }
        public List<String> getPermissions() { return permissions; }
        public List<String> getDescription() { return description; }
    }
}
