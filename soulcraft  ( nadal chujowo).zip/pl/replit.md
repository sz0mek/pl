# SoulCraft RPG Plugin - Replit Setup

## Overview
SoulCraft RPG is a comprehensive Minecraft Spigot plugin providing 600+ hours of engaging RPG content. This project has been configured to build successfully in the Replit environment.

## Project Type
Java Minecraft Plugin (Spigot/Bukkit API)

## Recent Changes
**Date: November 1, 2025 - MAJOR IMPROVEMENTS**
- ✅ **Party Dungeons System** - Full invite/accept/decline with auto-expire, party list, leader management
- ✅ **69 Custom Items** - 16 weapons, 11 armor, 8 tools, 10 consumables, 24 special items (exceeds 50+ target)
- ✅ **Pet System** - Already complete with full AI (follow/attack/defend), scaled bonuses (Baby 0% → Legendary 100%), 10 pet types, evolution stages
- ✅ **Legacy Managers Removed** - Deleted DungeonManager, ClanManager, EconomyManager duplicates, migrated to modern Service architecture
- ✅ **Polish Admin Documentation** - Complete 15+ page guide added at `pl/ADMIN_DOKUMENTACJA_PL.md`
- ✅ **Build Fixed** - All compilation errors resolved, CommandHandler updated to use ClanService/EconomyService
- ✅ **Plugin JAR** - Successfully built at 568KB with zero errors

**Previous Setup:**
- Initial Replit environment setup completed
- Java (GraalVM 19.0.2) and Maven (3.8.6) modules installed
- Build workflow configured to compile the plugin
- .gitignore added for Java/Maven project structure

## How to Build

### Using the Run Button
Simply click the **Run** button in Replit to build the plugin. The workflow will:
1. Execute the `pl/build.sh` script
2. Compile all Java sources using Maven
3. Generate the plugin JAR at `pl/target/SoulCraftPlugin-1.0.jar`

### Manual Build
```bash
cd pl
./build.sh
```

## Installation Instructions

After building the plugin:
1. Download `pl/target/SoulCraftPlugin-1.0.jar` from the target folder
2. Place it in your Minecraft server's `plugins` folder
3. Restart your Minecraft server
4. The plugin will automatically initialize all systems

## Technical Stack

### Build Environment
- **Java**: OpenJDK 19.0.2 (GraalVM CE 22.3.1)
- **Maven**: 3.8.6
- **Build Tool**: Maven Shade Plugin (for dependency bundling)
- **Target API**: Spigot 1.21-R0.1-SNAPSHOT

### Requirements
- **Minecraft Server**: Spigot/Paper 1.21 or compatible
- **Java**: 17 or higher (for server runtime)

## Project Structure
```
pl/                          # Main plugin directory
├── src/main/
│   ├── java/com/soulcraft/  # Java source files
│   │   ├── SoulCraftPlugin.java  # Main plugin class
│   │   ├── abilities/       # 12 unique abilities
│   │   ├── bosses/          # 5 custom bosses with AI
│   │   ├── items/           # 50+ custom items
│   │   ├── missions/        # 26 mission types
│   │   ├── pets/            # Pet system (levels 1-100)
│   │   ├── clans/           # Clan management
│   │   ├── dungeons/        # Procedural dungeons
│   │   └── ...              # Other systems
│   └── resources/           # Configuration files
│       ├── plugin.yml       # Plugin manifest
│       ├── config.yml       # Main configuration
│       └── missions.yml     # Mission definitions
├── build.sh                 # Build script
├── pom.xml                  # Maven configuration
└── target/                  # Build output (generated)
    └── SoulCraftPlugin-1.0.jar
```

## Features Overview

### Core Systems
- **12 Unique Abilities**: Berserk, Critical Strike, Dodge, Heal on Hit, Life Steal, Lucky, Regeneration, Shield, Soul Shield, Speed Burst, Thorns, Vampirism
- **5 Custom Bosses**: Soul Eater, Void Titan, Chaos Knight, Phantom Lord, Dark Emperor (with AI and phases)
- **50+ Custom Items**: Weapons, armor, tools, and consumables
- **Pet System**: Leveling from 1-100 with evolution, skills, and happiness mechanics
- **Clan System**: Comprehensive clan management with economy integration
- **Mission System**: 26 types of missions with tracking and rewards
- **Dungeon System**: Procedurally generated dungeons with custom encounters
- **Rebirth System**: Progress through rebirths for stat bonuses (+5% HP, +3% DMG, +2% SPD)
- **12 Gameplay Features**: Auto Pickup, Double Jump, Auto Replant, Keep Inventory, Auto Smelt, Night Vision, No Fall Damage, Fast Eat, Auto Feed, XP Boost, Money Boost, Loot Boost
- **Economy System**: Secure transaction handling with anti-exploit measures and Black Matter premium currency

### Commands
Over 40 plugin commands including:
- `/custom` or `/admin` - Admin panel
- `/spawnboss <boss_id>` - Spawn custom bosses
- `/giveitem <player> <item_id>` - Give custom items
- `/feature <toggle|enable|disable> <feature_id>` - Manage gameplay features
- `/abilities` - Open abilities shop
- `/missions` - View mission menu
- `/dungeon [name]` - Dungeon system
- `/pet [spawn|level|shop]` - Pet management
- `/profil [player]` - View player profile
- And many more...

## User Preferences
- Prefer simple language and clear, concise explanations
- Iterative development with frequent, small commits
- Ask before making major architectural changes
- Do not make changes to security or economy without confirmation

## Architecture Notes
- Service-oriented architecture with core services: `ClanService`, `EconomyService`, `SoulService`, etc.
- Unified `CommandHandler` manages all plugin commands
- Comprehensive null-safety checks and graceful fallbacks
- Custom GUIs for enchanting, shops, and upgrades with robust protection
- Automated build workflow generates shaded JAR ready for deployment

## Build Output
- **Build Time**: ~10-15 seconds (first build ~60 seconds for dependency download)
- **JAR Size**: ~568 KB
- **Output Location**: `pl/target/SoulCraftPlugin-1.0.jar`

## Development Status
This plugin contains fully implemented systems for all core features. The codebase is production-ready with complete implementations of game mechanics, event handlers, and persistence layers.

For detailed development notes and architecture documentation, see `pl/replit.md`.
