package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DoubleJump extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public DoubleJump(SoulCraftPlugin plugin) {
        super(
            "doublejump",
            "§b§lPodwójny Skok",
            "§7Możliwość wykonania drugiego skoku w powietrzu"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        
        // Enable flight for all players to detect double jump
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (canUse(player) && player.getGameMode() == GameMode.SURVIVAL && player.isOnGround()) {
                    player.setAllowFlight(true);
                }
            }
        }, 0L, 5L);
    }

    @Override
    public void onDisable() {
        PlayerToggleFlightEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        
        if (!canUse(player) || player.getGameMode() != GameMode.SURVIVAL) {
            return;
        }
        
        long now = System.currentTimeMillis();
        Long lastJump = cooldowns.get(player.getUniqueId());
        
        if (lastJump != null && now - lastJump < 500) {
            return;
        }
        
        event.setCancelled(true);
        player.setAllowFlight(false);
        player.setFlying(false);
        
        Vector velocity = player.getLocation().getDirection().multiply(0.6).setY(0.8);
        player.setVelocity(velocity);
        
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.3, 0.1, 0.3, 0.05);
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 0.5f, 1.5f);
        
        cooldowns.put(player.getUniqueId(), now);
    }
}
