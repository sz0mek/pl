package com.soulcraft.items.weapons;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;

import java.util.Arrays;

public class ChaosHammer extends CustomItem {
    private final SoulCraftPlugin plugin;

    public ChaosHammer(SoulCraftPlugin plugin) {
        super(
            "chaos_hammer",
            "§c§lMłot Chaosu",
            Material.NETHERITE_AXE,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §cNiszczycielska   §7│",
                "§7│ §cBroń Tytanów     §7│",
                "§7│ §fTrafienie:        §7│",
                "§7│ §eOdbicie wroga    §7│",
                "§7│ §c+50% obrażeń AoE §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Aktywne: §cUderzenie Ziemi",
                "§d⚔ Model: 1003"
            ),
            1003
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            // Ground slam AOE attack
            player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation(), 20, 3, 0.5, 3);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.7f);
            
            player.getNearbyEntities(5, 3, 5).forEach(entity -> {
                if (entity instanceof org.bukkit.entity.LivingEntity living && !(entity instanceof Player)) {
                    living.damage(15.0, player);
                    Vector knockback = living.getLocation().toVector().subtract(player.getLocation().toVector()).normalize().multiply(2);
                    living.setVelocity(knockback);
                }
            });
            
            player.sendMessage("§c§l⚡ Młot Chaosu Uderzył!");
        }
    }

    @Override
    public void onHit(Player attacker, Entity target) {
        Vector knockback = target.getLocation().toVector().subtract(attacker.getLocation().toVector()).normalize().multiply(1.5);
        target.setVelocity(knockback.setY(0.5));
        target.getWorld().spawnParticle(Particle.CRIT, target.getLocation(), 10);
    }
}
