// BossManager.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BossManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final ConcurrentHashMap<UUID, Double> playerDamage = new ConcurrentHashMap<>();
    private Wither currentBoss = null;
    private Location bossSpawnLocation = null;

    public BossManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
        loadBossSpawnLocation();
    }

    public void setBossSpawn(Player player) {
        bossSpawnLocation = player.getLocation();
        plugin.getConfig().set("boss_spawn.world", bossSpawnLocation.getWorld().getName());
        plugin.getConfig().set("boss_spawn.x", bossSpawnLocation.getX());
        plugin.getConfig().set("boss_spawn.y", bossSpawnLocation.getY());
        plugin.getConfig().set("boss_spawn.z", bossSpawnLocation.getZ());
        plugin.getConfig().set("boss_spawn.yaw", bossSpawnLocation.getYaw());
        plugin.getConfig().set("boss_spawn.pitch", bossSpawnLocation.getPitch());
        plugin.saveConfig();
        player.sendMessage("§aMiejsce spawnu bossa zostało ustawione!");
    }

    public void spawnBoss(Player player) {
        if (bossSpawnLocation == null) {
            player.sendMessage("§cNie ustawiono jeszcze miejsca spawnu bossa! Użyj /ustawboss");
            return;
        }

        if (currentBoss != null && !currentBoss.isDead()) {
            player.sendMessage("§cBoss już istnieje!");
            return;
        }

        playerDamage.clear();
        currentBoss = bossSpawnLocation.getWorld().spawn(bossSpawnLocation, Wither.class);
        currentBoss.setCustomName("§5§lKról Dusz");
        currentBoss.setCustomNameVisible(true);
        currentBoss.setMaxHealth(1000.0);
        currentBoss.setHealth(1000.0);

        Bukkit.broadcastMessage("§5§l[BOSS] Król Dusz się przebudził! Lokalizacja: " +
                bossSpawnLocation.getBlockX() + ", " + bossSpawnLocation.getBlockY() + ", "
                + bossSpawnLocation.getBlockZ());

        startBossTracker();
    }

    private void startBossTracker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (currentBoss == null || currentBoss.isDead()) {
                    this.cancel();
                    return;
                }

                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!player.getWorld().equals(currentBoss.getWorld()))
                        continue;
                    if (player.getLocation().distance(currentBoss.getLocation()) > 50)
                        continue;

                    Map.Entry<UUID, Double> top1 = getTopDamager(0);
                    Map.Entry<UUID, Double> top2 = getTopDamager(1);

                    StringBuilder message = new StringBuilder("§5§lKról Dusz §7| ");

                    if (top1 != null) {
                        Player topPlayer = Bukkit.getPlayer(top1.getKey());
                        if (topPlayer != null) {
                            message.append("§6Top 1: §f").append(topPlayer.getName())
                                    .append(" §7(").append((int) top1.getValue().doubleValue()).append(" HP)");
                        }
                    }

                    if (top2 != null) {
                        Player topPlayer = Bukkit.getPlayer(top2.getKey());
                        if (topPlayer != null) {
                            message.append(" §eTop 2: §f").append(topPlayer.getName())
                                    .append(" §7(").append((int) top2.getValue().doubleValue()).append(" HP)");
                        }
                    }

                    player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                            new TextComponent(message.toString()));
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private Map.Entry<UUID, Double> getTopDamager(int position) {
        return playerDamage.entrySet().stream()
                .sorted((e1, e2) -> Double.compare(e2.getValue(), e1.getValue()))
                .skip(position)
                .findFirst()
                .orElse(null);
    }

    @EventHandler
    public void onBossDamage(EntityDamageByEntityEvent event) {
        if (currentBoss != null && event.getEntity().equals(currentBoss) && event.getDamager() instanceof Player) {
            Player player = (Player) event.getDamager();
            UUID uuid = player.getUniqueId();
            double damage = event.getFinalDamage();

            playerDamage.merge(uuid, damage, Double::sum);
        }
    }

    @EventHandler
    public void onBossDeath(EntityDeathEvent event) {
        if (currentBoss == null || !event.getEntity().equals(currentBoss))
            return;

        Map.Entry<UUID, Double> top1 = getTopDamager(0);
        Map.Entry<UUID, Double> top2 = getTopDamager(1);

        if (top1 != null) {
            Player winner = Bukkit.getPlayer(top1.getKey());
            if (winner != null) {
                ItemStack head = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta headMeta = (SkullMeta) head.getItemMeta();
                headMeta.setDisplayName("§5Głowa Króla Dusz");
                headMeta.setLore(Arrays.asList(
                        "§7Rzadki przedmiot z bossa",
                        "§7Użyj u Czarodziejki do stworzenia",
                        "§7legendarnego miecza!"));
                head.setItemMeta(headMeta);

                winner.getInventory().addItem(head);
                plugin.getSoulManager().addSouls(winner.getUniqueId().toString(), 200);
                Bukkit.broadcastMessage("§6" + winner.getName()
                        + " §ezdobył nagrodę za Top 1 obrażenia! (+200 dusz, Głowa Króla Dusz)");
            }
        }

        if (top2 != null) {
            Player second = Bukkit.getPlayer(top2.getKey());
            if (second != null) {
                plugin.getSoulManager().addSouls(second.getUniqueId().toString(), 100);
                Bukkit.broadcastMessage("§6" + second.getName() + " §ezdobył nagrodę za Top 2 obrażenia! (+100 dusz)");
            }
        }

        currentBoss = null;
        playerDamage.clear();
    }

    private void loadBossSpawnLocation() {
        if (plugin.getConfig().contains("boss_spawn.world")) {
            World world = Bukkit.getWorld(plugin.getConfig().getString("boss_spawn.world"));
            if (world != null) {
                double x = plugin.getConfig().getDouble("boss_spawn.x");
                double y = plugin.getConfig().getDouble("boss_spawn.y");
                double z = plugin.getConfig().getDouble("boss_spawn.z");
                float yaw = (float) plugin.getConfig().getDouble("boss_spawn.yaw");
                float pitch = (float) plugin.getConfig().getDouble("boss_spawn.pitch");
                bossSpawnLocation = new Location(world, x, y, z, yaw, pitch);
            }
        }
    }
}