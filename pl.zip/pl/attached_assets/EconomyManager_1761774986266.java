// EconomyManager.java
package com.soulcraft;

public class EconomyManager {
    private final SoulCraftPlugin plugin;

    public EconomyManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public double getBalance(String uuid) {
        return plugin.getConfig().getDouble("players." + uuid + ".balance", 0.0);
    }

    public void addBalance(String uuid, double amount) {
        double current = getBalance(uuid);
        plugin.getConfig().set("players." + uuid + ".balance", current + amount);
        plugin.saveConfig();
    }

    public void removeBalance(String uuid, double amount) {
        double current = getBalance(uuid);
        plugin.getConfig().set("players." + uuid + ".balance", Math.max(0, current - amount));
        plugin.saveConfig();
    }

    public int getBlackMatter(String uuid) {
        return plugin.getConfig().getInt("players." + uuid + ".blackMatter", 0);
    }

    public void addBlackMatter(String uuid, int amount) {
        int current = getBlackMatter(uuid);
        plugin.getConfig().set("players." + uuid + ".blackMatter", current + amount);
        plugin.saveConfig();
    }

    public void removeBlackMatter(String uuid, int amount) {
        int current = getBlackMatter(uuid);
        plugin.getConfig().set("players." + uuid + ".blackMatter", Math.max(0, current - amount));
        plugin.saveConfig();
    }
}
