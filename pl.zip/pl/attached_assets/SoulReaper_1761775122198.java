package com.soulcraft.items.weapons;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class SoulReaper extends CustomItem {
    private final SoulCraftPlugin plugin;

    public SoulReaper(SoulCraftPlugin plugin) {
        super(
            "soul_reaper",
            "§5§lKosa Dusz",
            Material.NETHERITE_SWORD,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Legendarny Miecz §7│",
                "§7│ §fKażde zabicie:    §7│",
                "§7│ §a+5% więcej dusz  §7│",
                "§7│ §cRegeneracja HP    §7│",
                "§7│ §dEfekt Siły II     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §7Kradzież dusz",
                "§d⚔ Model: 1001"
            ),
            1001
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Prawy klik aby aktywować burstę dusz
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            long lastUse = player.getPersistentDataContainer().getOrDefault(
                new org.bukkit.NamespacedKey(plugin, "soul_reaper_cooldown"),
                org.bukkit.persistence.PersistentDataType.LONG,
                0L
            );
            
            if (System.currentTimeMillis() - lastUse < 30000) {
                player.sendMessage("§cUmiejętność na cooldownie!");
                return;
            }
            
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
            player.getWorld().spawnParticle(Particle.SOUL, player.getLocation(), 50, 1, 1, 1);
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SHOOT, 1.0f, 0.8f);
            player.sendMessage("§5§l✦ Moc Kosy Dusz Aktywowana!");
            
            player.getPersistentDataContainer().set(
                new org.bukkit.NamespacedKey(plugin, "soul_reaper_cooldown"),
                org.bukkit.persistence.PersistentDataType.LONG,
                System.currentTimeMillis()
            );
        }
    }

    @Override
    public void onKill(Player killer, LivingEntity killed) {
        killer.setHealth(Math.min(killer.getMaxHealth(), killer.getHealth() + 4.0));
        killer.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 1));
        killed.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, killed.getLocation(), 20);
        killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
    }
}
