package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DungeonCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    
    public DungeonCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTa komenda dostępna tylko dla graczy!");
            return true;
        }
        
        if (args.length == 0) {
            player.sendMessage("§5§l=== DOSTĘPNE DUNGEONS ===");
            player.sendMessage("§a/dungeon soul_catacombs §7- Katakumby Dusz (Lvl 1-10)");
            player.sendMessage("§a/dungeon void_abyss §7- Otchłań Pustki (Lvl 10-20)");
            player.sendMessage("§a/dungeon chaos_fortress §7- Twierdza Chaosu (Lvl 20-30)");
            player.sendMessage("§a/dungeon phantom_realm §7- Królestwo Widm (Lvl 30-40)");
            player.sendMessage("§a/dungeon eternal_sanctum §7- Wieczne Sanktuarium (Lvl 40-50)");
            return true;
        }
        
        String dungeonId = args[0].toLowerCase();
        plugin.getDungeonManager().startDungeon(player, dungeonId);
        return true;
    }
}
