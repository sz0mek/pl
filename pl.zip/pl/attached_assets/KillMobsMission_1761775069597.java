package com.soulcraft.missions.impl;

import com.soulcraft.missions.Mission;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.*;

public class KillMobsMission extends Mission {
    private final Map<UUID, Integer> progress = new HashMap<>();
    private final Map<UUID, Boolean> completed = new HashMap<>();
    private final EntityType targetMob;
    
    public KillMobsMission(String id, String displayName, String description, MissionType type,
                           int requiredProgress, List<MissionReward> rewards, String requiredRank, String mobType) {
        super(id, displayName, description, type, requiredProgress, rewards, requiredRank);
        this.targetMob = mobType != null ? EntityType.valueOf(mobType) : null;
    }
    
    @Override
    public boolean checkProgress(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof EntityType) {
            EntityType killedMob = (EntityType) args[0];
            if (targetMob == null || killedMob == targetMob) {
                incrementProgress(player.getUniqueId(), 1);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int getProgress(UUID playerId) {
        return progress.getOrDefault(playerId, 0);
    }
    
    @Override
    public void setProgress(UUID playerId, int value) {
        progress.put(playerId, value);
    }
    
    @Override
    public void incrementProgress(UUID playerId, int amount) {
        int current = getProgress(playerId);
        setProgress(playerId, Math.min(current + amount, requiredProgress));
    }
    
    @Override
    public boolean isCompleted(UUID playerId) {
        return completed.getOrDefault(playerId, false);
    }
    
    @Override
    public void complete(Player player) {
        completed.put(player.getUniqueId(), true);
        giveRewards(player);
        player.sendMessage("§a§l✔ Ukończono misję: " + displayName);
        player.sendMessage("§7Nagrody zostały przyznane!");
    }
    
    @Override
    public void giveRewards(Player player) {
        for (MissionReward reward : rewards) {
            // Rewards będą obsługiwane przez MissionManager
        }
    }
    
    @Override
    public void reset(UUID playerId) {
        progress.remove(playerId);
        completed.remove(playerId);
    }
}
