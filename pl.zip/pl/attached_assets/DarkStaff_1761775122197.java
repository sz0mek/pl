package com.soulcraft.items.weapons;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Arrays;

public class DarkStaff extends CustomItem {
    private final SoulCraftPlugin plugin;

    public DarkStaff(SoulCraftPlugin plugin) {
        super(
            "dark_staff",
            "§5§lLaska Ciemności",
            Material.BLAZE_ROD,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Magiczna Laska  §7│",
                "§7│ §fMoc:             §7│",
                "§7│ §5Wystrzeliwanie  §7│",
                "§7│ §5ciemnej energii  §7│",
                "§7│ §dOchrona przed   §7│",
                "§7│ §dmagią            §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Aktywne: §5Kula Ciemności",
                "§d⚔ Model: 1005"
            ),
            1005
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            // Shoot dark projectile
            Vector direction = player.getLocation().getDirection().multiply(2);
            org.bukkit.entity.Snowball projectile = player.launchProjectile(org.bukkit.entity.Snowball.class);
            projectile.setVelocity(direction);
            projectile.setCustomName("§5Dark Energy");
            
            player.getWorld().spawnParticle(Particle.WITCH, player.getLocation(), 30, 0.5, 0.5, 0.5);
            player.playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0f, 0.8f);
            player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
        }
    }
}
