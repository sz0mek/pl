package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;

public class AutoSmelt extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public AutoSmelt(SoulCraftPlugin plugin) {
        super(
            "autosmelt",
            "§c§lAuto Smelt",
            "§7Automatyczne przetapianie rud"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        BlockBreakEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onOreBreak(BlockBreakEvent event) {
        if (!canUse(event.getPlayer())) {
            return;
        }
        
        Block block = event.getBlock();
        Material smeltedType = getSmeltedType(block.getType());
        
        if (smeltedType == null) {
            return;
        }
        
        Collection<ItemStack> drops = block.getDrops(event.getPlayer().getInventory().getItemInMainHand());
        event.setDropItems(false);
        
        for (ItemStack drop : drops) {
            if (drop.getType() == block.getType() || isOre(drop.getType())) {
                block.getWorld().dropItemNaturally(
                    block.getLocation(),
                    new ItemStack(smeltedType, drop.getAmount())
                );
            } else {
                block.getWorld().dropItemNaturally(block.getLocation(), drop);
            }
        }
        
        block.getWorld().spawnParticle(Particle.FLAME, block.getLocation().add(0.5, 0.5, 0.5), 10);
        block.getWorld().playSound(block.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5f, 1.0f);
    }

    private Material getSmeltedType(Material oreType) {
        return switch (oreType) {
            case IRON_ORE, DEEPSLATE_IRON_ORE -> Material.IRON_INGOT;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE -> Material.GOLD_INGOT;
            case COPPER_ORE, DEEPSLATE_COPPER_ORE -> Material.COPPER_INGOT;
            case ANCIENT_DEBRIS -> Material.NETHERITE_SCRAP;
            default -> null;
        };
    }

    private boolean isOre(Material type) {
        return type == Material.RAW_IRON || type == Material.RAW_GOLD || 
               type == Material.RAW_COPPER;
    }
}
