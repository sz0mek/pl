package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveItemCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;

    public GiveItemCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("soulcraft.admin")) {
            sender.sendMessage("§cBrak uprawnień!");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage("§eUżycie: /giveitem <gracz> <item_id> [ilość]");
            sender.sendMessage("§7Przykład: /giveitem Steve soul_reaper 1");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage("§cGracz nie znaleziony!");
            return true;
        }

        String itemId = args[1].toLowerCase();
        int amount = args.length >= 3 ? Integer.parseInt(args[2]) : 1;

        ItemStack item = plugin.getCustomItemRegistry().createItem(itemId, amount);
        if (item == null) {
            sender.sendMessage("§cNieznany custom item: " + itemId);
            return true;
        }

        target.getInventory().addItem(item);
        target.sendMessage("§a§lOtrzymałeś custom item: §e" + itemId + " §7x" + amount);
        sender.sendMessage("§a§lDano " + target.getName() + " item: §e" + itemId + " §7x" + amount);
        return true;
    }
}
