package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class MarketManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Set<UUID> activePlayers = new HashSet<>();
    private final Map<UUID, String> playerCategory = new HashMap<>();

    public MarketManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void addItemToMarket(Player player, ItemStack item, double price) {
        String id = UUID.randomUUID().toString();
        ConfigurationSection market = plugin.getConfig().getConfigurationSection("market");
        if (market == null)
            market = plugin.getConfig().createSection("market");

        plugin.getConfig().set("market." + id + ".seller", player.getName());
        plugin.getConfig().set("market." + id + ".sellerUUID", player.getUniqueId().toString());
        plugin.getConfig().set("market." + id + ".price", price);
        plugin.getConfig().set("market." + id + ".item", item);
        plugin.saveConfig();
        player.sendMessage("§aPrzedmiot wystawiony na rynek za " + price + " hajsu.");
    }

    public void openMarketGUI(Player player) {
        openCategorySelectionGUI(player);
    }

    private void openCategorySelectionGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new MarketCategoryHolder(), 27, "§6Rynek - Wybierz kategorię");
        activePlayers.add(player.getUniqueId());

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.setDisplayName(" ");
            filler.setItemMeta(fillerMeta);
        }
        for (int i = 0; i < 27; i++)
            gui.setItem(i, filler);

        // All items button
        ItemStack allItems = new ItemStack(Material.CHEST);
        ItemMeta allMeta = allItems.getItemMeta();
        if (allMeta != null) {
            allMeta.setDisplayName("§aWszystkie przedmioty");
            allMeta.setLore(Arrays.asList("§7Zobacz wszystkie przedmioty", "§7dostępne na rynku"));
            allItems.setItemMeta(allMeta);
        }
        gui.setItem(11, allItems);

        // My items button
        ItemStack myItems = new ItemStack(Material.ENDER_CHEST);
        ItemMeta myMeta = myItems.getItemMeta();
        if (myMeta != null) {
            myMeta.setDisplayName("§eMoje przedmioty");
            myMeta.setLore(
                    Arrays.asList("§7Zobacz przedmioty które", "§7wystawiłeś na rynek", "§7i usuń je jeśli chcesz"));
            myItems.setItemMeta(myMeta);
        }
        gui.setItem(15, myItems);

        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        if (closeMeta != null) {
            closeMeta.setDisplayName("§cZamknij");
            close.setItemMeta(closeMeta);
        }
        gui.setItem(22, close);

        player.openInventory(gui);
    }

    private void openAllItemsGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new MarketAllHolder(), 54, "§6Rynek - Wszystkie przedmioty");
        activePlayers.add(player.getUniqueId());
        playerCategory.put(player.getUniqueId(), "all");

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.setDisplayName(" ");
            filler.setItemMeta(fillerMeta);
        }
        for (int i = 0; i < 54; i++)
            gui.setItem(i, filler);

        ConfigurationSection market = plugin.getConfig().getConfigurationSection("market");
        if (market != null) {
            int slot = 0;
            for (String key : market.getKeys(false)) {
                if (slot >= 45)
                    break;
                ItemStack item = plugin.getConfig().getItemStack("market." + key + ".item");
                String seller = plugin.getConfig().getString("market." + key + ".seller");
                String sellerUUID = plugin.getConfig().getString("market." + key + ".sellerUUID");
                double price = plugin.getConfig().getDouble("market." + key + ".price", 0.0);
                if (item == null || seller == null)
                    continue;

                // Skip items from this player
                if (sellerUUID.equals(player.getUniqueId().toString()))
                    continue;

                ItemStack display = item.clone();
                ItemMeta meta = display.getItemMeta();
                if (meta != null) {
                    List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                    lore.add("");
                    lore.add("§7Sprzedawca: §f" + seller);
                    lore.add("§7Cena: §6" + price + " hajsu");
                    lore.add("§aKliknij LPM aby kupić!");
                    meta.setLore(lore);
                    display.setItemMeta(meta);
                }
                gui.setItem(slot++, display);
            }
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§ePowrót");
            back.setItemMeta(backMeta);
        }
        gui.setItem(49, back);

        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        if (closeMeta != null) {
            closeMeta.setDisplayName("§cZamknij");
            close.setItemMeta(closeMeta);
        }
        gui.setItem(53, close);

        player.openInventory(gui);
    }

    private void openMyItemsGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new MarketMyHolder(), 54, "§6Rynek - Moje przedmioty");
        activePlayers.add(player.getUniqueId());
        playerCategory.put(player.getUniqueId(), "my");

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.setDisplayName(" ");
            filler.setItemMeta(fillerMeta);
        }
        for (int i = 0; i < 54; i++)
            gui.setItem(i, filler);

        ConfigurationSection market = plugin.getConfig().getConfigurationSection("market");
        if (market != null) {
            int slot = 0;
            for (String key : market.getKeys(false)) {
                if (slot >= 45)
                    break;
                ItemStack item = plugin.getConfig().getItemStack("market." + key + ".item");
                String sellerUUID = plugin.getConfig().getString("market." + key + ".sellerUUID");
                double price = plugin.getConfig().getDouble("market." + key + ".price", 0.0);
                if (item == null)
                    continue;

                // Only show items from this player
                if (!sellerUUID.equals(player.getUniqueId().toString()))
                    continue;

                ItemStack display = item.clone();
                ItemMeta meta = display.getItemMeta();
                if (meta != null) {
                    List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                    lore.add("");
                    lore.add("§7Cena: §6" + price + " hajsu");
                    lore.add("§cKliknij LPM aby usunąć z rynku!");
                    meta.setLore(lore);
                    display.setItemMeta(meta);
                }
                gui.setItem(slot++, display);
            }
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§ePowrót");
            back.setItemMeta(backMeta);
        }
        gui.setItem(49, back);

        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        if (closeMeta != null) {
            closeMeta.setDisplayName("§cZamknij");
            close.setItemMeta(closeMeta);
        }
        gui.setItem(53, close);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;

        InventoryHolder holder = event.getView().getTopInventory().getHolder();

        if (holder instanceof MarketCategoryHolder) {
            handleCategoryClick(event, player);
        } else if (holder instanceof MarketAllHolder) {
            handleAllItemsClick(event, player);
        } else if (holder instanceof MarketMyHolder) {
            handleMyItemsClick(event, player);
        }
    }

    private void handleCategoryClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE)
            return;

        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activePlayers.remove(player.getUniqueId());
            return;
        }

        if (raw == 11) { // All items
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openAllItemsGUI(player), 1L);
        } else if (raw == 15) { // My items
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> openMyItemsGUI(player), 1L);
        }
    }

    private void handleAllItemsClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE)
            return;

        // Back button
        if (clicked.getType() == Material.ARROW && raw == 49) {
            player.closeInventory();
            playerCategory.remove(player.getUniqueId());
            Bukkit.getScheduler().runTaskLater(plugin, () -> openCategorySelectionGUI(player), 1L);
            return;
        }

        // Close button
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activePlayers.remove(player.getUniqueId());
            playerCategory.remove(player.getUniqueId());
            return;
        }

        // Buying via left click only
        if (!event.getClick().isLeftClick())
            return;

        processPurchase(player, clicked);
    }

    private void handleMyItemsClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE)
            return;

        // Back button
        if (clicked.getType() == Material.ARROW && raw == 49) {
            player.closeInventory();
            playerCategory.remove(player.getUniqueId());
            Bukkit.getScheduler().runTaskLater(plugin, () -> openCategorySelectionGUI(player), 1L);
            return;
        }

        // Close button
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            activePlayers.remove(player.getUniqueId());
            playerCategory.remove(player.getUniqueId());
            return;
        }

        // Remove item via left click
        if (!event.getClick().isLeftClick())
            return;

        removeMyItem(player, clicked);
    }

    private void processPurchase(Player player, ItemStack clicked) {
        ConfigurationSection market = plugin.getConfig().getConfigurationSection("market");
        if (market == null)
            return;

        // Normalize clicked item
        ItemStack normalized = clicked.clone();
        ItemMeta nm = normalized.getItemMeta();
        if (nm != null && nm.hasLore()) {
            List<String> lore = new ArrayList<>(nm.getLore());
            lore.removeIf(line -> line.contains("Sprzedawca:") || line.contains("Cena:") || line.contains("Kliknij"));
            while (lore.size() > 0 && lore.get(lore.size() - 1).trim().isEmpty()) {
                lore.remove(lore.size() - 1);
            }
            nm.setLore(lore.isEmpty() ? null : lore);
            normalized.setItemMeta(nm);
        }

        String foundKey = null;
        for (String key : market.getKeys(false)) {
            ItemStack marketItem = plugin.getConfig().getItemStack("market." + key + ".item");
            if (marketItem == null)
                continue;
            String sellerUUID = plugin.getConfig().getString("market." + key + ".sellerUUID");
            if (sellerUUID.equals(player.getUniqueId().toString()))
                continue;
            if (areItemsEqual(marketItem, normalized)) {
                foundKey = key;
                break;
            }
        }

        if (foundKey == null) {
            player.sendMessage("§cNie znaleziono tego przedmiotu na rynku!");
            return;
        }

        String sellerName = plugin.getConfig().getString("market." + foundKey + ".seller", "");
        String sellerUUID = plugin.getConfig().getString("market." + foundKey + ".sellerUUID", "");
        double price = plugin.getConfig().getDouble("market." + foundKey + ".price", 0.0);

        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId().toString());
        if (balance < price) {
            player.sendMessage("§cNie masz wystarczająco hajsu! Potrzebujesz " + price + " hajsu.");
            return;
        }

        // Transfer money
        plugin.getEconomyManager().removeBalance(player.getUniqueId().toString(), price);

        // Give money to seller
        Player sellerPlayer = Bukkit.getPlayer(sellerName);
        if (sellerPlayer != null && sellerPlayer.getUniqueId().toString().equals(sellerUUID)) {
            plugin.getEconomyManager().addBalance(sellerUUID, price);
            player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
            player.sendMessage("§a§l  ✓ SPRZEDAŻ POMYŚLNA! ✓");
            sellerPlayer.sendMessage("§a§fTwój przedmiot został sprzedany za " + price + " hajsu!");
            player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
        } else if (!sellerUUID.isEmpty()) {
            plugin.getEconomyManager().addBalance(sellerUUID, price);
        }

        // Give item to buyer
        ItemStack marketItem = plugin.getConfig().getItemStack("market." + foundKey + ".item");
        if (marketItem != null) {
            player.getInventory().addItem(marketItem);
        }

        // Remove from market
        plugin.getConfig().set("market." + foundKey, null);
        plugin.saveConfig();

        player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
        player.sendMessage("§a§l  ✓ ZAKUP POMYŚLNY! ✓");
        player.sendMessage("§aKupiłeś przedmiot za " + price + " hajsu!");
        player.sendMessage("§5§l⭐ ═══════════════════════════════ ⭐");
        player.closeInventory();
        activePlayers.remove(player.getUniqueId());
        playerCategory.remove(player.getUniqueId());
    }

    private void removeMyItem(Player player, ItemStack clicked) {
        ConfigurationSection market = plugin.getConfig().getConfigurationSection("market");
        if (market == null)
            return;

        // Normalize clicked item
        ItemStack normalized = clicked.clone();
        ItemMeta nm = normalized.getItemMeta();
        if (nm != null && nm.hasLore()) {
            List<String> lore = new ArrayList<>(nm.getLore());
            lore.removeIf(line -> line.contains("Cena:") || line.contains("Kliknij"));
            while (lore.size() > 0 && lore.get(lore.size() - 1).trim().isEmpty()) {
                lore.remove(lore.size() - 1);
            }
            nm.setLore(lore.isEmpty() ? null : lore);
            normalized.setItemMeta(nm);
        }

        String foundKey = null;
        for (String key : market.getKeys(false)) {
            ItemStack marketItem = plugin.getConfig().getItemStack("market." + key + ".item");
            if (marketItem == null)
                continue;
            String sellerUUID = plugin.getConfig().getString("market." + key + ".sellerUUID");
            if (!sellerUUID.equals(player.getUniqueId().toString()))
                continue;
            if (areItemsEqual(marketItem, normalized)) {
                foundKey = key;
                break;
            }
        }

        if (foundKey == null) {
            player.sendMessage("§cNie znaleziono tego przedmiotu!");
            return;
        }

        // Return item to player
        ItemStack marketItem = plugin.getConfig().getItemStack("market." + foundKey + ".item");
        if (marketItem != null) {
            player.getInventory().addItem(marketItem);
        }

        // Remove from market
        plugin.getConfig().set("market." + foundKey, null);
        plugin.saveConfig();

        player.sendMessage("§aPrzedmiot został usunięty z rynku i zwrócony do ekwipunku!");
        player.closeInventory();
        activePlayers.remove(player.getUniqueId());
        playerCategory.remove(player.getUniqueId());
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player))
            return;

        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof MarketCategoryHolder || holder instanceof MarketAllHolder
                || holder instanceof MarketMyHolder) {
            for (int slot : event.getRawSlots()) {
                if (slot < event.getView().getTopInventory().getSize()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player))
            return;

        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof MarketCategoryHolder || holder instanceof MarketAllHolder
                || holder instanceof MarketMyHolder) {
            activePlayers.remove(player.getUniqueId());
            playerCategory.remove(player.getUniqueId());
        }
    }

    private boolean areItemsEqual(ItemStack a, ItemStack b) {
        if (a == null || b == null)
            return false;
        if (a.getType() != b.getType())
            return false;

        ItemStack aCopy = a.clone();
        ItemStack bCopy = b.clone();
        aCopy.setAmount(1);
        bCopy.setAmount(1);

        if (!aCopy.hasItemMeta() && !bCopy.hasItemMeta())
            return true;
        if (!aCopy.hasItemMeta() || !bCopy.hasItemMeta())
            return false;

        ItemMeta ma = aCopy.getItemMeta();
        ItemMeta mb = bCopy.getItemMeta();

        // Compare display names
        String na = ma.hasDisplayName() ? ma.getDisplayName() : "";
        String nb = mb.hasDisplayName() ? mb.getDisplayName() : "";
        if (!na.equals(nb))
            return false;

        // Compare lore with proper normalization (FIX: better edge case handling)
        List<String> la = ma.hasLore() ? new ArrayList<>(ma.getLore()) : new ArrayList<>();
        List<String> lb = mb.hasLore() ? new ArrayList<>(mb.getLore()) : new ArrayList<>();
        
        // Trim trailing empty lines from both
        while (!la.isEmpty() && (la.get(la.size() - 1) == null || la.get(la.size() - 1).trim().isEmpty())) {
            la.remove(la.size() - 1);
        }
        while (!lb.isEmpty() && (lb.get(lb.size() - 1) == null || lb.get(lb.size() - 1).trim().isEmpty())) {
            lb.remove(lb.size() - 1);
        }
        
        if (!la.equals(lb))
            return false;

        // Compare enchantments
        if (!ma.getEnchants().equals(mb.getEnchants()))
            return false;
            
        // Compare custom model data if present
        if (ma.hasCustomModelData() != mb.hasCustomModelData())
            return false;
        if (ma.hasCustomModelData() && ma.getCustomModelData() != mb.getCustomModelData())
            return false;

        return true;
    }

    private static class MarketCategoryHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static class MarketAllHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static class MarketMyHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
