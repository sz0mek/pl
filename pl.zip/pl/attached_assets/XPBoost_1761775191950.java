package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerExpChangeEvent;

public class XPBoost extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;
    private final double multiplier = 2.0;

    public XPBoost(SoulCraftPlugin plugin) {
        super(
            "xpboost",
            "§b§lBoost XP",
            "§7Podwójne doświadczenie ze wszystkich źródeł"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        PlayerExpChangeEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onExpGain(PlayerExpChangeEvent event) {
        if (!canUse(event.getPlayer())) {
            return;
        }
        
        int boostedAmount = (int) (event.getAmount() * multiplier);
        event.setAmount(boostedAmount);
    }
}
