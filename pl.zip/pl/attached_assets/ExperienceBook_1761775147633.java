package com.soulcraft.items.special;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class ExperienceBook extends CustomItem {
    public ExperienceBook(SoulCraftPlugin plugin) {
        super(
            "experience_book",
            "§a§lKsięga Doświadczenia",
            Material.ENCHANTED_BOOK,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §aMagiczna Księga §7│",
                "§7│ §fEfekt:           §7│",
                "§7│ §a+500 EXP        §7│",
                "§7│ §2+5 Poziomów     §7│",
                "§7│ §eNatychmiastowe  §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §aBłyskawiczny rozwój",
                "§d⚔ Model: 5003"
            ),
            5003
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            player.giveExp(500);
            player.setLevel(player.getLevel() + 5);
            
            player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation(), 100, 1, 1, 1);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            player.sendMessage("§a§l✦ Zdobyłeś +500 EXP i +5 poziomów!");
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
