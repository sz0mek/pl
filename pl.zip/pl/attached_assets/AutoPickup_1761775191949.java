package com.soulcraft.features.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.features.GameFeature;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPickupItemEvent;

public class AutoPickup extends GameFeature implements Listener {
    private final SoulCraftPlugin plugin;

    public AutoPickup(SoulCraftPlugin plugin) {
        super(
            "autopickup",
            "§a§lAuto Pickup",
            "§7Automatyczne podnoszenie przedmiotów"
        );
        this.plugin = plugin;
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onDisable() {
        PlayerPickupItemEvent.getHandlerList().unregister(this);
    }

    @EventHandler
    public void onItemPickup(PlayerPickupItemEvent event) {
        if (!canUse(event.getPlayer())) {
            return;
        }
        
        if (event.getPlayer().getGameMode() == GameMode.CREATIVE) {
            return;
        }
        
        // Item automatically goes to inventory - no special handling needed
        // This feature just grants permission to pick up items automatically
    }
}
