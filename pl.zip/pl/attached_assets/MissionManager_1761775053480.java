package com.soulcraft.missions;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.missions.impl.*;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class MissionManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Mission> allMissions;
    private final Map<UUID, Set<String>> playerCompletedMissions;
    private final Map<UUID, Map<String, Integer>> playerMissionProgress;
    private File missionsFile;
    private FileConfiguration missionsConfig;
    
    public MissionManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        this.allMissions = new HashMap<>();
        this.playerCompletedMissions = new HashMap<>();
        this.playerMissionProgress = new HashMap<>();
        
        loadMissionsData();
        registerMissions();
        startDailyReset();
        startWeeklyReset();
    }
    
    private void loadMissionsData() {
        missionsFile = new File(plugin.getDataFolder(), "missions.yml");
        if (!missionsFile.exists()) {
            plugin.saveResource("missions.yml", false);
        }
        missionsConfig = YamlConfiguration.loadConfiguration(missionsFile);
    }
    
    private void saveMissionsData() {
        try {
            missionsConfig.save(missionsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Nie można zapisać missions.yml: " + e.getMessage());
        }
    }
    
    private void registerMissions() {
        // DAILY MISSIONS (10 misji)
        allMissions.put("daily_kill_10_mobs", new KillMobsMission("daily_kill_10_mobs", 
            "§e§lZabij 10 Mobów", "§7Zabij 10 dowolnych mobów", Mission.MissionType.DAILY, 
            10, createRewards(100, 50, 100), "gracz", null));
            
        allMissions.put("daily_kill_20_mobs", new KillMobsMission("daily_kill_20_mobs",
            "§e§lZabij 20 Mobów", "§7Zabij 20 dowolnych mobów", Mission.MissionType.DAILY,
            20, createRewards(250, 100, 200), "gracz", null));
            
        allMissions.put("daily_kill_zombie", new KillMobsMission("daily_kill_zombie",
            "§e§lŁowca Zombie", "§7Zabij 15 zombie", Mission.MissionType.DAILY,
            15, createRewards(200, 80, 150), "gracz", "ZOMBIE"));
            
        allMissions.put("daily_mine_50_blocks", new MineBlocksMission("daily_mine_50_blocks",
            "§e§lGórnik", "§7Wykop 50 bloków", Mission.MissionType.DAILY,
            50, createRewards(150, 60, 100), "gracz"));
            
        allMissions.put("daily_kill_boss", new KillBossMission("daily_kill_boss",
            "§e§lZabójca Bossa", "§7Zabij dowolnego bossa", Mission.MissionType.DAILY,
            1, createRewardsWithAbility(500, 200, 500, "dodge"), "vip"));
            
        allMissions.put("daily_earn_souls", new EarnSoulsMission("daily_earn_souls",
            "§e§lZbieracz Dusz", "§7Zdobądź 500 dusz", Mission.MissionType.DAILY,
            500, createRewards(300, 150, 200), "gracz"));
            
        allMissions.put("daily_complete_dungeon", new CompleteDungeonMission("daily_complete_dungeon",
            "§e§lWłóczęga Dungeonów", "§7Ukończ dowolny dungeon", Mission.MissionType.DAILY,
            1, createRewardsWithAbility(600, 250, 600, "speed_burst"), "vip"));
            
        allMissions.put("daily_kill_5_players", new KillPlayersMission("daily_kill_5_players",
            "§e§lGłowa Łowca", "§7Zabij 5 graczy", Mission.MissionType.DAILY,
            5, createRewards(800, 400, 800), "svip"));
            
        allMissions.put("daily_collect_loot", new CollectLootMission("daily_collect_loot",
            "§e§lKolekcjoner", "§7Zbierz 100 itemów", Mission.MissionType.DAILY,
            100, createRewards(200, 100, 150), "gracz"));
            
        allMissions.put("daily_use_abilities", new UseAbilitiesMission("daily_use_abilities",
            "§e§lMistrz Zdolności", "§7Użyj abilities 20 razy", Mission.MissionType.DAILY,
            20, createRewards(400, 200, 400), "svip"));
        
        // WEEKLY MISSIONS (10 misji)
        allMissions.put("weekly_kill_100_mobs", new KillMobsMission("weekly_kill_100_mobs",
            "§6§lRzeź Mobów", "§7Zabij 100 mobów w tym tygodniu", Mission.MissionType.WEEKLY,
            100, createRewardsWithAbility(2000, 1000, 2000, "heal_on_hit"), "gracz", null));
            
        allMissions.put("weekly_kill_5_bosses", new KillBossMission("weekly_kill_5_bosses",
            "§6§lPojemniak Bossów", "§7Zabij 5 bossów", Mission.MissionType.WEEKLY,
            5, createRewardsWithAbility(3000, 1500, 3000, "critical_strike"), "vip"));
            
        allMissions.put("weekly_mine_500_blocks", new MineBlocksMission("weekly_mine_500_blocks",
            "§6§lKról Górników", "§7Wykop 500 bloków", Mission.MissionType.WEEKLY,
            500, createRewards(1500, 800, 1500), "gracz"));
            
        allMissions.put("weekly_earn_5000_souls", new EarnSoulsMission("weekly_earn_5000_souls",
            "§6§lMistrz Dusz", "§7Zdobądź 5000 dusz", Mission.MissionType.WEEKLY,
            5000, createRewardsWithAbility(2500, 1200, 2500, "life_steal"), "vip"));
            
        allMissions.put("weekly_complete_5_dungeons", new CompleteDungeonMission("weekly_complete_5_dungeons",
            "§6§lWładca Dungeonów", "§7Ukończ 5 dungeonów", Mission.MissionType.WEEKLY,
            5, createRewardsWithAbility(4000, 2000, 4000, "thorns"), "svip"));
            
        allMissions.put("weekly_kill_20_players", new KillPlayersMission("weekly_kill_20_players",
            "§6§lLegienda PvP", "§7Zabij 20 graczy", Mission.MissionType.WEEKLY,
            20, createRewardsWithAbility(5000, 2500, 5000, "berserk"), "soulgod"));
            
        allMissions.put("weekly_win_3_clan_wars", new ClanWarsMission("weekly_win_3_clan_wars",
            "§6§lWojownik Klanu", "§7Wygraj 3 wojny klanowe", Mission.MissionType.WEEKLY,
            3, createRewards(3000, 1500, 3000), "svip"));
            
        allMissions.put("weekly_complete_all_daily", new CompleteAllDailyMission("weekly_complete_all_daily",
            "§6§lPerfekt Tygodnia", "§7Ukończ wszystkie daily przez 7 dni", Mission.MissionType.WEEKLY,
            7, createRewardsWithAbility(10000, 5000, 10000, "soul_shield"), "soulgod"));
            
        allMissions.put("weekly_level_pet_10", new LevelPetMission("weekly_level_pet_10",
            "§6§lTrener Petów", "§7Zwiększ poziom peta o 10", Mission.MissionType.WEEKLY,
            10, createRewards(2000, 1000, 2000), "vip"));
            
        allMissions.put("weekly_spend_10000_souls", new SpendSoulsMission("weekly_spend_10000_souls",
            "§6§lKról Ekonomii", "§7Wydaj 10000 dusz", Mission.MissionType.WEEKLY,
            10000, createRewards(3000, 1500, 3000), "svip"));
        
        // ACHIEVEMENT MISSIONS (30+ achievements)
        registerAchievements();
    }
    
    private void registerAchievements() {
        // Achievements - Kill related
        allMissions.put("ach_kill_1000_mobs", new KillMobsMission("ach_kill_1000_mobs",
            "§5§lŻniwiarz", "§7Zabij 1000 mobów", Mission.MissionType.ACHIEVEMENT,
            1000, createRewardsWithAbility(5000, 2500, 5000, "regeneration"), "gracz", null));
            
        allMissions.put("ach_kill_100_bosses", new KillBossMission("ach_kill_100_bosses",
            "§5§lLegenda Bossów", "§7Zabij 100 bossów", Mission.MissionType.ACHIEVEMENT,
            100, createRewardsWithAbility(20000, 10000, 20000, "shield"), "vip"));
            
        allMissions.put("ach_kill_soul_eater", new KillSpecificBossMission("ach_kill_soul_eater",
            "§5§lPojemniak Dusz", "§7Zabij Soul Eatera", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(1000, 500, 1000), "gracz", "soul_eater"));
            
        allMissions.put("ach_kill_void_titan", new KillSpecificBossMission("ach_kill_void_titan",
            "§5§lZabójca Tytana", "§7Zabij Void Titana", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(1500, 750, 1500), "gracz", "void_titan"));
            
        allMissions.put("ach_kill_dark_emperor", new KillSpecificBossMission("ach_kill_dark_emperor",
            "§5§lImperator Zdetronizowany", "§7Zabij Dark Emperora", Mission.MissionType.ACHIEVEMENT,
            1, createRewardsWithAbility(3000, 1500, 3000, "vampirism"), "vip", "dark_emperor"));
        
        // Achievements - Mining/Gathering
        allMissions.put("ach_mine_10000_blocks", new MineBlocksMission("ach_mine_10000_blocks",
            "§5§lKról Górników", "§7Wykop 10000 bloków", Mission.MissionType.ACHIEVEMENT,
            10000, createRewards(8000, 4000, 8000), "gracz"));
            
        allMissions.put("ach_collect_1000_items", new CollectLootMission("ach_collect_1000_items",
            "§5§lZbieracz Mistrz", "§7Zbierz 1000 itemów", Mission.MissionType.ACHIEVEMENT,
            1000, createRewards(5000, 2500, 5000), "gracz"));
        
        // Achievements - Economy
        allMissions.put("ach_earn_50000_souls", new EarnSoulsMission("ach_earn_50000_souls",
            "§5§lMagnat Dusz", "§7Zdobądź 50000 dusz", Mission.MissionType.ACHIEVEMENT,
            50000, createRewards(10000, 5000, 10000), "vip"));
            
        allMissions.put("ach_spend_100000_souls", new SpendSoulsMission("ach_spend_100000_souls",
            "§5§lMarnotrawca", "§7Wydaj 100000 dusz", Mission.MissionType.ACHIEVEMENT,
            100000, createRewards(15000, 7500, 15000), "svip"));
        
        // Achievements - Dungeons
        allMissions.put("ach_complete_50_dungeons", new CompleteDungeonMission("ach_complete_50_dungeons",
            "§5§lWłóczęga Dungeonów", "§7Ukończ 50 dungeonów", Mission.MissionType.ACHIEVEMENT,
            50, createRewardsWithAbility(12000, 6000, 12000, "lucky"), "svip"));
        
        // Achievements - PvP
        allMissions.put("ach_kill_100_players", new KillPlayersMission("ach_kill_100_players",
            "§5§lŻniwiarz Graczy", "§7Zabij 100 graczy", Mission.MissionType.ACHIEVEMENT,
            100, createRewards(10000, 5000, 10000), "svip"));
        
        // Achievements - Clan
        allMissions.put("ach_create_clan", new CreateClanMission("ach_create_clan",
            "§5§lZałożyciel", "§7Stwórz klan", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(2000, 1000, 2000), "vip"));
            
        allMissions.put("ach_clan_level_30", new ClanLevelMission("ach_clan_level_30",
            "§5§lPotęga Klanu", "§7Osiągnij poziom 30 klanu", Mission.MissionType.ACHIEVEMENT,
            30, createRewards(15000, 7500, 15000), "svip"));
            
        allMissions.put("ach_win_10_clan_wars", new ClanWarsMission("ach_win_10_clan_wars",
            "§5§lWojownik", "§7Wygraj 10 wojen klanowych", Mission.MissionType.ACHIEVEMENT,
            10, createRewards(8000, 4000, 8000), "vip"));
        
        // Achievements - Pets
        allMissions.put("ach_get_first_pet", new GetPetMission("ach_get_first_pet",
            "§5§lPrzyjaciel", "§7Zdobądź pierwszego peta", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(1000, 500, 1000), "gracz"));
            
        allMissions.put("ach_pet_level_50", new LevelPetMission("ach_pet_level_50",
            "§5§lMistrz Treningu", "§7Osiągnij poziom 50 z petem", Mission.MissionType.ACHIEVEMENT,
            50, createRewards(5000, 2500, 5000), "vip"));
            
        allMissions.put("ach_pet_level_100", new LevelPetMission("ach_pet_level_100",
            "§5§lLegendarny Trener", "§7Osiągnij poziom 100 z petem", Mission.MissionType.ACHIEVEMENT,
            100, createRewards(15000, 7500, 15000), "soulgod"));
        
        // Achievements - Abilities
        allMissions.put("ach_unlock_5_abilities", new UnlockAbilitiesMission("ach_unlock_5_abilities",
            "§5§lOdkrywca Mocy", "§7Odblokuj 5 abilities", Mission.MissionType.ACHIEVEMENT,
            5, createRewards(3000, 1500, 3000), "vip"));
            
        allMissions.put("ach_unlock_all_abilities", new UnlockAbilitiesMission("ach_unlock_all_abilities",
            "§5§lMistrz Wszystkich Zdolności", "§7Odblokuj wszystkie 12 abilities", Mission.MissionType.ACHIEVEMENT,
            12, createRewards(25000, 12500, 25000), "soulgod"));
            
        allMissions.put("ach_use_abilities_1000", new UseAbilitiesMission("ach_use_abilities_1000",
            "§5§lMistrz Zdolności", "§7Użyj abilities 1000 razy", Mission.MissionType.ACHIEVEMENT,
            1000, createRewards(8000, 4000, 8000), "svip"));
        
        // Achievements - Rebirth
        allMissions.put("ach_rebirth_1", new RebirthMission("ach_rebirth_1",
            "§5§lOdrodzony", "§7Wykonaj pierwszy rebirth", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(10000, 5000, 10000), "vip"));
            
        allMissions.put("ach_rebirth_5", new RebirthMission("ach_rebirth_5",
            "§5§lWieczny", "§7Wykonaj 5 rebirth", Mission.MissionType.ACHIEVEMENT,
            5, createRewards(30000, 15000, 30000), "svip"));
            
        allMissions.put("ach_rebirth_10", new RebirthMission("ach_rebirth_10",
            "§5§lTranscendentny", "§7Osiągnij maksymalny rebirth", Mission.MissionType.ACHIEVEMENT,
            10, createRewards(100000, 50000, 100000), "soulgod"));
        
        // Achievements - Items
        allMissions.put("ach_get_soul_reaper", new GetCustomItemMission("ach_get_soul_reaper",
            "§5§lŻniwiarz", "§7Zdobądź Soul Reaper", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(2000, 1000, 2000), "vip", "soul_reaper"));
            
        allMissions.put("ach_collect_all_weapons", new CollectAllWeaponsMission("ach_collect_all_weapons",
            "§5§lArsenal", "§7Zdobądź wszystkie 5 broni", Mission.MissionType.ACHIEVEMENT,
            5, createRewards(10000, 5000, 10000), "svip"));
            
        allMissions.put("ach_collect_all_armor", new CollectAllArmorMission("ach_collect_all_armor",
            "§5§lNiezniszczalny", "§7Zdobądź kompletny set zbroi", Mission.MissionType.ACHIEVEMENT,
            4, createRewards(10000, 5000, 10000), "svip"));
        
        // Achievements - Misc
        allMissions.put("ach_play_100_hours", new PlayTimeMission("ach_play_100_hours",
            "§5§lWeteran", "§7Zagraj 100 godzin", Mission.MissionType.ACHIEVEMENT,
            6000000, createRewards(20000, 10000, 20000), "vip")); // 100h in ticks
            
        allMissions.put("ach_complete_tutorial", new CompleteTutorialMission("ach_complete_tutorial",
            "§5§lUczeń", "§7Ukończ tutorial", Mission.MissionType.ACHIEVEMENT,
            1, createRewards(500, 250, 500), "gracz"));
            
        allMissions.put("ach_complete_50_missions", new CompleteMissionsMission("ach_complete_50_missions",
            "§5§lKompletny", "§7Ukończ 50 misji", Mission.MissionType.ACHIEVEMENT,
            50, createRewards(8000, 4000, 8000), "svip"));
    }
    
    private List<Mission.MissionReward> createRewards(int souls, int money, int exp) {
        List<Mission.MissionReward> rewards = new ArrayList<>();
        rewards.add(new Mission.MissionReward(Mission.MissionReward.RewardType.SOULS, souls, null));
        rewards.add(new Mission.MissionReward(Mission.MissionReward.RewardType.MONEY, money, null));
        rewards.add(new Mission.MissionReward(Mission.MissionReward.RewardType.EXPERIENCE, exp, null));
        return rewards;
    }
    
    private List<Mission.MissionReward> createRewardsWithAbility(int souls, int money, int exp, String abilityId) {
        List<Mission.MissionReward> rewards = createRewards(souls, money, exp);
        rewards.add(new Mission.MissionReward(Mission.MissionReward.RewardType.ABILITY_UNLOCK, 1, abilityId));
        return rewards;
    }
    
    private void startDailyReset() {
        new BukkitRunnable() {
            @Override
            public void run() {
                resetDailyMissions();
            }
        }.runTaskTimer(plugin, 0L, 20L * 60 * 60 * 24); // Co 24h
    }
    
    private void startWeeklyReset() {
        new BukkitRunnable() {
            @Override
            public void run() {
                resetWeeklyMissions();
            }
        }.runTaskTimer(plugin, 0L, 20L * 60 * 60 * 24 * 7); // Co 7 dni
    }
    
    private void resetDailyMissions() {
        for (Mission mission : allMissions.values()) {
            if (mission.getType() == Mission.MissionType.DAILY) {
                for (UUID playerId : playerMissionProgress.keySet()) {
                    mission.reset(playerId);
                }
            }
        }
        Bukkit.broadcastMessage("§6§l✦ Codzienne misje zostały zresetowane!");
        saveMissionsData();
    }
    
    private void resetWeeklyMissions() {
        for (Mission mission : allMissions.values()) {
            if (mission.getType() == Mission.MissionType.WEEKLY) {
                for (UUID playerId : playerMissionProgress.keySet()) {
                    mission.reset(playerId);
                }
            }
        }
        Bukkit.broadcastMessage("§5§l✦ Tygodniowe misje zostały zresetowane!");
        saveMissionsData();
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        if (!playerCompletedMissions.containsKey(playerId)) {
            playerCompletedMissions.put(playerId, new HashSet<>());
        }
        if (!playerMissionProgress.containsKey(playerId)) {
            playerMissionProgress.put(playerId, new HashMap<>());
        }
    }
    
    public Mission getMission(String id) {
        return allMissions.get(id);
    }
    
    public List<Mission> getMissionsByType(Mission.MissionType type) {
        return allMissions.values().stream()
            .filter(m -> m.getType() == type)
            .collect(Collectors.toList());
    }
    
    public List<Mission> getActiveMissions(Player player) {
        return allMissions.values().stream()
            .filter(m -> !m.isCompleted(player.getUniqueId()))
            .collect(Collectors.toList());
    }
    
    public List<Mission> getCompletedMissions(Player player) {
        return allMissions.values().stream()
            .filter(m -> m.isCompleted(player.getUniqueId()))
            .collect(Collectors.toList());
    }
    
    public void trackProgress(Player player, String missionId, int amount) {
        Mission mission = allMissions.get(missionId);
        if (mission != null && !mission.isCompleted(player.getUniqueId())) {
            mission.incrementProgress(player.getUniqueId(), amount);
            
            if (mission.getProgress(player.getUniqueId()) >= mission.getRequiredProgress()) {
                mission.complete(player);
            }
        }
    }
    
    public SoulCraftPlugin getPlugin() {
        return plugin;
    }
    
    public Map<UUID, Set<String>> getPlayerCompletedMissions() {
        return playerCompletedMissions;
    }
    
    public Map<UUID, Map<String, Integer>> getPlayerMissionProgress() {
        return playerMissionProgress;
    }
}
