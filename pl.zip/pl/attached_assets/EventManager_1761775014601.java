package com.soulcraft.events;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.*;

public class EventManager implements Listener {
    private final SoulCraftPlugin plugin;
    private boolean eventActive = false;
    
    public EventManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        startRandomEvents();
    }
    
    private void startRandomEvents() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!eventActive && Math.random() < 0.3) {
                    startRandomEvent();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L * 60 * 30); // Co 30 minut
    }
    
    private void startRandomEvent() {
        int eventType = (int) (Math.random() * 5);
        eventActive = true;
        
        switch (eventType) {
            case 0 -> soulRainEvent();
            case 1 -> doubleLootEvent();
            case 2 -> bossWaveEvent();
            case 3 -> meteorStrikeEvent();
            case 4 -> bloodMoonEvent();
        }
    }
    
    private void soulRainEvent() {
        Bukkit.broadcastMessage("§5§l✦ EVENT: DESZCZ DUSZ! ✦");
        Bukkit.broadcastMessage("§dDusze spadają z nieba przez 5 minut!");
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 6000) {
                    Bukkit.broadcastMessage("§5§lEvent zakończony!");
                    eventActive = false;
                    cancel();
                    return;
                }
                
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (Math.random() < 0.1) {
                        plugin.getSoulManager().addSouls(player.getUniqueId().toString(), 10);
                        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
    
    private void doubleLootEvent() {
        Bukkit.broadcastMessage("§6§l✦ EVENT: PODWÓJNY LOOT! ✦");
        Bukkit.broadcastMessage("§e2x więcej dropów przez 10 minut!");
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Bukkit.broadcastMessage("§6§lEvent zakończony!");
            eventActive = false;
        }, 20L * 60 * 10);
    }
    
    private void bossWaveEvent() {
        Bukkit.broadcastMessage("§4§l✦ EVENT: FALA BOSSÓW! ✦");
        Bukkit.broadcastMessage("§cBossowie pojawiają się co minutę!");
        
        new BukkitRunnable() {
            int waves = 0;
            @Override
            public void run() {
                if (waves++ >= 5) {
                    Bukkit.broadcastMessage("§4§lEvent zakończony!");
                    eventActive = false;
                    cancel();
                    return;
                }
                
                for (World world : Bukkit.getWorlds()) {
                    Location loc = world.getSpawnLocation();
                    // Spawn boss here
                }
                Bukkit.broadcastMessage("§cFala " + waves + "/5!");
            }
        }.runTaskTimer(plugin, 0L, 20L * 60);
    }
    
    private void meteorStrikeEvent() {
        Bukkit.broadcastMessage("§c§l✦ EVENT: DESZCZ METEORÓW! ✦");
        Bukkit.broadcastMessage("§4Meteory spadają przez 3 minuty!");
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 3600) {
                    eventActive = false;
                    cancel();
                    return;
                }
                
                for (World world : Bukkit.getWorlds()) {
                    if (Math.random() < 0.2) {
                        Location loc = world.getSpawnLocation().add(
                            (Math.random() - 0.5) * 100,
                            50,
                            (Math.random() - 0.5) * 100
                        );
                        world.createExplosion(loc, 3.0f, false, false);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
    
    private void bloodMoonEvent() {
        Bukkit.broadcastMessage("§4§l✦ EVENT: KRWAWA NAŁOCZYCA! ✦");
        Bukkit.broadcastMessage("§cWszystkie moby są 2x silniejsze!");
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Bukkit.broadcastMessage("§4§lKrwawa noc dobiegła końca!");
            eventActive = false;
        }, 20L * 60 * 15);
    }
}
