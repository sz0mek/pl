package com.soulcraft.bosses.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.bosses.CustomBoss;
import org.bukkit.EntityEffect;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SoulEater extends CustomBoss {
    private final SoulCraftPlugin plugin;

    public SoulEater(SoulCraftPlugin plugin) {
        super(
            "soul_eater",
            "§5§l✦ Pożeracz Dusz ✦",
            EntityType.WITHER_SKELETON,
            500.0,
            15.0,
            5000
        );
        this.plugin = plugin;
    }

    @Override
    public void onSpawn(LivingEntity boss) {
        boss.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false));
        boss.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, boss.getLocation(), 100, 2, 2, 2);
    }

    @Override
    public void onTick(LivingEntity boss) {
        // Spawn soul particles around boss
        if (boss.getTicksLived() % 10 == 0) {
            boss.getWorld().spawnParticle(Particle.SOUL, boss.getLocation().add(0, 1, 0), 5, 0.5, 0.5, 0.5);
        }
        
        // Heal from nearby deaths
        if (boss.getHealth() < getMaxHealth() && Math.random() < 0.01) {
            boss.setHealth(Math.min(boss.getHealth() + 10, getMaxHealth()));
            boss.playEffect(EntityEffect.THORNS_HURT);
        }
    }

    @Override
    public void onDeath(LivingEntity boss, Player killer) {
        // Explosive death with souls
        boss.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, boss.getLocation(), 200, 3, 3, 3);
        boss.getWorld().createExplosion(boss.getLocation(), 0f, false, false);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_WITHER_DEATH, 2.0f, 0.5f);
        
        // Drop custom items
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("soul_reaper", 1)
        );
    }

    @Override
    public void onAttack(LivingEntity boss, Entity target) {
        if (target instanceof Player player) {
            // Soul drain effect
            player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0));
            boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_PHANTOM_BITE, 1.0f, 0.8f);
        }
    }
}
