package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class Vampirism extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Vampirism(SoulCraftPlugin plugin) {
        super("vampirism", "§5§lWampiryzm", "§7Kradnij 50% zadanych obrażeń jako HP", 0, "soulgod", 35000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        if (args.length > 0 && args[0] instanceof Double) {
            double damage = (Double) args[0];
            double heal = damage * 0.5;
            player.setHealth(Math.min(player.getHealth() + heal, player.getMaxHealth()));
        }
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
