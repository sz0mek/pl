package com.soulcraft.bosses.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.bosses.CustomBoss;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class VoidTitan extends CustomBoss {
    private final SoulCraftPlugin plugin;

    public VoidTitan(SoulCraftPlugin plugin) {
        super(
            "void_titan",
            "§0§l✦ Tytan Pustki ✦",
            EntityType.IRON_GOLEM,
            800.0,
            20.0,
            8000
        );
        this.plugin = plugin;
    }

    @Override
    public void onSpawn(LivingEntity boss) {
        boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2, false, false));
        boss.getWorld().spawnParticle(Particle.PORTAL, boss.getLocation(), 200, 3, 3, 3);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ENDERMAN_SCREAM, 2.0f, 0.5f);
    }

    @Override
    public void onTick(LivingEntity boss) {
        // Void aura damage
        if (boss.getTicksLived() % 40 == 0) {
            boss.getNearbyEntities(5, 5, 5).forEach(entity -> {
                if (entity instanceof Player player) {
                    player.damage(5.0, boss);
                    player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
                    boss.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 20);
                }
            });
        }
        
        // Void particles
        if (boss.getTicksLived() % 5 == 0) {
            boss.getWorld().spawnParticle(Particle.PORTAL, boss.getLocation().add(0, 1, 0), 10, 1, 1, 1);
        }
    }

    @Override
    public void onDeath(LivingEntity boss, Player killer) {
        boss.getWorld().spawnParticle(Particle.PORTAL, boss.getLocation(), 500, 5, 5, 5);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ENDERMAN_DEATH, 2.0f, 0.3f);
        
        // Drop void items
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("void_blade", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("void_leggings", 1)
        );
    }

    @Override
    public void onAttack(LivingEntity boss, Entity target) {
        if (target instanceof LivingEntity living) {
            // Massive knockback
            Vector knockback = target.getLocation().toVector()
                .subtract(boss.getLocation().toVector())
                .normalize()
                .multiply(3)
                .setY(1.5);
            target.setVelocity(knockback);
            boss.getWorld().playSound(target.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.5f);
        }
    }
}
