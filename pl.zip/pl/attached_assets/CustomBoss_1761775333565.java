package com.soulcraft.bosses;

import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public abstract class CustomBoss {
    private final String id;
    private final String displayName;
    private final EntityType entityType;
    private final double maxHealth;
    private final double damage;
    private final int rewardSouls;
    private final Map<String, Object> metadata;

    public CustomBoss(String id, String displayName, EntityType entityType, 
                      double maxHealth, double damage, int rewardSouls) {
        this.id = id;
        this.displayName = displayName;
        this.entityType = entityType;
        this.maxHealth = maxHealth;
        this.damage = damage;
        this.rewardSouls = rewardSouls;
        this.metadata = new HashMap<>();
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public EntityType getEntityType() {
        return entityType;
    }

    public double getMaxHealth() {
        return maxHealth;
    }

    public double getDamage() {
        return damage;
    }

    public int getRewardSouls() {
        return rewardSouls;
    }

    public LivingEntity spawn(Location location) {
        Entity entity = location.getWorld().spawnEntity(location, entityType);
        if (entity instanceof LivingEntity living) {
            living.setCustomName(displayName);
            living.setCustomNameVisible(true);
            living.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(maxHealth);
            living.setHealth(maxHealth);
            if (living.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
                living.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(damage);
            }
            
            // Marcar como boss custom
            living.setPersistent(true);
            living.setRemoveWhenFarAway(false);
            
            onSpawn(living);
            return living;
        }
        return null;
    }

    public boolean isBoss(LivingEntity entity) {
        if (entity == null || entity.getCustomName() == null) {
            return false;
        }
        return entity.getCustomName().equals(displayName);
    }

    // Abstract methods to override
    public abstract void onSpawn(LivingEntity boss);
    public abstract void onTick(LivingEntity boss);
    public abstract void onDeath(LivingEntity boss, Player killer);
    public abstract void onAttack(LivingEntity boss, Entity target);
}
