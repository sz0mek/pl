package com.soulcraft.items.weapons;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class VoidBlade extends CustomItem {
    private final SoulCraftPlugin plugin;

    public VoidBlade(SoulCraftPlugin plugin) {
        super(
            "void_blade",
            "§0§lOstrze Pustki",
            Material.NETHERITE_SWORD,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §0Miecz z Otchłani §7│",
                "§7│ §fTrafienie:        §7│",
                "§7│ §830% szansa na    §7│",
                "§7│ §8oślepienie wroga §7│",
                "§7│ §5+20% obrażeń     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Specjalne: §8Pustka pochłania światło",
                "§d⚔ Model: 1002"
            ),
            1002
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Ability - można dodać teleportację lub inne
    }

    @Override
    public void onHit(Player attacker, Entity target) {
        if (Math.random() < 0.3 && target instanceof org.bukkit.entity.LivingEntity living) {
            living.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
            living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
            living.getWorld().spawnParticle(Particle.SMOKE, living.getLocation(), 30);
            attacker.playSound(attacker.getLocation(), Sound.ENTITY_ENDERMAN_SCREAM, 0.5f, 0.7f);
        }
    }
}
