# SoulCraft Resource Pack - Dokumentacja Custom Model Data

## Przegląd
Ten dokument zawiera kompletną listę Custom Model Data (CMD) dla wszystkich custom itemów w pluginie SoulCraft. Resource pack musi zawierać modele 3D/textury z odpowiednimi wartościami CMD.

## Wymagania Resource Packa
- **Format**: Minecraft Resource Pack (1.21+)
- **Metoda**: Custom Model Data w plikach JSON
- **Hosting**: Zewnętrzny (np. Dropbox, Google Drive, własny serwer)
- **Instalacja**: Automatyczna przy wejściu na serwer (konfiguracja w config.yml)

## Custom Model Data - Kompletna Lista

### 🗡️ BROŃ (1001-1005)

#### 1001 - Soul Reaper
- **Bazowy Item**: `NETHERITE_SWORD`
- **Nazwa**: `§5§lŻniwiarz Dusz`
- **Opis**: Legendarna broń pochłaniająca dusze przeciwników
- **Mechanika**: 
  - +15% damage
  - Heal 2 HP przy każdym trafieniu
  - Siła I przez 5 sekund po zabiciu wroga
- **Model**: Ciemny miecz z fioletową aurą dusz

#### 1002 - Void Blade
- **Bazowy Item**: `NETHERITE_SWORD`
- **Nazwa**: `§0§lOstrze Pustki`
- **Opis**: Miecz wykuty w głębinach otchłani
- **Mechanika**:
  - +20% damage
  - Szansa na teleport za wroga (3 bloki)
- **Model**: Czarny miecz z efektem pustki

#### 1003 - Chaos Hammer
- **Bazowy Item**: `IRON_AXE`
- **Nazwa**: `§c§lMłot Chaosu`
- **Opis**: Potężny młot niszczący pancerze
- **Mechanika**:
  - Obszarowy atak (3x3)
  - Ogromny knockback
  - Ignoruje 30% pancerza
- **Model**: Masywny czerwony młot z runami

#### 1004 - Phantom Bow
- **Bazowy Item**: `BOW`
- **Nazwa**: `§3§lŁuk Widma`
- **Opis**: Łuk strzelający widmowymi strzałami
- **Mechanika**:
  - Strzały fazują przez bloki
  - +50% damage
  - Niewidzialność na 3 sekundy po strzale
- **Model**: Przezroczysty łuk z niebieską poświatą

#### 1005 - Dark Staff
- **Bazowy Item**: `STICK`
- **Nazwa**: `§8§lCiemna Laska`
- **Opis**: Magiczna laska mrocznego maga
- **Mechanika**:
  - Wystrzeliwuje magiczne pociski (prawy przycisk)
  - Cooldown: 3 sekundy
  - 10 damage magicznego
- **Model**: Długa laska z ciemnym kryształem

---

### 🛡️ ZBROJE (2001-2004)

#### 2001 - Eternal Chestplate
- **Bazowy Item**: `DIAMOND_CHESTPLATE`
- **Nazwa**: `§6§lNapiersnik Wieczności`
- **Opis**: Niezniszczalny pancerz bogów
- **Mechanika**:
  - Regeneracja II permanentnie
  - Odporność na ogień
  - +15 pancerza
- **Model**: Złoty napierśnik z runami

#### 2002 - Shadow Helmet
- **Bazowy Item**: `NETHERITE_HELMET`
- **Nazwa**: `§8§lHełm Cienia`
- **Opis**: Hełm ukrywający tożsamość
- **Mechanika**:
  - Widzenie w ciemności permanentnie
  - Niewidzialność w nocy (20:00-6:00)
  - +12 pancerza
- **Model**: Czarny hełm z cieniem

#### 2003 - Void Leggings
- **Bazowy Item**: `NETHERITE_LEGGINGS`
- **Nazwa**: `§5§lSpodnie Pustki`
- **Opis**: Pancerz otchłani
- **Mechanika**:
  - Prędkość II przy użyciu (prawy przycisk)
  - +18 pancerza
- **Model**: Fioletowe spodnie z efektem pustki

#### 2004 - Soul Boots
- **Bazowy Item**: `DIAMOND_BOOTS`
- **Nazwa**: `§b§lButy Dusz`
- **Opis**: Buty pozwalające biegać po powietrzu
- **Mechanika**:
  - Brak obrażeń od upadku
  - Double jump (spacja w powietrzu)
  - +10 pancerza
- **Model**: Niebieskie buty z aurą

---

### ⛏️ NARZĘDZIA (3001-3003)

#### 3001 - Soul Pickaxe
- **Bazowy Item**: `NETHERITE_PICKAXE`
- **Nazwa**: `§d§lKilof Dusz`
- **Opis**: Kilof wydobywający esencję z kamieni
- **Mechanika**:
  - Auto-smelt (rudy topią się automatycznie)
  - 3x3 mining
  - +300% szybkości kopania
- **Model**: Różowy kilof z kryształem duszy

#### 3002 - Ender Axe
- **Bazowy Item**: `NETHERITE_AXE`
- **Nazwa**: `§5§lSiekiera Endu`
- **Opis**: Siekiera ścinająca całe drzewa
- **Mechanika**:
  - Instant tree chop (całe drzewo naraz)
  - Vein miner dla drewna
  - +200% szybkości ścinania
- **Model**: Fioletowa siekiera z endermanowymi cząsteczkami

#### 3003 - Void Shovel
- **Bazowy Item**: `NETHERITE_SHOVEL`
- **Nazwa**: `§0§lŁopata Pustki`
- **Opis**: Łopata pochłaniająca ziemię
- **Mechanika**:
  - 5x5 digging
  - Pochłania wykopaną ziemię (nie dropuje itemów)
  - +200% szybkości kopania
- **Model**: Czarna łopata z efektem pochłaniania

---

### 🧪 CONSUMABLES (4001-4003)

#### 4001 - Soul Potion
- **Bazowy Item**: `POTION`
- **Nazwa**: `§5§lMikstura Dusz`
- **Opis**: Eliksir przywracający siły witalne
- **Mechanika**:
  - Natychmiastowe zdrowie IV
  - Regeneracja III przez 30 sekund
  - Absorpcja II przez 60 sekund
- **Model**: Fioletowa mikstura z unoszącymi się duszami

#### 4002 - Regeneration Orb
- **Bazowy Item**: `ENDER_EYE`
- **Nazwa**: `§a§lKula Regeneracji`
- **Opis**: Magiczna kula leczenia
- **Mechanika**:
  - Pełne HP natychmiast (prawy przycisk)
  - Usuwa wszystkie negatywne efekty
  - Zużywa się po użyciu
- **Model**: Zielona świecąca kula

#### 4003 - Experience Book
- **Bazowy Item**: `BOOK`
- **Nazwa**: `§e§lKsięga Doświadczenia`
- **Opis**: Księga przechowująca wiedzę
- **Mechanika**:
  - Przechowuje doświadczenie (shift + prawy przycisk = zapisz)
  - Przywraca doświadczenie (prawy przycisk = odczytaj)
  - Pokazuje zapisane XP w lore
- **Model**: Złota księga z magicznymi runami

---

### ✨ SPECIAL ITEMS (5001-5005)

#### 5001 - Strength Talisman
- **Bazowy Item**: `NETHER_STAR`
- **Nazwa**: `§c§lTalizman Mocy`
- **Opis**: Artefakt zwiększający siłę
- **Mechanika**:
  - Siła II permanentnie (w ekwipunku)
  - +5 max HP
  - +10% damage
- **Model**: Czerwona gwiazda z symbolem mocy

#### 5002 - Teleportation Stone
- **Bazowy Item**: `ENDER_PEARL`
- **Nazwa**: `§b§lKamień Teleportacji`
- **Opis**: Kamień pozwalający na szybkie podróże
- **Mechanika**:
  - Teleport do zapisanej lokacji (prawy przycisk)
  - Ustawienie punktu (shift + prawy przycisk)
  - Cooldown: 30 sekund
- **Model**: Niebieski kryształ z efektem teleportacji

#### 5003 - Speed Crystal
- **Bazowy Item**: `AMETHYST_SHARD`
- **Nazwa**: `§e§lKryształ Prędkości`
- **Opis**: Kryształ dający niesamowitą szybkość
- **Mechanika**:
  - Prędkość III przez 10 sekund (prawy przycisk)
  - Pośpiech III przez 10 sekund
  - Cooldown: 60 sekund
- **Model**: Żółty kryształ z błyskawicami

#### 5004 - Soul Compass
- **Bazowy Item**: `RECOVERY_COMPASS`
- **Nazwa**: `§d§lKompas Dusz`
- **Opis**: Kompas prowadzący do bossów
- **Mechanika**:
  - Wskazuje najbliższego bossa
  - Pokazuje odległość w lore
  - Świeci gdy boss blisko (<50 bloków)
- **Model**: Różowy kompas z duszą w środku

#### 5005 - Lucky Coin
- **Bazowy Item**: `GOLD_NUGGET`
- **Nazwa**: `§6§lMoneta Szczęścia`
- **Opis**: Rzadka moneta zwiększająca szczęście
- **Mechanika**:
  - Fortune III dla wszystkiego (w ekwipunku)
  - +100% drop rate
  - +50% szansa na rare loot z bossów
- **Model**: Złota moneta z symbolem szczęścia

---

## Instrukcja Tworzenia Resource Packa

### 1. Struktura Folderów
```
resource_pack/
├── pack.mcmeta
├── pack.png
└── assets/
    └── minecraft/
        ├── models/
        │   └── item/
        │       ├── netherite_sword.json
        │       ├── netherite_pickaxe.json
        │       ├── diamond_chestplate.json
        │       └── ... (inne bazowe itemy)
        └── textures/
            └── item/
                └── soulcraft/
                    ├── soul_reaper.png
                    ├── void_blade.png
                    └── ... (wszystkie textury)
```

### 2. Przykład pack.mcmeta
```json
{
  "pack": {
    "pack_format": 34,
    "description": "§5§lSoulCraft Resource Pack\n§7Custom items dla pluginu RPG"
  }
}
```

### 3. Przykład JSON dla Netherite Sword
```json
{
  "parent": "item/handheld",
  "textures": {
    "layer0": "item/netherite_sword"
  },
  "overrides": [
    {
      "predicate": {
        "custom_model_data": 1001
      },
      "model": "item/soulcraft/soul_reaper"
    },
    {
      "predicate": {
        "custom_model_data": 1002
      },
      "model": "item/soulcraft/void_blade"
    }
  ]
}
```

### 4. Przykład modelu item/soulcraft/soul_reaper.json
```json
{
  "parent": "item/handheld",
  "textures": {
    "layer0": "item/soulcraft/soul_reaper"
  }
}
```

### 5. Hosting Resource Packa
1. Spakuj folder resource_pack/ do ZIP
2. Umieść na:
   - Dropbox (użyj `?dl=1` na końcu URL)
   - Google Drive (użyj direct download link)
   - Własny serwer (HTTPS wymagane)
3. Wklej URL do `config.yml`:
   ```yaml
   resourcepack:
     enabled: true
     url: "https://twoj-link.com/soulcraft-pack.zip"
     required: true
   ```

## Konfiguracja w Pluginie

### config.yml
```yaml
resourcepack:
  enabled: true
  url: "https://example.com/soulcraft-pack.zip"
  required: true
  prompt: "§dZainstaluj resource pack aby uzyskać pełne doświadczenie!"
  join_message: "§5§l✦ SoulCraft ✦\n§7Pobieranie resource packa...\n§ePoczekaj chwilę!"
```

### Sprawdzenie SHA-1 (opcjonalne, dla bezpieczeństwa)
```bash
sha1sum soulcraft-pack.zip
```

## Testowanie
1. Zainstaluj resource pack lokalnie w `.minecraft/resourcepacks/`
2. Sprawdź wszystkie itemy w grze: `/giveitem <nick> <item_id>`
3. Upewnij się, że wszystkie CMD działają poprawnie
4. Przetestuj animacje i efekty cząsteczek

## Wsparcie
- Format resource packa: 1.21+ (pack_format: 34)
- Wszystkie textury powinny być PNG 16x16 lub 32x32 dla HD
- Modele 3D mogą używać większej rozdzielczości
- Pamiętaj o optymalizacji wielkości pliku (<50MB zalecane)

---

**Autor**: SoulCraft Plugin Development Team  
**Wersja**: 1.0  
**Data**: Październik 2025
