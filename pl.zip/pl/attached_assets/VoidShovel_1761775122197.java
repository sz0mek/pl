package com.soulcraft.items.tools;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class VoidShovel extends CustomItem {
    public VoidShovel(SoulCraftPlugin plugin) {
        super(
            "void_shovel",
            "§0§lŁopata Pustki",
            Material.NETHERITE_SHOVEL,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §0Ciemna Łopata   §7│",
                "§7│ §fZdolności:       §7│",
                "§7│ §eKopanie 5x5     §7│",
                "§7│ §8Pochłanianie    §7│",
                "§7│ §a+200% szybkości §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §0Pustka pochłania ziemię",
                "§d⚔ Model: 3003"
            ),
            3003
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // 5x5 digging handled by block break events
    }
}
