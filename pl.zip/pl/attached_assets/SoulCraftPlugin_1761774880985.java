// SoulCraftPlugin.java
package com.soulcraft;

import com.soulcraft.bosses.BossRegistry;
import com.soulcraft.core.ConfigService;
import com.soulcraft.core.NotificationService;
import com.soulcraft.core.ResourcePackManager;
import com.soulcraft.features.FeatureManager;
import com.soulcraft.items.CustomItemRegistry;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public class SoulCraftPlugin extends JavaPlugin {
    // Core Services
    private ConfigService configService;
    private NotificationService notificationService;
    private ResourcePackManager resourcePackManager;
    private CustomItemRegistry customItemRegistry;
    private BossRegistry bossRegistry;
    private FeatureManager featureManager;
    
    // New Advanced Systems
    private com.soulcraft.missions.MissionManager missionManager;
    private com.soulcraft.missions.MissionGUI missionGUI;
    private com.soulcraft.abilities.AbilityManager abilityManager;
    private com.soulcraft.dungeons.DungeonManager dungeonManager;
    private com.soulcraft.pets.PetManager petManager;
    private com.soulcraft.rebirth.RebirthManager rebirthManager;
    private com.soulcraft.tutorial.TutorialManager tutorialManager;
    private com.soulcraft.events.EventManager eventManager;
    private com.soulcraft.leaderboards.LeaderboardManager leaderboardManager;
    private com.soulcraft.clans.EnhancedClanManager enhancedClanManager;
    private com.soulcraft.achievements.AchievementManager achievementManager;
    
    // Legacy Managers
    private ScoreboardManager scoreboardManager;
    private EconomyManager economyManager;
    private ClanManager clanManager;
    private SoulManager soulManager;
    private ZombieManager zombieManager;
    private UpgradeGUI upgradeGUI;
    private RankManager rankManager;
    private KitManager kitManager;
    private SpawnManager spawnManager;
    private AntiLogoutManager antiLogoutManager;
    private CommandHandler commandHandler;
    private MarketManager marketManager;
    private ShopManager shopManager;
    private HomeManager homeManager;
    private BossManager bossManager;
    private NPCManager npcManager;
    private WarpManager warpManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Initialize Core Services First
        configService = ConfigService.getInstance(this);
        notificationService = NotificationService.getInstance();
        resourcePackManager = ResourcePackManager.getInstance(this);
        customItemRegistry = CustomItemRegistry.getInstance(this);
        bossRegistry = BossRegistry.getInstance(this);
        featureManager = FeatureManager.getInstance(this);

        // Managers (nie rejestrujemy eventów w konstruktorach)
        scoreboardManager = new ScoreboardManager(this);
        economyManager = new EconomyManager(this);
        clanManager = new ClanManager(this);
        soulManager = new SoulManager(this);
        zombieManager = new ZombieManager(this);
        upgradeGUI = new UpgradeGUI(this);
        rankManager = new RankManager(this);
        kitManager = new KitManager(this, rankManager);
        spawnManager = new SpawnManager(this, rankManager);
        antiLogoutManager = new AntiLogoutManager(this);
        marketManager = new MarketManager(this);
        shopManager = new ShopManager(this);
        homeManager = new HomeManager(this, rankManager);
        bossManager = new BossManager(this);
        npcManager = new NPCManager(this);
        warpManager = new WarpManager(this, rankManager);
        
        // Initialize New Advanced Systems
        missionManager = new com.soulcraft.missions.MissionManager(this);
        missionGUI = new com.soulcraft.missions.MissionGUI(this, missionManager);
        abilityManager = new com.soulcraft.abilities.AbilityManager(this);
        dungeonManager = new com.soulcraft.dungeons.DungeonManager(this);
        petManager = new com.soulcraft.pets.PetManager(this);
        rebirthManager = new com.soulcraft.rebirth.RebirthManager(this);
        tutorialManager = new com.soulcraft.tutorial.TutorialManager(this);
        eventManager = new com.soulcraft.events.EventManager(this);
        leaderboardManager = new com.soulcraft.leaderboards.LeaderboardManager(this);
        enhancedClanManager = new com.soulcraft.clans.EnhancedClanManager(this);
        achievementManager = new com.soulcraft.achievements.AchievementManager(this);

        commandHandler = new CommandHandler(this, rankManager, marketManager, shopManager, homeManager, bossManager,
                npcManager, warpManager);

        // Rejestracja listenerów centralnie, tylko raz
        Bukkit.getPluginManager().registerEvents(resourcePackManager, this); // New core service
        Bukkit.getPluginManager().registerEvents(customItemRegistry, this); // Custom Items system
        Bukkit.getPluginManager().registerEvents(bossRegistry, this); // Boss system
        Bukkit.getPluginManager().registerEvents(featureManager, this); // Feature system
        Bukkit.getPluginManager().registerEvents(soulManager, this);
        Bukkit.getPluginManager().registerEvents(zombieManager, this);
        Bukkit.getPluginManager().registerEvents(upgradeGUI, this);
        Bukkit.getPluginManager().registerEvents(kitManager, this);
        Bukkit.getPluginManager().registerEvents(antiLogoutManager, this);
        Bukkit.getPluginManager().registerEvents(marketManager, this);
        Bukkit.getPluginManager().registerEvents(shopManager, this);
        Bukkit.getPluginManager().registerEvents(bossManager, this);
        Bukkit.getPluginManager().registerEvents(npcManager, this);
        Bukkit.getPluginManager().registerEvents(warpManager, this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(this, rankManager), this);
        
        // Register New Advanced Systems Listeners
        Bukkit.getPluginManager().registerEvents(missionManager, this);
        Bukkit.getPluginManager().registerEvents(missionGUI, this);
        Bukkit.getPluginManager().registerEvents(abilityManager, this);
        Bukkit.getPluginManager().registerEvents(dungeonManager, this);
        Bukkit.getPluginManager().registerEvents(petManager, this);
        Bukkit.getPluginManager().registerEvents(rebirthManager, this);
        Bukkit.getPluginManager().registerEvents(tutorialManager, this);
        Bukkit.getPluginManager().registerEvents(eventManager, this);
        Bukkit.getPluginManager().registerEvents(leaderboardManager, this);
        Bukkit.getPluginManager().registerEvents(enhancedClanManager, this);
        Bukkit.getPluginManager().registerEvents(achievementManager, this);
        
        getLogger().info("§a✓ SoulCraft Plugin załadowany pomyślnie!");
        getLogger().info("§a✓ Wszystkie systemy gotowe!");
        getLogger().info("§5§l✦ 600+ godzin contentu załadowane!");
        getLogger().info("§d- Mission System: 50+ misji");
        getLogger().info("§d- Abilities System: 12 zdolności");
        getLogger().info("§d- Dungeon System: 5 dungeonów");
        getLogger().info("§d- Pet System: 10 petów");
        getLogger().info("§d- Rebirth System: 10 poziomów");
        getLogger().info("§d- Event System: 5 eventów");
        getLogger().info("§d- Enhanced Clans: Wojny + Sojusze + Poziomy 1-50");

        // New Admin Commands
        Objects.requireNonNull(getCommand("custom")).setExecutor(new com.soulcraft.commands.CustomCommand(this));
        Objects.requireNonNull(getCommand("spawnboss")).setExecutor(new com.soulcraft.commands.SpawnBossCommand(this));
        Objects.requireNonNull(getCommand("giveitem")).setExecutor(new com.soulcraft.commands.GiveItemCommand(this));
        Objects.requireNonNull(getCommand("feature")).setExecutor(new com.soulcraft.commands.FeatureCommand(this));
        
        // Legacy Komendy
        Objects.requireNonNull(getCommand("dodajhajs")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("usunhajs")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("klan")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("zombie")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("ulepsz")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("jakgrac")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("help")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("event")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dajrange")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("spawn")).setExecutor(spawnManager);
        Objects.requireNonNull(getCommand("ustawspawn")).setExecutor(spawnManager);
        Objects.requireNonNull(getCommand("kit")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dajkrysztal")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("rynek")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("wystaw")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("sklep")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("sethome")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("usunhome")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("home")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("ustawboos")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("startboos")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("spawnnpc")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("rebirth")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("dodajczarnamateria")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("warp")).setExecutor(commandHandler);
        Objects.requireNonNull(getCommand("missions")).setExecutor(new com.soulcraft.commands.MissionCommand(this, missionGUI));
        Objects.requireNonNull(getCommand("abilities")).setExecutor(new com.soulcraft.commands.AbilityCommand(this, abilityManager));
        Objects.requireNonNull(getCommand("dungeon")).setExecutor(new com.soulcraft.commands.DungeonCommand(this));
        Objects.requireNonNull(getCommand("pet")).setExecutor(new com.soulcraft.commands.PetCommand(this));

        clanManager.loadClans();

        // Inicjalizacja max health dla online graczy
        Bukkit.getOnlinePlayers().forEach(player -> {
            int level = getConfig().getInt("players." + player.getUniqueId() + ".healthLevel", 0);
            player.setMaxHealth(20 + level * 2);
            rankManager.updatePermissions(player);
        });
    }

    @Override
    public void onDisable() {
        saveConfig();
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public SoulManager getSoulManager() {
        return soulManager;
    }

    public ZombieManager getZombieManager() {
        return zombieManager;
    }

    public UpgradeGUI getUpgradeGUI() {
        return upgradeGUI;
    }

    public RankManager getRankManager() {
        return rankManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public SpawnManager getSpawnManager() {
        return spawnManager;
    }

    public AntiLogoutManager getAntiLogoutManager() {
        return antiLogoutManager;
    }

    public CommandHandler getCommandHandler() {
        return commandHandler;
    }

    public MarketManager getMarketManager() {
        return marketManager;
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public BossManager getBossManager() {
        return bossManager;
    }

    public NPCManager getNPCManager() {
        return npcManager;
    }

    public WarpManager getWarpManager() {
        return warpManager;
    }
    
    // Core Service Getters
    public ConfigService getConfigService() {
        return configService;
    }
    
    public NotificationService getNotificationService() {
        return notificationService;
    }
    
    public ResourcePackManager getResourcePackManager() {
        return resourcePackManager;
    }
    
    public CustomItemRegistry getCustomItemRegistry() {
        return customItemRegistry;
    }
    
    public BossRegistry getBossRegistry() {
        return bossRegistry;
    }
    
    public FeatureManager getFeatureManager() {
        return featureManager;
    }
    
    // New Advanced Systems Getters
    public com.soulcraft.missions.MissionManager getMissionManager() {
        return missionManager;
    }
    
    public com.soulcraft.abilities.AbilityManager getAbilityManager() {
        return abilityManager;
    }
    
    public com.soulcraft.dungeons.DungeonManager getDungeonManager() {
        return dungeonManager;
    }
    
    public com.soulcraft.pets.PetManager getPetManager() {
        return petManager;
    }
    
    public com.soulcraft.rebirth.RebirthManager getRebirthManager() {
        return rebirthManager;
    }
    
    public com.soulcraft.tutorial.TutorialManager getTutorialManager() {
        return tutorialManager;
    }
    
    public com.soulcraft.events.EventManager getEventManager() {
        return eventManager;
    }
    
    public com.soulcraft.leaderboards.LeaderboardManager getLeaderboardManager() {
        return leaderboardManager;
    }
    
    public com.soulcraft.clans.EnhancedClanManager getEnhancedClanManager() {
        return enhancedClanManager;
    }
    
    public com.soulcraft.achievements.AchievementManager getAchievementManager() {
        return achievementManager;
    }
}
