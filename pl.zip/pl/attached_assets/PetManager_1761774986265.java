package com.soulcraft.pets;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import java.util.*;

public class PetManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Pet> activePets = new HashMap<>();
    
    public PetManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void spawnPet(Player player, String petType) {
        Pet pet = new Pet(petType, player, plugin);
        activePets.put(player.getUniqueId(), pet);
        pet.spawn();
    }
    
    public void levelUpPet(Player player) {
        Pet pet = activePets.get(player.getUniqueId());
        if (pet != null) {
            pet.level++;
            player.sendMessage("§a§lPet osiągnął poziom " + pet.level + "!");
        }
    }
    
    public static class Pet {
        final String type;
        final Player owner;
        final SoulCraftPlugin plugin;
        int level = 1;
        int exp = 0;
        Entity entity;
        
        public Pet(String type, Player owner, SoulCraftPlugin plugin) {
            this.type = type;
            this.owner = owner;
            this.plugin = plugin;
        }
        
        public void spawn() {
            EntityType entityType = switch (type) {
                case "soul_wolf" -> EntityType.WOLF;
                case "void_cat" -> EntityType.CAT;
                case "chaos_dragon" -> EntityType.ENDER_DRAGON;
                case "phantom_horse" -> EntityType.HORSE;
                case "eternal_phoenix" -> EntityType.PARROT;
                case "dark_spider" -> EntityType.SPIDER;
                case "crystal_golem" -> EntityType.IRON_GOLEM;
                case "shadow_bat" -> EntityType.BAT;
                case "frost_fox" -> EntityType.FOX;
                case "blaze_hound" -> EntityType.BLAZE;
                default -> EntityType.WOLF;
            };
            
            entity = owner.getWorld().spawnEntity(owner.getLocation(), entityType);
            if (entity instanceof Tameable tameable) {
                tameable.setOwner(owner);
                tameable.setTamed(true);
            }
            entity.setCustomName("§d" + owner.getName() + "'s Pet §7[Lvl " + level + "]");
            entity.setCustomNameVisible(true);
        }
    }
}
