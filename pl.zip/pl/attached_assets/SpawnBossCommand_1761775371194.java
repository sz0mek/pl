package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnBossCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;

    public SpawnBossCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cTylko gracze mogą używać tej komendy!");
            return true;
        }

        if (!player.hasPermission("soulcraft.admin")) {
            player.sendMessage("§cBrak uprawnień!");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§c§lDostępne bossy:");
            player.sendMessage("§7- soul_eater §5(Pożeracz Dusz)");
            player.sendMessage("§7- void_titan §0(Tytan Pustki)");
            player.sendMessage("§7- chaos_knight §c(Rycerz Chaosu)");
            player.sendMessage("§7- phantom_lord §b(Pan Widm)");
            player.sendMessage("§7- dark_emperor §4(Mroczny Imperator)");
            player.sendMessage("§eUżycie: /spawnboss <boss_id>");
            return true;
        }

        String bossId = args[0].toLowerCase();
        if (plugin.getBossRegistry().getBoss(bossId) == null) {
            player.sendMessage("§cNieznany boss! Użyj /spawnboss aby zobaczyć listę.");
            return true;
        }

        plugin.getBossRegistry().spawnBoss(bossId, player.getLocation());
        player.sendMessage("§a§lBoss " + bossId + " zespawnowany!");
        return true;
    }
}
