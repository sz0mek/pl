package com.soulcraft.features;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.HashMap;
import java.util.Map;

public class FeatureManager implements Listener {
    private static FeatureManager instance;
    private final Map<String, GameFeature> features = new HashMap<>();
    private final SoulCraftPlugin plugin;

    private FeatureManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        registerAllFeatures();
    }

    public static FeatureManager getInstance(SoulCraftPlugin plugin) {
        if (instance == null) {
            instance = new FeatureManager(plugin);
        }
        return instance;
    }

    private void registerAllFeatures() {
        register(new com.soulcraft.features.impl.AutoPickup(plugin));
        register(new com.soulcraft.features.impl.DoubleJump(plugin));
        register(new com.soulcraft.features.impl.AutoReplant(plugin));
        register(new com.soulcraft.features.impl.KeepInventory(plugin));
        register(new com.soulcraft.features.impl.AutoSmelt(plugin));
        register(new com.soulcraft.features.impl.NightVision(plugin));
        register(new com.soulcraft.features.impl.NoFallDamage(plugin));
        register(new com.soulcraft.features.impl.FastEat(plugin));
        register(new com.soulcraft.features.impl.AutoFeed(plugin));
        register(new com.soulcraft.features.impl.XPBoost(plugin));
        register(new com.soulcraft.features.impl.MoneyBoost(plugin));
        register(new com.soulcraft.features.impl.LootBoost(plugin));
    }

    public void register(GameFeature feature) {
        features.put(feature.getId(), feature);
        
        // Register feature as listener if it implements Listener
        if (feature instanceof Listener) {
            Bukkit.getPluginManager().registerEvents((Listener) feature, plugin);
        }
        
        feature.onEnable();
    }

    public GameFeature getFeature(String id) {
        return features.get(id);
    }

    public void toggleFeature(String id, boolean enabled) {
        GameFeature feature = features.get(id);
        if (feature != null) {
            feature.setEnabled(enabled);
        }
    }

    public boolean isFeatureEnabled(String id) {
        GameFeature feature = features.get(id);
        return feature != null && feature.isEnabled();
    }

    public boolean canPlayerUseFeature(Player player, String featureId) {
        GameFeature feature = features.get(featureId);
        return feature != null && feature.canUse(player);
    }

    public Map<String, GameFeature> getAllFeatures() {
        return new HashMap<>(features);
    }

    public void disableAll() {
        for (GameFeature feature : features.values()) {
            feature.setEnabled(false);
        }
    }

    public void enableAll() {
        for (GameFeature feature : features.values()) {
            feature.setEnabled(true);
        }
    }
}
