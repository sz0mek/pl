package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.*;

public class SoulManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Long> lastKilled = new HashMap<>();
    private final Set<UUID> activeEnchantingPlayers = new HashSet<>();

    public SoulManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public int getSouls(String uuid) {
        return plugin.getConfig().getInt("players." + uuid + ".souls", 100);
    }

    public void addSouls(String uuid, int amount) {
        int current = getSouls(uuid);
        plugin.getConfig().set("players." + uuid + ".souls", current + amount);
        plugin.saveConfig();
    }

    public void removeSouls(String uuid, int amount) {
        int current = getSouls(uuid);
        plugin.getConfig().set("players." + uuid + ".souls", Math.max(0, current - amount));
        plugin.saveConfig();
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)) {
            String victimUUID = victim.getUniqueId().toString();
            String killerUUID = killer.getUniqueId().toString();
            long currentTime = System.currentTimeMillis();
            String killKey = killerUUID + ":" + victimUUID;
            Long lastKillTime = lastKilled.get(killKey);
            if (lastKillTime == null || (currentTime - lastKillTime > 2 * 60 * 60 * 1000)) {
                int victimSouls = getSouls(victimUUID);
                double multiplier = getSoulDropMultiplier(killer);
                int soulDrop = (int) (victimSouls * multiplier);
                if (soulDrop > 0) {
                    removeSouls(victimUUID, soulDrop);
                    addSouls(killerUUID, soulDrop);
                    killer.sendMessage("§5Zdobyłeś " + soulDrop + " dusz za zabicie " + victim.getName() + "!");
                    lastKilled.put(killKey, currentTime);
                    plugin.getConfig().set("players." + killerUUID + ".kills",
                            plugin.getConfig().getInt("players." + killerUUID + ".kills", 0) + 1);
                    plugin.saveConfig();
                }
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT_CLICK") && event.getItem() != null) {
            ItemStack item = event.getItem();

            // Handle Zaklinacz Dusz
            if (item.getType() == Material.NETHER_STAR && item.hasItemMeta() && item.getItemMeta().hasDisplayName()
                    && item.getItemMeta().getDisplayName().equals("§0Zaklinacz Dusz")) {
                event.setCancelled(true);
                openEnchanterGUI(event.getPlayer());
                return;
            }

            // Handle Soul Crystal
            if (item.getType() == Material.EMERALD && item.hasItemMeta() && item.getItemMeta().hasDisplayName()
                    && item.getItemMeta().hasLore()) {
                ItemMeta meta = item.getItemMeta();
                String name = meta.getDisplayName();
                List<String> lore = meta.getLore();
                if (name.startsWith("§bKryształ Dusz (Lvl ")
                        && lore.contains("Kliknij prawym przyciskiem myszy trzymając przedmiot")) {
                    int level = Integer.parseInt(name.split("Lvl ")[1].replace(")", ""));
                    int soulsToAdd = level * 10;
                    Player player = event.getPlayer();
                    String uuid = player.getUniqueId().toString();
                    addSouls(uuid, soulsToAdd);
                    player.sendMessage("§aOdebrałeś " + soulsToAdd + " dusz z kryształu!");
                    if (item.getAmount() > 1) {
                        item.setAmount(item.getAmount() - 1);
                    } else {
                        player.getInventory().setItemInMainHand(null);
                    }
                }
            }
        }
    }

    private void openEnchanterGUI(Player player) {
        Inventory gui = Bukkit.createInventory(new EnchanterHolder(), 27, "§0Zaklinacz Dusz");
        activeEnchantingPlayers.add(player.getUniqueId());

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.setDisplayName(" ");
            filler.setItemMeta(fillerMeta);
        }
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, filler);
        }
        // Explicitly set slot 13 to empty
        gui.setItem(13, null);

        ItemStack upgradeButton = new ItemStack(Material.ANVIL);
        ItemMeta upgradeMeta = upgradeButton.getItemMeta();
        if (upgradeMeta != null) {
            upgradeMeta.setDisplayName("§aUlepsz");
            upgradeMeta.setLore(Arrays.asList("§7Kliknij aby ulepszyć przedmiot", "§7w slocie 13"));
            upgradeButton.setItemMeta(upgradeMeta);
        }
        gui.setItem(22, upgradeButton);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;
        if (!(event.getView().getTopInventory().getHolder() instanceof EnchanterHolder))
            return;

        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize())
            return;

        if (raw == 13) {
            // Allow placing item here
            return;
        }

        // Block pickup from filler slots and upgrade button
        event.setCancelled(true);

        if (raw == 22) { // Upgrade button
            ItemStack itemToUpgrade = event.getView().getTopInventory().getItem(13);
            if (itemToUpgrade == null || itemToUpgrade.getType() == Material.AIR) {
                player.sendMessage("§cWłóż miecz lub element zbroi do slotu!");
                return;
            }

            ItemStack enchanter = player.getInventory().getItemInMainHand();
            if (enchanter == null || enchanter.getType() != Material.NETHER_STAR ||
                    !enchanter.hasItemMeta() || !enchanter.getItemMeta().getDisplayName().equals("§0Zaklinacz Dusz")) {
                player.sendMessage("§cMusisz trzymać Zaklinacz Dusz w ręce!");
                return;
            }

            boolean upgraded = false;
            ItemStack upgradedItem = itemToUpgrade.clone();

            // Check if it's a sword
            if (itemToUpgrade.getType().name().endsWith("_SWORD")) {
                ItemMeta meta = upgradedItem.getItemMeta();
                if (meta != null) {
                    int currentSharpness = meta.getEnchantLevel(Enchantment.SHARPNESS);
                    meta.addEnchant(Enchantment.SHARPNESS, currentSharpness + 1, true);
                    upgradedItem.setItemMeta(meta);
                    upgraded = true;
                }
            }
            // Check if it's armor
            else if (itemToUpgrade.getType().name().endsWith("_HELMET") ||
                    itemToUpgrade.getType().name().endsWith("_CHESTPLATE") ||
                    itemToUpgrade.getType().name().endsWith("_LEGGINGS") ||
                    itemToUpgrade.getType().name().endsWith("_BOOTS")) {
                ItemMeta meta = upgradedItem.getItemMeta();
                if (meta != null) {
                    int currentProtection = meta.getEnchantLevel(Enchantment.PROTECTION);
                    meta.addEnchant(Enchantment.PROTECTION, currentProtection + 1, true);
                    upgradedItem.setItemMeta(meta);
                    upgraded = true;
                }
            }

            if (upgraded) {
                // Remove item from slot 13
                event.getView().getTopInventory().setItem(13, null);

                // Give upgraded item to player
                player.getInventory().addItem(upgradedItem);

                // Remove 1 Zaklinacz Dusz from hand
                if (enchanter.getAmount() > 1) {
                    enchanter.setAmount(enchanter.getAmount() - 1);
                } else {
                    player.getInventory().setItemInMainHand(null);
                }

                player.sendMessage("§aPrzedmiot ulepszony!");
                player.closeInventory();
                activeEnchantingPlayers.remove(player.getUniqueId());
            } else {
                player.sendMessage("§cWłóż miecz lub element zbroi!");
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player))
            return;
        if (!(event.getView().getTopInventory().getHolder() instanceof EnchanterHolder))
            return;

        // Allow dragging only into slot 13
        for (int slot : event.getRawSlots()) {
            if (slot >= event.getView().getTopInventory().getSize())
                continue;
            if (slot != 13) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player))
            return;
        if (!(event.getView().getTopInventory().getHolder() instanceof EnchanterHolder))
            return;

        // Return item from slot 13 to player
        ItemStack item = event.getView().getTopInventory().getItem(13);
        if (item != null)
            player.getInventory().addItem(item);

        activeEnchantingPlayers.remove(player.getUniqueId());
    }

    private double getSoulDropMultiplier(Player player) {
        ItemStack sword = player.getInventory().getItemInMainHand();
        if (sword == null || !sword.getType().toString().contains("_SWORD") || !sword.hasItemMeta()
                || !sword.getItemMeta().hasLore()) {
            return 0.05;
        }
        List<String> lore = sword.getItemMeta().getLore();
        for (String line : lore) {
            if (line.startsWith("§5Większy Drop Dusz: Lvl ")) {
                int level = Integer.parseInt(line.split("Lvl ")[1]);
                double[] multipliers = { 0.05, 0.07, 0.10, 0.12, 0.15, 0.20 };
                return (level - 1 < multipliers.length) ? multipliers[level - 1] : 0.05;
            }
        }
        return 0.05;
    }

    private static class EnchanterHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}