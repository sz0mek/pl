package com.soulcraft.clans;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;

public class EnhancedClanManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<String, Clan> clans = new HashMap<>();
    private final Map<UUID, String> playerClans = new HashMap<>();
    
    public EnhancedClanManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void createClan(Player player, String clanName, String tag) {
        if (playerClans.containsKey(player.getUniqueId())) return;
        
        Clan clan = new Clan(clanName, tag, player.getUniqueId());
        clans.put(clanName.toLowerCase(), clan);
        playerClans.put(player.getUniqueId(), clanName.toLowerCase());
        
        player.sendMessage("§a§l✔ Utworzono klan: " + clanName + " [" + tag + "]");
    }
    
    public void depositToBank(Player player, int amount) {
        String clanName = playerClans.get(player.getUniqueId());
        if (clanName == null) return;
        
        Clan clan = clans.get(clanName);
        if (clan != null) {
            plugin.getSoulManager().removeSouls(player.getUniqueId().toString(), amount);
            clan.bankBalance += amount;
            player.sendMessage("§a§lWpłacono " + amount + " dusz do banku klanu!");
        }
    }
    
    public void declareWar(Player player, String targetClanName) {
        String clanName = playerClans.get(player.getUniqueId());
        if (clanName == null) return;
        
        Clan clan = clans.get(clanName);
        Clan target = clans.get(targetClanName.toLowerCase());
        
        if (clan != null && target != null && clan.leader.equals(player.getUniqueId())) {
            clan.wars.add(targetClanName.toLowerCase());
            target.wars.add(clanName);
            
            player.sendMessage("§c§l⚔ Wypowiedziano wojnę klanowi: " + targetClanName);
        }
    }
    
    public void createAlliance(Player player, String targetClanName) {
        String clanName = playerClans.get(player.getUniqueId());
        if (clanName == null) return;
        
        Clan clan = clans.get(clanName);
        Clan target = clans.get(targetClanName.toLowerCase());
        
        if (clan != null && target != null && clan.leader.equals(player.getUniqueId())) {
            clan.alliances.add(targetClanName.toLowerCase());
            target.alliances.add(clanName);
            
            player.sendMessage("§b§l✦ Utworzono sojusz z klanem: " + targetClanName);
        }
    }
    
    public void levelUp(String clanName) {
        Clan clan = clans.get(clanName.toLowerCase());
        if (clan != null && clan.level < 50) {
            clan.level++;
            // Unlock perks based on level
        }
    }
    
    public static class Clan {
        final String name, tag;
        final UUID leader;
        final Set<UUID> members = new HashSet<>();
        final Set<String> wars = new HashSet<>();
        final Set<String> alliances = new HashSet<>();
        int level = 1;
        int bankBalance = 0;
        int taxRate = 5; // 5% tax on soul earnings
        
        public Clan(String name, String tag, UUID leader) {
            this.name = name;
            this.tag = tag;
            this.leader = leader;
            this.members.add(leader);
        }
        
        public int getRequiredExpForNextLevel() {
            return level * 10000;
        }
        
        public String getPerks() {
            StringBuilder perks = new StringBuilder();
            if (level >= 5) perks.append("§a• +5% Damage\n");
            if (level >= 10) perks.append("§a• Teleport do członków\n");
            if (level >= 15) perks.append("§a• +10% Drop Rate\n");
            if (level >= 20) perks.append("§a• Clan Home\n");
            if (level >= 25) perks.append("§a• +15% XP\n");
            if (level >= 30) perks.append("§a• Clan Vault (Extra Storage)\n");
            if (level >= 35) perks.append("§a• +20% Souls Earnings\n");
            if (level >= 40) perks.append("§a• Clan Shop Discounts 10%\n");
            if (level >= 45) perks.append("§a• +25% Max HP\n");
            if (level >= 50) perks.append("§5§l• LEGENDARY STATUS\n");
            return perks.toString();
        }
    }
}
