package com.soulcraft.abilities;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Complete ability system with cooldowns, event listeners, and synergy
 */
public class AbilityService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final Map<String, AbilityConfig> abilityConfigs;
    private final Map<UUID, Map<String, AbilityState>> playerStates;
    
    public AbilityService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.abilityConfigs = new HashMap<>();
        this.playerStates = new HashMap<>();
        
        loadAbilityConfigs();
    }
    
    private void loadAbilityConfigs() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load all 12 abilities
        String[] abilities = {
            "berserk", "critical_strike", "dodge", "heal_on_hit",
            "life_steal", "lucky", "regeneration", "shield",
            "soul_shield", "speed_burst", "thorns", "vampirism"
        };
        
        for (String abilityId : abilities) {
            AbilityConfig config = new AbilityConfig();
            String path = "abilities." + abilityId;
            
            config.id = abilityId;
            config.name = balance.getString(path + ".name");
            config.cooldown = balance.getInt(path + ".cooldown", 0);
            config.duration = balance.getInt(path + ".duration", 0);
            config.soulCost = balance.getInt(path + ".soul_cost", 0);
            config.levelRequired = balance.getInt(path + ".level_required", 0);
            
            // Ability-specific stats
            config.damageBoost = balance.getDouble(path + ".damage_boost", 0);
            config.speedBoost = balance.getDouble(path + ".speed_boost", 0);
            config.chance = balance.getDouble(path + ".chance", 0);
            config.damageMultiplier = balance.getDouble(path + ".damage_multiplier", 0);
            config.healPercent = balance.getDouble(path + ".heal_percent", 0);
            config.stealPercent = balance.getDouble(path + ".steal_percent", 0);
            config.lootBonus = balance.getDouble(path + ".loot_bonus", 0);
            config.healthPerSecond = balance.getDouble(path + ".health_per_second", 0);
            config.absorptionAmount = balance.getDouble(path + ".absorption_amount", 0);
            config.damageReduction = balance.getDouble(path + ".damage_reduction", 0);
            config.reflectDamage = balance.getDouble(path + ".reflect_damage", 0);
            config.reflectPercent = balance.getDouble(path + ".reflect_percent", 0);
            
            abilityConfigs.put(abilityId, config);
        }
    }
    
    /**
     * Check if player can unlock ability
     */
    public boolean canUnlock(Player player, String abilityId) {
        AbilityConfig config = abilityConfigs.get(abilityId);
        if (config == null) return false;
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        
        if (data.hasAbility(abilityId)) return false;
        if (data.getLevel() < config.levelRequired) return false;
        if (!economyService.hasEnough(player, config.soulCost)) return false;
        
        return true;
    }
    
    /**
     * Unlock ability for player
     */
    public boolean unlockAbility(Player player, String abilityId) {
        if (!canUnlock(player, abilityId)) return false;
        
        AbilityConfig config = abilityConfigs.get(abilityId);
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        
        if (!economyService.withdraw(player, config.soulCost, "Unlock ability: " + config.name)) {
            return false;
        }
        
        data.unlockAbility(abilityId);
        return true;
    }
    
    /**
     * Check if player has ability unlocked
     */
    public boolean hasAbility(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.hasAbility(abilityId);
    }
    
    /**
     * Check if ability is on cooldown
     */
    public boolean isOnCooldown(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.isAbilityOnCooldown(abilityId);
    }
    
    /**
     * Get remaining cooldown in seconds
     */
    public int getRemainingCooldown(Player player, String abilityId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        Long cooldownEnd = data.getAbilityCooldowns().get(abilityId);
        
        if (cooldownEnd == null) return 0;
        
        long remaining = cooldownEnd - System.currentTimeMillis();
        if (remaining <= 0) return 0;
        
        return (int)(remaining / 1000);
    }
    
    /**
     * Activate ability
     */
    public boolean activateAbility(Player player, String abilityId) {
        if (!hasAbility(player, abilityId)) return false;
        if (isOnCooldown(player, abilityId)) return false;
        
        AbilityConfig config = abilityConfigs.get(abilityId);
        if (config == null) return false;
        
        // Set cooldown
        if (config.cooldown > 0) {
            PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
            data.setAbilityCooldown(abilityId, System.currentTimeMillis() + (config.cooldown * 1000L));
        }
        
        // Start ability effect
        if (config.duration > 0) {
            startAbilityEffect(player, abilityId, config);
        }
        
        return true;
    }
    
    /**
     * Start ability effect (for active abilities with duration)
     */
    private void startAbilityEffect(Player player, String abilityId, AbilityConfig config) {
        UUID playerId = player.getUniqueId();
        
        AbilityState state = new AbilityState();
        state.abilityId = abilityId;
        state.startTime = System.currentTimeMillis();
        state.endTime = state.startTime + (config.duration * 1000L);
        state.config = config;
        
        Map<String, AbilityState> states = playerStates.computeIfAbsent(playerId, k -> new HashMap<>());
        states.put(abilityId, state);
        
        // Schedule end
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            endAbilityEffect(playerId, abilityId);
        }, config.duration * 20L); // Convert to ticks
    }
    
    /**
     * End ability effect
     */
    private void endAbilityEffect(UUID playerId, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(playerId);
        if (states != null) {
            states.remove(abilityId);
        }
    }
    
    /**
     * Check if ability is currently active
     */
    public boolean isAbilityActive(Player player, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(player.getUniqueId());
        if (states == null) return false;
        
        AbilityState state = states.get(abilityId);
        if (state == null) return false;
        
        return System.currentTimeMillis() < state.endTime;
    }
    
    /**
     * Get ability config
     */
    public AbilityConfig getConfig(String abilityId) {
        return abilityConfigs.get(abilityId);
    }
    
    /**
     * Get active ability state
     */
    public AbilityState getActiveState(Player player, String abilityId) {
        Map<String, AbilityState> states = playerStates.get(player.getUniqueId());
        if (states == null) return null;
        return states.get(abilityId);
    }
    
    /**
     * Get all active abilities for player
     */
    public Map<String, AbilityState> getActiveAbilities(Player player) {
        return playerStates.getOrDefault(player.getUniqueId(), new HashMap<>());
    }
    
    /**
     * Cleanup when player logs out
     */
    public void cleanup(UUID playerId) {
        playerStates.remove(playerId);
    }
    
    /**
     * Ability configuration
     */
    public static class AbilityConfig {
        public String id;
        public String name;
        public int cooldown;
        public int duration;
        public int soulCost;
        public int levelRequired;
        
        // Combat stats
        public double damageBoost;
        public double speedBoost;
        public double chance;
        public double damageMultiplier;
        public double healPercent;
        public double stealPercent;
        public double lootBonus;
        public double healthPerSecond;
        public double absorptionAmount;
        public double damageReduction;
        public double reflectDamage;
        public double reflectPercent;
    }
    
    /**
     * Active ability state
     */
    public static class AbilityState {
        public String abilityId;
        public long startTime;
        public long endTime;
        public AbilityConfig config;
        
        public boolean isActive() {
            return System.currentTimeMillis() < endTime;
        }
        
        public int getRemainingSeconds() {
            long remaining = endTime - System.currentTimeMillis();
            return remaining > 0 ? (int)(remaining / 1000) : 0;
        }
    }
}
