package com.soulcraft.clans;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Complete clan system with economy, wars, territory, and seasons
 */
public class ClanService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    
    private final Map<String, Clan> clans;  // clan ID -> clan
    private final Map<UUID, String> playerClans;  // player ID -> clan ID
    private final Map<String, ClanWar> activeWars;  // war ID -> war
    
    private final long CREATION_COST = 50000;
    private final int MAX_MEMBERS = 50;
    private final int DAILY_COST_PER_MEMBER = 100;
    
    public ClanService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.clans = new ConcurrentHashMap<>();
        this.playerClans = new ConcurrentHashMap<>();
        this.activeWars = new ConcurrentHashMap<>();
        
        loadClans();
        startUpkeepTask();
    }
    
    private void loadClans() {
        // Load clans from storage
        // Placeholder - would load from YAML/database
    }
    
    /**
     * Create new clan
     */
    public boolean createClan(UUID ownerId, String clanName, String tag) {
        // Check if player already in clan
        if (playerClans.containsKey(ownerId)) {
            return false;
        }
        
        // Check cost
        if (!economyService.hasEnough(ownerId, CREATION_COST)) {
            return false;
        }
        
        // Check if name/tag already exists
        for (Clan clan : clans.values()) {
            if (clan.name.equalsIgnoreCase(clanName) || clan.tag.equalsIgnoreCase(tag)) {
                return false;
            }
        }
        
        // Charge cost
        if (!economyService.withdraw(ownerId, CREATION_COST, "Clan creation")) {
            return false;
        }
        
        // Create clan
        String clanId = UUID.randomUUID().toString();
        Clan clan = new Clan();
        clan.id = clanId;
        clan.name = clanName;
        clan.tag = tag;
        clan.owner = ownerId;
        clan.members.add(ownerId);
        clan.level = 1;
        clan.bankBalance = 0;
        clan.creationTime = System.currentTimeMillis();
        
        clans.put(clanId, clan);
        playerClans.put(ownerId, clanId);
        
        // Update player data
        PlayerData data = dataStore.loadPlayerData(ownerId);
        data.setClanId(clanId);
        
        Player player = Bukkit.getPlayer(ownerId);
        if (player != null) {
            player.sendMessage("§b§l✦ Clan Created! §e" + clanName + " §7[" + tag + "]");
        }
        
        return true;
    }
    
    /**
     * Invite player to clan
     */
    public boolean invitePlayer(UUID inviterId, UUID targetId) {
        String clanId = playerClans.get(inviterId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check permissions
        if (!clan.owner.equals(inviterId) && !clan.officers.contains(inviterId)) {
            return false;
        }
        
        // Check if target already in clan
        if (playerClans.containsKey(targetId)) {
            return false;
        }
        
        // Check member limit
        if (clan.members.size() >= clan.getMaxMembers()) {
            return false;
        }
        
        // Add to pending invites
        clan.pendingInvites.add(targetId);
        
        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            target.sendMessage("§b§l✦ Clan Invite! §e" + clan.name + " §7[" + clan.tag + "]");
            target.sendMessage("§7Use /klan accept to join!");
        }
        
        return true;
    }
    
    /**
     * Accept clan invite
     */
    public boolean acceptInvite(UUID playerId, String clanId) {
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!clan.pendingInvites.contains(playerId)) {
            return false;
        }
        
        clan.pendingInvites.remove(playerId);
        clan.members.add(playerId);
        playerClans.put(playerId, clanId);
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.setClanId(clanId);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a§l✓ Joined clan: §e" + clan.name);
        }
        
        // Announce to clan
        broadcastToClan(clanId, "§b" + player.getName() + " joined the clan!");
        
        return true;
    }
    
    /**
     * Leave clan
     */
    public boolean leaveClan(UUID playerId) {
        String clanId = playerClans.remove(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check if owner
        if (clan.owner.equals(playerId)) {
            if (clan.members.size() > 1) {
                // Transfer ownership or disband
                return false; // Require explicit transfer
            } else {
                // Disband clan
                clans.remove(clanId);
            }
        } else {
            clan.members.remove(playerId);
            clan.officers.remove(playerId);
        }
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.setClanId(null);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§7Left clan: " + clan.name);
        }
        
        return true;
    }
    
    /**
     * Contribute to clan bank
     */
    public boolean contribute(UUID playerId, long amount) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        if (!economyService.hasEnough(playerId, amount)) {
            return false;
        }
        
        if (!economyService.withdraw(playerId, amount, "Clan contribution")) {
            return false;
        }
        
        clan.bankBalance += amount;
        
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.addClanContribution(amount);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a§l✓ Contributed §6" + amount + " souls §ato clan bank");
        }
        
        return true;
    }
    
    /**
     * Upgrade clan level
     */
    public boolean upgradeClan(UUID playerId) {
        String clanId = playerClans.get(playerId);
        if (clanId == null) return false;
        
        Clan clan = clans.get(clanId);
        if (clan == null) return false;
        
        // Check permissions
        if (!clan.owner.equals(playerId)) {
            return false;
        }
        
        if (clan.level >= 5) {
            return false; // Max level
        }
        
        long upgradeCost = clan.getUpgradeCost();
        if (clan.bankBalance < upgradeCost) {
            return false;
        }
        
        clan.bankBalance -= upgradeCost;
        clan.level++;
        
        broadcastToClan(clanId, "§b§l✦ Clan upgraded to level " + clan.level + "!");
        
        return true;
    }
    
    /**
     * Declare war on another clan
     */
    public boolean declareWar(UUID declarerId, String targetClanId) {
        String attackerClanId = playerClans.get(declarerId);
        if (attackerClanId == null) return false;
        
        Clan attackerClan = clans.get(attackerClanId);
        Clan defenderClan = clans.get(targetClanId);
        
        if (attackerClan == null || defenderClan == null) return false;
        
        // Check permissions
        if (!attackerClan.owner.equals(declarerId)) {
            return false;
        }
        
        // Check cost
        long warCost = 25000;
        if (attackerClan.bankBalance < warCost) {
            return false;
        }
        
        attackerClan.bankBalance -= warCost;
        
        // Create war
        String warId = UUID.randomUUID().toString();
        ClanWar war = new ClanWar();
        war.id = warId;
        war.attackerClanId = attackerClanId;
        war.defenderClanId = targetClanId;
        war.startTime = System.currentTimeMillis();
        war.endTime = war.startTime + (7200 * 1000); // 2 hours
        war.attackerPoints = 0;
        war.defenderPoints = 0;
        
        activeWars.put(warId, war);
        
        // Announce
        broadcastToClan(attackerClanId, "§c§l⚔ War declared against " + defenderClan.name + "!");
        broadcastToClan(targetClanId, "§c§l⚔ War declared by " + attackerClan.name + "!");
        
        return true;
    }
    
    /**
     * Record kill in clan war
     */
    public void recordWarKill(UUID killerId, UUID victimId) {
        String killerClanId = playerClans.get(killerId);
        String victimClanId = playerClans.get(victimId);
        
        if (killerClanId == null || victimClanId == null) return;
        
        // Find active war between these clans
        for (ClanWar war : activeWars.values()) {
            if ((war.attackerClanId.equals(killerClanId) && war.defenderClanId.equals(victimClanId)) ||
                (war.attackerClanId.equals(victimClanId) && war.defenderClanId.equals(killerClanId))) {
                
                // Add points
                if (war.attackerClanId.equals(killerClanId)) {
                    war.attackerPoints += 10;
                } else {
                    war.defenderPoints += 10;
                }
                
                break;
            }
        }
    }
    
    /**
     * End clan war
     */
    public void endWar(String warId) {
        ClanWar war = activeWars.remove(warId);
        if (war == null) return;
        
        Clan attackerClan = clans.get(war.attackerClanId);
        Clan defenderClan = clans.get(war.defenderClanId);
        
        if (attackerClan == null || defenderClan == null) return;
        
        // Determine winner
        Clan winner;
        Clan loser;
        long winnerReward = 100000;
        long loserReward = 25000;
        
        if (war.attackerPoints > war.defenderPoints) {
            winner = attackerClan;
            loser = defenderClan;
        } else {
            winner = defenderClan;
            loser = attackerClan;
        }
        
        winner.bankBalance += winnerReward;
        loser.bankBalance += loserReward;
        
        // Announce
        Bukkit.broadcastMessage("§c§l⚔ Clan War Ended!");
        Bukkit.broadcastMessage("§e" + winner.name + " §7defeated §e" + loser.name);
        
        broadcastToClan(winner.id, "§a§l✓ Victory! +§6" + winnerReward + " souls");
        broadcastToClan(loser.id, "§c§lDefeat! +§6" + loserReward + " souls");
    }
    
    /**
     * Get clan
     */
    public Clan getClan(String clanId) {
        return clans.get(clanId);
    }
    
    /**
     * Get player's clan
     */
    public Clan getPlayerClan(UUID playerId) {
        String clanId = playerClans.get(playerId);
        return clanId != null ? clans.get(clanId) : null;
    }
    
    /**
     * Broadcast message to clan
     */
    private void broadcastToClan(String clanId, String message) {
        Clan clan = clans.get(clanId);
        if (clan == null) return;
        
        for (UUID memberId : clan.members) {
            Player player = Bukkit.getPlayer(memberId);
            if (player != null) {
                player.sendMessage(message);
            }
        }
    }
    
    /**
     * Start upkeep task
     */
    private void startUpkeepTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Clan clan : clans.values()) {
                long upkeep = clan.members.size() * DAILY_COST_PER_MEMBER;
                
                if (clan.bankBalance >= upkeep) {
                    clan.bankBalance -= upkeep;
                } else {
                    // Warn clan about insufficient funds
                    broadcastToClan(clan.id, "§c§l⚠ Insufficient funds for upkeep!");
                }
            }
            
            // Check and end wars
            List<String> endedWars = new ArrayList<>();
            for (Map.Entry<String, ClanWar> entry : activeWars.entrySet()) {
                if (System.currentTimeMillis() > entry.getValue().endTime) {
                    endWar(entry.getKey());
                    endedWars.add(entry.getKey());
                }
            }
            endedWars.forEach(activeWars::remove);
            
        }, 24000L, 24000L); // Run every 20 minutes (simulated day)
    }
    
    /**
     * Clan class
     */
    public static class Clan {
        public String id;
        public String name;
        public String tag;
        public UUID owner;
        public Set<UUID> members = new HashSet<>();
        public Set<UUID> officers = new HashSet<>();
        public Set<UUID> pendingInvites = new HashSet<>();
        public int level = 1;
        public long bankBalance = 0;
        public long creationTime;
        public Map<Integer, Integer> territory = new HashMap<>();  // chunk -> claim time
        
        public int getMaxMembers() {
            return level * 10;
        }
        
        public long getMaxBankSize() {
            return level * 250000L;
        }
        
        public long getUpgradeCost() {
            return level * 100000L;
        }
    }
    
    /**
     * Clan war class
     */
    public static class ClanWar {
        public String id;
        public String attackerClanId;
        public String defenderClanId;
        public long startTime;
        public long endTime;
        public int attackerPoints;
        public int defenderPoints;
    }
}
