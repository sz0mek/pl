package com.soulcraft.dungeons;

import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import com.soulcraft.economy.EconomyService;
import com.soulcraft.missions.MissionService;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;

import java.util.*;

/**
 * Complete procedural dungeon generation system with biomes, affixes, and loot
 */
public class DungeonService {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MissionService missionService;
    
    private final Map<String, DifficultyConfig> difficulties;
    private final List<BiomeConfig> biomes;
    private final List<String> affixes;
    private final Map<UUID, DungeonInstance> activeDungeons;
    private final Random random;
    
    public DungeonService(Plugin plugin, DataStore dataStore, EconomyService economyService, MissionService missionService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.missionService = missionService;
        this.difficulties = new HashMap<>();
        this.biomes = new ArrayList<>();
        this.affixes = new ArrayList<>();
        this.activeDungeons = new HashMap<>();
        this.random = new Random();
        
        loadDungeonConfig();
    }
    
    private void loadDungeonConfig() {
        YamlConfiguration balance = dataStore.loadConfig("balance.yml");
        
        // Load difficulties
        ConfigurationSection diffSection = balance.getConfigurationSection("dungeons.difficulties");
        if (diffSection != null) {
            for (String diff : diffSection.getKeys(false)) {
                String path = "dungeons.difficulties." + diff;
                DifficultyConfig config = new DifficultyConfig();
                config.id = diff;
                config.mobLevelMultiplier = balance.getDouble(path + ".mob_level_multiplier");
                config.lootMultiplier = balance.getDouble(path + ".loot_multiplier");
                config.soulReward = balance.getLong(path + ".soul_reward");
                config.requiredLevel = balance.getInt(path + ".required_level");
                difficulties.put(diff, config);
            }
        }
        
        // Load biomes
        List<Map<?, ?>> biomesList = balance.getMapList("dungeons.biomes");
        for (Map<?, ?> biomeMap : biomesList) {
            BiomeConfig biome = new BiomeConfig();
            biome.name = (String) biomeMap.get("name");
            biome.theme = (String) biomeMap.get("theme");
            biome.mobs = (List<String>) biomeMap.get("mobs");
            biomes.add(biome);
        }
        
        // Load affixes
        ConfigurationSection affixSection = balance.getConfigurationSection("dungeons.affixes");
        if (affixSection != null) {
            for (String key : affixSection.getKeys(false)) {
                affixes.add(key);
            }
        }
    }
    
    /**
     * Generate and enter dungeon
     */
    public boolean enterDungeon(Player player, String difficulty) {
        DifficultyConfig config = difficulties.get(difficulty);
        if (config == null) return false;
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        if (data.getLevel() < config.requiredLevel) {
            player.sendMessage("§c§lRequires level " + config.requiredLevel + "!");
            return false;
        }
        
        // Check if player already in dungeon
        if (activeDungeons.containsKey(player.getUniqueId())) {
            player.sendMessage("§c§lYou are already in a dungeon!");
            return false;
        }
        
        // Generate dungeon
        DungeonInstance dungeon = generateDungeon(difficulty);
        dungeon.playerId = player.getUniqueId();
        dungeon.startTime = System.currentTimeMillis();
        
        activeDungeons.put(player.getUniqueId(), dungeon);
        
        // Teleport player
        player.teleport(dungeon.spawnLocation);
        player.sendMessage("§5§l✦ Entered " + difficulty.toUpperCase() + " Dungeon");
        player.sendMessage("§7Biome: §e" + dungeon.biome.name);
        if (!dungeon.activeAffixes.isEmpty()) {
            player.sendMessage("§7Affixes: §c" + String.join(", ", dungeon.activeAffixes));
        }
        
        return true;
    }
    
    /**
     * Generate dungeon structure
     */
    private DungeonInstance generateDungeon(String difficulty) {
        DungeonInstance dungeon = new DungeonInstance();
        dungeon.difficulty = difficulty;
        dungeon.config = difficulties.get(difficulty);
        
        // Pick random biome
        dungeon.biome = biomes.get(random.nextInt(biomes.size()));
        
        // Pick random affixes (0-2)
        int affixCount = random.nextInt(3);
        for (int i = 0; i < affixCount; i++) {
            dungeon.activeAffixes.add(affixes.get(random.nextInt(affixes.size())));
        }
        
        // Generate location (in separate dimension or far from spawn)
        World world = Bukkit.getWorlds().get(0);
        int x = random.nextInt(10000) + 10000;
        int z = random.nextInt(10000) + 10000;
        dungeon.spawnLocation = new Location(world, x, 100, z);
        
        // Generate rooms (5-10 rooms)
        int roomCount = random.nextInt(6) + 5;
        generateRooms(dungeon, roomCount);
        
        return dungeon;
    }
    
    /**
     * Generate dungeon rooms
     */
    private void generateRooms(DungeonInstance dungeon, int roomCount) {
        Location currentLoc = dungeon.spawnLocation.clone();
        
        for (int i = 0; i < roomCount; i++) {
            RoomType type;
            
            if (i == roomCount - 1) {
                type = RoomType.BOSS;  // Last room is boss
            } else {
                // Random room type
                double rand = random.nextDouble();
                if (rand < 0.6) type = RoomType.COMBAT;
                else if (rand < 0.75) type = RoomType.TREASURE;
                else if (rand < 0.85) type = RoomType.PUZZLE;
                else type = RoomType.TRAP;
            }
            
            Room room = generateRoom(currentLoc, type, dungeon);
            dungeon.rooms.add(room);
            
            // Move to next room location
            currentLoc = currentLoc.clone().add(random.nextInt(20) + 10, 0, random.nextInt(20) + 10);
        }
    }
    
    /**
     * Generate individual room
     */
    private Room generateRoom(Location location, RoomType type, DungeonInstance dungeon) {
        Room room = new Room();
        room.location = location;
        room.type = type;
        room.size = random.nextInt(10) + 10;  // 10-20 blocks
        
        // Build room structure
        buildRoomStructure(room, dungeon);
        
        // Populate room based on type
        switch (type) {
            case COMBAT:
                spawnMobs(room, dungeon);
                break;
            case TREASURE:
                spawnChests(room, dungeon);
                break;
            case PUZZLE:
                createPuzzle(room);
                break;
            case TRAP:
                createTraps(room);
                break;
            case BOSS:
                spawnBoss(room, dungeon);
                break;
        }
        
        return room;
    }
    
    /**
     * Build room structure
     */
    private void buildRoomStructure(Room room, DungeonInstance dungeon) {
        Location loc = room.location;
        int size = room.size;
        
        // Determine materials based on biome
        Material wallMaterial = Material.STONE_BRICKS;
        Material floorMaterial = Material.STONE;
        
        switch (dungeon.biome.theme.toLowerCase()) {
            case "undead":
                wallMaterial = Material.MOSSY_STONE_BRICKS;
                floorMaterial = Material.SOUL_SAND;
                break;
            case "void":
                wallMaterial = Material.END_STONE_BRICKS;
                floorMaterial = Material.OBSIDIAN;
                break;
            case "fire":
                wallMaterial = Material.NETHER_BRICKS;
                floorMaterial = Material.NETHERRACK;
                break;
            case "ice":
                wallMaterial = Material.PACKED_ICE;
                floorMaterial = Material.ICE;
                break;
        }
        
        // Build floor
        for (int x = 0; x < size; x++) {
            for (int z = 0; z < size; z++) {
                Block block = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() - 1, loc.getBlockZ() + z);
                block.setType(floorMaterial);
            }
        }
        
        // Build walls
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i < size; i++) {
                // Four walls
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ()).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + i, loc.getBlockY() + y, loc.getBlockZ() + size - 1).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX(), loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
                loc.getWorld().getBlockAt(loc.getBlockX() + size - 1, loc.getBlockY() + y, loc.getBlockZ() + i).setType(wallMaterial);
            }
        }
        
        // Clear interior
        for (int x = 1; x < size - 1; x++) {
            for (int z = 1; z < size - 1; z++) {
                for (int y = 0; y < 5; y++) {
                    Block block = loc.getWorld().getBlockAt(loc.getBlockX() + x, loc.getBlockY() + y, loc.getBlockZ() + z);
                    block.setType(Material.AIR);
                }
            }
        }
    }
    
    /**
     * Spawn mobs in combat room
     */
    private void spawnMobs(Room room, DungeonInstance dungeon) {
        int mobCount = random.nextInt(5) + 3;  // 3-8 mobs
        
        for (int i = 0; i < mobCount; i++) {
            String mobType = dungeon.biome.mobs.get(random.nextInt(dungeon.biome.mobs.size()));
            Location spawnLoc = room.location.clone().add(
                random.nextInt(room.size - 2) + 1,
                0,
                random.nextInt(room.size - 2) + 1
            );
            
            LivingEntity mob = spawnMobFromName(mobType, spawnLoc);
            if (mob != null) {
                // Apply difficulty multiplier
                double multiplier = dungeon.config.mobLevelMultiplier;
                if (mob.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH) != null) {
                    double health = mob.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue() * multiplier;
                    mob.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
                    mob.setHealth(health);
                }
                
                room.entities.add(mob.getUniqueId());
            }
        }
    }
    
    /**
     * Spawn mob from name
     */
    private LivingEntity spawnMobFromName(String mobType, Location location) {
        try {
            EntityType type = EntityType.valueOf(mobType.toUpperCase());
            return (LivingEntity) location.getWorld().spawnEntity(location, type);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Spawn chests in treasure room
     */
    private void spawnChests(Room room, DungeonInstance dungeon) {
        int chestCount = random.nextInt(3) + 2;  // 2-5 chests
        
        for (int i = 0; i < chestCount; i++) {
            Location chestLoc = room.location.clone().add(
                random.nextInt(room.size - 2) + 1,
                0,
                random.nextInt(room.size - 2) + 1
            );
            
            Block block = chestLoc.getBlock();
            block.setType(Material.CHEST);
            
            // Would populate chest with loot based on difficulty multiplier
        }
    }
    
    /**
     * Create puzzle elements
     */
    private void createPuzzle(Room room) {
        // Placeholder - would create pressure plates, levers, etc.
    }
    
    /**
     * Create trap elements
     */
    private void createTraps(Room room) {
        // Placeholder - would create TNT, tripwires, etc.
    }
    
    /**
     * Spawn boss in boss room
     */
    private void spawnBoss(Room room, DungeonInstance dungeon) {
        // Placeholder - would spawn mini-boss
    }
    
    /**
     * Complete dungeon
     */
    public void completeDungeon(UUID playerId) {
        DungeonInstance dungeon = activeDungeons.remove(playerId);
        if (dungeon == null) return;
        
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        // Calculate time bonus
        long timeSpent = (System.currentTimeMillis() - dungeon.startTime) / 1000;
        
        // Give rewards
        economyService.deposit(player, dungeon.config.soulReward, "Dungeon completion");
        
        // Progress missions
        PlayerData data = dataStore.loadPlayerData(playerId);
        data.incrementDungeonsCompleted();
        missionService.progressMission(playerId, MissionService.MissionType.COMPLETE_DUNGEONS, 1);
        
        // Announce
        player.sendMessage("§a§l✓ DUNGEON COMPLETE!");
        player.sendMessage("§7Time: §e" + timeSpent + "s");
        player.sendMessage("§6Reward: §e+" + dungeon.config.soulReward + " souls");
        
        // Teleport back
        player.teleport(player.getWorld().getSpawnLocation());
    }
    
    /**
     * Configuration classes
     */
    public static class DifficultyConfig {
        public String id;
        public double mobLevelMultiplier;
        public double lootMultiplier;
        public long soulReward;
        public int requiredLevel;
    }
    
    public static class BiomeConfig {
        public String name;
        public String theme;
        public List<String> mobs;
    }
    
    public static class DungeonInstance {
        public UUID playerId;
        public String difficulty;
        public DifficultyConfig config;
        public BiomeConfig biome;
        public List<String> activeAffixes = new ArrayList<>();
        public Location spawnLocation;
        public List<Room> rooms = new ArrayList<>();
        public long startTime;
    }
    
    public static class Room {
        public Location location;
        public RoomType type;
        public int size;
        public List<UUID> entities = new ArrayList<>();
    }
    
    public enum RoomType {
        COMBAT,
        TREASURE,
        PUZZLE,
        TRAP,
        BOSS
    }
}
