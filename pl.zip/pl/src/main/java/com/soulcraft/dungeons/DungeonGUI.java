package com.soulcraft.dungeons;

import com.soulcraft.gui.GUIBuilder;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * GUI for dungeon selection and party management
 */
public class DungeonGUI implements Listener, InventoryHolder {
    private final DungeonService dungeonService;
    private final DataStore dataStore;
    private final Player player;
    
    public DungeonGUI(DungeonService dungeonService, DataStore dataStore) {
        this.dungeonService = dungeonService;
        this.dataStore = dataStore;
        this.player = null;
    }
    
    public void openDungeonSelection(Player player) {
        Inventory gui = GUIBuilder.create("§5§l✦ Dungeon Selection ✦", 6, this)
            .fillBorder(Material.PURPLE_STAINED_GLASS_PANE, "§5§l◆")
            .build();
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        int playerLevel = data.getLevel();
        
        // Easy Dungeon
        ItemStack easyDungeon = createDungeonItem(
            Material.WOODEN_SWORD,
            "§a§lEasy Dungeon",
            "easy",
            1,
            "10x10 rooms",
            "500 souls reward",
            playerLevel >= 1
        );
        gui.setItem(10, easyDungeon);
        
        // Medium Dungeon
        ItemStack mediumDungeon = createDungeonItem(
            Material.STONE_SWORD,
            "§e§lMedium Dungeon",
            "medium",
            20,
            "15x15 rooms",
            "1,500 souls reward",
            playerLevel >= 20
        );
        gui.setItem(12, mediumDungeon);
        
        // Hard Dungeon
        ItemStack hardDungeon = createDungeonItem(
            Material.IRON_SWORD,
            "§6§lHard Dungeon",
            "hard",
            35,
            "20x20 rooms",
            "3,500 souls reward",
            playerLevel >= 35
        );
        gui.setItem(14, hardDungeon);
        
        // Nightmare Dungeon
        ItemStack nightmareDungeon = createDungeonItem(
            Material.DIAMOND_SWORD,
            "§c§lNightmare Dungeon",
            "nightmare",
            50,
            "30x30 rooms",
            "8,000 souls reward",
            playerLevel >= 50
        );
        gui.setItem(16, nightmareDungeon);
        
        // Chaos Dungeon
        ItemStack chaosDungeon = createDungeonItem(
            Material.NETHERITE_SWORD,
            "§4§lChaos Dungeon",
            "chaos",
            75,
            "40x40 rooms",
            "20,000 souls reward",
            playerLevel >= 75
        );
        gui.setItem(28, chaosDungeon);
        
        // Info item
        ItemStack info = GUIBuilder.createItem(
            Material.BOOK,
            "§d§lDungeon Info",
            "§7Complete dungeons for rewards!",
            "§7",
            "§eFeatures:",
            "§7• Procedurally generated rooms",
            "§7• Time-limited challenges",
            "§7• Party support (up to 5 players)",
            "§7• Daily seed changes",
            "§7• Leaderboard tracking",
            "§7",
            "§aTip: Complete faster for bonus rewards!"
        );
        gui.setItem(31, info);
        
        // Party info
        ItemStack partyInfo = GUIBuilder.createItem(
            Material.PLAYER_HEAD,
            "§b§lParty Dungeons",
            "§7Form a party to tackle harder",
            "§7dungeons together!",
            "§7",
            "§7Party size scales difficulty",
            "§7but increases rewards.",
            "§7",
            "§e/dungeon party create",
            "§e/dungeon party invite <player>",
            "§e/dungeon party start <difficulty>"
        );
        gui.setItem(32, partyInfo);
        
        // Statistics
        int completions = data.getDungeonsCompleted();
        ItemStack stats = GUIBuilder.createItem(
            Material.WRITABLE_BOOK,
            "§6§lYour Statistics",
            "§7Dungeons Completed: §e" + completions,
            "§7Current Level: §e" + playerLevel,
            "§7",
            "§7Complete more dungeons to",
            "§7unlock higher difficulties!"
        );
        gui.setItem(49, stats);
        
        player.openInventory(gui);
    }
    
    private ItemStack createDungeonItem(Material material, String name, String difficultyId, int levelReq, String roomSize, String reward, boolean unlocked) {
        List<String> lore = new ArrayList<>();
        lore.add("§7");
        lore.add("§7Required Level: §e" + levelReq);
        lore.add("§7Room Size: §e" + roomSize);
        lore.add("§7Reward: §e" + reward);
        lore.add("§7");
        
        DungeonService.DifficultyConfig config = dungeonService.getDifficulties().get(difficultyId);
        if (config != null) {
            lore.add("§7Difficulty Multiplier: §c" + config.mobLevelMultiplier + "x");
            lore.add("§7Loot Multiplier: §6" + config.lootMultiplier + "x");
            lore.add("§7");
        }
        
        if (unlocked) {
            lore.add("§a§l✓ Click to Enter!");
            return GUIBuilder.createGlowingItem(material, name, lore);
        } else {
            lore.add("§c§l✗ LOCKED");
            lore.add("§7Reach level " + levelReq + " to unlock");
            return GUIBuilder.createItem(material, name, lore);
        }
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getInventory().getHolder() != this) return;
        
        event.setCancelled(true);
        
        Player player = (Player) event.getWhoClicked();
        ItemStack clicked = event.getCurrentItem();
        
        if (clicked == null || clicked.getType() == Material.AIR) return;
        
        String displayName = clicked.getItemMeta().getDisplayName();
        
        if (displayName.contains("Easy Dungeon")) {
            player.closeInventory();
            dungeonService.startDungeon(player, "easy");
        } else if (displayName.contains("Medium Dungeon")) {
            player.closeInventory();
            dungeonService.startDungeon(player, "medium");
        } else if (displayName.contains("Hard Dungeon")) {
            player.closeInventory();
            dungeonService.startDungeon(player, "hard");
        } else if (displayName.contains("Nightmare Dungeon")) {
            player.closeInventory();
            dungeonService.startDungeon(player, "nightmare");
        } else if (displayName.contains("Chaos Dungeon")) {
            player.closeInventory();
            dungeonService.startDungeon(player, "chaos");
        }
    }
    
    @Override
    public Inventory getInventory() {
        return null;
    }
}
