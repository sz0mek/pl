package com.soulcraft.features;

import com.soulcraft.economy.EconomyService;
import com.soulcraft.persistence.DataStore;
import com.soulcraft.persistence.PlayerData;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.util.*;

/**
 * Complete gameplay features system with 12 features
 * All features have:
 * - Purchase system via economy
 * - Level requirements
 * - Per-player toggleable state
 * - Visual/audio feedback
 * - Configuration integration
 */
public class GameplayFeaturesService implements Listener {
    private final Plugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final Map<String, FeatureConfig> featureConfigs;
    
    // Double jump tracking
    private final Set<UUID> canDoubleJump = new HashSet<>();
    private final Map<UUID, Long> lastDoubleJump = new HashMap<>();
    
    public GameplayFeaturesService(Plugin plugin, DataStore dataStore, EconomyService economyService) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.featureConfigs = new HashMap<>();
        
        loadConfiguration();
        startPassiveFeatures();
    }
    
    /**
     * Load feature configurations from balance.yml
     */
    private void loadConfiguration() {
        File balanceFile = new File(plugin.getDataFolder(), "balance.yml");
        if (!balanceFile.exists()) {
            plugin.getLogger().warning("balance.yml not found! Using default values.");
            return;
        }
        
        FileConfiguration balance = YamlConfiguration.loadConfiguration(balanceFile);
        ConfigurationSection featuresSection = balance.getConfigurationSection("features");
        
        if (featuresSection == null) {
            plugin.getLogger().warning("No features section in balance.yml!");
            return;
        }
        
        for (String featureId : featuresSection.getKeys(false)) {
            ConfigurationSection section = featuresSection.getConfigurationSection(featureId);
            if (section == null) continue;
            
            FeatureConfig config = new FeatureConfig();
            config.id = featureId;
            config.name = section.getString("name", featureId);
            config.description = section.getString("description", "");
            config.enabled = section.getBoolean("enabled", true);
            config.soulCost = section.getInt("soul_cost", 0);
            config.levelRequired = section.getInt("level_required", 1);
            config.cooldown = section.getDouble("cooldown", 0);
            config.multiplier = section.getDouble("multiplier", 1.0);
            config.bonusSouls = section.getInt("bonus_souls", 0);
            config.radius = section.getInt("radius", 0);
            config.threshold = section.getInt("threshold", 0);
            
            featureConfigs.put(featureId, config);
        }
        
        plugin.getLogger().info("Loaded " + featureConfigs.size() + " gameplay features from configuration");
    }
    
    /**
     * Start passive feature tasks (night vision, auto feed)
     */
    private void startPassiveFeatures() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (hasFeatureActive(player, "nightvision")) {
                    if (!player.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
                        player.addPotionEffect(new PotionEffect(
                            PotionEffectType.NIGHT_VISION, 400, 0, false, false
                        ));
                    }
                }
            }
        }, 20L, 100L);
        
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (hasFeatureActive(player, "autofeed")) {
                    FeatureConfig config = featureConfigs.get("autofeed");
                    int threshold = config != null ? config.threshold : 15;
                    
                    if (player.getFoodLevel() < threshold) {
                        for (ItemStack item : player.getInventory().getContents()) {
                            if (item != null && isFood(item.getType())) {
                                item.setAmount(item.getAmount() - 1);
                                player.setFoodLevel(Math.min(20, player.getFoodLevel() + 4));
                                player.setSaturation(player.getSaturation() + 2.4f);
                                player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 0.5f, 1.0f);
                                break;
                            }
                        }
                    }
                }
            }
        }, 20L, 40L);
    }
    
    /**
     * Purchase a feature for a player
     */
    public boolean purchaseFeature(Player player, String featureId) {
        FeatureConfig config = featureConfigs.get(featureId);
        if (config == null) {
            player.sendMessage("§c§l✗ Unknown feature: " + featureId);
            return false;
        }
        
        if (!config.enabled) {
            player.sendMessage("§c§l✗ This feature is currently disabled!");
            return false;
        }
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        
        if (data.hasFeature(featureId)) {
            player.sendMessage("§e§l⚠ You already own: §f" + config.name);
            return false;
        }
        
        if (data.getLevel() < config.levelRequired) {
            player.sendMessage("§c§l✗ Level Required: §e" + config.levelRequired + " §7(You: " + data.getLevel() + ")");
            return false;
        }
        
        if (!economyService.hasEnough(player, config.soulCost)) {
            player.sendMessage("§c§l✗ Insufficient Souls! Need: §e" + config.soulCost + " §7(You have: " + economyService.getBalance(player) + ")");
            return false;
        }
        
        if (!economyService.withdraw(player, config.soulCost, "Feature Purchase: " + config.name)) {
            player.sendMessage("§c§l✗ Transaction failed!");
            return false;
        }
        
        data.setFeature(featureId, true);
        
        player.sendMessage("§a§l✓ Unlocked: §e" + config.name);
        player.sendMessage("§7" + config.description);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        player.spawnParticle(Particle.HEART, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5);
        
        return true;
    }
    
    /**
     * Check if player has feature unlocked
     */
    public boolean hasFeatureUnlocked(Player player, String featureId) {
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.hasFeature(featureId);
    }
    
    /**
     * Check if player has feature active (unlocked + enabled globally)
     */
    public boolean hasFeatureActive(Player player, String featureId) {
        FeatureConfig config = featureConfigs.get(featureId);
        if (config == null || !config.enabled) return false;
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        return data.hasFeature(featureId);
    }
    
    /**
     * Toggle feature on/off for player (if already unlocked)
     */
    public void toggleFeature(Player player, String featureId) {
        FeatureConfig config = featureConfigs.get(featureId);
        if (config == null) {
            player.sendMessage("§c§l✗ Unknown feature: " + featureId);
            return;
        }
        
        PlayerData data = dataStore.loadPlayerData(player.getUniqueId());
        boolean current = data.hasFeature(featureId);
        data.setFeature(featureId, !current);
        
        if (!current) {
            player.sendMessage("§a§l✓ Enabled: §e" + config.name);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
        } else {
            player.sendMessage("§c§l✗ Disabled: §e" + config.name);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
        }
    }
    
    public Map<String, FeatureConfig> getFeatureConfigs() {
        return featureConfigs;
    }
    
    public FeatureConfig getFeatureConfig(String featureId) {
        return featureConfigs.get(featureId);
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();
        
        if (killer == null) return;
        
        if (hasFeatureActive(killer, "autopickup")) {
            Location loc = killer.getLocation();
            for (ItemStack drop : event.getDrops()) {
                killer.getInventory().addItem(drop);
            }
            event.getDrops().clear();
            killer.playSound(killer.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.3f, 1.5f);
        }
        
        if (hasFeatureActive(killer, "moneyboost")) {
            FeatureConfig config = featureConfigs.get("moneyboost");
            int bonusSouls = config != null ? config.bonusSouls : 50;
            economyService.deposit(killer, bonusSouls, "Money Boost - Mob Kill");
        }
        
        if (hasFeatureActive(killer, "lootboost")) {
            FeatureConfig config = featureConfigs.get("lootboost");
            double multiplier = config != null ? config.multiplier : 2.0;
            
            List<ItemStack> bonusDrops = new ArrayList<>();
            for (ItemStack drop : event.getDrops()) {
                ItemStack bonus = drop.clone();
                bonus.setAmount((int) (drop.getAmount() * (multiplier - 1)));
                bonusDrops.add(bonus);
            }
            event.getDrops().addAll(bonusDrops);
            
            if (!bonusDrops.isEmpty()) {
                killer.spawnParticle(Particle.HEART, entity.getLocation(), 10);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        Material type = block.getType();
        
        if (hasFeatureActive(player, "autosmelt")) {
            Material smelted = getSmeltedType(type);
            if (smelted != null) {
                event.setDropItems(false);
                block.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(smelted, 1));
                player.giveExp(1);
                player.playSound(block.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.3f, 2.0f);
                player.spawnParticle(Particle.FLAME, block.getLocation().add(0.5, 0.5, 0.5), 5);
            }
        }
        
        if (hasFeatureActive(player, "autoreplant")) {
            if (isMatureCrop(block)) {
                Material cropType = type;
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    block.setType(cropType);
                    if (block.getBlockData() instanceof Ageable) {
                        Ageable ageable = (Ageable) block.getBlockData();
                        ageable.setAge(0);
                        block.setBlockData(ageable);
                    }
                }, 1L);
                player.spawnParticle(Particle.HEART, block.getLocation().add(0.5, 0.5, 0.5), 3);
            }
        }
        
        if (hasFeatureActive(player, "autopickup")) {
            Collection<ItemStack> drops = block.getDrops(player.getInventory().getItemInMainHand());
            event.setDropItems(false);
            for (ItemStack drop : drops) {
                player.getInventory().addItem(drop);
            }
            player.playSound(block.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.2f, 1.5f);
        }
    }
    
    @EventHandler
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }
        
        if (!hasFeatureActive(player, "doublejump")) {
            return;
        }
        
        FeatureConfig config = featureConfigs.get("doublejump");
        long cooldown = config != null ? (long) (config.cooldown * 1000) : 500;
        
        Long lastJump = lastDoubleJump.get(player.getUniqueId());
        if (lastJump != null && System.currentTimeMillis() - lastJump < cooldown) {
            event.setCancelled(true);
            return;
        }
        
        event.setCancelled(true);
        player.setAllowFlight(false);
        player.setFlying(false);
        
        player.setVelocity(player.getLocation().getDirection().multiply(1.2).setY(1.0));
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 0.5f, 1.5f);
        player.spawnParticle(Particle.CLOUD, player.getLocation(), 10, 0.3, 0.1, 0.3, 0.02);
        
        lastDoubleJump.put(player.getUniqueId(), System.currentTimeMillis());
        canDoubleJump.remove(player.getUniqueId());
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        if (!hasFeatureActive(player, "doublejump")) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        
        if (player.isOnGround() && !canDoubleJump.contains(player.getUniqueId())) {
            player.setAllowFlight(true);
            canDoubleJump.add(player.getUniqueId());
        }
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeatureActive(player, "doublejump")) {
            if (player.getGameMode() == GameMode.SURVIVAL || player.getGameMode() == GameMode.ADVENTURE) {
                player.setAllowFlight(true);
            }
        }
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        
        if (hasFeatureActive(player, "keepinventory")) {
            event.setKeepInventory(true);
            event.setKeepLevel(true);
            event.getDrops().clear();
            event.setDroppedExp(0);
            
            player.sendMessage("§a§l✓ Keep Inventory: §7Your items were saved!");
        }
        
        canDoubleJump.remove(player.getUniqueId());
    }
    
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeatureActive(player, "doublejump")) {
            if (player.getGameMode() == GameMode.SURVIVAL || player.getGameMode() == GameMode.ADVENTURE) {
                player.setAllowFlight(true);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        
        Player player = (Player) event.getEntity();
        
        if (hasFeatureActive(player, "nofalldamage")) {
            if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                event.setCancelled(true);
                player.playSound(player.getLocation(), Sound.BLOCK_WOOL_FALL, 0.5f, 0.8f);
                player.spawnParticle(Particle.CLOUD, player.getLocation(), 5, 0.3, 0.1, 0.3);
            }
        }
    }
    
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeatureActive(player, "fasteat")) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0f, 1.2f);
            player.spawnParticle(Particle.HEART, player.getLocation().add(0, 2, 0), 3);
        }
    }
    
    @EventHandler
    public void onExpChange(PlayerExpChangeEvent event) {
        Player player = event.getPlayer();
        
        if (hasFeatureActive(player, "xpboost")) {
            FeatureConfig config = featureConfigs.get("xpboost");
            double multiplier = config != null ? config.multiplier : 2.0;
            event.setAmount((int) (event.getAmount() * multiplier));
        }
    }
    
    @EventHandler
    public void onGameModeChange(PlayerGameModeChangeEvent event) {
        Player player = event.getPlayer();
        
        if (event.getNewGameMode() == GameMode.SURVIVAL || event.getNewGameMode() == GameMode.ADVENTURE) {
            if (hasFeatureActive(player, "doublejump")) {
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    player.setAllowFlight(true);
                }, 5L);
            }
        }
    }
    
    private boolean isMatureCrop(Block block) {
        if (!(block.getBlockData() instanceof Ageable)) return false;
        
        Ageable ageable = (Ageable) block.getBlockData();
        return ageable.getAge() == ageable.getMaximumAge();
    }
    
    private Material getSmeltedType(Material ore) {
        switch (ore) {
            case IRON_ORE:
            case DEEPSLATE_IRON_ORE:
                return Material.IRON_INGOT;
            case GOLD_ORE:
            case DEEPSLATE_GOLD_ORE:
            case NETHER_GOLD_ORE:
                return Material.GOLD_INGOT;
            case COPPER_ORE:
            case DEEPSLATE_COPPER_ORE:
                return Material.COPPER_INGOT;
            case ANCIENT_DEBRIS:
                return Material.NETHERITE_SCRAP;
            default:
                return null;
        }
    }
    
    private boolean isFood(Material material) {
        switch (material) {
            case BREAD:
            case COOKED_BEEF:
            case COOKED_PORKCHOP:
            case COOKED_CHICKEN:
            case COOKED_MUTTON:
            case COOKED_RABBIT:
            case COOKED_COD:
            case COOKED_SALMON:
            case APPLE:
            case GOLDEN_APPLE:
            case ENCHANTED_GOLDEN_APPLE:
            case MELON_SLICE:
            case SWEET_BERRIES:
            case GLOW_BERRIES:
            case CARROT:
            case POTATO:
            case BAKED_POTATO:
            case BEETROOT:
            case DRIED_KELP:
            case COOKIE:
            case PUMPKIN_PIE:
            case CAKE:
            case MUSHROOM_STEW:
            case RABBIT_STEW:
            case BEETROOT_SOUP:
            case SUSPICIOUS_STEW:
                return true;
            default:
                return false;
        }
    }
    
    public Map<String, Object> getAllFeatures() {
        Map<String, Object> features = new HashMap<>();
        for (Map.Entry<String, FeatureConfig> entry : featureConfigs.entrySet()) {
            features.put(entry.getKey(), entry.getValue());
        }
        return features;
    }
    
    public Object getFeature(String featureId) {
        return featureConfigs.get(featureId);
    }
    
    public boolean isFeatureEnabled(String featureId) {
        FeatureConfig config = featureConfigs.get(featureId);
        return config != null && config.enabled;
    }
    
    public void toggleFeature(String featureId, boolean enabled) {
        FeatureConfig config = featureConfigs.get(featureId);
        if (config != null) {
            config.enabled = enabled;
        }
    }
    
    public static class FeatureConfig {
        public String id;
        public String name;
        public String description;
        public boolean enabled;
        public int soulCost;
        public int levelRequired;
        public double cooldown;
        public double multiplier;
        public int bonusSouls;
        public int radius;
        public int threshold;
        
        @Override
        public String toString() {
            return "FeatureConfig{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", cost=" + soulCost +
                ", level=" + levelRequired +
                '}';
        }
    }
}
