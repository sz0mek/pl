package com.soulcraft.persistence;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Unified persistence layer with YAML storage and SQL-ready abstraction
 * Handles autosave, migrations, and error handling
 */
public class DataStore {
    private final Plugin plugin;
    private final File dataFolder;
    private final Map<String, YamlConfiguration> configCache;
    private final Map<UUID, PlayerData> playerDataCache;
    private boolean autoSaveEnabled = true;
    
    public DataStore(Plugin plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        this.configCache = new ConcurrentHashMap<>();
        this.playerDataCache = new ConcurrentHashMap<>();
        
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
        
        startAutoSave();
    }
    
    /**
     * Load player data from storage
     */
    public PlayerData loadPlayerData(UUID playerId) {
        if (playerDataCache.containsKey(playerId)) {
            return playerDataCache.get(playerId);
        }
        
        File playerFile = new File(dataFolder, playerId.toString() + ".yml");
        PlayerData data;
        
        if (playerFile.exists()) {
            try {
                YamlConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
                data = PlayerData.fromYaml(playerId, config);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error loading player data for " + playerId, e);
                data = new PlayerData(playerId);
            }
        } else {
            data = new PlayerData(playerId);
        }
        
        playerDataCache.put(playerId, data);
        return data;
    }
    
    /**
     * Save player data to storage
     */
    public void savePlayerData(UUID playerId) {
        PlayerData data = playerDataCache.get(playerId);
        if (data == null) return;
        
        File playerFile = new File(dataFolder, playerId.toString() + ".yml");
        try {
            YamlConfiguration config = new YamlConfiguration();
            data.toYaml(config);
            config.save(playerFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Error saving player data for " + playerId, e);
        }
    }
    
    /**
     * Save all cached player data
     */
    public void saveAll() {
        for (UUID playerId : playerDataCache.keySet()) {
            savePlayerData(playerId);
        }
    }
    
    /**
     * Unload player data from cache (save first)
     */
    public void unloadPlayerData(UUID playerId) {
        savePlayerData(playerId);
        playerDataCache.remove(playerId);
    }
    
    /**
     * Start autosave task (every 5 minutes)
     */
    private void startAutoSave() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            if (autoSaveEnabled) {
                saveAll();
                plugin.getLogger().info("Auto-saved " + playerDataCache.size() + " player data files");
            }
        }, 6000L, 6000L); // 5 minutes
    }
    
    /**
     * Load a configuration file
     */
    public YamlConfiguration loadConfig(String fileName) {
        if (configCache.containsKey(fileName)) {
            return configCache.get(fileName);
        }
        
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            plugin.saveResource(fileName, false);
        }
        
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        configCache.put(fileName, config);
        return config;
    }
    
    /**
     * Reload all configurations
     */
    public void reloadConfigs() {
        configCache.clear();
    }
    
    /**
     * Shutdown - save all data
     */
    public void shutdown() {
        autoSaveEnabled = false;
        saveAll();
    }
}
