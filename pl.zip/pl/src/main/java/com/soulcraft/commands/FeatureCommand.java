package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class FeatureCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;

    public FeatureCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("soulcraft.admin")) {
            sender.sendMessage("§cBrak uprawnień!");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage("§eUżycie: /feature <toggle|enable|disable> <feature_id>");
            sender.sendMessage("§7Dostępne funkcje: autopickup, doublejump, autoreplant, keepinventory, autosmelt, nightvision, nofalldamage, fasteat, autofeed, xpboost, moneyboost, lootboost");
            return true;
        }

        String action = args[0].toLowerCase();
        String featureId = args[1].toLowerCase();

        if (plugin.getFeatureManager().getFeature(featureId) == null) {
            sender.sendMessage("§cNieznana funkcja: " + featureId);
            return true;
        }

        switch (action) {
            case "toggle":
                boolean currentState = plugin.getFeatureManager().isFeatureEnabled(featureId);
                plugin.getFeatureManager().toggleFeature(featureId, !currentState);
                sender.sendMessage("§a§lFunkcja " + featureId + ": " + (!currentState ? "§aWŁĄCZONA" : "§cWYŁĄCZONA"));
                break;
            case "enable":
                plugin.getFeatureManager().toggleFeature(featureId, true);
                sender.sendMessage("§a§lFunkcja " + featureId + " WŁĄCZONA");
                break;
            case "disable":
                plugin.getFeatureManager().toggleFeature(featureId, false);
                sender.sendMessage("§c§lFunkcja " + featureId + " WYŁĄCZONA");
                break;
            default:
                sender.sendMessage("§cNieznana akcja! Użyj: toggle, enable, lub disable");
                break;
        }

        return true;
    }
}
