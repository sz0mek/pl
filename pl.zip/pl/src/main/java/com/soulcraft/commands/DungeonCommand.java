package com.soulcraft.commands;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.dungeons.DungeonGUI;
import com.soulcraft.dungeons.DungeonService;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DungeonCommand implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final DungeonGUI dungeonGUI;
    
    public DungeonCommand(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        this.dungeonGUI = new DungeonGUI(plugin.getDungeonService(), plugin.getDataStore());
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cThis command is only available for players!");
            return true;
        }
        
        if (args.length == 0) {
            dungeonGUI.openDungeonSelection(player);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "easy":
            case "medium":
            case "hard":
            case "nightmare":
            case "chaos":
                plugin.getDungeonService().startDungeon(player, subCommand);
                break;
                
            case "leave":
                if (plugin.getDungeonService().isInDungeon(player.getUniqueId())) {
                    plugin.getDungeonService().leaveDungeon(player);
                } else {
                    player.sendMessage("§c§lYou are not in a dungeon!");
                }
                break;
                
            case "party":
                handlePartyCommand(player, args);
                break;
                
            case "gui":
                dungeonGUI.openDungeonSelection(player);
                break;
                
            default:
                player.sendMessage("§5§l✦ Dungeon Commands ✦");
                player.sendMessage("§e/dungeon §7- Open dungeon GUI");
                player.sendMessage("§e/dungeon <easy|medium|hard|nightmare|chaos> §7- Enter dungeon");
                player.sendMessage("§e/dungeon leave §7- Leave current dungeon");
                player.sendMessage("§e/dungeon party create §7- Create a party");
                player.sendMessage("§e/dungeon party invite <player> §7- Invite player to party");
                player.sendMessage("§e/dungeon party start <difficulty> §7- Start party dungeon");
                break;
        }
        
        return true;
    }
    
    private void handlePartyCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§c§lUsage: /dungeon party <create|invite|start>");
            return;
        }
        
        String partyAction = args[1].toLowerCase();
        DungeonService service = plugin.getDungeonService();
        
        switch (partyAction) {
            case "create":
                DungeonService.DungeonParty party = service.createParty(player);
                player.sendMessage("§a§lParty created! Party ID: §e" + party.id.substring(0, 8));
                player.sendMessage("§7Use §e/dungeon party invite <player>§7 to add members");
                break;
                
            case "invite":
                if (args.length < 3) {
                    player.sendMessage("§c§lUsage: /dungeon party invite <player>");
                    return;
                }
                player.sendMessage("§c§lParty invites not yet implemented - use GUI");
                break;
                
            case "start":
                if (args.length < 3) {
                    player.sendMessage("§c§lUsage: /dungeon party start <difficulty>");
                    return;
                }
                player.sendMessage("§c§lParty dungeons not yet fully implemented");
                break;
                
            default:
                player.sendMessage("§c§lInvalid party command!");
                break;
        }
    }
}
