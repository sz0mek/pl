// UpgradeGUI.java
package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class UpgradeGUI implements Listener {
    private final SoulCraftPlugin plugin;
    private final List<UUID> activePlayers = new ArrayList<>();

    public UpgradeGUI(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void openGUI(Player player) {
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held == null || !held.getType().toString().contains("_SWORD")) {
            player.sendMessage("§cMusisz trzymać miecz w ręce!");
            return;
        }
        Inventory gui = Bukkit.createInventory(null, 27, "§6Ulepsz Miecz");

        activePlayers.add(player.getUniqueId());

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, filler);
        }

        ItemStack soulDrop = new ItemStack(Material.SOUL_SAND);
        ItemMeta soulMeta = soulDrop.getItemMeta();
        soulMeta.setDisplayName("§5Większy Drop Dusz");
        soulMeta.setLore(Arrays.asList(
                "§7Lvl 1: 7% (50 dusz)",
                "§7Lvl 2: 10% (100 dusz)",
                "§7Lvl 3: 12% (200 dusz)",
                "§7Lvl 4: 15% (500 dusz)",
                "§7Lvl 5: 20% (1000 dusz)"));
        soulDrop.setItemMeta(soulMeta);
        gui.setItem(10, soulDrop);

        ItemStack damage = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta damageMeta = damage.getItemMeta();
        damageMeta.setDisplayName("§cWiększy Damage");
        damageMeta.setLore(Arrays.asList(
                "§7Lvl 1: +10% (20 dusz)",
                "§7Lvl 2: +20% (50 dusz)",
                "§7Lvl 3: +40% (200 dusz)",
                "§7Lvl 4: +60% (500 dusz)",
                "§7Lvl 5: +100% (2000 dusz)"));
        damage.setItemMeta(damageMeta);
        gui.setItem(13, damage);

        ItemStack health = new ItemStack(Material.HEART_OF_THE_SEA);
        ItemMeta healthMeta = health.getItemMeta();
        healthMeta.setDisplayName("§dUlepszenie Życia");
        healthMeta.setLore(Arrays.asList(
                "§7Lvl 1: +1 serce (100 dusz)",
                "§7Lvl 2: +2 serca (300 dusz)",
                "§7Lvl 3: +3 serca (600 dusz)",
                "§7Lvl 4: +4 serca (1000 dusz)",
                "§7Lvl 5: +5 serc (2000 dusz)"));
        health.setItemMeta(healthMeta);
        gui.setItem(16, health);

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;
        if (!activePlayers.contains(player.getUniqueId()))
            return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE)
            return;

        ItemStack sword = player.getInventory().getItemInMainHand();
        if (sword == null || !sword.getType().toString().contains("_SWORD")) {
            player.sendMessage("§cMusisz trzymać miecz w ręce!");
            player.closeInventory();
            activePlayers.remove(player.getUniqueId());
            return;
        }
        UUID uuid = player.getUniqueId();
        long souls = plugin.getEconomyService().getBalance(uuid);

        if (clicked.getType() == Material.SOUL_SAND) {
            int[] costs = { 50, 100, 200, 500, 1000 };
            int currentLevel = getUpgradeLevel(sword, "§5Większy Drop Dusz");
            if (currentLevel >= 5) {
                player.sendMessage("§cMaksymalny poziom ulepszenia!");
                return;
            }
            int cost = costs[currentLevel];
            if (souls >= cost) {
                plugin.getEconomyService().withdraw(uuid, cost, "Sword soul drop upgrade");
                updateLore(sword, "§5Większy Drop Dusz: Lvl " + (currentLevel + 1), "§5Większy Drop Dusz");
                player.sendMessage("§aUlepszono drop dusz do poziomu " + (currentLevel + 1) + "!");
            } else {
                player.sendMessage("§cNie masz wystarczająco dusz!");
            }
        } else if (clicked.getType() == Material.DIAMOND_SWORD) {
            int[] costs = { 20, 50, 200, 500, 2000 };
            int currentLevel = getUpgradeLevel(sword, "§cWiększy Damage");
            if (currentLevel >= 5) {
                player.sendMessage("§cMaksymalny poziom ulepszenia!");
                return;
            }
            int cost = costs[currentLevel];
            if (souls >= cost) {
                plugin.getEconomyService().withdraw(uuid, cost, "Sword damage upgrade");
                updateLore(sword, "§cWiększy Damage: Lvl " + (currentLevel + 1), "§cWiększy Damage");
                player.sendMessage("§aUlepszono obrażenia do poziomu " + (currentLevel + 1) + "!");
            } else {
                player.sendMessage("§cNie masz wystarczająco dusz!");
            }
        } else if (clicked.getType() == Material.HEART_OF_THE_SEA) {
            int[] costs = { 100, 300, 600, 1000, 2000 };
            int currentLevel = plugin.getConfig().getInt("players." + uuid.toString() + ".healthLevel", 0);
            if (currentLevel >= 5) {
                player.sendMessage("§cMaksymalny poziom ulepszenia!");
                return;
            }
            int cost = costs[currentLevel];
            if (souls >= cost) {
                plugin.getEconomyService().withdraw(uuid, cost, "Health upgrade");
                int newLevel = currentLevel + 1;
                plugin.getConfig().set("players." + uuid.toString() + ".healthLevel", newLevel);
                plugin.saveConfig();
                player.setMaxHealth(20 + newLevel * 2);
                player.setHealth(player.getMaxHealth());
                player.sendMessage("§aUlepszono życie do poziomu " + newLevel + " (+ " + newLevel + " serca)!");
            } else {
                player.sendMessage("§cNie masz wystarczająco dusz!");
            }
        }
        player.closeInventory();
        activePlayers.remove(player.getUniqueId());
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player))
            return;
        if (!activePlayers.contains(player.getUniqueId()))
            return;
        event.setCancelled(true);
    }

    private int getUpgradeLevel(ItemStack item, String type) {
        if (!item.hasItemMeta() || !item.getItemMeta().hasLore())
            return 0;
        List<String> lore = item.getItemMeta().getLore();
        for (String line : lore) {
            if (line.startsWith(type + ": Lvl ")) {
                return Integer.parseInt(line.split("Lvl ")[1]);
            }
        }
        return 0;
    }

    private void updateLore(ItemStack item, String newLine, String type) {
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.removeIf(l -> l.startsWith(type + ": Lvl "));
        lore.add(newLine);
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && event.getEntity() instanceof Player) {
            ItemStack sword = player.getInventory().getItemInMainHand();
            if (sword != null && sword.getType().toString().contains("_SWORD") && sword.hasItemMeta()
                    && sword.getItemMeta().hasLore()) {
                int level = getUpgradeLevel(sword, "§cWiększy Damage");
                double[] boosts = { 1.0, 1.1, 1.2, 1.4, 1.6, 2.0 };
                if (level < boosts.length) {
                    event.setDamage(event.getDamage() * boosts[level]);
                }
            }
        }
    }
}
