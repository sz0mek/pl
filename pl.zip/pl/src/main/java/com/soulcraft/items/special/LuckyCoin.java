package com.soulcraft.items.special;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;
import java.util.Random;

public class LuckyCoin extends CustomItem {
    private final Random random = new Random();

    public LuckyCoin(SoulCraftPlugin plugin) {
        super(
            "lucky_coin",
            "§6§lSzczęśliwa Moneta",
            Material.GOLD_NUGGET,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §6Magiczna Moneta §7│",
                "§7│ §fEfekt:           §7│",
                "§7│ §aLosowa nagroda  §7│",
                "§7│ §e50% szansa      §7│",
                "§7│ §6Duży jackpot!   §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §6Rzut monetą",
                "§d⚔ Model: 5002"
            ),
            5002
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            int roll = random.nextInt(100);
            
            if (roll < 50) {
                // Win
                int souls = 100 + random.nextInt(400);
                ((SoulCraftPlugin) event.getPlayer().getServer().getPluginManager().getPlugin("SoulCraftPlugin"))
                    .getEconomyService().deposit(player.getUniqueId(), souls, "Lucky coin bonus");
                
                player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 1200, 2));
                player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation(), 30);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
                player.sendMessage("§6§l✦ WYGRANA! +" + souls + " dusz!");
            } else {
                // Lose
                player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 20);
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
                player.sendMessage("§c§l✖ Przegrana! Spróbuj ponownie!");
            }
            
            if (event.getItem().getAmount() > 1) {
                event.getItem().setAmount(event.getItem().getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }
}
