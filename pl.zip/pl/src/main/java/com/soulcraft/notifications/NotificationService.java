package com.soulcraft.notifications;

import org.bukkit.Bukkit;

/**
 * Simple notification service for broadcasting messages
 */
public class NotificationService {
    
    /**
     * Broadcast message to all players
     */
    public void broadcast(String message) {
        Bukkit.broadcastMessage(message);
    }
}
