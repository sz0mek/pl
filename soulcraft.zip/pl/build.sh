#!/bin/bash
# Build script for SoulCraft Minecraft Plugin

echo "🎮 Building SoulCraft RPG Plugin..."

# Use system-installed Java and Maven (from java-graalvm22.3 module)
echo "Java Version:"
java -version 2>&1 | head -1

echo ""
echo "Maven Version:"
mvn -version 2>&1 | head -1

echo ""
echo "🔨 Building plugin with Maven..."
mvn clean package -DskipTests

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build successful!"
    echo "📦 Plugin JAR: target/SoulCraftPlugin-1.0.jar"
    ls -lh target/*.jar 2>/dev/null || echo "JAR file location: target/SoulCraftPlugin-1.0.jar"
else
    echo ""
    echo "❌ Build failed! Check errors above."
    exit 1
fi
