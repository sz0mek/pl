package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SpeedBurst extends Ability {
    private final SoulCraftPlugin plugin;
    
    public SpeedBurst(SoulCraftPlugin plugin) {
        super("speed_burst", "§e§lWybuch Prędkości", "§7Prędkość IV przez 5 sekund", 30, "svip", 10000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 3));
        player.sendMessage("§e§l⚡ Aktywowano Wybuch Prędkości!");
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
