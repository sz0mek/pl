package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.Player;

public class Lucky extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Lucky(SoulCraftPlugin plugin) {
        super("lucky", "§6§lSzczęście", "§750% więcej dropów ze wszystkiego", 0, "soulgod", 30000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        // Passive ability - affects loot drops
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
