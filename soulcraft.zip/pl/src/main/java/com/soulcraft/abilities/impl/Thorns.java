package com.soulcraft.abilities.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.abilities.Ability;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class Thorns extends Ability {
    private final SoulCraftPlugin plugin;
    
    public Thorns(SoulCraftPlugin plugin) {
        super("thorns", "§8§lKolce", "§7Odbij 40% otrzymanych obrażeń", 0, "soulgod", 20000);
        this.plugin = plugin;
    }
    
    @Override
    public void activate(Player player, Object... args) {
        if (args.length > 1 && args[0] instanceof Double && args[1] instanceof LivingEntity) {
            double damage = (Double) args[0];
            LivingEntity attacker = (LivingEntity) args[1];
            double reflect = damage * 0.4;
            attacker.damage(reflect, player);
        }
    }
    
    @Override
    public boolean canUse(Player player) {
        return true;
    }
}
