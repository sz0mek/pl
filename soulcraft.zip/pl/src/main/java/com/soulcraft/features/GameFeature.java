package com.soulcraft.features;

import org.bukkit.entity.Player;

public abstract class GameFeature {
    private final String id;
    private final String displayName;
    private final String description;
    private boolean enabled;

    public GameFeature(String id, String displayName, String description) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.enabled = true;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public boolean hasPermission(Player player) {
        return player.hasPermission("soulcraft.feature." + id);
    }

    public boolean canUse(Player player) {
        return enabled && hasPermission(player);
    }

    // Lifecycle methods
    public abstract void onEnable();
    public abstract void onDisable();
}
