package com.soulcraft.core;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.Collection;

public class NotificationService {
    private static NotificationService instance;

    private NotificationService() {}

    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    public void broadcast(String message) {
        Bukkit.broadcastMessage(message);
    }

    public void broadcastTitle(String title, String subtitle) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle(title, subtitle, 10, 70, 20);
        }
    }

    public void broadcastActionBar(String message) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, 
                new TextComponent(message));
        }
    }

    public void broadcastSound(Sound sound, float volume, float pitch) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
    }

    public void broadcastFull(String chatMessage, String title, String subtitle, 
                             Sound sound, float volume, float pitch) {
        if (chatMessage != null && !chatMessage.isEmpty()) {
            broadcast(chatMessage);
        }
        if (title != null && !title.isEmpty()) {
            broadcastTitle(title, subtitle != null ? subtitle : "");
        }
        if (sound != null) {
            broadcastSound(sound, volume, pitch);
        }
    }

    public void sendTitle(Player player, String title, String subtitle) {
        player.sendTitle(title, subtitle, 10, 70, 20);
    }

    public void sendTitle(Player player, String title, String subtitle, 
                         int fadeIn, int stay, int fadeOut) {
        player.sendTitle(title, subtitle, fadeIn, stay, fadeOut);
    }

    public void sendActionBar(Player player, String message) {
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, 
            new TextComponent(message));
    }

    public void sendSound(Player player, Sound sound, float volume, float pitch) {
        player.playSound(player.getLocation(), sound, volume, pitch);
    }

    public void sendFull(Player player, String message, String title, String subtitle,
                        Sound sound, float volume, float pitch) {
        if (message != null && !message.isEmpty()) {
            player.sendMessage(message);
        }
        if (title != null && !title.isEmpty()) {
            sendTitle(player, title, subtitle != null ? subtitle : "");
        }
        if (sound != null) {
            sendSound(player, sound, volume, pitch);
        }
    }

    public void announceBossSpawn(String bossName, int x, int y, int z, String worldName) {
        String message = String.format(
            "§5§l✦✦✦ BOSS POJAWIŁ SIĘ! ✦✦✦\n" +
            "§7Boss: §d%s\n" +
            "§7Lokalizacja: §e%d, %d, %d §7w świecie §e%s\n" +
            "§5§l✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦",
            bossName, x, y, z, worldName
        );
        
        broadcastFull(
            message,
            "§5§l⚔ BOSS ⚔",
            "§f" + bossName + " §7się przebudził!",
            Sound.ENTITY_ENDER_DRAGON_GROWL,
            1.0f,
            0.8f
        );
    }

    public void announceBossDeath(String bossName, String killerName) {
        String message = String.format(
            "§5§l✦✦✦ BOSS POKONANY! ✦✦✦\n" +
            "§6%s §7pokonał bossa §d%s§7!\n" +
            "§5§l✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦",
            killerName, bossName
        );
        
        broadcastFull(
            message,
            "§a§l✓ ZWYCIĘSTWO ✓",
            "§f" + bossName + " §7został pokonany!",
            Sound.UI_TOAST_CHALLENGE_COMPLETE,
            1.0f,
            1.0f
        );
    }

    public void announceEvent(String eventName, String description) {
        String message = String.format(
            "§6§l★ EVENT: %s ★\n" +
            "§7%s",
            eventName, description
        );
        
        broadcastFull(
            message,
            "§6§l★ EVENT ★",
            eventName,
            Sound.BLOCK_BELL_USE,
            1.0f,
            1.2f
        );
    }

    public void notifyPlayers(Collection<Player> players, String message, Sound sound) {
        for (Player player : players) {
            player.sendMessage(message);
            if (sound != null) {
                sendSound(player, sound, 1.0f, 1.0f);
            }
        }
    }
}
