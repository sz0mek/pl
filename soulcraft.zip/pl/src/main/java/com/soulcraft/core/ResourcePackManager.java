package com.soulcraft.core;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

public class ResourcePackManager implements Listener {
    private static ResourcePackManager instance;
    private final SoulCraftPlugin plugin;
    private final ConfigService config;

    private ResourcePackManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
        this.config = ConfigService.getInstance(plugin);
    }

    public static ResourcePackManager getInstance(SoulCraftPlugin plugin) {
        if (instance == null) {
            instance = new ResourcePackManager(plugin);
        }
        return instance;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        boolean enabled = config.getBoolean("resourcepack.enabled", false);
        if (!enabled) {
            return;
        }

        String url = config.getString("resourcepack.url", "");
        boolean required = config.getBoolean("resourcepack.required", true);
        String prompt = config.getString("resourcepack.prompt", "§dZainstaluj resource pack aby uzyskać pełne doświadczenie!");

        if (url.isEmpty()) {
            return;
        }

        // Spigot 1.21 setResourcePack method
        player.setResourcePack(url, (byte[]) null, prompt, required);

        String joinMessage = config.getString("resourcepack.join_message", 
                "§5§l✦ SoulCraft ✦\n§7Pobieranie resource packa...\n§ePoczekaj chwilę!");
        player.sendMessage(joinMessage);
    }

    @EventHandler
    public void onResourcePackStatus(PlayerResourcePackStatusEvent event) {
        Player player = event.getPlayer();
        PlayerResourcePackStatusEvent.Status status = event.getStatus();

        boolean required = config.getBoolean("resourcepack.required", true);
        String kickMessage = config.getString("resourcepack.kick_message",
                "§c§l✖ Resource Pack Wymagany!\n\n§7Musisz zaakceptować resource pack\n§7aby grać na tym serwerze!");

        switch (status) {
            case SUCCESSFULLY_LOADED:
                String successMsg = config.getString("resourcepack.success_message",
                        "§a§l✓ Resource pack załadowany pomyślnie!\n§7Miłej gry!");
                player.sendMessage(successMsg);
                break;

            case DECLINED:
                if (required) {
                    player.kickPlayer(kickMessage);
                } else {
                    String declineMsg = config.getString("resourcepack.decline_message",
                            "§e⚠ Resource pack odrzucony.\n§7Niektóre funkcje mogą nie działać poprawnie.");
                    player.sendMessage(declineMsg);
                }
                break;

            case FAILED_DOWNLOAD:
                String failMsg = config.getString("resourcepack.fail_message",
                        "§c✖ Błąd pobierania resource packa!\n§7Spróbuj dołączyć ponownie.");
                if (required) {
                    player.kickPlayer(failMsg);
                } else {
                    player.sendMessage(failMsg);
                }
                break;

            case ACCEPTED:
                String acceptMsg = config.getString("resourcepack.accept_message",
                        "§e⌛ Pobieranie resource packa...");
                player.sendMessage(acceptMsg);
                break;
        }
    }

    public void setResourcePack(String url, boolean required) {
        config.set("resourcepack.url", url);
        config.set("resourcepack.required", required);
        config.set("resourcepack.enabled", true);
    }
    
    public void setResourcePackPrompt(String prompt) {
        config.set("resourcepack.prompt", prompt);
    }

    public void disable() {
        config.set("resourcepack.enabled", false);
    }

    public boolean isEnabled() {
        return config.getBoolean("resourcepack.enabled", false);
    }

    public String getUrl() {
        return config.getString("resourcepack.url", "");
    }
}
