package com.soulcraft.leaderboards;

import com.soulcraft.SoulCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import java.util.*;
import java.util.stream.Collectors;

public class LeaderboardManager implements Listener {
    private final SoulCraftPlugin plugin;
    private final Map<UUID, Integer> bossKills = new HashMap<>();
    private final Map<UUID, Long> bossDamage = new HashMap<>();
    private final Map<UUID, Integer> pvpKills = new HashMap<>();
    private final Map<UUID, Integer> dungeonsCompleted = new HashMap<>();
    
    public LeaderboardManager(SoulCraftPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void addBossKill(Player player) {
        bossKills.merge(player.getUniqueId(), 1, Integer::sum);
    }
    
    public void addBossDamage(Player player, long damage) {
        bossDamage.merge(player.getUniqueId(), damage, Long::sum);
    }
    
    public void addPvPKill(Player player) {
        pvpKills.merge(player.getUniqueId(), 1, Integer::sum);
    }
    
    public void addDungeonCompletion(Player player) {
        dungeonsCompleted.merge(player.getUniqueId(), 1, Integer::sum);
    }
    
    public List<Map.Entry<UUID, Integer>> getTopBossKills(int limit) {
        return bossKills.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toList());
    }
    
    public List<Map.Entry<UUID, Long>> getTopBossDamage(int limit) {
        return bossDamage.entrySet().stream()
            .sorted(Map.Entry.<UUID, Long>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toList());
    }
    
    public List<Map.Entry<UUID, Integer>> getTopPvP(int limit) {
        return pvpKills.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toList());
    }
    
    public List<Map.Entry<UUID, Integer>> getTopDungeons(int limit) {
        return dungeonsCompleted.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .limit(limit)
            .collect(Collectors.toList());
    }
}
