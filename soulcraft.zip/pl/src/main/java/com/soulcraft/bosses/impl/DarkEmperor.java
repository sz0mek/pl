package com.soulcraft.bosses.impl;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.bosses.CustomBoss;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class DarkEmperor extends CustomBoss {
    private final SoulCraftPlugin plugin;

    public DarkEmperor(SoulCraftPlugin plugin) {
        super(
            "dark_emperor",
            "§4§l✦ MROCZNY IMPERATOR ✦",
            EntityType.WITHER,
            1200.0,
            25.0,
            15000
        );
        this.plugin = plugin;
    }

    @Override
    public void onSpawn(LivingEntity boss) {
        boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        boss.getWorld().spawnParticle(Particle.EXPLOSION, boss.getLocation(), 300, 5, 5, 5);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_WITHER_SPAWN, 2.0f, 0.5f);
        
        // Epic announcement
        plugin.getNotificationService().broadcast("§4§l§m━━━━━━━━━━━━━━━━━━━━━");
        plugin.getNotificationService().broadcast("§c§l  ⚠ MROCZNY IMPERATOR ZJAWIŁ SIĘ! ⚠");
        plugin.getNotificationService().broadcast("§4§l§m━━━━━━━━━━━━━━━━━━━━━");
    }

    @Override
    public void onTick(LivingEntity boss) {
        // Dark aura
        if (boss.getTicksLived() % 5 == 0) {
            boss.getWorld().spawnParticle(Particle.SMOKE, boss.getLocation().add(0, 2, 0), 20, 2, 2, 2);
            boss.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, boss.getLocation().add(0, 1, 0), 10, 1, 1, 1);
        }
        
        // Area damage aura
        if (boss.getTicksLived() % 60 == 0) {
            boss.getNearbyEntities(8, 8, 8).forEach(entity -> {
                if (entity instanceof Player player) {
                    player.damage(8.0, boss);
                    player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 2));
                    player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1));
                    boss.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 30);
                }
            });
            boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_WITHER_SHOOT, 1.5f, 0.5f);
        }
        
        // Summon minions
        if (boss.getTicksLived() % 300 == 0) {
            for (int i = 0; i < 3; i++) {
                boss.getWorld().spawnEntity(
                    boss.getLocation().add(Math.random() * 4 - 2, 0, Math.random() * 4 - 2),
                    EntityType.WITHER_SKELETON
                );
            }
            boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ZOMBIE_VILLAGER_CONVERTED, 1.0f, 0.7f);
        }
        
        // Enrage at low health
        if (boss.getHealth() < getMaxHealth() * 0.25) {
            boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 5, false, false));
            boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2, false, false));
            boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 4, false, false));
        }
    }

    @Override
    public void onDeath(LivingEntity boss, Player killer) {
        // Epic death
        boss.getWorld().spawnParticle(Particle.EXPLOSION, boss.getLocation(), 1000, 10, 10, 10);
        boss.getWorld().createExplosion(boss.getLocation(), 0f, false, false);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_WITHER_DEATH, 2.0f, 0.3f);
        
        // Epic rewards
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("dark_staff", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("eternal_chestplate", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("shadow_helmet", 1)
        );
        boss.getWorld().dropItemNaturally(
            boss.getLocation(),
            plugin.getCustomItemRegistry().createItem("experience_book", 5)
        );
        
        // Epic announcement
        plugin.getNotificationService().broadcast("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
        plugin.getNotificationService().broadcast("§e§l  ★ IMPERATOR POKONANY PRZEZ " + killer.getName() + "! ★");
        plugin.getNotificationService().broadcast("§6§l§m━━━━━━━━━━━━━━━━━━━━━");
    }

    @Override
    public void onAttack(LivingEntity boss, Entity target) {
        if (target instanceof Player player) {
            // Emperor's curse
            player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 200, 3));
            player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 200, 2));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 2));
            boss.getWorld().playSound(target.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0f, 0.5f);
            boss.getWorld().spawnParticle(Particle.SMOKE, target.getLocation(), 50, 1, 1, 1);
        }
    }
}
