package com.soulcraft.items.special;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class SoulCompass extends CustomItem {
    private final SoulCraftPlugin plugin;

    public SoulCompass(SoulCraftPlugin plugin) {
        super(
            "soul_compass",
            "§5§lKompas Dusz",
            Material.COMPASS,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §5Duchowy Kompas  §7│",
                "§7│ §fZdolność:        §7│",
                "§7│ §dWskazuje        §7│",
                "§7│ §dnajbliższego    §7│",
                "§7│ §dgracza          §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Użycie: §dLokalizowanie graczy",
                "§d⚔ Model: 5004"
            ),
            5004
        );
        this.plugin = plugin;
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        if (event.getAction().name().contains("RIGHT")) {
            event.setCancelled(true);
            
            Player nearest = null;
            double minDistance = Double.MAX_VALUE;
            
            for (Player online : player.getServer().getOnlinePlayers()) {
                if (online.equals(player) || !online.getWorld().equals(player.getWorld())) {
                    continue;
                }
                
                double distance = player.getLocation().distance(online.getLocation());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = online;
                }
            }
            
            if (nearest != null) {
                player.setCompassTarget(nearest.getLocation());
                player.sendMessage(String.format(
                    "§5§l✦ Kompas wskazuje: §f%s §7(%.1fm)",
                    nearest.getName(),
                    minDistance
                ));
            } else {
                player.sendMessage("§c§l✖ Brak graczy w pobliżu!");
            }
        }
    }
}
