package com.soulcraft.items;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public abstract class CustomItem {
    private final String id;
    private final String displayName;
    private final Material material;
    private final List<String> lore;
    private final int customModelData;

    public CustomItem(String id, String displayName, Material material, List<String> lore, int customModelData) {
        this.id = id;
        this.displayName = displayName;
        this.material = material;
        this.lore = lore;
        this.customModelData = customModelData;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getMaterial() {
        return material;
    }

    public List<String> getLore() {
        return lore;
    }

    public int getCustomModelData() {
        return customModelData;
    }

    public ItemStack create(int amount) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(displayName);
            meta.setLore(lore);
            meta.setCustomModelData(customModelData);
            item.setItemMeta(meta);
        }
        
        return item;
    }

    public boolean isThisItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName() || !meta.getDisplayName().equals(displayName)) {
            return false;
        }
        
        return item.getType() == material && 
               meta.hasCustomModelData() && 
               meta.getCustomModelData() == customModelData;
    }

    public abstract void onUse(Player player, PlayerInteractEvent event);
    
    public void onKill(Player killer, org.bukkit.entity.LivingEntity killed) {
        // Override if needed
    }
    
    public void onHit(Player attacker, org.bukkit.entity.Entity target) {
        // Override if needed
    }
}
