package com.soulcraft.items.armor;

import com.soulcraft.SoulCraftPlugin;
import com.soulcraft.items.CustomItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Arrays;

public class SoulBoots extends CustomItem {
    public SoulBoots(SoulCraftPlugin plugin) {
        super(
            "soul_boots",
            "§b§lButy Dusz",
            Material.NETHERITE_BOOTS,
            Arrays.asList(
                "§7╭──────────────────╮",
                "§7│ §bDuchowe Obuwie  §7│",
                "§7│ §fBonusy:          §7│",
                "§7│ §bChodzenie po    §7│",
                "§7│ §bwodzie           §7│",
                "§7│ §a+12 Ochrony     §7│",
                "§7╰──────────────────╯",
                "",
                "§5✦ Pasywne: §bLewitacja nad wodą",
                "§d⚔ Model: 2004"
            ),
            2004
        );
    }

    @Override
    public void onUse(Player player, PlayerInteractEvent event) {
        // Water walking handled elsewhere
    }
}
