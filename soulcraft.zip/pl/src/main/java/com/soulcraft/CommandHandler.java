package com.soulcraft;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CommandHandler implements CommandExecutor {
    private final SoulCraftPlugin plugin;
    private final RankManager rankManager;
    private final MarketManager marketManager;
    private final ShopManager shopManager;
    private final HomeManager homeManager;
    private final BossManager bossManager;
    private final NPCManager npcManager;
    private final WarpManager warpManager;

    public CommandHandler(SoulCraftPlugin plugin, RankManager rankManager, MarketManager marketManager,
            ShopManager shopManager, HomeManager homeManager, BossManager bossManager,
            NPCManager npcManager, WarpManager warpManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
        this.marketManager = marketManager;
        this.shopManager = shopManager;
        this.homeManager = homeManager;
        this.bossManager = bossManager;
        this.npcManager = npcManager;
        this.warpManager = warpManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmdName = command.getName().toLowerCase();

        // NOWA KOMENDA WARP
        if (cmdName.equals("warp")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            warpManager.openMainWarpGUI(player);
            return true;
        }

        // OP-only commands
        if (cmdName.equals("dodajhajs") || cmdName.equals("usunhajs") || cmdName.equals("zombie")
                || cmdName.equals("event") || cmdName.equals("dajrange") || cmdName.equals("dajkrysztal")
                || cmdName.equals("ustawboos") || cmdName.equals("startboos") || cmdName.equals("spawnnpc")
                || cmdName.equals("dodajczarnamateria")) {

            if (!sender.hasPermission("soulcraft.op"))
                return false;
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy z permisją OP!");
                return true;
            }
            Player player = (Player) sender;

            if (cmdName.equals("dodajhajs") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                if (target != null) {
                    try {
                        double amount = Double.parseDouble(args[1]);
                        plugin.getEconomyService().deposit(target.getUniqueId(), amount, "Admin give command");
                        sender.sendMessage("§aDodano " + amount + " hajsu dla " + args[0]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cKwota musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cGracz nie jest online!");
                }
                return true;
            }

            if (cmdName.equals("usunhajs") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                if (target != null) {
                    try {
                        double amount = Double.parseDouble(args[1]);
                        plugin.getEconomyService().withdraw(target.getUniqueId(), amount, "Admin remove command");
                        sender.sendMessage("§aUsunięto " + amount + " hajsu dla " + args[0]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cKwota musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cGracz nie jest online!");
                }
                return true;
            }

            if (cmdName.equals("zombie")) {
                // Spawn special zombie at player location
                plugin.getZombieManager().spawnSpecialZombie(player.getLocation());
                player.sendMessage("§5Przywołano specjalnego zombie!");
                return true;
            }

            if (cmdName.equals("event")) {
                // Trigger soul crystal event
                plugin.getSoulManager().triggerSoulCrystalEvent(player.getLocation());
                player.sendMessage("§5Event kryształu dusz został uruchomiony!");
                return true;
            }

            if (cmdName.equals("dajrange") && args.length >= 2) {
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§cGracz nie jest online!");
                    return true;
                }
                String rank = args[1].toLowerCase();
                long duration = 0;
                if (args.length == 3) {
                    String time = args[2].toLowerCase();
                    try {
                        if (time.endsWith("m"))
                            duration = Long.parseLong(time.replace("m", "")) * 60;
                        else if (time.endsWith("h"))
                            duration = Long.parseLong(time.replace("h", "")) * 60 * 60;
                        else if (time.endsWith("d"))
                            duration = Long.parseLong(time.replace("d", "")) * 60 * 60 * 24;
                        else if (time.equals("na zawsze"))
                            duration = -1;
                    } catch (NumberFormatException e) {
                        player.sendMessage("§cNieprawidłowy czas!");
                        return true;
                    }
                }
                if (rankManager.isValidRank(rank)) {
                    rankManager.setRank(target, rank, duration);
                    player.sendMessage("§aNadano rangę " + rank + " graczowi " + target.getName()
                            + (duration > 0 ? " na " + (duration / 60) + " minut" : ""));
                } else {
                    player.sendMessage("§cNieprawidłowa ranga!");
                }
                return true;
            }

            if (cmdName.equals("dajkrysztal") && args.length == 3) {
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§cGracz nie jest online!");
                    return true;
                }
                int level;
                int amount;
                try {
                    level = Integer.parseInt(args[1]);
                    amount = Integer.parseInt(args[2]);
                    if (level < 1 || level > 5 || amount < 1) {
                        player.sendMessage("§cPoziom musi być od 1 do 5, a ilość większa od 0!");
                        return true;
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("§cPoziom i ilość muszą być liczbami!");
                    return true;
                }
                ItemStack crystal = createSoulCrystal(level);
                crystal.setAmount(amount);
                target.getInventory().addItem(crystal);
                player.sendMessage(
                        "§aDano " + amount + " kryształów dusz (lvl " + level + ") graczowi " + target.getName());
                return true;
            }

            if (cmdName.equals("ustawboos")) {
                bossManager.setBossSpawn(player);
                player.sendMessage("§aUstawiono spawn bossa!");
                return true;
            }

            if (cmdName.equals("startboos")) {
                bossManager.spawnBoss(player);
                player.sendMessage("§aRozpoczęto bossa!");
                return true;
            }

            if (cmdName.equals("spawnnpc")) {
                int type = 1; // default
                if (args.length > 0) {
                    try {
                        type = Integer.parseInt(args[0]);
                    } catch (NumberFormatException e) {
                        player.sendMessage("§cTyp musi być liczbą (1 lub 2)!");
                        return true;
                    }
                }
                npcManager.spawnNPC(player, type);
                return true;
            }

            if (cmdName.equals("dodajczarnamateria") && args.length == 2) {
                Player target = plugin.getServer().getPlayer(args[0]);
                String targetUUID = null;
                if (target != null) {
                    targetUUID = target.getUniqueId().toString();
                } else {
                    // Try to find offline player UUID by name
                    for (String uuid : plugin.getConfig().getConfigurationSection("players") != null
                            ? plugin.getConfig().getConfigurationSection("players").getKeys(false)
                            : new java.util.HashSet<String>()) {
                        if (args[0].equals(plugin.getConfig().getString("players." + uuid + ".name"))) {
                            targetUUID = uuid;
                            break;
                        }
                    }
                }

                if (targetUUID != null) {
                    try {
                        int amount = Integer.parseInt(args[1]);
                        plugin.getEconomyService().addBlackMatter(java.util.UUID.fromString(targetUUID), amount);
                        sender.sendMessage("§aDodano " + amount + " czarnej materii dla " + args[0]);
                        if (target != null) {
                            target.sendMessage("§aOtrzymałeś " + amount + " czarnej materii!");
                        }
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cIlość musi być liczbą!");
                    }
                } else {
                    sender.sendMessage("§cNie znaleziono gracza!");
                }
                return true;
            }

            return true;
        }

        // Rebirth command
        if (cmdName.equals("rebirth")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            String uuid = player.getUniqueId().toString();
            int healthLevel = plugin.getConfig().getInt("players." + uuid + ".healthLevel", 0);

            if (healthLevel == 5) {
                plugin.getConfig().set("players." + uuid + ".healthLevel", 0);
                plugin.getEconomyService().addBlackMatter(player.getUniqueId(), 20);
                plugin.saveConfig();

                player.setMaxHealth(20);
                player.setHealth(20);
                player.sendMessage(
                        "§aPrzeszedłeś rebirth! Straciłeś ulepszone serca, ale zdobyłeś 20 czarnej materii.");
            } else {
                player.sendMessage("§cMusisz mieć maksymalne ulepszenie serc (poziom 5)!");
            }
            return true;
        }

        // Clan commands
        if (cmdName.equals("klan")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length == 0)
                return false;
            switch (args[0].toLowerCase()) {
                case "stworz":
                    if (args.length == 2) {
                        if (plugin.getClanManager().isInClan(player.getName())) {
                            player.sendMessage("§cJuż jesteś w klanie! Użyj /klan opusc aby go opuścić.");
                            return true;
                        }
                        plugin.getClanManager().createClan(player.getName(), args[1]);
                        player.sendMessage("§aStworzono klan " + args[1]);
                    }
                    break;
                case "dodaj":
                    if (args.length == 2) {
                        if (!plugin.getClanManager().isInClan(player.getName())) {
                            player.sendMessage("§cNie jesteś w żadnym klanie!");
                            return true;
                        }
                        plugin.getClanManager().invitePlayer(player.getName(), args[1]);
                    }
                    break;
                case "przyjmij":
                    plugin.getClanManager().acceptInvite(player.getName());
                    break;
                case "opusc":
                    plugin.getClanManager().leaveClan(player.getName());
                    break;
                default:
                    player.sendMessage("§cUżycie: /klan [stworz|dodaj|przyjmij|opusc] [argumenty]");
                    break;
            }
            return true;
        }

        // Market
        if (cmdName.equals("rynek")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            marketManager.openMarketGUI(player);
            return true;
        }

        if (cmdName.equals("wystaw")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /wystaw <cena>");
                return true;
            }
            try {
                double price = Double.parseDouble(args[0]);
                if (price <= 0) {
                    player.sendMessage("§cCena musi być większa od 0!");
                    return true;
                }
                ItemStack item = player.getInventory().getItemInMainHand();
                if (item == null || item.getType() == Material.AIR) {
                    player.sendMessage("§cMusisz trzymać przedmiot w ręce!");
                    return true;
                }
                ItemStack itemToSell = item.clone();
                itemToSell.setAmount(1);
                marketManager.addItemToMarket(player, itemToSell, price);
                if (item.getAmount() > 1) {
                    item.setAmount(item.getAmount() - 1);
                } else {
                    player.getInventory().setItemInMainHand(null);
                }
                player.sendMessage("§aWystawiono przedmiot na rynek za " + price + " hajsu!");
            } catch (NumberFormatException e) {
                player.sendMessage("§cCena musi być liczbą!");
            }
            return true;
        }

        // Shop
        if (cmdName.equals("sklep")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            shopManager.openShopGUI(player);
            return true;
        }

        // Home
        if (cmdName.equals("sethome")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /sethome <nazwa>");
                return true;
            }
            homeManager.setHome(player, args[0]);
            return true;
        }

        if (cmdName.equals("usunhome")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                player.sendMessage("§cUżycie: /usunhome <nazwa>");
                return true;
            }
            homeManager.removeHome(player, args[0]);
            return true;
        }

        if (cmdName.equals("home")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length != 1) {
                String homes = homeManager.getHomesString(player.getUniqueId().toString());
                player.sendMessage("§eTwoje domy: " + homes);
                player.sendMessage("§eUżycie: /home <nazwa>");
                return true;
            }
            homeManager.teleportToHome(player, args[0]);
            return true;
        }

        // Upgrade GUI
        if (cmdName.equals("ulepsz")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            plugin.getUpgradeGUI().openGUI(player);
            return true;
        }

        // How to play
        if (cmdName.equals("jakgrac")) {
            sender.sendMessage("§5§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sender.sendMessage("§5§l    JAK GRAĆ W SOULCRAFT RPG?");
            sender.sendMessage("§5§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sender.sendMessage("");
            sender.sendMessage("§6§l⚔ DUSZE - GŁÓWNA WALUTA:");
            sender.sendMessage("  §e• §7Zabijaj graczy aby kraść ich dusze (5% dusz)");
            sender.sendMessage("  §e• §7Zabijaj specjalne zombie za 5 dusz");
            sender.sendMessage("  §e• §7Znajdź kryształy dusz na mapie (losowe eventy!)");
            sender.sendMessage("  §e• §7Ukończ misje i dungeony za masę dusz");
            sender.sendMessage("");
            sender.sendMessage("§b§l✨ PROGRESJA POSTACI:");
            sender.sendMessage("  §3• §7Level 1-100: Zdobywaj XP z mobów i questów");
            sender.sendMessage("  §3• §7Rebirth: Na max poziomie użyj §e/rebirth");
            sender.sendMessage("  §3• §7Każdy rebirth: +5% HP, +3% DMG, +2% SPD");
            sender.sendMessage("  §3• §7Odblokowuj zdolności: §e/abilities");
            sender.sendMessage("");
            sender.sendMessage("§d§l🐺 SYSTEMY RPG:");
            sender.sendMessage("  §d1. §5Pety §7(1-100 lvl): §e/pet spawn <typ>");
            sender.sendMessage("  §d2. §5Abilities §7(12 typów): §e/abilities");
            sender.sendMessage("  §d3. §5Misje §7(26 typów): §e/missions");
            sender.sendMessage("  §d4. §5Dungeony §7(procedural): §e/dungeon");
            sender.sendMessage("  §d5. §5Bossowie §7(5 epickich): Znajdź na mapie");
            sender.sendMessage("  §d6. §5Custom Itemy §7(50+ items): Drop z bossów");
            sender.sendMessage("");
            sender.sendMessage("§a§l💰 EKONOMIA:");
            sender.sendMessage("  §a• §7Ulepsz miecz/zbroję: §e/ulepsz §7(z duszami)");
            sender.sendMessage("  §a• §7Handluj z graczami: §e/rynek §7+ §e/wystaw <cena>");
            sender.sendMessage("  §a• §7Kup w sklepie: §e/sklep");
            sender.sendMessage("");
            sender.sendMessage("§c§l⚔ KLANY & PVP:");
            sender.sendMessage("  §c• §7Stwórz klan: §e/klan stworz <nazwa>");
            sender.sendMessage("  §c• §7Zapros graczy: §e/klan dodaj <nick>");
            sender.sendMessage("  §c• §7Wars & Territory: Walcz o dominację!");
            sender.sendMessage("");
            sender.sendMessage("§e§l🎯 TIPS PRO:");
            sender.sendMessage("  §e⚡ §7Pety dają bonus XP przy wysokiej szczęśliwości");
            sender.sendMessage("  §e⚡ §7Zbieraj daily misje co 24h za nagrody");
            sender.sendMessage("  §e⚡ §7Używaj kryształów dusz strategicznie");
            sender.sendMessage("  §e⚡ §7Eksploruj dungeony w grupach dla lepszych dropów");
            sender.sendMessage("");
            sender.sendMessage("§7§oWięcej komend: §e/help §7§o| Misje: §e/missions");
            sender.sendMessage("§5§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            return true;
        }

        // Kits
        if (cmdName.equals("kit")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cTa komenda jest tylko dla graczy!");
                return true;
            }
            Player player = (Player) sender;
            plugin.getKitManager().openKitGUI(player);
            return true;
        }

        // Help
        if (cmdName.equals("help")) {
            sender.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sender.sendMessage("§6§l         SOULCRAFT RPG - KOMENDY");
            sender.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sender.sendMessage("");
            sender.sendMessage("§e§l▸ SYSTEMY GŁÓWNE:");
            sender.sendMessage("  §e/missions §7- Otwiera menu misji i questów");
            sender.sendMessage("  §e/abilities §7- Sklep i zarządzanie zdolnościami");
            sender.sendMessage("  §e/pet [spawn|level|shop] §7- System petów (1-100 poziomów)");
            sender.sendMessage("  §e/dungeon [nazwa] §7- Lista dungeonów i teleportacja");
            sender.sendMessage("  §e/rebirth §7- Przechodzi rebirth (+5% HP, +3% DMG, +2% SPD)");
            sender.sendMessage("");
            sender.sendMessage("§b§l▸ KLANY & PVP:");
            sender.sendMessage("  §b/klan stworz <nazwa> §7- Tworzy nowy klan");
            sender.sendMessage("  §b/klan dodaj <nick> §7- Zaprasza gracza do klanu");
            sender.sendMessage("  §b/klan przyjmij §7- Akceptuje zaproszenie");
            sender.sendMessage("  §b/klan opusc §7- Opuszcza aktualny klan");
            sender.sendMessage("");
            sender.sendMessage("§a§l▸ EKONOMIA & HANDEL:");
            sender.sendMessage("  §a/rynek §7- Przeglądaj oferty innych graczy");
            sender.sendMessage("  §a/wystaw <cena> §7- Wystaw przedmiot na rynek");
            sender.sendMessage("  §a/sklep §7- Sklep serwerowy (kupuj/sprzedawaj)");
            sender.sendMessage("");
            sender.sendMessage("§d§l▸ TELEPORTACJA:");
            sender.sendMessage("  §d/spawn §7- Teleportacja do spawnu");
            sender.sendMessage("  §d/warp §7- Menu warpów (stałe punkty)");
            sender.sendMessage("  §d/sethome <nazwa> §7- Ustawia prywatny punkt");
            sender.sendMessage("  §d/home <nazwa> §7- Teleportacja do domu");
            sender.sendMessage("  §d/usunhome <nazwa> §7- Usuwa dom");
            sender.sendMessage("");
            sender.sendMessage("§c§l▸ CUSTOM SYSTEMY:");
            sender.sendMessage("  §c/ulepsz §7- Ulepsz miecz/zbroję (dusze)");
            sender.sendMessage("  §c/kit §7- Menu kitów dla rang");
            sender.sendMessage("  §c/feature <toggle|enable|disable> <id> §7- Funkcje gameplay");
            sender.sendMessage("");
            sender.sendMessage("§5§l▸ ADMIN (tylko OP):");
            sender.sendMessage("  §5/zombie §7- Wywołaj specjalnego zombie");
            sender.sendMessage("  §5/event §7- Wywołaj event kryształu dusz");
            sender.sendMessage("  §5/spawnboss <boss_id> §7- Przywołaj bossa");
            sender.sendMessage("  §5/giveitem <gracz> <item_id> §7- Daj custom item");
            sender.sendMessage("  §5/spawnnpc [typ] §7- Przywołaj NPC");
            sender.sendMessage("");
            sender.sendMessage("§7§oWięcej info: §e/jakgrac §7§o| Tutorial: §e/tutorial");
            sender.sendMessage("§6§l§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            return true;
        }

        return false;
    }

    public ItemStack createSoulCrystal(int level) {
        ItemStack crystal = new ItemStack(Material.EMERALD);
        ItemMeta meta = crystal.getItemMeta();
        if (meta != null) {
            String name = "Kryształ Dusz (Lvl " + level + ")";
            meta.setDisplayName("§b" + name);
            meta.setLore(java.util.Arrays.asList("Dodaje " + (level * 10) + " dusz",
                    "Kliknij prawym przyciskiem myszy trzymając przedmiot"));
            crystal.setItemMeta(meta);
        }
        return crystal;
    }
}
